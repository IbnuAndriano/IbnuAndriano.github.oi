﻿<?php
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}
mysqli_report(MYSQLI_REPORT_OFF);
$koneksi = @mysqli_connect("localhost", "root", "", "db_portofolio");

if (!function_exists('get_settings')) {
    function get_settings($conn = null) {
        return [
            'nama'   => 'Ibnu Andriano',
            'kampus' => 'Universitas Bina Bangsa',
            'prodi'  => 'S1 Sistem Informasi'
        ];
    }
}
?>
