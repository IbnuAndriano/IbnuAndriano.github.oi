﻿# SIPANDU SDGs Goal 1: Tanpa Kemiskinan — Kabupaten Tangerang 2026

Aplikasi Sistem Informasi Penanggulangan Kemiskinan Terpadu (10 Modul) berbasis data resmi BPS Kabupaten Tangerang 2026 (265,90 ribu jiwa / 6,42%), Portal Open Data Kabupaten Tangerang, dan Dashboard DTSEN 2026 (Kemenko PM).

## Cara Menjalankan di Localhost (XAMPP)
1. Ekstrak folder ini ke `C:\xampp\htdocs\sdgs-tangerang\`
2. Nyalakan modul **Apache** di XAMPP Control Panel (MySQL bersifat opsional karena sistem sudah dilengkapi Hybrid Local Storage otomatis di `uploads/sdgs_local_db.json`).
3. Buka di browser: `http://localhost/sdgs-tangerang/` atau `http://localhost/sdgs-tangerang/sdgs-demo.php`

## Kredensial Login Admin SDGs
- **Username:** `admin`
- **Password:** `Ibnu@2026!`

## 10 Modul Tersedia
1. Pendataan Masyarakat Miskin (DTSEN Desil 1-3 & Sensor NIK Publik)
2. Penyaluran Bantuan Sosial (PKH, BPNT, BLT-DD, PBI-JK, PIP + Cetak Nota)
3. Program Pemberdayaan UMKM Binaan
4. Bursa Lowongan Kerja & Upload CV
5. Pelatihan Keterampilan & Cetak Sertifikat Resmi
6. Donasi & Crowdfunding Sosial (Simulasi Payment Gateway QRIS / VA / E-Wallet)
7. Monitoring SDGs & Grafik Resmi BPS Kabupaten Tangerang 2020-2026
8. Pengaduan Masyarakat & Lacak Nomor Tiket 4 Tahap
9. Pemetaan Spasial Wilayah Interaktif Leaflet.js (29 Kecamatan Kab. Tangerang)
10. Admin Control Center (Visibilitas Modul, Export CSV Excel & Cetak Laporan PDF A4)

Author: Ibnu Andriano — S1 Sistem Informasi, Universitas Bina Bangsa
