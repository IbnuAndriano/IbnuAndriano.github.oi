<?php
require_once __DIR__ . '/includes/header.php';

$cart = $_SESSION['cart'] ?? [];
$total_harga = 0;
foreach ($cart as $item) {
    $total_harga += ($item['harga'] * $item['jumlah']);
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Header Navigasi Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-muted">Beranda</a></li>
                    <li class="breadcrumb-item active text-dark fw-bold" aria-current="page">Checkout Pesanan</li>
                </ol>
            </nav>

            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h2 class="fw-bold text-dark mb-1"><i class="bi bi-bag-check-fill text-warning me-2"></i> Konfirmasi & Pembayaran</h2>
                    <p class="text-muted mb-0">Lengkapi data pemesan dan pilih metode pembayaran Anda.</p>
                </div>
                <a href="index.php#menu-section" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-arrow-left me-1"></i> Tambah Menu Lain
                </a>
            </div>

            <?php if (empty($cart)): ?>
                <div class="card border-0 shadow-sm p-5 text-center rounded-4">
                    <span class="fs-1 d-block mb-3">🍲</span>
                    <h4 class="fw-bold text-dark">Keranjang Belanja Anda Kosong</h4>
                    <p class="text-muted mb-4">Anda belum memilih menu Soto Lamongan atau hidangan lainnya.</p>
                    <div>
                        <a href="index.php#menu-section" class="btn btn-primary-cakjoyo px-4 py-2">
                            <i class="bi bi-book me-2"></i> Buka Daftar Menu
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <form action="simpan_pesanan.php" method="POST" enctype="multipart/form-data" id="checkoutForm">
                    <div class="row g-4">
                        <!-- KOLOM KIRI: Form Data Pemesan & Pengantaran -->
                        <div class="col-lg-7">
                            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                                <h5 class="fw-bold text-dark mb-3">
                                    <i class="bi bi-person-fill text-warning me-2"></i> 1. Informasi Pemesan
                                </h5>

                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
                                    <input type="text" name="nama" class="form-control" placeholder="Contoh: Budi Santoso" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nomor WhatsApp / HP <span class="text-danger">*</span></label>
                                    <input type="tel" name="hp" class="form-control" placeholder="Contoh: 081234567890" required>
                                    <div class="form-text text-muted">Untuk konfirmasi pesanan dan update status.</div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Tipe Pesanan <span class="text-danger">*</span></label>
                                    <div class="row g-2">
                                        <div class="col-4">
                                            <input type="radio" class="btn-check" name="tipe_pesanan" id="tipe_dine_in" value="dine_in" checked>
                                            <label class="btn btn-outline-warning w-100 text-dark fw-bold py-2" for="tipe_dine_in">
                                                🍽️ Makan Sini
                                            </label>
                                        </div>
                                        <div class="col-4">
                                            <input type="radio" class="btn-check" name="tipe_pesanan" id="tipe_take_away" value="take_away">
                                            <label class="btn btn-outline-warning w-100 text-dark fw-bold py-2" for="tipe_take_away">
                                                🥡 Bungkus
                                            </label>
                                        </div>
                                        <div class="col-4">
                                            <input type="radio" class="btn-check" name="tipe_pesanan" id="tipe_delivery" value="delivery">
                                            <label class="btn btn-outline-warning w-100 text-dark fw-bold py-2" for="tipe_delivery">
                                                🛵 Antar
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <!-- Input Nomor Meja (Khusus Dine-In) -->
                                <div class="mb-3" id="wrapNomorMeja">
                                    <label class="form-label fw-semibold">Nomor Meja <span class="text-danger">*</span></label>
                                    <input type="text" name="nomor_meja" id="inputMeja" class="form-control" placeholder="Contoh: Meja 05" required>
                                    <div class="form-text text-muted">Lihat stiker nomor di meja tempat Anda duduk.</div>
                                </div>

                                <!-- Input Alamat (Khusus Delivery) -->
                                <div class="mb-3 d-none" id="wrapAlamat">
                                    <label class="form-label fw-semibold">Alamat Lengkap Pengantaran <span class="text-danger">*</span></label>
                                    <textarea name="alamat_pengiriman" id="inputAlamat" class="form-control" rows="3" placeholder="Masukkan alamat lengkap, patokan, nomor rumah/kantor..."></textarea>
                                </div>

                                <div class="mb-2">
                                    <label class="form-label fw-semibold">Catatan Khusus (Opsional)</label>
                                    <textarea name="catatan" class="form-control" rows="2" placeholder="Contoh: Koyanya banyakin ya cak, kuah tanpa seledri..."></textarea>
                                </div>
                            </div>

                            <!-- Form Metode Pembayaran -->
                            <div class="card border-0 shadow-sm p-4 rounded-4">
                                <h5 class="fw-bold text-dark mb-3">
                                    <i class="bi bi-wallet2 text-warning me-2"></i> 2. Metode Pembayaran
                                </h5>

                                <div class="list-group mb-3">
                                    <!-- Opsi 1: Tunai / Kasir -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="cash" checked onchange="togglePaymentInfo('cash')">
                                        <div class="w-100">
                                            <h6 class="mb-0 fw-bold"><i class="bi bi-cash-stack text-success me-2"></i> Bayar Tunai / di Kasir (COD)</h6>
                                            <small class="text-muted">Bayar langsung saat makanan dihidangkan atau di kasir.</small>
                                        </div>
                                    </label>

                                    <!-- Opsi 2: QRIS -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="qris" onchange="togglePaymentInfo('qris')">
                                        <div class="w-100">
                                            <h6 class="mb-0 fw-bold"><i class="bi bi-qr-code text-danger me-2"></i> QRIS (Semua Bank / E-Wallet)</h6>
                                            <small class="text-muted">BCA, Mandiri, BRI, GoPay, OVO, DANA, ShopeePay, dll.</small>
                                        </div>
                                    </label>

                                    <!-- Opsi 3: Transfer Bank -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="transfer" onchange="togglePaymentInfo('transfer')">
                                        <div class="w-100">
                                            <h6 class="mb-0 fw-bold"><i class="bi bi-bank text-primary me-2"></i> Transfer Rekening Bank</h6>
                                            <small class="text-muted">Transfer manual ke rekening resmi Cak Joyo.</small>
                                        </div>
                                    </label>

                                    <!-- Opsi 4: E-Wallet -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="ewallet" onchange="togglePaymentInfo('ewallet')">
                                        <div class="w-100">
                                            <h6 class="mb-0 fw-bold"><i class="bi bi-phone text-info me-2"></i> E-Wallet (GoPay, OVO, DANA, ShopeePay, LinkAja)</h6>
                                            <small class="text-muted">Transfer melalui aplikasi dompet digital Anda.</small>
                                        </div>
                                    </label>
                                </div>

                                <!-- Box Detail QRIS -->
                                <div id="boxQRIS" class="p-3 bg-light rounded-3 border mb-3 d-none">
                                    <div class="text-center">
                                        <h6 class="fw-bold text-dark mb-1">Pindai QRIS Cak Joyo</h6>
                                        <p class="small text-muted mb-2">NMID: <?= htmlspecialchars($resto['qris_nmid']); ?></p>
                                        <img src="uploads/qris/<?= htmlspecialchars($resto['qris_image']); ?>" alt="QRIS Cak Joyo" class="img-fluid rounded border shadow-sm mb-2" style="max-width: 230px;" onerror="this.src='uploads/qris/qris_sample.png'">
                                        <p class="small text-muted mb-0">Buka aplikasi m-Banking atau E-Wallet Anda, lalu scan kode di atas.</p>
                                    </div>
                                    <div class="mt-3">
                                        <label class="form-label small fw-bold">Unggah Bukti Pembayaran QRIS (Opsional / Dianjurkan):</label>
                                        <input type="file" name="bukti" class="form-control form-control-sm" accept="image/*">
                                    </div>
                                </div>

                                <!-- Box Detail Transfer Bank -->
                                <div id="boxTransfer" class="p-3 bg-light rounded-3 border mb-3 d-none">
                                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-info-circle me-1"></i> Rekening Tujuan:</h6>
                                    <div class="p-2 bg-white rounded border small mb-3">
                                        <?= nl2br(htmlspecialchars($resto['rekening_bank'])); ?>
                                    </div>
                                    <div class="mt-2">
                                        <label class="form-label small fw-bold">Unggah Bukti Transfer:</label>
                                        <input type="file" name="bukti" class="form-control form-control-sm" accept="image/*">
                                    </div>
                                </div>

                                <!-- Box Detail E-Wallet -->
                                <div id="boxEwallet" class="p-3 bg-light rounded-3 border mb-3 d-none">
                                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-phone text-info me-1"></i> Transfer via E-Wallet:</h6>
                                    <div class="d-flex flex-wrap gap-2 mb-3">
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2 rounded-pill fw-bold">
                                            <i class="bi bi-wallet2 me-1"></i> GoPay
                                        </span>
                                        <span class="badge bg-primary bg-opacity-10 text-primary border border-primary px-3 py-2 rounded-pill fw-bold">
                                            <i class="bi bi-wallet2 me-1"></i> OVO
                                        </span>
                                        <span class="badge bg-info bg-opacity-10 text-info border border-info px-3 py-2 rounded-pill fw-bold">
                                            <i class="bi bi-wallet2 me-1"></i> DANA
                                        </span>
                                        <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-3 py-2 rounded-pill fw-bold">
                                            <i class="bi bi-wallet2 me-1"></i> ShopeePay
                                        </span>
                                        <span class="badge bg-warning bg-opacity-10 text-dark border border-warning px-3 py-2 rounded-pill fw-bold">
                                            <i class="bi bi-wallet2 me-1"></i> LinkAja
                                        </span>
                                    </div>
                                    <div class="p-2 bg-white rounded border small mb-3">
                                        <strong class="d-block mb-1">📱 Nomor Akun E-Wallet Cak Joyo:</strong>
                                        <?= nl2br(htmlspecialchars($resto['ewallet_info'] ?? 'Hubungi WA untuk info akun e-wallet.')); ?>
                                    </div>
                                    <div class="alert alert-info small py-2 px-3 mb-3">
                                        <i class="bi bi-info-circle me-1"></i> Buka aplikasi e-wallet Anda, pilih <strong>"Transfer"</strong>, masukkan nomor tujuan, lalu kirim sesuai total tagihan.
                                    </div>
                                    <div class="mt-2">
                                        <label class="form-label small fw-bold">Unggah Bukti Pembayaran E-Wallet:</label>
                                        <input type="file" name="bukti" class="form-control form-control-sm" accept="image/*">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- KOLOM KANAN: Ringkasan Pesanan & Tombol Kirim -->
                        <div class="col-lg-5">
                            <div class="card border-0 shadow-sm p-4 rounded-4 sticky-top" style="top: 90px;">
                                <h5 class="fw-bold text-dark mb-3">
                                    <i class="bi bi-receipt text-warning me-2"></i> Ringkasan Pesanan
                                </h5>

                                <div class="table-responsive mb-3">
                                    <table class="table table-borderless align-middle mb-0">
                                        <tbody class="border-top">
                                            <?php foreach ($cart as $key => $item): 
                                                $subtotal = $item['harga'] * $item['jumlah'];
                                            ?>
                                                <tr class="border-bottom">
                                                    <td class="ps-0">
                                                        <div class="fw-bold text-dark"><?= htmlspecialchars($item['nama']); ?></div>
                                                        <div class="small text-muted"><?= $item['jumlah']; ?> x <?= format_rupiah($item['harga']); ?></div>
                                                        <?php if (!empty($item['catatan'])): ?>
                                                            <small class="text-warning fst-italic">"<?= htmlspecialchars($item['catatan']); ?>"</small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-end fw-bold pe-0">
                                                        <?= format_rupiah($subtotal); ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">Total Tagihan:</span>
                                    <span class="fs-4 fw-bold text-warning"><?= format_rupiah($total_harga); ?></span>
                                </div>

                                <hr class="my-3">

                                <button type="submit" class="btn btn-primary-cakjoyo w-100 py-3 fw-bold fs-6 rounded-3 shadow">
                                    <i class="bi bi-check-circle-fill me-2"></i> Proses Pesanan Sekarang
                                </button>

                                <div class="text-center mt-3">
                                    <small class="text-muted d-block">
                                        <i class="bi bi-lock-fill text-success"></i> Transaksi Anda Dijamin Aman & Cepat
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Handle perubahan tipe pesanan (Dine-in vs Delivery vs Takeaway)
document.querySelectorAll('input[name="tipe_pesanan"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const val = this.value;
        const wrapMeja = document.getElementById('wrapNomorMeja');
        const inputMeja = document.getElementById('inputMeja');
        const wrapAlamat = document.getElementById('wrapAlamat');
        const inputAlamat = document.getElementById('inputAlamat');

        if (val === 'dine_in') {
            wrapMeja.classList.remove('d-none');
            inputMeja.required = true;
            wrapAlamat.classList.add('d-none');
            inputAlamat.required = false;
        } else if (val === 'delivery') {
            wrapMeja.classList.add('d-none');
            inputMeja.required = false;
            wrapAlamat.classList.remove('d-none');
            inputAlamat.required = true;
        } else {
            // Take Away
            wrapMeja.classList.add('d-none');
            inputMeja.required = false;
            wrapAlamat.classList.add('d-none');
            inputAlamat.required = false;
        }
    });
});

// Handle perubahan metode pembayaran (QRIS, Transfer, Cash, E-Wallet)
function togglePaymentInfo(metode) {
    const boxQRIS = document.getElementById('boxQRIS');
    const boxTransfer = document.getElementById('boxTransfer');
    const boxEwallet = document.getElementById('boxEwallet');

    boxQRIS.classList.add('d-none');
    boxTransfer.classList.add('d-none');
    boxEwallet.classList.add('d-none');

    if (metode === 'qris') {
        boxQRIS.classList.remove('d-none');
    } else if (metode === 'transfer') {
        boxTransfer.classList.remove('d-none');
    } else if (metode === 'ewallet') {
        boxEwallet.classList.remove('d-none');
    }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
