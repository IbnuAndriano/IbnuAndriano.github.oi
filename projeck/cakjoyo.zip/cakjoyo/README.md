# 🍲 Soto Ayam Lamongan Cak Joyo (PHP Native & Localhost)

Aplikasi website pemesanan dan penjualan online resmi untuk **Soto Ayam Lamongan Cak Joyo**, dibuat menggunakan **PHP Native** dan database **MySQL** yang berjalan di localhost XAMPP sesuai dengan dokumen spesifikasi usaha.

---

## 📋 Informasi Profil Usaha (Sesuai Dokumen)

* **Nama Usaha:** Soto ayam lamongan cak joyo
* **Owner:** Pak cak joyo
* **Jam Operasional:** Buka 06.00 - 17.00 WIB
* **Layanan:** Menerima Pesanan (Makan di Tempat / Bungkus / Katering)
* **No. HP / WhatsApp:** 0812-9254-3664

---

## 🍽️ Daftar Menu & Harga Resmi

### 1. Daftar Menu Utama
| Nama Menu | Harga |
| :--- | :--- |
| Soto ayam | Rp 11.000 |
| Soto daging | Rp 16.000 |
| Soto babat | Rp 16.000 |
| Soto kikil | Rp 20.000 |
| Rabeg | Rp 16.000 |
| Rawon | Rp 16.000 |
| Nasi | Rp 5.000 |

### 2. Menu Special
| Nama Menu | Harga |
| :--- | :--- |
| Soto ayam + daging | Rp 23.000 |
| Soto ayam + babat | Rp 23.000 |
| Soto ayam + kikil | Rp 26.000 |
| Soto daging + kikil | Rp 30.000 |
| Soto ayam + daging + babat | Rp 28.000 |
| Soto daging + kikil + babat | Rp 35.000 |
| Soto ayam + daging + babat + kikil | Rp 40.000 |

### 3. Toping
| Nama Toping | Harga |
| :--- | :--- |
| Dada | Rp 50.000 |
| Paha | Rp 25.000 |
| Sayap | Rp 5.000 |
| Punggung | Rp 5.000 |
| Ceker | Rp 1.000 |

### 4. Minuman
| Nama Minuman | Harga |
| :--- | :--- |
| Es jeruk | Rp 2.000 |
| Es jeruk nipis | Rp 2.000 |
| Es teh manis | Rp 3.000 |
| Es teh tawar | Rp 1.000 |
| Es teh botol | Rp 6.000 |
| Air mineral | Rp 4.000 |

---

## 🚀 Panduan Menjalankan di Localhost (XAMPP)

### 1. Pastikan XAMPP Aktif
Buka **XAMPP Control Panel**, lalu pastikan modul **Apache** dan **MySQL** dalam status **Running**.

### 2. Inisialisasi / Reset Database
Buka browser dan akses URL instalasi otomatis:
> **[http://localhost/cakjoyo/setup_db.php](http://localhost/cakjoyo/setup_db.php)**

Skrip ini akan menyinkronkan seluruh tabel dan data menu persis seperti pada dokumen di atas ke database `db_cakjoyo`.

---

## 🌐 Tautan Akses Website

- **Website Pembeli:** [http://localhost/cakjoyo/](http://localhost/cakjoyo/)
- **Cek Status Pesanan:** [http://localhost/cakjoyo/lacak.php](http://localhost/cakjoyo/lacak.php)
- **Panel Admin / Kasir:** [http://localhost/cakjoyo/admin/login.php](http://localhost/cakjoyo/admin/login.php)
  - **Username:** `admin`
  - **Password:** `admin123` *(atau `admin`)*
