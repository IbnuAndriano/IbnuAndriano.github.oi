<?php
require_once __DIR__ . '/header.php';

$success = '';
$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (isset($_POST['simpan_profil'])) {
        $nama_resto   = clean($koneksi, $_POST['nama_resto']);
        $slogan       = clean($koneksi, $_POST['slogan']);
        $no_wa        = clean($koneksi, $_POST['no_wa']);
        $alamat       = clean($koneksi, $_POST['alamat']);
        $jam_buka     = clean($koneksi, $_POST['jam_buka']);
        $qris_nmid    = clean($koneksi, $_POST['qris_nmid']);
        $rekening     = clean($koneksi, $_POST['rekening_bank']);
        $ewallet      = clean($koneksi, $_POST['ewallet_info'] ?? '');

        $qris_file = $resto['qris_image'];

        // Cek jika ada upload QRIS baru
        if (isset($_FILES['qris_image']) && $_FILES['qris_image']['error'] === UPLOAD_ERR_OK) {
            $tmpName  = $_FILES['qris_image']['tmp_name'];
            $fileName = $_FILES['qris_image']['name'];
            $ext      = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowed  = ['jpg', 'jpeg', 'png', 'webp', 'svg'];

            if (in_array($ext, $allowed)) {
                $newQris = "qris_" . time() . "." . $ext;
                $destDir = __DIR__ . '/../uploads/qris';
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0777, true);
                }
                if (move_uploaded_file($tmpName, "$destDir/$newQris")) {
                    $qris_file = $newQris;
                }
            } else {
                $error = "Format file QRIS tidak valid. Gunakan format JPG, PNG, atau WEBP.";
            }
        }

        if (empty($error)) {
            $sqlUpdate = "UPDATE pengaturan SET 
                            nama_resto = '$nama_resto',
                            slogan = '$slogan',
                            no_wa = '$no_wa',
                            alamat = '$alamat',
                            jam_buka = '$jam_buka',
                            qris_nmid = '$qris_nmid',
                            qris_image = '$qris_file',
                            rekening_bank = '$rekening',
                            ewallet_info = '$ewallet'
                          WHERE id = 1";
            if (mysqli_query($koneksi, $sqlUpdate)) {
                $success = "Pengaturan warung berhasil disimpan!";
                // Refresh data resto
                $resto = get_pengaturan($koneksi);
            } else {
                $error = "Gagal memperbarui pengaturan: " . mysqli_error($koneksi);
            }
        }
    }

    // Ubah Password Admin
    if (isset($_POST['ubah_password'])) {
        $passLama = $_POST['pass_lama'] ?? '';
        $passBaru = $_POST['pass_baru'] ?? '';
        $passKonf = $_POST['pass_konf'] ?? '';

        $adminId = $_SESSION['admin_id'];
        $qAdmin = mysqli_query($koneksi, "SELECT password FROM admin WHERE id = $adminId LIMIT 1");
        $adminData = mysqli_fetch_assoc($qAdmin);

        if (!password_verify($passLama, $adminData['password']) && $passLama !== $adminData['password']) {
            $error = "Password lama yang Anda masukkan salah!";
        } elseif (strlen($passBaru) < 5) {
            $error = "Password baru minimal 5 karakter!";
        } elseif ($passBaru !== $passKonf) {
            $error = "Konfirmasi password baru tidak cocok!";
        } else {
            $hashBaru = password_hash($passBaru, PASSWORD_DEFAULT);
            mysqli_query($koneksi, "UPDATE admin SET password = '$hashBaru' WHERE id = $adminId");
            $success = "Password admin berhasil diperbarui!";
        }
    }
}
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h4 class="fw-bold text-dark mb-1">Pengaturan Warung & Profil</h4>
        <p class="text-muted small mb-0">Kelola informasi kontak warung, barcode QRIS, rekening bank, dan password admin.</p>
    </div>
</div>

<?php if (!empty($success)): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($success); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- FORM PROFIL WARUNG -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm p-4 rounded-4">
            <h5 class="fw-bold text-dark mb-3"><i class="bi bi-shop text-warning me-2"></i> Informasi Warung Soto</h5>
            <form method="POST" action="pengaturan.php" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nama Usaha / Warung</label>
                        <input type="text" name="nama_resto" class="form-control" value="<?= htmlspecialchars($resto['nama_resto']); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nomor WhatsApp Resmi</label>
                        <input type="text" name="no_wa" class="form-control" value="<?= htmlspecialchars($resto['no_wa']); ?>" required>
                        <div class="form-text text-muted">Contoh: 081292543664 (atau 6281292543664)</div>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Slogan / Tagline Usaha</label>
                        <input type="text" name="slogan" class="form-control" value="<?= htmlspecialchars($resto['slogan']); ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Jam Operasional</label>
                        <input type="text" name="jam_buka" class="form-control" value="<?= htmlspecialchars($resto['jam_buka']); ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Alamat Lengkap Warung</label>
                        <textarea name="alamat" class="form-control" rows="2" required><?= htmlspecialchars($resto['alamat']); ?></textarea>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">NMID QRIS</label>
                        <input type="text" name="qris_nmid" class="form-control" value="<?= htmlspecialchars($resto['qris_nmid']); ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Upload Gambar Barcode QRIS</label>
                        <input type="file" name="qris_image" class="form-control" accept="image/*">
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Informasi Rekening Bank (Transfer)</label>
                        <textarea name="rekening_bank" class="form-control" rows="3" placeholder="Nama Bank: Nomor Rekening a.n Pemilik"><?= htmlspecialchars($resto['rekening_bank']); ?></textarea>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold"><i class="bi bi-phone text-info me-1"></i> Informasi Akun E-Wallet</label>
                        <textarea name="ewallet_info" class="form-control" rows="3" placeholder="GoPay: 08xxxxxxxxxx a.n Nama&#10;OVO: 08xxxxxxxxxx a.n Nama&#10;DANA: 08xxxxxxxxxx a.n Nama"><?= htmlspecialchars($resto['ewallet_info'] ?? ''); ?></textarea>
                        <div class="form-text text-muted">Masukkan info akun e-wallet (GoPay, OVO, DANA, ShopeePay, LinkAja). Satu akun per baris.</div>
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" name="simpan_profil" class="btn btn-warning fw-bold px-4 text-dark">
                        <i class="bi bi-save me-1"></i> Simpan Profil Resto
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- KOLOM KANAN: PREVIEW QRIS & GANTI PASSWORD -->
    <div class="col-lg-4">
        <!-- Preview QRIS -->
        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4 text-center">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-qr-code text-warning me-2"></i> QRIS Toko Saat Ini</h6>
            <img src="../uploads/qris/<?= htmlspecialchars($resto['qris_image']); ?>" alt="QRIS" class="img-fluid rounded border shadow-sm mb-2" style="max-height: 220px;" onerror="this.src='../uploads/qris/qris_sample.png'">
            <small class="text-muted d-block">NMID: <?= htmlspecialchars($resto['qris_nmid']); ?></small>
        </div>

        <!-- Form Ubah Password Admin -->
        <div class="card border-0 shadow-sm p-4 rounded-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-shield-lock text-warning me-2"></i> Ganti Password Admin</h6>
            <form method="POST" action="pengaturan.php">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Password Saat Ini</label>
                    <input type="password" name="pass_lama" class="form-control form-control-sm" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Password Baru</label>
                    <input type="password" name="pass_baru" class="form-control form-control-sm" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Konfirmasi Password Baru</label>
                    <input type="password" name="pass_konf" class="form-control form-control-sm" required>
                </div>
                <button type="submit" name="ubah_password" class="btn btn-outline-dark btn-sm w-100 fw-bold">
                    <i class="bi bi-key-fill me-1"></i> Update Password
                </button>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
