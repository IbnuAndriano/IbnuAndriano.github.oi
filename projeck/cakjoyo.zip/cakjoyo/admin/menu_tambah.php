<?php
require_once __DIR__ . '/header.php';

$error = '';
$success = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $nama        = clean($koneksi, $_POST['nama_menu'] ?? '');
    $kategori_id = (int)($_POST['kategori_id'] ?? 1);
    $harga       = (int)($_POST['harga'] ?? 0);
    $deskripsi   = clean($koneksi, $_POST['deskripsi'] ?? '');
    $status      = clean($koneksi, $_POST['status'] ?? 'tersedia');
    $is_favorite = isset($_POST['is_favorite']) ? 1 : 0;

    if (empty($nama) || $harga <= 0) {
        $error = 'Nama menu dan harga harus diisi dengan benar!';
    } else {
        $gambarNama = 'default_soto.jpg';

        // Proses Upload Foto jika ada
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['gambar']['tmp_name'];
            $fileName = $_FILES['gambar']['name'];
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg'];

            if (in_array($ext, $allowed)) {
                $gambarNama = "menu_" . time() . "_" . rand(100, 999) . "." . $ext;
                $destDir = __DIR__ . '/../uploads/menu';
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0777, true);
                }
                move_uploaded_file($tmpName, "$destDir/$gambarNama");
            } else {
                $error = 'Format file gambar tidak didukung! Gunakan JPG, PNG, atau WEBP.';
            }
        }

        if (empty($error)) {
            $sql = "INSERT INTO menu (kategori_id, nama_menu, deskripsi, harga, gambar, status, is_favorite)
                    VALUES ($kategori_id, '$nama', '$deskripsi', $harga, '$gambarNama', '$status', $is_favorite)";
            
            if (mysqli_query($koneksi, $sql)) {
                header("Location: menu.php");
                exit;
            } else {
                $error = 'Gagal menyimpan menu: ' . mysqli_error($koneksi);
            }
        }
    }
}

// Ambil kategori untuk pilihan dropdown
$kategoriList = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY urutan ASC");
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <h4 class="fw-bold text-dark mb-1">Tambah Menu Baru</h4>
                <p class="text-muted small mb-0">Tambahkan hidangan soto, lauk pelengkap, atau minuman ke daftar menu warung.</p>
            </div>
            <a href="menu.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke Menu
            </a>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm p-4 rounded-4">
            <form action="menu_tambah.php" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label fw-semibold">Nama Menu <span class="text-danger">*</span></label>
                        <input type="text" name="nama_menu" class="form-control" placeholder="Contoh: Soto Ayam Lamongan Spesial" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                        <select name="kategori_id" class="form-select" required>
                            <?php while($k = mysqli_fetch_assoc($kategoriList)): ?>
                                <option value="<?= $k['id']; ?>"><?= htmlspecialchars($k['nama_kategori']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Harga (Rp) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" name="harga" class="form-control" placeholder="18000" min="0" required>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Status Ketersediaan</label>
                        <select name="status" class="form-select">
                            <option value="tersedia">Tersedia (Ready)</option>
                            <option value="habis">Habis (Sold Out)</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Deskripsi Menu</label>
                        <textarea name="deskripsi" class="form-control" rows="3" placeholder="Jelaskan kelezatan bumbu, isian daging, atau kesegaran minuman..."></textarea>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Foto Menu</label>
                        <input type="file" name="gambar" class="form-control" accept="image/*">
                        <div class="form-text text-muted">Format yang disarankan: JPG, PNG, WEBP. Maksimal 2MB. (Jika dikosongkan akan menggunakan gambar default)</div>
                    </div>

                    <div class="col-12">
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" name="is_favorite" id="is_favorite" value="1">
                            <label class="form-check-label fw-semibold" for="is_favorite">
                                Tandai sebagai <strong>Menu Favorit / Rekomendasi</strong> (Tampil di bagian atas)
                            </label>
                        </div>
                    </div>
                </div>

                <hr class="my-4">

                <div class="d-flex justify-content-end gap-2">
                    <a href="menu.php" class="btn btn-light px-4">Batal</a>
                    <button type="submit" class="btn btn-warning fw-bold px-4 text-dark">
                        <i class="bi bi-save me-1"></i> Simpan Menu
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
