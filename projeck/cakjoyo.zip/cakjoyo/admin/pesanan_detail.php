<?php
require_once __DIR__ . '/header.php';

$id = (int)($_GET['id'] ?? 0);
$queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id = $id LIMIT 1");
$pesanan = mysqli_fetch_assoc($queryPesanan);

if (!$pesanan) {
    header("Location: pesanan.php");
    exit;
}

// Ambil item menu yang dipesan
$queryDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $id");

// Handle update status dari form detail jika dikirim
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['update_status'])) {
    $newStatus = clean($koneksi, $_POST['status']);
    mysqli_query($koneksi, "UPDATE pesanan SET status = '$newStatus' WHERE id = $id");
    header("Location: pesanan_detail.php?id=$id&updated=1");
    exit;
}
?>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1">
                <li class="breadcrumb-item"><a href="pesanan.php" class="text-decoration-none">Pesanan</a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($pesanan['kode_pesanan']); ?></li>
            </ol>
        </nav>
        <h4 class="fw-bold text-dark mb-0">Rincian Pesanan: <?= htmlspecialchars($pesanan['kode_pesanan']); ?></h4>
    </div>
    <div class="d-flex gap-2">
        <a href="cetak_struk.php?id=<?= $pesanan['id']; ?>" target="_blank" class="btn btn-outline-dark btn-sm">
            <i class="bi bi-printer me-1"></i> Cetak Struk Kasir
        </a>
        <a href="<?= whatsapp_link($pesanan['no_hp'], 'Halo ' . $pesanan['nama_pelanggan'] . ', perihal pesanan Anda di Soto Lamongan Cak Joyo (' . $pesanan['kode_pesanan'] . ')...'); ?>" target="_blank" class="btn btn-success btn-sm">
            <i class="bi bi-whatsapp me-1"></i> Hubungi Pemesan
        </a>
    </div>
</div>

<?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> Status pesanan berhasil diperbarui!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- KOLOM KIRI: Tabel Rincian Menu -->
    <div class="col-lg-8">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <h6 class="fw-bold text-dark mb-0"><i class="bi bi-basket-fill text-warning me-2"></i> Item yang Dipesan</h6>
            </div>
            <div class="table-responsive">
                <table class="table table-custom align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Menu</th>
                            <th class="text-end">Harga</th>
                            <th class="text-center">Jumlah</th>
                            <th class="text-end">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($d = mysqli_fetch_assoc($queryDetail)): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($d['nama_menu']); ?></div>
                                    <?php if (!empty($d['catatan_item'])): ?>
                                        <small class="text-warning fst-italic">Catatan: "<?= htmlspecialchars($d['catatan_item']); ?>"</small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end"><?= format_rupiah($d['harga']); ?></td>
                                <td class="text-center fw-bold"><?= $d['jumlah']; ?></td>
                                <td class="text-end fw-bold text-dark"><?= format_rupiah($d['subtotal']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                    <tfoot class="border-top">
                        <tr>
                            <th colspan="3" class="text-end fs-6">TOTAL PEMBAYARAN:</th>
                            <th class="text-end fs-5 text-warning"><?= format_rupiah($pesanan['total_harga']); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <?php if (!empty($pesanan['catatan'])): ?>
            <div class="card border-0 shadow-sm p-3 rounded-4 mb-4 bg-light">
                <h6 class="fw-bold text-dark mb-1"><i class="bi bi-chat-left-dots text-warning me-2"></i> Catatan Khusus dari Pelanggan:</h6>
                <p class="mb-0 text-muted fst-italic">"<?= nl2br(htmlspecialchars($pesanan['catatan'])); ?>"</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- KOLOM KANAN: Informasi Pemesan & Ubah Status -->
    <div class="col-lg-4">
        <!-- Card Update Status -->
        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-sliders text-warning me-2"></i> Kelola Status Pesanan</h6>
            <div class="mb-3">
                <span class="small text-muted d-block mb-1">Status Saat Ini:</span>
                <div><?= status_badge($pesanan['status']); ?></div>
            </div>

            <form method="POST" action="pesanan_detail.php?id=<?= $pesanan['id']; ?>">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Ubah Status Menjadi:</label>
                    <select name="status" class="form-select">
                        <option value="Baru" <?= $pesanan['status'] === 'Baru' ? 'selected' : ''; ?>>🔵 Baru (Menunggu)</option>
                        <option value="Diproses" <?= $pesanan['status'] === 'Diproses' ? 'selected' : ''; ?>>🟠 Diproses (Dimasak di Dapur)</option>
                        <option value="Siap" <?= $pesanan['status'] === 'Siap' ? 'selected' : ''; ?>>🟣 Siap (Disajikan / Diantar)</option>
                        <option value="Selesai" <?= $pesanan['status'] === 'Selesai' ? 'selected' : ''; ?>>🟢 Selesai (Lunas & Diterima)</option>
                        <option value="Dibatalkan" <?= $pesanan['status'] === 'Dibatalkan' ? 'selected' : ''; ?>>🔴 Dibatalkan</option>
                    </select>
                </div>
                <button type="submit" name="update_status" class="btn btn-warning w-100 fw-bold text-dark">
                    <i class="bi bi-check-lg me-1"></i> Simpan Status Baru
                </button>
            </form>
        </div>

        <!-- Card Data Pemesan -->
        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-person-lines-fill text-warning me-2"></i> Data Pelanggan</h6>
            <div class="mb-2">
                <small class="text-muted d-block">Nama Lengkap:</small>
                <strong><?= htmlspecialchars($pesanan['nama_pelanggan']); ?></strong>
            </div>
            <div class="mb-2">
                <small class="text-muted d-block">Nomor Telepon / WA:</small>
                <strong><?= htmlspecialchars($pesanan['no_hp']); ?></strong>
            </div>
            <div class="mb-2">
                <small class="text-muted d-block">Tipe Layanan:</small>
                <strong><?= tipe_pesanan_label($pesanan['tipe_pesanan'], $pesanan['nomor_meja']); ?></strong>
            </div>
            <?php if (!empty($pesanan['alamat_pengiriman'])): ?>
                <div class="mb-2">
                    <small class="text-muted d-block">Alamat Pengiriman:</small>
                    <p class="small text-dark mb-0"><?= nl2br(htmlspecialchars($pesanan['alamat_pengiriman'])); ?></p>
                </div>
            <?php endif; ?>
            <div class="mb-2">
                <small class="text-muted d-block">Metode Pembayaran:</small>
                <strong><?= metode_bayar_label($pesanan['metode_pembayaran']); ?></strong>
            </div>
            <div>
                <small class="text-muted d-block">Waktu Pesan:</small>
                <small class="text-dark"><?= format_tanggal($pesanan['created_at']); ?></small>
            </div>
        </div>

        <!-- Card Bukti Pembayaran -->
        <?php if (!empty($pesanan['bukti_bayar'])): ?>
            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-image text-warning me-2"></i> Bukti Pembayaran</h6>
                <a href="../uploads/bukti/<?= htmlspecialchars($pesanan['bukti_bayar']); ?>" target="_blank">
                    <img src="../uploads/bukti/<?= htmlspecialchars($pesanan['bukti_bayar']); ?>" alt="Bukti Transfer" class="img-fluid rounded border shadow-sm">
                </a>
                <small class="text-muted d-block text-center mt-2">Klik gambar untuk memperbesar</small>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
