<?php
require_once __DIR__ . '/header.php';

$tglMulai   = clean($koneksi, $_GET['tgl_mulai'] ?? date('Y-m-01'));
$tglSelesai = clean($koneksi, $_GET['tgl_selesai'] ?? date('Y-m-d'));
$status     = clean($koneksi, $_GET['status'] ?? '');

$where = ["DATE(created_at) BETWEEN '$tglMulai' AND '$tglSelesai'"];
if (!empty($status)) {
    $where[] = "status = '$status'";
}

$whereSql = "WHERE " . implode(" AND ", $where);

// Ambil data transaksi
$sql = "SELECT * FROM pesanan $whereSql ORDER BY id DESC";
$result = mysqli_query($koneksi, $sql);

// Hitung total omzet dalam periode
$sqlSum = "SELECT SUM(total_harga) as total, COUNT(*) as jml FROM pesanan $whereSql AND status != 'Dibatalkan'";
$qSum = mysqli_query($koneksi, $sqlSum);
$sumData = mysqli_fetch_assoc($qSum);
$totalOmzet = $sumData['total'] ?? 0;
$totalTransaksi = $sumData['jml'] ?? 0;
?>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
        <h4 class="fw-bold text-dark mb-1">Laporan Penjualan & Keuangan</h4>
        <p class="text-muted small mb-0">Rekap transaksi penjualan Soto Lamongan Cak Joyo berdasarkan periode tanggal.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="export.php?tgl_mulai=<?= $tglMulai; ?>&tgl_selesai=<?= $tglSelesai; ?>&status=<?= $status; ?>" class="btn btn-success btn-sm">
            <i class="bi bi-file-earmark-excel me-1"></i> Download File Excel
        </a>
        <button onclick="window.print()" class="btn btn-outline-dark btn-sm">
            <i class="bi bi-printer me-1"></i> Cetak Laporan
        </button>
    </div>
</div>

<!-- FILTER TANGGAL -->
<div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
    <form method="GET" action="laporan.php" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label small fw-semibold">Dari Tanggal</label>
            <input type="date" name="tgl_mulai" class="form-control" value="<?= htmlspecialchars($tglMulai); ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label small fw-semibold">Sampai Tanggal</label>
            <input type="date" name="tgl_selesai" class="form-control" value="<?= htmlspecialchars($tglSelesai); ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label small fw-semibold">Status Pesanan</label>
            <select name="status" class="form-select">
                <option value="">Semua Status</option>
                <option value="Selesai" <?= $status === 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                <option value="Diproses" <?= $status === 'Diproses' ? 'selected' : ''; ?>>Diproses</option>
                <option value="Baru" <?= $status === 'Baru' ? 'selected' : ''; ?>>Baru</option>
                <option value="Dibatalkan" <?= $status === 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
            </select>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-warning w-100 fw-bold text-dark">
                <i class="bi bi-search me-1"></i> Tampilkan
            </button>
            <a href="laporan.php" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>
</div>

<!-- RINGKASAN PERIODE -->
<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm p-4 rounded-4 bg-white border-start border-4 border-success">
            <span class="text-muted small fw-semibold">Total Pendapatan Bersih (Non-Batal)</span>
            <h3 class="fw-bold text-success mt-1 mb-0"><?= format_rupiah($totalOmzet); ?></h3>
            <small class="text-muted">Periode: <?= date('d M Y', strtotime($tglMulai)); ?> s/d <?= date('d M Y', strtotime($tglSelesai)); ?></small>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm p-4 rounded-4 bg-white border-start border-4 border-primary">
            <span class="text-muted small fw-semibold">Total Transaksi Berhasil</span>
            <h3 class="fw-bold text-primary mt-1 mb-0"><?= $totalTransaksi; ?> Pesanan</h3>
            <small class="text-muted">Rata-rata: <?= $totalTransaksi > 0 ? format_rupiah($totalOmzet / $totalTransaksi) : 'Rp 0'; ?> per transaksi</small>
        </div>
    </div>
</div>

<!-- TABEL REKAP TRANSAKSI -->
<div class="admin-card">
    <div class="admin-card-header">
        <h6 class="fw-bold text-dark mb-0">Rincian Transaksi dalam Periode Ini</h6>
    </div>
    <div class="table-responsive">
        <table class="table table-custom table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Pesanan</th>
                    <th>Waktu</th>
                    <th>Pelanggan</th>
                    <th>Layanan</th>
                    <th>Metode</th>
                    <th>Status</th>
                    <th class="text-end">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php 
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($result)): 
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td>
                                <a href="pesanan_detail.php?id=<?= $row['id']; ?>" class="fw-bold text-dark text-decoration-none">
                                    <?= htmlspecialchars($row['kode_pesanan']); ?>
                                </a>
                            </td>
                            <td><small class="text-muted"><?= date('d/m/Y H:i', strtotime($row['created_at'])); ?></small></td>
                            <td>
                                <div class="fw-semibold"><?= htmlspecialchars($row['nama_pelanggan']); ?></div>
                                <small class="text-muted"><?= htmlspecialchars($row['no_hp']); ?></small>
                            </td>
                            <td><small><?= tipe_pesanan_label($row['tipe_pesanan'], $row['nomor_meja']); ?></small></td>
                            <td><span class="badge bg-light text-dark border"><?= metode_bayar_label($row['metode_pembayaran']); ?></span></td>
                            <td><?= status_badge($row['status']); ?></td>
                            <td class="text-end fw-bold"><?= format_rupiah($row['total_harga']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            Tidak ada transaksi pada rentang tanggal ini.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
