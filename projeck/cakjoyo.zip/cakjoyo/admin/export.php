<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$tglMulai   = clean($koneksi, $_GET['tgl_mulai'] ?? date('Y-m-01'));
$tglSelesai = clean($koneksi, $_GET['tgl_selesai'] ?? date('Y-m-d'));
$status     = clean($koneksi, $_GET['status'] ?? '');

$where = ["DATE(created_at) BETWEEN '$tglMulai' AND '$tglSelesai'"];
if (!empty($status)) {
    $where[] = "status = '$status'";
}
$whereSql = "WHERE " . implode(" AND ", $where);

$sql = "SELECT * FROM pesanan $whereSql ORDER BY id DESC";
$result = mysqli_query($koneksi, $sql);

$filename = "Laporan_Penjualan_CakJoyo_" . date('Ymd_His') . ".xls";

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Penjualan Cak Joyo</title>
</head>
<body>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th colspan="9" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #f59e0b; color: #fff;">
                    LAPORAN PENJUALAN SOTO LAMONGAN CAK JOYO
                </th>
            </tr>
            <tr>
                <th colspan="9" style="text-align: center; font-size: 12px;">
                    Periode: <?= $tglMulai; ?> s/d <?= $tglSelesai; ?>
                </th>
            </tr>
            <tr style="background-color: #e2e8f0; font-weight: bold;">
                <th>No</th>
                <th>Kode Pesanan</th>
                <th>Waktu Transaksi</th>
                <th>Nama Pelanggan</th>
                <th>No WhatsApp</th>
                <th>Tipe Layanan</th>
                <th>Metode Pembayaran</th>
                <th>Status</th>
                <th>Total Harga (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            $grandTotal = 0;
            while ($row = mysqli_fetch_assoc($result)): 
                if ($row['status'] !== 'Dibatalkan') {
                    $grandTotal += (int)$row['total_harga'];
                }
            ?>
                <tr>
                    <td align="center"><?= $no++; ?></td>
                    <td>'<?= htmlspecialchars($row['kode_pesanan']); ?></td>
                    <td><?= htmlspecialchars($row['created_at']); ?></td>
                    <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                    <td>'<?= htmlspecialchars($row['no_hp']); ?></td>
                    <td><?= tipe_pesanan_label($row['tipe_pesanan'], $row['nomor_meja']); ?></td>
                    <td><?= metode_bayar_label($row['metode_pembayaran']); ?></td>
                    <td><?= htmlspecialchars($row['status']); ?></td>
                    <td align="right"><?= $row['total_harga']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr style="background-color: #fef3c7; font-weight: bold;">
                <td colspan="8" align="right">TOTAL PENDAPATAN (Non-Batal):</td>
                <td align="right"><?= $grandTotal; ?></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
