<?php
require_once __DIR__ . '/header.php';

// Filter berdasarkan kategori atau pencarian
$katFilter = clean($koneksi, $_GET['kategori'] ?? '');
$search    = clean($koneksi, $_GET['search'] ?? '');

$where = [];
if (!empty($katFilter)) {
    $where[] = "m.kategori_id = '$katFilter'";
}
if (!empty($search)) {
    $where[] = "(m.nama_menu LIKE '%$search%' OR m.deskripsi LIKE '%$search%')";
}

$whereSql = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT m.*, k.nama_kategori 
        FROM menu m 
        LEFT JOIN kategori k ON m.kategori_id = k.id 
        $whereSql 
        ORDER BY m.id DESC";
$result = mysqli_query($koneksi, $sql);

// Ambil list kategori untuk filter dropdown
$kategoriList = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY urutan ASC");
?>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
        <h4 class="fw-bold text-dark mb-1">Daftar Menu Makanan & Minuman</h4>
        <p class="text-muted small mb-0">Kelola ketersediaan, harga, dan foto menu Soto Lamongan Cak Joyo.</p>
    </div>
    <a href="menu_tambah.php" class="btn btn-warning fw-bold text-dark">
        <i class="bi bi-plus-circle me-1"></i> Tambah Menu Baru
    </a>
</div>

<!-- FILTER & SEARCH -->
<div class="card border-0 shadow-sm p-3 rounded-4 mb-4">
    <form method="GET" action="menu.php" class="row g-2 align-items-center">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                <input type="text" name="search" class="form-control" placeholder="Cari nama menu..." value="<?= htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-md-4">
            <select name="kategori" class="form-select">
                <option value="">Semua Kategori</option>
                <?php while($k = mysqli_fetch_assoc($kategoriList)): ?>
                    <option value="<?= $k['id']; ?>" <?= $katFilter == $k['id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($k['nama_kategori']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-dark w-100">
                <i class="bi bi-filter me-1"></i> Filter
            </button>
            <?php if (!empty($search) || !empty($katFilter)): ?>
                <a href="menu.php" class="btn btn-outline-secondary">Reset</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- TABEL MENU -->
<div class="admin-card">
    <div class="table-responsive">
        <table class="table table-custom table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th style="width: 80px;">Foto</th>
                    <th>Nama Menu</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Favorit</th>
                    <th class="text-center" style="width: 150px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($m = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <img src="../uploads/menu/<?= htmlspecialchars($m['gambar']); ?>" alt="<?= htmlspecialchars($m['nama_menu']); ?>" class="rounded-3 border" style="width: 60px; height: 50px; object-fit: cover;" onerror="this.src='../uploads/menu/default_soto.jpg'">
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($m['nama_menu']); ?></div>
                                <small class="text-muted d-block text-truncate" style="max-width: 250px;">
                                    <?= htmlspecialchars($m['deskripsi'] ?? '-'); ?>
                                </small>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <?= htmlspecialchars($m['nama_kategori'] ?? 'Tanpa Kategori'); ?>
                                </span>
                            </td>
                            <td>
                                <strong class="text-warning"><?= format_rupiah($m['harga']); ?></strong>
                            </td>
                            <td>
                                <?php if ($m['status'] === 'tersedia'): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">
                                        <i class="bi bi-check-circle me-1"></i> Tersedia
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                                        <i class="bi bi-x-circle me-1"></i> Habis
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($m['is_favorite'] == 1): ?>
                                    <span class="badge bg-danger text-white"><i class="bi bi-star-fill me-1"></i> Ya</span>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="menu_edit.php?id=<?= $m['id']; ?>" class="btn btn-outline-primary" title="Edit Menu">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="menu_toggle.php?id=<?= $m['id']; ?>&field=status" class="btn btn-outline-warning" title="Ubah Status (Tersedia / Habis)">
                                        <i class="bi bi-arrow-repeat"></i>
                                    </a>
                                    <a href="menu_hapus.php?id=<?= $m['id']; ?>" class="btn btn-outline-danger" title="Hapus Menu" onclick="return confirm('Apakah Anda yakin ingin menghapus menu <?= addslashes($m['nama_menu']); ?>?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            <i class="bi bi-journal-x fs-1 d-block mb-2 text-secondary"></i>
                            Tidak ada menu yang sesuai dengan pencarian atau filter.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
