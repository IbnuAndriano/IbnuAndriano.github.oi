<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id = (int)($_GET['id'] ?? 0);
$field = clean($koneksi, $_GET['field'] ?? 'status');

if ($id > 0) {
    if ($field === 'status') {
        $q = mysqli_query($koneksi, "SELECT status FROM menu WHERE id = $id");
        if ($row = mysqli_fetch_assoc($q)) {
            $newStatus = ($row['status'] === 'tersedia') ? 'habis' : 'tersedia';
            mysqli_query($koneksi, "UPDATE menu SET status = '$newStatus' WHERE id = $id");
        }
    }
}

header("Location: menu.php");
exit;
