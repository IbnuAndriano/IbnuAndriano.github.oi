<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id = (int)($_GET['id'] ?? 0);

if ($id > 0) {
    // Ambil info gambar untuk dihapus jika bukan default
    $query = mysqli_query($koneksi, "SELECT gambar FROM menu WHERE id = $id");
    if ($row = mysqli_fetch_assoc($query)) {
        $gambar = $row['gambar'];
        if (!empty($gambar) && strpos($gambar, 'menu_') === 0) {
            $filePath = __DIR__ . '/../uploads/menu/' . $gambar;
            if (file_exists($filePath)) {
                @unlink($filePath);
            }
        }
    }
    mysqli_query($koneksi, "DELETE FROM menu WHERE id = $id");
}

header("Location: menu.php");
exit;
