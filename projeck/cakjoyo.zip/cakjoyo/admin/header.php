<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$currentPage = basename($_SERVER['PHP_SELF']);
$resto = get_pengaturan($koneksi);

// Hitung jumlah pesanan baru yang belum diproses
$queryPending = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM pesanan WHERE status = 'Baru'");
$pendingCount = 0;
if ($queryPending) {
    $rowPending = mysqli_fetch_assoc($queryPending);
    $pendingCount = (int)$rowPending['jml'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin - <?= htmlspecialchars($resto['nama_resto']); ?></title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5.3 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    
    <!-- Custom Admin CSS -->
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">

<!-- SIDEBAR -->
<aside class="admin-sidebar">
    <a href="dashboard.php" class="admin-brand">
        <div class="admin-brand-icon">
            <i class="bi bi-egg-fried"></i>
        </div>
        <div>
            <div class="fw-bold fs-6 text-white">Cak Joyo Admin</div>
            <small class="text-warning fw-semibold">Soto Lamongan</small>
        </div>
    </a>

    <nav class="admin-nav">
        <a href="dashboard.php" class="admin-nav-item <?= in_array($currentPage, ['dashboard.php', 'index.php']) ? 'active' : ''; ?>">
            <i class="bi bi-speedometer2"></i>
            <span>Dashboard</span>
        </a>
        
        <a href="pesanan.php" class="admin-nav-item <?= in_array($currentPage, ['pesanan.php', 'pesanan_detail.php']) ? 'active' : ''; ?>">
            <i class="bi bi-bag-check"></i>
            <span class="flex-grow-1">Pesanan Masuk</span>
            <?php if ($pendingCount > 0): ?>
                <span class="badge bg-danger rounded-pill"><?= $pendingCount; ?></span>
            <?php endif; ?>
        </a>

        <a href="menu.php" class="admin-nav-item <?= in_array($currentPage, ['menu.php', 'menu_tambah.php', 'menu_edit.php']) ? 'active' : ''; ?>">
            <i class="bi bi-journal-text"></i>
            <span>Kelola Menu</span>
        </a>

        <a href="laporan.php" class="admin-nav-item <?= $currentPage === 'laporan.php' ? 'active' : ''; ?>">
            <i class="bi bi-bar-chart-line"></i>
            <span>Laporan Penjualan</span>
        </a>

        <a href="pengaturan.php" class="admin-nav-item <?= $currentPage === 'pengaturan.php' ? 'active' : ''; ?>">
            <i class="bi bi-gear"></i>
            <span>Pengaturan Warung</span>
        </a>

        <div class="my-3 border-top border-secondary opacity-25"></div>

        <a href="../index.php" target="_blank" class="admin-nav-item text-info">
            <i class="bi bi-box-arrow-up-right"></i>
            <span>Buka Website Pembeli</span>
        </a>
    </nav>

    <div class="admin-user-bottom">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-2">
                <div class="bg-secondary rounded-circle text-white d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                    <i class="bi bi-person-fill"></i>
                </div>
                <div>
                    <div class="text-white small fw-bold text-truncate" style="max-width: 120px;">
                        <?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin Cak Joyo'); ?>
                    </div>
                    <small class="text-white-50" style="font-size: 0.72rem;">Online</small>
                </div>
            </div>
            <a href="logout.php" class="text-danger fs-5" title="Keluar / Logout" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                <i class="bi bi-box-arrow-right"></i>
            </a>
        </div>
    </div>
</aside>

<!-- MAIN CONTENT WRAPPER -->
<main class="admin-main">
    <!-- Topbar -->
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-2">
            <h5 class="fw-bold mb-0 text-dark">
                <?php
                if (in_array($currentPage, ['dashboard.php', 'index.php'])) echo 'Ringkasan Dashboard';
                elseif ($currentPage === 'pesanan.php') echo 'Daftar Pesanan Masuk';
                elseif ($currentPage === 'pesanan_detail.php') echo 'Detail & Nota Pesanan';
                elseif ($currentPage === 'menu.php') echo 'Manajemen Menu Soto & Minuman';
                elseif ($currentPage === 'menu_tambah.php') echo 'Tambah Menu Baru';
                elseif ($currentPage === 'menu_edit.php') echo 'Edit Menu';
                elseif ($currentPage === 'laporan.php') echo 'Laporan Penjualan & Keuangan';
                elseif ($currentPage === 'pengaturan.php') echo 'Pengaturan Profil & QRIS';
                else echo 'Panel Administrasi';
                ?>
            </h5>
        </div>
        <div class="d-flex align-items-center gap-3">
            <div class="text-end d-none d-md-block">
                <small class="text-muted d-block"><?= date('l, d F Y'); ?></small>
                <small class="fw-bold text-warning"><i class="bi bi-clock me-1"></i> Jam Buka: <?= htmlspecialchars($resto['jam_buka']); ?></small>
            </div>
        </div>
    </div>
