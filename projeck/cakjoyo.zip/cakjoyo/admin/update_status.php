<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id     = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$status = clean($koneksi, $_GET['status'] ?? $_POST['status'] ?? '');

$allowed = ['Baru', 'Diproses', 'Siap', 'Selesai', 'Dibatalkan'];

if ($id > 0 && in_array($status, $allowed)) {
    mysqli_query($koneksi, "UPDATE pesanan SET status = '$status' WHERE id = $id");
}

$ref = $_SERVER['HTTP_REFERER'] ?? 'pesanan.php';
header("Location: $ref");
exit;
