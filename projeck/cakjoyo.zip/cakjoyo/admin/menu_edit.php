<?php
require_once __DIR__ . '/header.php';

$id = (int)($_GET['id'] ?? 0);
$queryMenu = mysqli_query($koneksi, "SELECT * FROM menu WHERE id = $id LIMIT 1");
$menu = mysqli_fetch_assoc($queryMenu);

if (!$menu) {
    header("Location: menu.php");
    exit;
}

$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $nama        = clean($koneksi, $_POST['nama_menu'] ?? '');
    $kategori_id = (int)($_POST['kategori_id'] ?? 1);
    $harga       = (int)($_POST['harga'] ?? 0);
    $deskripsi   = clean($koneksi, $_POST['deskripsi'] ?? '');
    $status      = clean($koneksi, $_POST['status'] ?? 'tersedia');
    $is_favorite = isset($_POST['is_favorite']) ? 1 : 0;

    if (empty($nama) || $harga <= 0) {
        $error = 'Nama menu dan harga harus diisi dengan benar!';
    } else {
        $gambarNama = $menu['gambar'];

        // Cek jika ada upload gambar baru
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['gambar']['tmp_name'];
            $fileName = $_FILES['gambar']['name'];
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg'];

            if (in_array($ext, $allowed)) {
                $newGambar = "menu_" . time() . "_" . rand(100, 999) . "." . $ext;
                $destDir = __DIR__ . '/../uploads/menu';
                if (!is_dir($destDir)) {
                    mkdir($destDir, 0777, true);
                }
                if (move_uploaded_file($tmpName, "$destDir/$newGambar")) {
                    $gambarNama = $newGambar;
                }
            } else {
                $error = 'Format file gambar tidak didukung! Gunakan JPG, PNG, atau WEBP.';
            }
        }

        if (empty($error)) {
            $sql = "UPDATE menu SET 
                        kategori_id = $kategori_id,
                        nama_menu = '$nama',
                        deskripsi = '$deskripsi',
                        harga = $harga,
                        gambar = '$gambarNama',
                        status = '$status',
                        is_favorite = $is_favorite
                    WHERE id = $id";
            
            if (mysqli_query($koneksi, $sql)) {
                header("Location: menu.php");
                exit;
            } else {
                $error = 'Gagal memperbarui menu: ' . mysqli_error($koneksi);
            }
        }
    }
}

// Ambil kategori untuk pilihan dropdown
$kategoriList = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY urutan ASC");
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <h4 class="fw-bold text-dark mb-1">Edit Menu: <?= htmlspecialchars($menu['nama_menu']); ?></h4>
                <p class="text-muted small mb-0">Perbarui informasi harga, status ketersediaan, atau foto menu.</p>
            </div>
            <a href="menu.php" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke Menu
            </a>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm p-4 rounded-4">
            <form action="menu_edit.php?id=<?= $id; ?>" method="POST" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label fw-semibold">Nama Menu <span class="text-danger">*</span></label>
                        <input type="text" name="nama_menu" class="form-control" value="<?= htmlspecialchars($menu['nama_menu']); ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                        <select name="kategori_id" class="form-select" required>
                            <?php while($k = mysqli_fetch_assoc($kategoriList)): ?>
                                <option value="<?= $k['id']; ?>" <?= $menu['kategori_id'] == $k['id'] ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($k['nama_kategori']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Harga (Rp) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" name="harga" class="form-control" value="<?= $menu['harga']; ?>" min="0" required>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Status Ketersediaan</label>
                        <select name="status" class="form-select">
                            <option value="tersedia" <?= $menu['status'] === 'tersedia' ? 'selected' : ''; ?>>Tersedia (Ready)</option>
                            <option value="habis" <?= $menu['status'] === 'habis' ? 'selected' : ''; ?>>Habis (Sold Out)</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Deskripsi Menu</label>
                        <textarea name="deskripsi" class="form-control" rows="3"><?= htmlspecialchars($menu['deskripsi'] ?? ''); ?></textarea>
                    </div>

                    <div class="col-md-8">
                        <label class="form-label fw-semibold">Ganti Foto Menu</label>
                        <input type="file" name="gambar" class="form-control" accept="image/*">
                        <div class="form-text text-muted">Biarkan kosong jika tidak ingin mengubah foto saat ini.</div>
                    </div>

                    <div class="col-md-4 text-center">
                        <label class="form-label fw-semibold d-block">Foto Saat Ini</label>
                        <img src="../uploads/menu/<?= htmlspecialchars($menu['gambar']); ?>" alt="Preview" class="rounded-3 border shadow-sm" style="max-height: 80px; object-fit: cover;" onerror="this.src='../uploads/menu/default_soto.jpg'">
                    </div>

                    <div class="col-12">
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" name="is_favorite" id="is_favorite" value="1" <?= $menu['is_favorite'] == 1 ? 'checked' : ''; ?>>
                            <label class="form-check-label fw-semibold" for="is_favorite">
                                Tandai sebagai <strong>Menu Favorit / Rekomendasi</strong> (Tampil di bagian atas)
                            </label>
                        </div>
                    </div>
                </div>

                <hr class="my-4">

                <div class="d-flex justify-content-end gap-2">
                    <a href="menu.php" class="btn btn-light px-4">Batal</a>
                    <button type="submit" class="btn btn-warning fw-bold px-4 text-dark">
                        <i class="bi bi-save me-1"></i> Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
