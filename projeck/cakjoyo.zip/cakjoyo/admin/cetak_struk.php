<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id = (int)($_GET['id'] ?? 0);
$queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id = $id LIMIT 1");
$pesanan = mysqli_fetch_assoc($queryPesanan);

if (!$pesanan) {
    die("Pesanan tidak ditemukan.");
}

$queryDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $id");
$resto = get_pengaturan($koneksi);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Struk - <?= htmlspecialchars($pesanan['kode_pesanan']); ?></title>
    <style>
        body {
            font-family: 'Courier New', Courier, monospace;
            background-color: #f1f5f9;
            margin: 0;
            padding: 20px;
            color: #000;
        }
        .struk-container {
            width: 320px;
            background: #fff;
            padding: 20px 15px;
            margin: 0 auto;
            border: 1px solid #ddd;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }
        .text-center { text-align: center; }
        .text-end { text-align: right; }
        .fw-bold { font-weight: bold; }
        .dashed {
            border-top: 1px dashed #000;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }
        td, th {
            padding: 4px 0;
            vertical-align: top;
        }
        .no-print {
            text-align: center;
            margin-bottom: 20px;
        }
        .btn-print {
            background: #d97706;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        @media print {
            body { background: transparent; padding: 0; }
            .struk-container {
                width: 100%;
                border: none;
                box-shadow: none;
                padding: 0;
                margin: 0;
            }
            .no-print { display: none; }
        }
    </style>
</head>
<body>

<div class="no-print">
    <button class="btn-print" onclick="window.print()">🖨️ Cetak Struk (Kasir / Dapur)</button>
    <button onclick="window.close()" style="padding: 8px 16px; margin-left: 8px;">Tutup</button>
</div>

<div class="struk-container">
    <div class="text-center">
        <h3 style="margin: 0; font-size: 16px; text-transform: uppercase;"><?= htmlspecialchars($resto['nama_resto']); ?></h3>
        <p style="margin: 4px 0; font-size: 11px;"><?= htmlspecialchars($resto['alamat']); ?></p>
        <p style="margin: 0; font-size: 11px;">WA: <?= htmlspecialchars($resto['no_wa']); ?></p>
    </div>

    <div class="dashed"></div>

    <table style="font-size: 11px;">
        <tr>
            <td>No: <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong></td>
            <td class="text-end"><?= date('d/m/Y H:i', strtotime($pesanan['created_at'])); ?></td>
        </tr>
        <tr>
            <td>Plg: <?= htmlspecialchars($pesanan['nama_pelanggan']); ?></td>
            <td class="text-end"><?= tipe_pesanan_label($pesanan['tipe_pesanan'], $pesanan['nomor_meja']); ?></td>
        </tr>
        <tr>
            <td>Bayar: <?= metode_bayar_label($pesanan['metode_pembayaran']); ?></td>
            <td class="text-end">Status: <?= $pesanan['status']; ?></td>
        </tr>
    </table>

    <div class="dashed"></div>

    <table>
        <?php while ($d = mysqli_fetch_assoc($queryDetail)): ?>
            <tr>
                <td colspan="2">
                    <strong><?= htmlspecialchars($d['nama_menu']); ?></strong>
                    <?php if (!empty($d['catatan_item'])): ?>
                        <div style="font-size: 10px; font-style: italic;">* <?= htmlspecialchars($d['catatan_item']); ?></div>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td style="padding-left: 10px;">
                    <?= $d['jumlah']; ?> x <?= number_format($d['harga'], 0, ',', '.'); ?>
                </td>
                <td class="text-end fw-bold">
                    <?= number_format($d['subtotal'], 0, ',', '.'); ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <div class="dashed"></div>

    <table>
        <tr>
            <td class="fw-bold" style="font-size: 14px;">TOTAL:</td>
            <td class="text-end fw-bold" style="font-size: 15px;">
                Rp <?= number_format($pesanan['total_harga'], 0, ',', '.'); ?>
            </td>
        </tr>
    </table>

    <?php if (!empty($pesanan['catatan'])): ?>
        <div class="dashed"></div>
        <div style="font-size: 11px;">
            <strong>Catatan Pesanan:</strong><br>
            <?= nl2br(htmlspecialchars($pesanan['catatan'])); ?>
        </div>
    <?php endif; ?>

    <div class="dashed"></div>

    <div class="text-center" style="font-size: 11px; margin-top: 10px;">
        Matur Suwun atas Kunjungan Anda!<br>
        Soto Lamongan Cak Joyo Asli
    </div>
</div>

<script>
// Auto print saat dibuka jika diinginkan
// window.print();
</script>
</body>
</html>
