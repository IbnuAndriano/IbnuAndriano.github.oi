<?php
require_once __DIR__ . '/includes/header.php';

$kode = clean($koneksi, $_GET['kode'] ?? $_SESSION['last_order_code'] ?? '');

if (empty($kode)) {
    echo "<div class='container py-5 text-center'><h4>Kode pesanan tidak valid.</h4><a href='index.php' class='btn btn-warning mt-3'>Kembali ke Beranda</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Ambil data pesanan
$queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE kode_pesanan = '$kode' LIMIT 1");
$pesanan = mysqli_fetch_assoc($queryPesanan);

if (!$pesanan) {
    echo "<div class='container py-5 text-center'><h4>Pesanan dengan kode <strong>" . htmlspecialchars($kode) . "</strong> tidak ditemukan.</h4><a href='index.php' class='btn btn-warning mt-3'>Kembali ke Beranda</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Ambil rincian pesanan
$pesanan_id = $pesanan['id'];
$queryDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $pesanan_id");

// Format Pesan WhatsApp Konfirmasi
$waText = "Halo Cak Joyo! Saya mau konfirmasi pesanan:\n\n"
        . "*Kode Pesanan:* " . $pesanan['kode_pesanan'] . "\n"
        . "*Nama:* " . $pesanan['nama_pelanggan'] . "\n"
        . "*Tipe:* " . ucfirst($pesanan['tipe_pesanan']) . ($pesanan['nomor_meja'] ? " (Meja " . $pesanan['nomor_meja'] . ")" : "") . "\n"
        . "*Total:* " . format_rupiah($pesanan['total_harga']) . "\n"
        . "*Metode Bayar:* " . ucfirst($pesanan['metode_pembayaran']) . "\n\n"
        . "Mohon dicek dan diproses ya Cak. Matur suwun!";
$waUrl = whatsapp_link($resto['no_wa'], $waText);
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Alert Berhasil -->
            <div class="alert alert-success d-flex align-items-center mb-4 no-print shadow-sm rounded-4 p-3" role="alert">
                <i class="bi bi-check-circle-fill fs-2 me-3"></i>
                <div>
                    <h5 class="alert-heading fw-bold mb-1">Pesanan Anda Berhasil Diterima!</h5>
                    <p class="mb-0 small">Dapur Soto Lamongan Cak Joyo telah menerima pesanan Anda dengan kode: <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong></p>
                </div>
            </div>

            <!-- Stepper Progres Pesanan -->
            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4 no-print">
                <h6 class="fw-bold text-center text-dark mb-3">Status Pengerjaan Pesanan</h6>
                <div class="order-stepper">
                    <?php
                    $status = $pesanan['status'];
                    $steps = [
                        'Baru' => ['title' => 'Diterima', 'icon' => 'bi-receipt'],
                        'Diproses' => ['title' => 'Dimasak', 'icon' => 'bi-fire'],
                        'Siap' => ['title' => 'Siap', 'icon' => 'bi-bell'],
                        'Selesai' => ['title' => 'Selesai', 'icon' => 'bi-check2-circle']
                    ];
                    $reached = true;
                    $statusKeys = ['Baru', 'Diproses', 'Siap', 'Selesai'];
                    $currentIndex = array_search($status, $statusKeys);
                    if ($currentIndex === false && $status === 'Dibatalkan') {
                        $currentIndex = -1;
                    }

                    $idx = 0;
                    foreach ($steps as $stName => $stData):
                        $isCompleted = ($currentIndex !== false && $idx < $currentIndex);
                        $isActive = ($currentIndex !== false && $idx === $currentIndex);
                        $class = $isCompleted ? 'completed' : ($isActive ? 'active' : '');
                        $idx++;
                    ?>
                        <div class="step-item <?= $class; ?>">
                            <div class="step-circle">
                                <i class="bi <?= $stData['icon']; ?>"></i>
                            </div>
                            <div class="step-title"><?= $stData['title']; ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($pesanan['status'] === 'Dibatalkan'): ?>
                    <div class="alert alert-danger text-center mb-0 mt-3 py-2">
                        <i class="bi bi-x-circle-fill me-1"></i> Pesanan ini telah <strong>Dibatalkan</strong>.
                    </div>
                <?php else: ?>
                    <div class="text-center mt-3">
                        <span class="text-muted small">Status saat ini:</span> <?= status_badge($pesanan['status']); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- NOTA / STRUK PEMBELIAN -->
            <div class="receipt-box">
                <div class="text-center mb-4">
                    <div class="brand-icon mx-auto mb-2" style="width: 44px; height: 44px; font-size: 1.3rem;">
                        <i class="bi bi-egg-fried"></i>
                    </div>
                    <h4 class="fw-bold text-dark mb-0"><?= htmlspecialchars($resto['nama_resto']); ?></h4>
                    <p class="small text-muted mb-1"><?= htmlspecialchars($resto['alamat']); ?></p>
                    <p class="small text-muted mb-0">Telp/WA: <?= htmlspecialchars($resto['no_wa']); ?></p>
                </div>

                <hr style="border-top: 1px dashed #cbd5e1;">

                <div class="row g-2 small mb-3">
                    <div class="col-6">
                        <span class="text-muted">Kode Pesanan:</span><br>
                        <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Waktu:</span><br>
                        <strong><?= format_tanggal($pesanan['created_at']); ?></strong>
                    </div>
                    <div class="col-6">
                        <span class="text-muted">Nama Pemesan:</span><br>
                        <strong><?= htmlspecialchars($pesanan['nama_pelanggan']); ?> (<?= htmlspecialchars($pesanan['no_hp']); ?>)</strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Layanan:</span><br>
                        <strong><?= tipe_pesanan_label($pesanan['tipe_pesanan'], $pesanan['nomor_meja']); ?></strong>
                    </div>
                    <?php if ($pesanan['alamat_pengiriman']): ?>
                        <div class="col-12">
                            <span class="text-muted">Alamat Antar:</span><br>
                            <strong><?= nl2br(htmlspecialchars($pesanan['alamat_pengiriman'])); ?></strong>
                        </div>
                    <?php endif; ?>
                    <div class="col-6">
                        <span class="text-muted">Metode Bayar:</span><br>
                        <strong><?= metode_bayar_label($pesanan['metode_pembayaran']); ?></strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Status:</span><br>
                        <strong><?= htmlspecialchars($pesanan['status']); ?></strong>
                    </div>
                </div>

                <hr style="border-top: 1px dashed #cbd5e1;">

                <!-- Tabel Menu -->
                <table class="table table-sm table-borderless small mb-3">
                    <thead>
                        <tr class="border-bottom text-muted">
                            <th class="ps-0">Menu</th>
                            <th class="text-center">Qty</th>
                            <th class="text-end pe-0">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($d = mysqli_fetch_assoc($queryDetail)): ?>
                            <tr>
                                <td class="ps-0">
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($d['nama_menu']); ?></div>
                                    <div class="text-muted" style="font-size: 0.8rem;"><?= format_rupiah($d['harga']); ?></div>
                                    <?php if (!empty($d['catatan_item'])): ?>
                                        <div class="text-warning fst-italic" style="font-size: 0.78rem;">"<?= htmlspecialchars($d['catatan_item']); ?>"</div>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center align-middle"><?= $d['jumlah']; ?></td>
                                <td class="text-end align-middle pe-0 fw-bold"><?= format_rupiah($d['subtotal']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <hr style="border-top: 1px dashed #cbd5e1;">

                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-bold text-dark">TOTAL TAGIHAN:</span>
                    <span class="fs-4 fw-bold text-dark"><?= format_rupiah($pesanan['total_harga']); ?></span>
                </div>

                <?php if (!empty($pesanan['catatan'])): ?>
                    <div class="p-2 bg-light rounded small mt-2 mb-3">
                        <strong>Catatan:</strong> <?= htmlspecialchars($pesanan['catatan']); ?>
                    </div>
                <?php endif; ?>

                <div class="text-center small text-muted mt-4">
                    <p class="mb-1">Terima kasih atas pesanan Anda di Soto Lamongan Cak Joyo!</p>
                    <p class="mb-0 fst-italic">"Kelezatan Asli, Gurih Kaldunya Mantap Koyanya"</p>
                </div>
            </div>

            <!-- Tombol Aksi di Bawah Nota -->
            <div class="d-flex flex-wrap gap-2 justify-content-center mt-4 no-print">
                <button onclick="window.print()" class="btn btn-outline-dark px-4 py-2">
                    <i class="bi bi-printer me-2"></i> Cetak Struk
                </button>
                <a href="<?= $waUrl; ?>" target="_blank" class="btn btn-success px-4 py-2">
                    <i class="bi bi-whatsapp me-2"></i> Konfirmasi ke WhatsApp Resto
                </a>
                <a href="index.php" class="btn btn-warning px-4 py-2 fw-bold text-dark">
                    <i class="bi bi-plus-circle me-2"></i> Pesan Menu Baru
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
