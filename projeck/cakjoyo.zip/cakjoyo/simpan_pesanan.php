<?php
/**
 * Simpan Pesanan Pelanggan Soto Lamongan Cak Joyo
 */
session_start();
require_once __DIR__ . '/koneksi.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header("Location: index.php");
    exit;
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: index.php");
    exit;
}

// 1. Ambil data formulir
$nama            = clean($koneksi, $_POST['nama'] ?? '');
$hp              = clean($koneksi, $_POST['hp'] ?? '');
$tipe_pesanan    = clean($koneksi, $_POST['tipe_pesanan'] ?? 'dine_in');
$nomor_meja      = clean($koneksi, $_POST['nomor_meja'] ?? '');
$alamat          = clean($koneksi, $_POST['alamat_pengiriman'] ?? '');
$metode          = clean($koneksi, $_POST['metode'] ?? 'cash');
$catatan         = clean($koneksi, $_POST['catatan'] ?? '');

// Hitung total harga dari session cart
$total_harga = 0;
foreach ($cart as $item) {
    $total_harga += ($item['harga'] * $item['jumlah']);
}

// 2. Generate Kode Pesanan Unik
$kode_pesanan = generate_kode_pesanan();

// 3. Proses Upload Bukti Bayar jika ada
$bukti_nama = null;
if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] === UPLOAD_ERR_OK) {
    $fileTmp  = $_FILES['bukti']['tmp_name'];
    $fileName = $_FILES['bukti']['name'];
    $ext      = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowed  = ['jpg', 'jpeg', 'png', 'webp'];

    if (in_array($ext, $allowed)) {
        $bukti_nama = "bukti_" . time() . "_" . rand(100, 999) . "." . $ext;
        $destDir    = __DIR__ . '/uploads/bukti';
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }
        move_uploaded_file($fileTmp, "$destDir/$bukti_nama");
    }
}

// 4. Masukkan ke tabel `pesanan`
$sqlPesanan = "INSERT INTO pesanan (
    kode_pesanan,
    nama_pelanggan,
    no_hp,
    tipe_pesanan,
    nomor_meja,
    alamat_pengiriman,
    metode_pembayaran,
    total_harga,
    catatan,
    bukti_bayar,
    status,
    created_at
) VALUES (
    '$kode_pesanan',
    '$nama',
    '$hp',
    '$tipe_pesanan',
    " . (!empty($nomor_meja) ? "'$nomor_meja'" : "NULL") . ",
    " . (!empty($alamat) ? "'$alamat'" : "NULL") . ",
    '$metode',
    $total_harga,
    " . (!empty($catatan) ? "'$catatan'" : "NULL") . ",
    " . (!empty($bukti_nama) ? "'$bukti_nama'" : "NULL") . ",
    'Baru',
    NOW()
)";

if (mysqli_query($koneksi, $sqlPesanan)) {
    $pesanan_id = mysqli_insert_id($koneksi);

    // 5. Masukkan rincian pesanan ke tabel `detail_pesanan`
    foreach ($cart as $item) {
        $menu_id   = (int)$item['menu_id'];
        $nama_menu = clean($koneksi, $item['nama']);
        $harga     = (int)$item['harga'];
        $jumlah    = (int)$item['jumlah'];
        $subtotal  = $harga * $jumlah;
        $catatan_i = clean($koneksi, $item['catatan'] ?? '');

        $sqlDetail = "INSERT INTO detail_pesanan (
            pesanan_id, menu_id, nama_menu, harga, jumlah, subtotal, catatan_item
        ) VALUES (
            $pesanan_id, $menu_id, '$nama_menu', $harga, $jumlah, $subtotal, " . (!empty($catatan_i) ? "'$catatan_i'" : "NULL") . "
        )";
        mysqli_query($koneksi, $sqlDetail);
    }

    // 6. Kosongkan keranjang belanja
    $_SESSION['cart'] = [];

    // 7. Simpan kode pesanan terakhir di session agar mudah dicek
    $_SESSION['last_order_code'] = $kode_pesanan;

    // 8. Alihkan ke halaman nota / konfirmasi
    header("Location: nota.php?kode=" . urlencode($kode_pesanan));
    exit;
} else {
    die("Terjadi kesalahan saat menyimpan pesanan: " . mysqli_error($koneksi));
}
