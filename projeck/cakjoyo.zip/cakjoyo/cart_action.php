<?php
/**
 * Controller Aksi Keranjang Belanja (AJAX & Session)
 */
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/koneksi.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'add':
        $menu_id = (int)($_POST['menu_id'] ?? 0);
        $jumlah  = max(1, (int)($_POST['jumlah'] ?? 1));
        $catatan = clean($koneksi, $_POST['catatan'] ?? '');

        if ($menu_id > 0) {
            $query = mysqli_query($koneksi, "SELECT * FROM menu WHERE id = $menu_id AND status = 'tersedia' LIMIT 1");
            if ($menu = mysqli_fetch_assoc($query)) {
                $key = 'item_' . $menu_id;
                if (isset($_SESSION['cart'][$key])) {
                    $_SESSION['cart'][$key]['jumlah'] += $jumlah;
                    if (!empty($catatan)) {
                        $_SESSION['cart'][$key]['catatan'] = $catatan;
                    }
                } else {
                    $_SESSION['cart'][$key] = [
                        'menu_id' => $menu['id'],
                        'nama'    => $menu['nama_menu'],
                        'harga'   => (int)$menu['harga'],
                        'gambar'  => $menu['gambar'],
                        'jumlah'  => $jumlah,
                        'catatan' => $catatan
                    ];
                }

                echo json_encode([
                    'status'  => 'success',
                    'message' => $menu['nama_menu'] . ' berhasil ditambahkan!',
                    'cart'    => get_cart_summary()
                ]);
                exit;
            }
        }
        echo json_encode(['status' => 'error', 'message' => 'Menu tidak ditemukan atau sedang habis']);
        exit;

    case 'update':
        $key    = $_POST['key'] ?? '';
        $jumlah = (int)($_POST['jumlah'] ?? 1);

        if (isset($_SESSION['cart'][$key])) {
            if ($jumlah <= 0) {
                unset($_SESSION['cart'][$key]);
            } else {
                $_SESSION['cart'][$key]['jumlah'] = $jumlah;
            }
            echo json_encode([
                'status'  => 'success',
                'message' => 'Keranjang diperbarui',
                'cart'    => get_cart_summary()
            ]);
            exit;
        }
        echo json_encode(['status' => 'error', 'message' => 'Item tidak ditemukan']);
        exit;

    case 'remove':
        $key = $_POST['key'] ?? '';
        if (isset($_SESSION['cart'][$key])) {
            unset($_SESSION['cart'][$key]);
            echo json_encode([
                'status'  => 'success',
                'message' => 'Menu dihapus dari keranjang',
                'cart'    => get_cart_summary()
            ]);
            exit;
        }
        echo json_encode(['status' => 'error', 'message' => 'Item tidak ditemukan']);
        exit;

    case 'clear':
        $_SESSION['cart'] = [];
        echo json_encode([
            'status'  => 'success',
            'message' => 'Keranjang berhasil dikosongkan',
            'cart'    => get_cart_summary()
        ]);
        exit;

    case 'get':
    default:
        echo json_encode([
            'status' => 'success',
            'cart'   => get_cart_summary()
        ]);
        exit;
}

function get_cart_summary() {
    $items = $_SESSION['cart'] ?? [];
    $total_items = 0;
    $total_harga = 0;

    foreach ($items as $key => $item) {
        $subtotal = $item['harga'] * $item['jumlah'];
        $items[$key]['subtotal'] = $subtotal;
        $items[$key]['subtotal_formatted'] = format_rupiah($subtotal);
        $items[$key]['harga_formatted'] = format_rupiah($item['harga']);
        $total_items += $item['jumlah'];
        $total_harga += $subtotal;
    }

    return [
        'items'                => $items,
        'total_items'          => $total_items,
        'total_harga'          => $total_harga,
        'total_harga_formatted'=> format_rupiah($total_harga)
    ];
}
