<?php
/**
 * Koneksi Database Soto Lamongan Cak Joyo
 */

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_cakjoyo";

// Matikan exception otomatis mysqli agar error ditangani secara aman
mysqli_report(MYSQLI_REPORT_OFF);

$koneksi = @mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    // Cek apakah server MySQL jalan tapi databasenya belum dibuat
    $check_server = @mysqli_connect($host, $user, $pass);
    if ($check_server) {
        // Otomatis buat database jika belum ada
        mysqli_query($check_server, "CREATE DATABASE IF NOT EXISTS `$db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $koneksi = @mysqli_connect($host, $user, $pass, $db);
        mysqli_close($check_server);
    }
    
    if (!$koneksi) {
        die("
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 25px; border: 1px solid #f5c6cb; border-radius: 8px; background: #fdf7f7;'>
                <h3 style='color: #721c24; margin-top: 0;'>❌ Gagal Terhubung ke MySQL</h3>
                <p>Tidak dapat terhubung ke server database XAMPP.</p>
                <p><strong>Langkah Mengatasi:</strong></p>
                <ol>
                    <li>Buka aplikasi <strong>XAMPP Control Panel</strong>.</li>
                    <li>Pastikan modul <strong>Apache</strong> dan <strong>MySQL</strong> dalam status <strong>Running</strong>.</li>
                    <li>Refresh kembali halaman ini.</li>
                </ol>
            </div>
        ");
    }
}

mysqli_set_charset($koneksi, "utf8mb4");

// Auto-check jika tabel-tabel utama (seperti kategori / menu) belum terbuat, buat otomatis dari database.sql
$checkTable = @mysqli_query($koneksi, "SHOW TABLES LIKE 'kategori'");
if (!$checkTable || mysqli_num_rows($checkTable) === 0) {
    $sqlFile = __DIR__ . '/database.sql';
    if (file_exists($sqlFile)) {
        $sqlContent = file_get_contents($sqlFile);
        if ($koneksi->multi_query($sqlContent)) {
            do {
                if ($res = $koneksi->store_result()) {
                    $res->free();
                }
            } while ($koneksi->more_results() && $koneksi->next_result());
        }
    }
}

// Auto-add ewallet_info column if missing (upgrade existing installs)
$checkEwallet = @mysqli_query($koneksi, "SHOW COLUMNS FROM pengaturan LIKE 'ewallet_info'");
if ($checkEwallet && mysqli_num_rows($checkEwallet) === 0) {
    @mysqli_query($koneksi, "ALTER TABLE pengaturan ADD COLUMN ewallet_info TEXT DEFAULT NULL");
}

// Muat fungsi helper global
require_once __DIR__ . '/includes/helper.php';
?>
