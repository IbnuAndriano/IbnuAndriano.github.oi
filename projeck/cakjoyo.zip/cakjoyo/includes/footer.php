<?php
if (!isset($resto)) {
    require_once __DIR__ . '/../koneksi.php';
    $resto = get_pengaturan($koneksi);
}
?>
<!-- FLOATING CART BUTTON -->
<a href="javascript:void(0)" class="floating-cart-btn" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas" title="Buka Keranjang Pesanan">
    <i class="bi bi-cart3"></i>
    <span class="cart-counter" style="display: none;">0</span>
</a>

<!-- FOOTER -->
<footer class="footer-cakjoyo">
    <div class="container">
        <div class="row g-4 g-lg-5">
            <!-- Kolom 1: Profil Warung -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon" style="width: 40px; height: 40px; font-size: 1.25rem;">
                        <i class="bi bi-egg-fried"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold text-white mb-0"><?= htmlspecialchars($resto['nama_resto']); ?></h5>
                        <small class="footer-tagline">Khas Lamongan Asli • Owner: <strong>Pak Cak Joyo</strong></small>
                    </div>
                </div>
                <p class="footer-desc mb-4">
                    Menyajikan keaslian cita rasa soto ayam Lamongan gurih berempah dengan koya melimpah. <strong>Menerima pesanan</strong> untuk santap di tempat, bawa pulang, maupun acara hajatan.
                </p>
                <div class="d-flex flex-wrap gap-2">
                    <a href="<?= whatsapp_link($resto['no_wa'], 'Halo Pak Cak Joyo, saya mau memesan soto...'); ?>" target="_blank" class="btn btn-footer-wa">
                        <i class="bi bi-whatsapp"></i> WhatsApp (0812-9254-3664)
                    </a>
                    <a href="lacak.php" class="btn btn-footer-track">
                        <i class="bi bi-search"></i> Lacak Pesanan
                    </a>
                </div>
            </div>

            <!-- Kolom 2: Jam Operasional -->
            <div class="col-lg-4 col-md-6">
                <h5 class="footer-title"><i class="bi bi-clock-history text-amber me-2"></i> Jam Operasional & Layanan</h5>
                <ul class="footer-list list-unstyled">
                    <li class="footer-list-item mb-2">
                        <span class="footer-label">Jam Buka:</span>
                        <span class="footer-value fw-bold text-white"><?= htmlspecialchars($resto['jam_buka']); ?></span>
                    </li>
                    <li class="footer-list-item mb-2">
                        <span class="footer-label">Status:</span>
                        <span class="badge bg-warning text-dark fw-bold">Menerima Pesanan</span>
                    </li>
                    <li class="footer-list-item mb-2">
                        <span class="footer-label">Layanan:</span>
                        <span class="footer-value">Dine-In (Makan di Tempat), Take Away (Bungkus), Delivery Online.</span>
                    </li>
                    <li class="footer-list-item mb-2">
                        <span class="footer-label">Owner:</span>
                        <span class="footer-value text-white fw-bold">Pak Cak Joyo</span>
                    </li>
                </ul>
            </div>

            <!-- Kolom 3: Alamat & Kontak -->
            <div class="col-lg-4 col-md-12">
                <h5 class="footer-title"><i class="bi bi-geo-alt-fill text-amber me-2"></i> Lokasi & Kontak</h5>
                <p class="footer-text mb-2">
                    <?= nl2br(htmlspecialchars($resto['alamat'])); ?>
                </p>
                <p class="footer-text mb-3">
                    <i class="bi bi-telephone-fill text-amber me-2"></i> <span class="footer-label">HP / WhatsApp:</span> <span class="footer-value fw-semibold text-white">0812-9254-3664</span>
                </p>
                <div class="footer-catering-card">
                    <i class="bi bi-stars text-amber me-2 fs-6"></i>
                    <span>Siap melayani pesanan katering, syukuran, & acara kantor!</span>
                </div>
            </div>
        </div>

        <div class="footer-bottom d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <div class="footer-copyright">
                &copy; <?= date('Y'); ?> <strong class="text-white"><?= htmlspecialchars($resto['nama_resto']); ?></strong>. All rights reserved.
            </div>
            <div class="footer-tech-stack">
                <span class="tech-badge"><i class="bi bi-code-slash me-1"></i> PHP Native & MySQL</span>
                <span class="tech-badge"><i class="bi bi-server me-1"></i> XAMPP Localhost</span>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5.3 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script Keranjang Belanja -->
<script src="assets/js/cart.js"></script>

</body>
</html>
