<?php
/**
 * Helper Functions - Soto Lamongan Cak Joyo
 */

if (!function_exists('format_rupiah')) {
    function format_rupiah($angka) {
        return "Rp " . number_format((float)$angka, 0, ',', '.');
    }
}

if (!function_exists('format_tanggal')) {
    function format_tanggal($datetime) {
        if (!$datetime) return "-";
        $timestamp = strtotime($datetime);
        $bulanIndo = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        $tgl = date('d', $timestamp);
        $bln = (int)date('m', $timestamp);
        $thn = date('Y', $timestamp);
        $jam = date('H:i', $timestamp);
        return "$tgl {$bulanIndo[$bln]} $thn, $jam WIB";
    }
}

if (!function_exists('status_badge')) {
    function status_badge($status) {
        switch ($status) {
            case 'Baru':
                return '<span class="badge bg-primary text-white"><i class="bi bi-clock-history me-1"></i>Pesanan Baru</span>';
            case 'Diproses':
                return '<span class="badge bg-warning text-dark"><i class="bi bi-fire me-1"></i>Sedang Dimasak</span>';
            case 'Siap':
                return '<span class="badge bg-info text-dark"><i class="bi bi-bell me-1"></i>Siap Disajikan</span>';
            case 'Selesai':
                return '<span class="badge bg-success text-white"><i class="bi bi-check-circle me-1"></i>Selesai</span>';
            case 'Dibatalkan':
                return '<span class="badge bg-danger text-white"><i class="bi bi-x-circle me-1"></i>Dibatalkan</span>';
            default:
                return '<span class="badge bg-secondary">' . htmlspecialchars($status) . '</span>';
        }
    }
}

if (!function_exists('tipe_pesanan_label')) {
    function tipe_pesanan_label($tipe, $meja = null) {
        switch ($tipe) {
            case 'dine_in':
                return '🍽️ Makan di Tempat' . ($meja ? ' (Meja ' . htmlspecialchars($meja) . ')' : '');
            case 'take_away':
                return '🥡 Bawa Pulang (Take Away)';
            case 'delivery':
                return '🛵 Pengantaran (Delivery)';
            default:
                return htmlspecialchars($tipe);
        }
    }
}

if (!function_exists('metode_bayar_label')) {
    function metode_bayar_label($metode) {
        switch (strtolower($metode)) {
            case 'cash':
            case 'tunai':
                return '💵 Tunai / Kasir';
            case 'qris':
                return '📱 QRIS (Semua E-Wallet/Bank)';
            case 'transfer':
                return '🏦 Transfer Bank';
            case 'ewallet':
                return '📱 E-Wallet (GoPay/OVO/DANA/ShopeePay/LinkAja)';
            default:
                return htmlspecialchars(ucfirst($metode));
        }
    }
}

if (!function_exists('generate_kode_pesanan')) {
    function generate_kode_pesanan() {
        return "CJ-" . date("Ymd") . "-" . strtoupper(substr(uniqid(), -4));
    }
}

if (!function_exists('get_pengaturan')) {
    function get_pengaturan($koneksi) {
        $query = mysqli_query($koneksi, "SELECT * FROM pengaturan WHERE id = 1 LIMIT 1");
        if ($query && mysqli_num_rows($query) > 0) {
            return mysqli_fetch_assoc($query);
        }
        // Fallback default
        return [
            'nama_resto' => 'Soto ayam lamongan cak joyo',
            'slogan' => 'Menerima pesanan - Kelezatan Asli Soto Lamongan',
            'no_wa' => '081292543664',
            'alamat' => 'Jl. Pemuda No. 45, Lamongan / Surabaya, Jawa Timur',
            'jam_buka' => 'Buka 06.00-17.00',
            'qris_image' => 'qris_sample.png',
            'qris_nmid' => 'ID1020030040050',
            'rekening_bank' => "BCA: 8735123490 a.n Pak Cak Joyo\nMandiri: 142001928374 a.n Pak Cak Joyo",
            'ewallet_info' => "GoPay: 081292543664 a.n Pak Cak Joyo\nOVO: 081292543664 a.n Pak Cak Joyo\nDANA: 081292543664 a.n Pak Cak Joyo\nShopeePay: 081292543664 a.n Pak Cak Joyo\nLinkAja: 081292543664 a.n Pak Cak Joyo"
        ];
    }
}

if (!function_exists('clean')) {
    function clean($koneksi, $data) {
        if (is_null($data)) return '';
        return mysqli_real_escape_string($koneksi, trim($data));
    }
}

if (!function_exists('whatsapp_link')) {
    function whatsapp_link($no_wa, $pesan) {
        // Normalisasi nomor wa (hilangkan karakter selain angka)
        $no_wa = preg_replace('/[^0-9]/', '', $no_wa);
        if (substr($no_wa, 0, 1) === '0') {
            $no_wa = '62' . substr($no_wa, 1);
        }
        return "https://api.whatsapp.com/send?phone=" . urlencode($no_wa) . "&text=" . urlencode($pesan);
    }
}
?>
