<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../koneksi.php';
$resto = get_pengaturan($koneksi);
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($resto['nama_resto']); ?> - Gurih Kaldunya Mantap Koyanya</title>
    
    <!-- Google Font: Plus Jakarta Sans -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-cakjoyo">
    <div class="container">
        <a class="navbar-brand navbar-brand-logo" href="index.php">
            <div class="brand-icon">
                <i class="bi bi-egg-fried"></i>
            </div>
            <div>
                <div class="brand-title">Soto Lamongan</div>
                <div class="brand-subtitle">Cak Joyo Asli</div>
            </div>
        </a>

        <div class="d-flex align-items-center gap-2 order-lg-last">
            <!-- Tombol Buka Keranjang (Drawer) -->
            <button class="btn btn-cart-nav position-relative d-flex align-items-center gap-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas" title="Buka Keranjang Pesanan">
                <i class="bi bi-bag-check-fill fs-5"></i>
                <span class="d-none d-sm-inline fw-semibold">Keranjang</span>
                <span class="cart-counter" style="display: none;">0</span>
            </button>

            <!-- Navbar Toggler Mobile -->
            <button class="navbar-toggler border-0 shadow-none px-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="bi bi-list fs-2 text-dark"></i>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="navbarContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-lg-1">
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'index.php' ? 'active' : ''; ?>" href="index.php">
                        <i class="bi bi-house-door me-1"></i> Beranda
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#menu-section">
                        <i class="bi bi-journal-text me-1"></i> Daftar Menu
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'lacak.php' ? 'active' : ''; ?>" href="lacak.php">
                        <i class="bi bi-search me-1"></i> Cek Status Pesanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php#tentang-section">
                        <i class="bi bi-info-circle me-1"></i> Tentang Kami
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-admin" href="admin/login.php" target="_blank" title="Login Pemilik / Petugas">
                        <i class="bi bi-shield-lock me-1"></i> Admin
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- OFFCANVAS CART DRAWER -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
    <div class="offcanvas-header border-bottom py-3 px-4">
        <h5 class="offcanvas-title fw-bold text-dark d-flex align-items-center gap-2 mb-0" id="cartOffcanvasLabel">
            <span class="drawer-icon-wrap"><i class="bi bi-bag-check-fill"></i></span> Keranjang Pesanan
        </h5>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column p-4">
        <!-- List Item Keranjang -->
        <div id="cartDrawerItems" class="flex-grow-1 overflow-auto pe-1">
            <div class="text-center py-5 text-muted">
                <span class="fs-1 d-block mb-3">🍲</span>
                <h6>Memuat keranjang...</h6>
            </div>
        </div>

        <!-- Ringkasan & Tombol Checkout -->
        <div class="border-top pt-3 mt-2">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted fw-bold">Total Pembayaran:</span>
                <span id="cartDrawerTotal" class="fs-5 fw-bold text-dark">Rp 0</span>
            </div>
            <a href="checkout.php" id="cartDrawerCheckoutBtn" class="btn btn-primary-cakjoyo w-100 py-2 d-flex align-items-center justify-content-center gap-2">
                <span>Lanjut ke Pembayaran</span>
                <i class="bi bi-arrow-right"></i>
            </a>
            <div class="text-center mt-2">
                <small class="text-muted"><i class="bi bi-shield-check text-success"></i> Proses Cepat & Higienis</small>
            </div>
        </div>
    </div>
</div>
