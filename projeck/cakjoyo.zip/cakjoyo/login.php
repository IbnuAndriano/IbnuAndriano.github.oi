<?php
// Redirect root login.php ke admin/login.php
header("Location: admin/login.php");
exit;
?>
