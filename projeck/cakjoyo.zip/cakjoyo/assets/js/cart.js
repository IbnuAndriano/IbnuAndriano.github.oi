/**
 * Script Interaktif Keranjang & Filter Menu - Soto Lamongan Cak Joyo
 */

document.addEventListener('DOMContentLoaded', function () {
    // Muat data keranjang saat halaman pertama kali dibuka
    refreshCart();

    // Event listener untuk tombol "Tambah ke Keranjang"
    document.querySelectorAll('.btn-add-cart').forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const menuId = this.getAttribute('data-id');
            const menuName = this.getAttribute('data-name');
            addToCart(menuId, 1, '', menuName);
        });
    });

    // Filter Kategori Menu di Halaman Utama
    const filterPills = document.querySelectorAll('.category-pill');
    const menuItems = document.querySelectorAll('.menu-col');

    filterPills.forEach(pill => {
        pill.addEventListener('click', function () {
            filterPills.forEach(p => p.classList.remove('active'));
            this.classList.add('active');

            const category = this.getAttribute('data-category');
            menuItems.forEach(item => {
                if (category === 'all' || item.getAttribute('data-category') === category) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Live Search Menu
    const searchInput = document.getElementById('searchMenu');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const query = this.value.toLowerCase().trim();
            menuItems.forEach(item => {
                const title = item.querySelector('.menu-name').textContent.toLowerCase();
                const desc = item.querySelector('.menu-desc') ? item.querySelector('.menu-desc').textContent.toLowerCase() : '';
                if (title.includes(query) || desc.includes(query)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }
});

/**
 * Tambah Item ke Keranjang via AJAX
 */
function addToCart(menuId, jumlah = 1, catatan = '', menuName = 'Menu') {
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('menu_id', menuId);
    formData.append('jumlah', jumlah);
    formData.append('catatan', catatan);

    fetch('cart_action.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            updateCartUI(data.cart);
            showToast(`${menuName} berhasil masuk keranjang!`, 'success');
        } else {
            showToast(data.message || 'Gagal menambahkan menu.', 'danger');
        }
    })
    .catch(err => {
        console.error('Error adding to cart:', err);
    });
}

/**
 * Update Jumlah Item
 */
function updateCartQty(key, newQty) {
    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('key', key);
    formData.append('jumlah', newQty);

    fetch('cart_action.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            updateCartUI(data.cart);
        }
    });
}

/**
 * Hapus Item dari Keranjang
 */
function removeCartItem(key) {
    const formData = new FormData();
    formData.append('action', 'remove');
    formData.append('key', key);

    fetch('cart_action.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            updateCartUI(data.cart);
            showToast('Menu telah dihapus dari keranjang', 'info');
        }
    });
}

/**
 * Ambil & Segarkan Tampilan Keranjang
 */
function refreshCart() {
    fetch('cart_action.php?action=get')
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            updateCartUI(data.cart);
        }
    });
}

/**
 * Update Elemen DOM Keranjang
 */
function updateCartUI(cart) {
    // 1. Update Counter Badges
    const badgeElements = document.querySelectorAll('.cart-counter');
    badgeElements.forEach(badge => {
        badge.textContent = cart.total_items;
        if (cart.total_items > 0) {
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    });

    // 2. Render List Item di Offcanvas Drawer
    const cartListContainer = document.getElementById('cartDrawerItems');
    const cartTotalPrice = document.getElementById('cartDrawerTotal');
    const checkoutBtn = document.getElementById('cartDrawerCheckoutBtn');

    if (cartListContainer && cartTotalPrice) {
        cartTotalPrice.textContent = cart.total_harga_formatted;

        const items = Object.entries(cart.items);
        if (items.length === 0) {
            cartListContainer.innerHTML = `
                <div class="text-center py-5 text-muted">
                    <span class="fs-1 d-block mb-3">🍲</span>
                    <h6>Keranjang Anda Masih Kosong</h6>
                    <p class="small">Yuk pilih menu Soto Lamongan favorit Anda sekarang!</p>
                </div>
            `;
            if (checkoutBtn) checkoutBtn.classList.add('disabled');
        } else {
            if (checkoutBtn) checkoutBtn.classList.remove('disabled');
            let html = '';
            items.forEach(([key, item]) => {
                html += `
                    <div class="card mb-3 border-0 shadow-sm rounded-3 p-2">
                        <div class="d-flex align-items-center gap-2">
                            <img src="uploads/menu/${item.gambar}" alt="${item.nama}" class="rounded-3" style="width: 55px; height: 55px; object-fit: cover;">
                            <div class="flex-grow-1">
                                <h6 class="mb-0 fw-bold fs-6 text-dark">${item.nama}</h6>
                                <span class="text-warning fw-bold small">${item.subtotal_formatted}</span>
                                <div class="d-flex align-items-center gap-2 mt-1">
                                    <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="updateCartQty('${key}', ${item.jumlah - 1})">-</button>
                                    <span class="small fw-bold">${item.jumlah}</span>
                                    <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="updateCartQty('${key}', ${item.jumlah + 1})">+</button>
                                </div>
                            </div>
                            <button class="btn btn-sm text-danger border-0 p-1" title="Hapus Item" onclick="removeCartItem('${key}')">
                                <i class="bi bi-trash-fill fs-5"></i>
                            </button>
                        </div>
                    </div>
                `;
            });
            cartListContainer.innerHTML = html;
        }
    }
}

/**
 * Toast Notifikasi Sederhana
 */
function showToast(message, type = 'success') {
    let toastContainer = document.getElementById('toastNotificationArea');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toastNotificationArea';
        toastContainer.style.position = 'fixed';
        toastContainer.style.bottom = '20px';
        toastContainer.style.left = '20px';
        toastContainer.style.zIndex = '9999';
        document.body.appendChild(toastContainer);
    }

    const toastId = 'toast_' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' : (type === 'danger' ? 'bg-danger' : 'bg-primary');
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0 mb-2 shadow" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body d-flex align-items-center gap-2">
                    <i class="bi bi-check-circle-fill"></i> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    const toastElem = document.getElementById(toastId);
    const bsToast = new bootstrap.Toast(toastElem, { delay: 3000 });
    bsToast.show();

    toastElem.addEventListener('hidden.bs.toast', () => {
        toastElem.remove();
    });
}
