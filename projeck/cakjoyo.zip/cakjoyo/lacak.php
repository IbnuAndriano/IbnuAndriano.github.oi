<?php
require_once __DIR__ . '/includes/header.php';

$search = clean($koneksi, $_GET['search'] ?? $_SESSION['last_order_code'] ?? '');
$orders = [];

if (!empty($search)) {
    $sql = "SELECT * FROM pesanan 
            WHERE kode_pesanan = '$search' 
               OR no_hp LIKE '%$search%' 
            ORDER BY id DESC LIMIT 5";
    $res = mysqli_query($koneksi, $sql);
    while ($row = mysqli_fetch_assoc($res)) {
        $orders[] = $row;
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-4">
                <span class="fs-1 text-warning"><i class="bi bi-search-heart"></i></span>
                <h2 class="fw-bold text-dark mt-2">Lacak Status Pesanan</h2>
                <p class="text-muted">Pantau status pengerjaan pesanan Soto Lamongan Anda secara real-time.</p>
            </div>

            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <form method="GET" action="lacak.php">
                    <label class="form-label fw-bold text-dark">Masukkan Kode Pesanan atau Nomor WhatsApp:</label>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-receipt"></i></span>
                        <input type="text" name="search" class="form-control border-start-0" placeholder="Contoh: CJ-20261112-XXXX atau 081234567890" value="<?= htmlspecialchars($search); ?>" required>
                        <button class="btn btn-primary-cakjoyo px-4 fw-bold" type="submit">
                            <i class="bi bi-search me-1"></i> Cari
                        </button>
                    </div>
                    <div class="form-text text-muted mt-2">Kode pesanan didapatkan setelah Anda menyelesaikan checkout.</div>
                </form>
            </div>

            <?php if (!empty($search)): ?>
                <?php if (count($orders) > 0): ?>
                    <h5 class="fw-bold text-dark mb-3">Hasil Pencarian Pesanan (<?= count($orders); ?> ditemukan):</h5>
                    <?php foreach ($orders as $ord): ?>
                        <div class="card border-0 shadow-sm p-4 rounded-4 mb-3">
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3 pb-3 border-bottom">
                                <div>
                                    <span class="badge bg-light text-dark border px-3 py-2 fs-6 fw-bold">
                                        <?= htmlspecialchars($ord['kode_pesanan']); ?>
                                    </span>
                                    <div class="small text-muted mt-1">
                                        <i class="bi bi-clock me-1"></i> <?= format_tanggal($ord['created_at']); ?>
                                    </div>
                                </div>
                                <div>
                                    <?= status_badge($ord['status']); ?>
                                </div>
                            </div>

                            <div class="row g-3 mb-3 small">
                                <div class="col-sm-6">
                                    <span class="text-muted">Nama Pemesan:</span>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($ord['nama_pelanggan']); ?></div>
                                </div>
                                <div class="col-sm-6">
                                    <span class="text-muted">Layanan:</span>
                                    <div class="fw-bold text-dark"><?= tipe_pesanan_label($ord['tipe_pesanan'], $ord['nomor_meja']); ?></div>
                                </div>
                                <div class="col-sm-6">
                                    <span class="text-muted">Metode Pembayaran:</span>
                                    <div class="fw-bold text-dark"><?= metode_bayar_label($ord['metode_pembayaran']); ?></div>
                                </div>
                                <div class="col-sm-6">
                                    <span class="text-muted">Total Pembayaran:</span>
                                    <div class="fs-6 fw-bold text-warning"><?= format_rupiah($ord['total_harga']); ?></div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 pt-2 border-top">
                                <a href="nota.php?kode=<?= urlencode($ord['kode_pesanan']); ?>" class="btn btn-outline-dark btn-sm rounded-pill px-3">
                                    <i class="bi bi-receipt me-1"></i> Lihat Rincian & Nota
                                </a>
                                <a href="<?= whatsapp_link($resto['no_wa'], 'Halo Cak Joyo, saya mau tanya status pesanan kode: ' . $ord['kode_pesanan']); ?>" target="_blank" class="btn btn-success btn-sm rounded-pill px-3">
                                    <i class="bi bi-whatsapp me-1"></i> Hubungi Resto
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="card border-0 shadow-sm p-5 text-center rounded-4">
                        <span class="fs-1 text-danger d-block mb-3"><i class="bi bi-emoji-frown"></i></span>
                        <h5 class="fw-bold text-dark">Pesanan Tidak Ditemukan</h5>
                        <p class="text-muted small">Tidak ada pesanan dengan kode atau nomor HP <strong>"<?= htmlspecialchars($search); ?>"</strong>. Pastikan Anda memasukkan kode yang benar.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
