<?php
// Redirect root dashboard.php ke admin/dashboard.php
header("Location: admin/dashboard.php");
exit;
?>
