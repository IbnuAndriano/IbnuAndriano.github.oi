<?php
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-4">
                <span class="fs-1 text-warning"><i class="bi bi-wallet2"></i></span>
                <h2 class="fw-bold text-dark mt-2">Metode Pembayaran Resmi</h2>
                <p class="text-muted">Pilihan pembayaran aman dan mudah di Soto Lamongan Cak Joyo.</p>
            </div>

            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-qr-code text-danger me-2"></i> 1. Pembayaran QRIS Nasional</h5>
                <p class="text-muted small">Pindai kode QRIS kami menggunakan aplikasi mobile banking (BCA, Mandiri, BRI, BNI) atau dompet digital (GoPay, OVO, Dana, ShopeePay, LinkAja).</p>
                <div class="text-center my-3">
                    <img src="uploads/qris/<?= htmlspecialchars($resto['qris_image']); ?>" alt="QRIS" class="img-fluid rounded border shadow-sm" style="max-width: 250px;" onerror="this.src='uploads/qris/qris_sample.png'">
                    <div class="small fw-bold text-dark mt-2">NMID: <?= htmlspecialchars($resto['qris_nmid']); ?></div>
                </div>
            </div>

            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-bank text-primary me-2"></i> 2. Transfer Rekening Bank</h5>
                <p class="text-muted small">Lakukan transfer langsung ke rekening bank operasional Cak Joyo:</p>
                <div class="p-3 bg-light rounded-3 border">
                    <pre class="mb-0 fw-bold text-dark" style="font-family: inherit; font-size: 0.95rem;"><?= htmlspecialchars($resto['rekening_bank']); ?></pre>
                </div>
            </div>

            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-cash-stack text-success me-2"></i> 3. Tunai di Tempat (Kasir / COD)</h5>
                <p class="text-muted small mb-0">Untuk pesanan makan di tempat (Dine-in) atau bungkus (Take Away), Anda dapat langsung membayar secara tunai kepada kasir atau pramusaji saat pesanan disajikan.</p>
            </div>

            <div class="text-center mt-4">
                <a href="index.php#menu-section" class="btn btn-primary-cakjoyo px-4 py-2">
                    <i class="bi bi-book me-1"></i> Buka Menu & Pesan Sekarang
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
