<?php
require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-5 text-center">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm p-4 rounded-4">
                <span class="fs-1 text-danger mb-2"><i class="bi bi-qr-code"></i></span>
                <h3 class="fw-bold text-dark">QRIS Resmi Cak Joyo</h3>
                <p class="text-muted small">Scan dengan aplikasi e-Wallet atau Mobile Banking apa saja</p>
                <div class="my-3">
                    <img src="uploads/qris/<?= htmlspecialchars($resto['qris_image']); ?>" alt="QRIS Cak Joyo" class="img-fluid rounded border shadow-sm" style="max-width: 280px;" onerror="this.src='uploads/qris/qris_sample.png'">
                </div>
                <h6 class="fw-bold text-dark mb-1"><?= htmlspecialchars($resto['nama_resto']); ?></h6>
                <div class="text-muted small mb-3">NMID: <?= htmlspecialchars($resto['qris_nmid']); ?></div>
                <div class="p-2 bg-warning-subtle text-dark rounded small">
                    <i class="bi bi-check2-circle text-success me-1"></i> Mendukung BCA, Mandiri, BRI, BNI, GoPay, OVO, Dana, ShopeePay
                </div>
                <div class="mt-4">
                    <a href="checkout.php" class="btn btn-primary-cakjoyo btn-sm px-4">
                        <i class="bi bi-arrow-left me-1"></i> Kembali ke Checkout
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
