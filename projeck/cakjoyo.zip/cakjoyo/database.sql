-- Database: db_cakjoyo
-- Aplikasi Website Penjualan Soto Ayam Lamongan Cak Joyo
-- Sesuai Dokumen Spesifikasi Resmi

CREATE DATABASE IF NOT EXISTS `db_cakjoyo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `db_cakjoyo`;

-- 1. Table Admin
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `nama_lengkap` VARCHAR(100) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Password hash for 'admin123'
INSERT INTO `admin` (`id`, `username`, `password`, `nama_lengkap`) VALUES
(1, 'admin', '$2y$10$GexRGNXkL8ZsfV51X4.Yz.tro1D7Sg/iH6e0khk6JAzoQAT3CkEee', 'Pak Cak Joyo');

-- 2. Table Kategori
DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama_kategori` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `urutan` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `kategori` (`id`, `nama_kategori`, `slug`, `urutan`) VALUES
(1, 'Daftar Menu', 'daftar-menu', 1),
(2, 'Menu Special', 'menu-special', 2),
(3, 'Toping', 'toping', 3),
(4, 'Minuman', 'minuman', 4);

-- 3. Table Menu
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kategori_id` INT NOT NULL,
  `nama_menu` VARCHAR(150) NOT NULL,
  `deskripsi` TEXT DEFAULT NULL,
  `harga` INT NOT NULL,
  `gambar` VARCHAR(255) DEFAULT 'default_soto.jpg',
  `status` ENUM('tersedia', 'habis') DEFAULT 'tersedia',
  `is_favorite` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (`kategori_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `menu` (`id`, `kategori_id`, `nama_menu`, `deskripsi`, `harga`, `gambar`, `status`, `is_favorite`) VALUES
-- Daftar Menu (Kategori 1)
(1, 1, 'Soto Ayam', 'Soto ayam khas Lamongan dengan suwiran ayam gurih, kuah kuning kaldu berempah dan koya.', 11000, 'soto_ayam.jpg', 'tersedia', 1),
(2, 1, 'Soto Daging', 'Soto daging sapi empuk dengan bumbu kuah khas Lamongan yang nikmat.', 16000, 'soto_daging.jpg', 'tersedia', 0),
(3, 1, 'Soto Babat', 'Soto dengan babat sapi pilihan yang empuk dan bersih dengan racikan rempah sedap.', 16000, 'soto_babat.jpg', 'tersedia', 0),
(4, 1, 'Soto Kikil', 'Soto dengan potongan kikil kenyal lembut dan gurih meresap kuah berempah.', 20000, 'soto_kikil.jpg', 'tersedia', 0),
(5, 1, 'Rabeg', 'Masakan khas berempah sedap dengan bumbu tradisional pilihan.', 16000, 'rabeg.jpg', 'tersedia', 0),
(6, 1, 'Rawon', 'Rawon daging khas Jawa Timur dengan kuah kluwek hitam gurih mantap.', 16000, 'rawon.jpg', 'tersedia', 0),
(7, 1, 'Nasi', 'Nasi putih pulen, hangat, dan wangi.', 5000, 'nasi.jpg', 'tersedia', 0),

-- Menu Special (Kategori 2)
(8, 2, 'Soto Ayam + Daging', 'Kombinasi suwiran ayam gurih dan potongan daging sapi lezat.', 23000, 'soto_ayam_daging.jpg', 'tersedia', 1),
(9, 2, 'Soto Ayam + Babat', 'Perpaduan ayam gurih dan babat sapi kenyal nikmat.', 23000, 'soto_ayam_babat.jpg', 'tersedia', 0),
(10, 2, 'Soto Ayam + Kikil', 'Kombinasi ayam dan kikil sapi kenyal lembut dengan kuah mantap.', 26000, 'soto_ayam_kikil.jpg', 'tersedia', 0),
(11, 2, 'Soto Daging + Kikil', 'Porsi istimewa daging sapi empuk dan kikil gurih berempah.', 30000, 'soto_daging_kikil.jpg', 'tersedia', 1),
(12, 2, 'Soto Ayam + Daging + Babat', 'Kombinasi komplit ayam, daging sapi, dan babat lezat.', 28000, 'soto_ayam_daging_babat.jpg', 'tersedia', 1),
(13, 2, 'Soto Daging + Kikil + Babat', 'Porsi mantap daging sapi, kikil lembut, dan babat empuk.', 35000, 'soto_daging_kikil_babat.jpg', 'tersedia', 1),
(14, 2, 'Soto Ayam + Daging + Babat + Kikil', 'Menu super spesial komplit dengan 4 isian istimewa sekaligus!', 40000, 'soto_spesial_komplit.jpg', 'tersedia', 1),

-- Toping (Kategori 3)
(15, 3, 'Dada', 'Potongan ayam bagian dada empuk dan berdaging tebal.', 50000, 'topping_dada.jpg', 'tersedia', 0),
(16, 3, 'Paha', 'Potongan ayam bagian paha gurih dan lembut meresap.', 25000, 'topping_paha.jpg', 'tersedia', 0),
(17, 3, 'Sayap', 'Potongan sayap ayam gurih renyah pendamping soto.', 5000, 'topping_sayap.jpg', 'tersedia', 0),
(18, 3, 'Punggung', 'Bagian punggung ayam berbumbu gurih sedap.', 5000, 'topping_punggung.jpg', 'tersedia', 0),
(19, 3, 'Ceker', 'Ceker ayam lembut bumbu rempah gurih.', 1000, 'topping_ceker.jpg', 'tersedia', 0),

-- Minuman (Kategori 4)
(20, 4, 'Es Jeruk', 'Jeruk manis peras segar dingin alami.', 2000, 'es_jeruk.jpg', 'tersedia', 1),
(21, 4, 'Es Jeruk Nipis', 'Jeruk nipis asli segar asam manis menyegarkan dahaga.', 2000, 'es_jeruk_nipis.jpg', 'tersedia', 0),
(22, 4, 'Es Teh Manis', 'Teh melati wangi manis dingin menyegarkan.', 3000, 'es_teh_manis.jpg', 'tersedia', 0),
(23, 4, 'Es Teh Tawar', 'Teh segar dingin tanpa gula pelepas dahaga.', 1000, 'es_teh_tawar.jpg', 'tersedia', 0),
(24, 4, 'Es Teh Botol', 'Teh botol kemasan dingin praktis dan segar.', 6000, 'es_teh_botol.jpg', 'tersedia', 0),
(25, 4, 'Air Mineral', 'Air mineral murni kemasan dingin / biasa.', 4000, 'air_mineral.jpg', 'tersedia', 0);

-- 4. Table Pesanan
DROP TABLE IF EXISTS `pesanan`;
CREATE TABLE `pesanan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kode_pesanan` VARCHAR(50) NOT NULL UNIQUE,
  `nama_pelanggan` VARCHAR(100) NOT NULL,
  `no_hp` VARCHAR(25) NOT NULL,
  `tipe_pesanan` ENUM('dine_in', 'take_away', 'delivery') NOT NULL DEFAULT 'dine_in',
  `nomor_meja` VARCHAR(20) DEFAULT NULL,
  `alamat_pengiriman` TEXT DEFAULT NULL,
  `metode_pembayaran` VARCHAR(50) NOT NULL DEFAULT 'cash',
  `total_harga` INT NOT NULL DEFAULT 0,
  `catatan` TEXT DEFAULT NULL,
  `bukti_bayar` VARCHAR(255) DEFAULT NULL,
  `status` ENUM('Baru', 'Diproses', 'Siap', 'Selesai', 'Dibatalkan') NOT NULL DEFAULT 'Baru',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (`kode_pesanan`),
  INDEX (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Table Detail Pesanan
DROP TABLE IF EXISTS `detail_pesanan`;
CREATE TABLE `detail_pesanan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `pesanan_id` INT NOT NULL,
  `menu_id` INT NOT NULL,
  `nama_menu` VARCHAR(150) NOT NULL,
  `harga` INT NOT NULL,
  `jumlah` INT NOT NULL,
  `subtotal` INT NOT NULL,
  `catatan_item` VARCHAR(255) DEFAULT NULL,
  INDEX (`pesanan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Table Pengaturan Restoran
DROP TABLE IF EXISTS `pengaturan`;
CREATE TABLE `pengaturan` (
  `id` INT PRIMARY KEY,
  `nama_resto` VARCHAR(100) NOT NULL,
  `slogan` VARCHAR(255) NOT NULL,
  `no_wa` VARCHAR(25) NOT NULL,
  `alamat` TEXT NOT NULL,
  `jam_buka` VARCHAR(100) NOT NULL,
  `qris_image` VARCHAR(255) DEFAULT 'qris_sample.png',
  `qris_nmid` VARCHAR(50) DEFAULT 'ID1020030040050',
  `rekening_bank` TEXT NOT NULL,
  `ewallet_info` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengaturan` (`id`, `nama_resto`, `slogan`, `no_wa`, `alamat`, `jam_buka`, `qris_image`, `qris_nmid`, `rekening_bank`, `ewallet_info`) VALUES
(1, 'Soto ayam lamongan cak joyo', 'Menerima pesanan - Kelezatan Asli Soto Lamongan', '081292543664', 'Jl. Pemuda No. 45, Lamongan / Surabaya, Jawa Timur', 'Buka 06.00-17.00', 'qris_sample.png', 'ID1020030040050', 'BCA: 8735123490 a.n Pak Cak Joyo\nMandiri: 142001928374 a.n Pak Cak Joyo\nBRI: 019201827364 a.n Pak Cak Joyo', 'GoPay: 081292543664 a.n Pak Cak Joyo\nOVO: 081292543664 a.n Pak Cak Joyo\nDANA: 081292543664 a.n Pak Cak Joyo\nShopeePay: 081292543664 a.n Pak Cak Joyo\nLinkAja: 081292543664 a.n Pak Cak Joyo');
