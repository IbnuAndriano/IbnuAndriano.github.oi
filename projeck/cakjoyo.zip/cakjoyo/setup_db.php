<?php
/**
 * Setup & Migrasi Database Otomatis untuk Soto Lamongan Cak Joyo
 * Buka file ini di browser: http://localhost/cakjoyo/setup_db.php
 */

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "db_cakjoyo";

$pesan = [];
$status = "info";

try {
    // 1. Hubungkan ke MySQL Server
    $conn = @new mysqli($host, $user, $pass);
    if ($conn->connect_error) {
        throw new Exception("Gagal terhubung ke MySQL Server: " . $conn->connect_error . ". Pastikan XAMPP MySQL sudah dinyalakan (klik START di XAMPP Control Panel)!");
    }

    // 2. Buat Database
    $conn->query("CREATE DATABASE IF NOT EXISTS `$dbname` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $conn->select_db($dbname);
    $pesan[] = "Database `$dbname` berhasil dipersiapkan.";

    // 3. Baca dan eksekusi skrip SQL dari database.sql
    $sqlFile = __DIR__ . '/database.sql';
    if (!file_exists($sqlFile)) {
        throw new Exception("File database.sql tidak ditemukan di direktori proyek!");
    }

    $sqlContent = file_get_contents($sqlFile);
    // Jalankan multi query
    if ($conn->multi_query($sqlContent)) {
        do {
            // Free result
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->more_results() && $conn->next_result());
        $pesan[] = "Semua tabel (admin, kategori, menu, pesanan, detail_pesanan, pengaturan) dan data awal berhasil dibuat.";
        $status = "success";
    } else {
        throw new Exception("Gagal mengeksekusi skema database: " . $conn->error);
    }

    $conn->close();
} catch (Exception $e) {
    $status = "danger";
    $pesan[] = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inisialisasi Database - Soto Lamongan Cak Joyo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #FFFBEB 0%, #FEF3C7 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        }
        .btn-cakjoyo {
            background: #D97706;
            color: #fff;
            border-radius: 8px;
            font-weight: 600;
        }
        .btn-cakjoyo:hover {
            background: #B45309;
            color: #fff;
        }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card p-4 p-md-5">
                <div class="text-center mb-4">
                    <span class="fs-1 text-warning"><i class="bi bi-database-fill-gear"></i></span>
                    <h2 class="fw-bold mt-2 text-dark">Setup Database Cak Joyo</h2>
                    <p class="text-muted">Aplikasi Website Penjualan Soto Lamongan Cak Joyo</p>
                </div>

                <?php if ($status === 'success'): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
                        <i class="bi bi-check-circle-fill fs-4 me-3"></i>
                        <div>
                            <strong>Berhasil!</strong> Database <code>db_cakjoyo</code> dan tabel pendukung siap digunakan.
                        </div>
                    </div>
                    <ul class="list-group list-group-flush mb-4">
                        <?php foreach($pesan as $p): ?>
                            <li class="list-group-item text-success"><i class="bi bi-check2 me-2"></i><?= htmlspecialchars($p); ?></li>
                        <?php endforeach; ?>
                    </ul>

                    <div class="card bg-light p-3 mb-4 border">
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-lock me-1"></i> Akun Login Admin Bawaan:</h6>
                        <div class="d-flex justify-content-between mb-1">
                            <span>Username:</span>
                            <span class="badge bg-secondary">admin</span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Password:</span>
                            <span class="badge bg-secondary">admin123</span>
                        </div>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                        <a href="index.php" class="btn btn-cakjoyo px-4 py-2"><i class="bi bi-shop me-2"></i> Buka Website Pembeli</a>
                        <a href="admin/login.php" class="btn btn-outline-dark px-4 py-2"><i class="bi bi-speedometer2 me-2"></i> Masuk Panel Admin</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        <h5 class="alert-heading fw-bold"><i class="bi bi-exclamation-triangle-fill me-2"></i> Terjadi Masalah</h5>
                        <?php foreach($pesan as $p): ?>
                            <p class="mb-1"><?= htmlspecialchars($p); ?></p>
                        <?php endforeach; ?>
                        <hr>
                        <p class="small mb-0"><strong>Tips:</strong> Buka <b>XAMPP Control Panel</b>, pastikan modul <b>Apache</b> dan <b>MySQL</b> dalam status <span class="badge bg-success">Running</span>, lalu refresh halaman ini.</p>
                    </div>
                    <div class="text-center mt-3">
                        <a href="setup_db.php" class="btn btn-primary"><i class="bi bi-arrow-clockwise me-1"></i> Coba Lagi</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
