<?php
/**
 * SISTEM INFORMASI PENANGGULANGAN KEMISKINAN TERPADU (SIPANDU SDGs GOAL 1)
 * Kabupaten Tangerang 2026 — Proyek Rekayasa Sistem Informasi Semester 2
 * Author: Ibnu Andriano (S1 Sistem Informasi — Universitas Bina Bangsa)
 *
 * Fitur & Keamanan Disamakan 100% dengan Portofolio & Aplikasi Cak Joyo:
 * - Proteksi Kontrol Admin Khusus (Login PadukaIbnu / Shared Session dengan Portofolio)
 * - Sensor Privasi NIK Otomatis untuk Pengunjung Publik & Kontrol Visibilitas Modul
 * - Hybrid Storage (MySQL + Local JSON Persistence) — 100% Langsung Berhasil Simpan
 * - Data Resmi BPS Kabupaten Tangerang 2026 (265,90 Ribu Jiwa / 6,42%) + Peta 29 Kecamatan
 */

require_once __DIR__ . '/sdgs/sdgs_backend.php';
$s_portofolio = get_settings($koneksi);

function sdgs_mod_visible($key, $cfg, $is_admin) {
    if ($is_admin) return true;
    return !empty($cfg[$key]);
}
$mask_nik = !empty($sdgs_cfg['mask_nik_public']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>SIPANDU SDGs Goal 1 — Kabupaten Tangerang 2026 | <?= htmlspecialchars($s_portofolio['nama']); ?></title>
  <meta name="description" content="Sistem Informasi Penanggulangan Kemiskinan Terpadu (SDGs Goal 1: Tanpa Kemiskinan) Kabupaten Tangerang berbasis Data Resmi BPS 2026 (265,90 ribu jiwa / 6,42%), Open Data, dan DTSEN Kemenko PM.">
  <meta name="theme-color" content="#090B10">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
  <link rel="stylesheet" href="sdgs/assets/sdgs.css">
  <style>
    .sdgs-admin-floating {
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 950;
      background: rgba(15, 23, 42, 0.94);
      border: 1px solid rgba(56, 189, 248, 0.4);
      backdrop-filter: blur(14px);
      padding: 10px 18px;
      border-radius: 999px;
      display: flex;
      align-items: center;
      gap: 12px;
      box-shadow: 0 12px 34px rgba(0, 0, 0, 0.55);
      font-size: 12.5px;
      color: #F8FAFC;
      flex-wrap: wrap;
    }
    .vis-switch-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
      gap: 10px;
      margin-bottom: 16px;
    }
    .vis-switch-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 11px 14px;
      border-radius: 10px;
      background: var(--bg-primary);
      border: 1px solid var(--border-subtle);
      cursor: pointer;
      font-size: 13px;
    }
    .vis-switch-item input {
      width: 17px;
      height: 17px;
      accent-color: var(--emerald);
      cursor: pointer;
    }
  </style>
</head>
<body>

  <!-- ==================== TOP HUD BAR ==================== -->
  <div class="sdgs-hud-bar">
    <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
      <span class="hud-item">
        <i class="fa-solid fa-circle" style="color: var(--emerald); font-size: 8px;"></i>
        <span>SIPANDU SDGs-1 // KAB. TANGERANG 2026</span>
      </span>
      <span class="hud-item">
        <i class="fa-solid fa-database" style="color: var(--accent);"></i>
        <span><?= $koneksi ? 'MYSQL + HYBRID SYNC ACTIVE' : 'HYBRID STORAGE ACTIVE'; ?></span>
      </span>
      <span class="hud-item">
        <i class="fa-solid fa-chart-simple" style="color: var(--sdgs-red);"></i>
        <span>BPS 2025/2026: <strong>265,90 RIBU JIWA (6,42%)</strong></span>
      </span>
    </div>

    <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
      <?php if ($sdgs_is_admin): ?>
        <span class="hud-item" style="border-color: rgba(16,185,129,0.4); color: var(--emerald);">
          <i class="fa-solid fa-shield-halved"></i>
          <span>ADMIN: <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Ibnu Andriano'); ?></span>
        </span>
      <?php else: ?>
        <span class="hud-item">
          <i class="fa-solid fa-eye" style="color: var(--accent);"></i>
          <span>MODE PUBLIK (NIK TERSENSOR)</span>
        </span>
      <?php endif; ?>
      <a href="http://localhost/cakjoyo" target="_blank" class="hud-item" style="color: var(--amber); text-decoration: none;">
        <i class="fa-solid fa-bowl-food"></i>
        <span>Web Cak Joyo</span>
      </a>
      <a href="admin/index.php" class="hud-item" style="color: var(--accent); text-decoration: none;">
        <i class="fa-solid fa-sliders"></i>
        <span>Admin Portofolio</span>
      </a>
    </div>
  </div>

  <!-- ==================== STICKY NAVIGATION BAR ==================== -->
  <header class="sdgs-navbar">
    <div class="sdgs-nav-inner">
      <div style="display: flex; align-items: center; gap: 14px;">
        <a href="index.php#projects" class="btn-sdgs btn-sdgs-sm" title="Kembali ke Portofolio Utama">
          <i class="fa-solid fa-arrow-left"></i> Portofolio
        </a>
        <a href="sdgs-demo.php" class="sdgs-brand">
          <div class="sdgs-brand-mark">1</div>
          <div>
            <div class="sdgs-brand-title">
              <span>SIPANDU SDGs Goal 1</span>
              <span class="pill-badge crimson" style="font-size: 10.5px;">TANPA KEMISKINAN</span>
            </div>
            <div class="sdgs-brand-sub"><?= htmlspecialchars($sdgs_cfg['nama_instansi']); ?></div>
          </div>
        </a>
      </div>

      <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
        <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="switchSdgsModule('mod-monitoring', true)">
          <i class="fa-solid fa-chart-line" style="color:var(--sdgs-red)"></i> Data BPS 2026
        </button>
        <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="goToPetaKecamatan()">
          <i class="fa-solid fa-map-location-dot" style="color:var(--accent)"></i> Peta 29 Kecamatan
        </button>
        <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="switchSdgsModule('mod-donasi', true)">
          <i class="fa-solid fa-qrcode" style="color:var(--emerald)"></i> Donasi QRIS
        </button>
        <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="switchSdgsModule('mod-pengaduan', true)">
          <i class="fa-solid fa-magnifying-glass" style="color:var(--amber)"></i> Lacak Aduan
        </button>

        <?php if ($sdgs_is_admin): ?>
          <button type="button" class="btn-sdgs btn-sdgs-emerald btn-sdgs-sm" onclick="switchSdgsModule('mod-admin', true)">
            <i class="fa-solid fa-shield-halved"></i> Kontrol Admin
          </button>
          <form method="POST" action="sdgs-demo.php" style="display:inline;">
            <input type="hidden" name="sdgs_action" value="sdgs_admin_logout">
            <button type="submit" class="btn-sdgs btn-sdgs-sm" title="Keluar dari Mode Admin">
              <i class="fa-solid fa-power-off" style="color:var(--sdgs-red)"></i>
            </button>
          </form>
        <?php else: ?>
          <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="openAdminLoginModal()" title="Login Pemilik / Admin SDGs">
            <i class="fa-solid fa-lock" style="color:var(--accent)"></i> Login Admin
          </button>
        <?php endif; ?>

        <button type="button" class="icon-btn-sdgs" id="themeToggle" title="Ubah Tema Gelap / Terang" aria-label="Toggle Theme">
          <i class="fa-solid fa-sun"></i>
        </button>
      </div>
    </div>
  </header>

  <!-- ==================== MAIN CONTAINER ==================== -->
  <main class="sdgs-wrapper">

    <!-- 1. HERO EXECUTIVE SUMMARY & DATA RESMI BPS KABUPATEN TANGERANG 2026 -->
    <section class="sdgs-hero-card">
      <div class="sdgs-hero-grid">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 12px;">
            <span class="pill-badge crimson"><i class="fa-solid fa-circle-check"></i> PUBLIKASI RESMI BPS KABUPATEN TANGERANG 2026</span>
            <span class="pill-badge cyan"><i class="fa-solid fa-calendar-check"></i> Rilis: 25 September 2026</span>
            <?php if ($sdgs_is_admin): ?>
              <span class="pill-badge emerald"><i class="fa-solid fa-unlock-keyhole"></i> Akses Penuh Admin Aktif</span>
            <?php else: ?>
              <span class="pill-badge"><i class="fa-solid fa-shield"></i> Portal Publik Terproteksi</span>
            <?php endif; ?>
          </div>

          <h1 style="font-size: 27px; margin-bottom: 10px;">
            Data & Sistem Pengentasan Kemiskinan SDGs Goal 1 — Kabupaten Tangerang 2026
          </h1>
          <p style="color: var(--text-muted); font-size: 14.5px; margin-bottom: 16px; line-height: 1.65;">
            Berdasarkan publikasi resmi <strong>Badan Pusat Statistik (BPS) Kabupaten Tangerang 2026</strong> (<em>Statistik Daerah Kabupaten Tangerang 2026</em>, rilis 25 September 2026), jumlah penduduk miskin tahun 2025 di Kabupaten Tangerang tercatat sebesar <strong style="color:var(--text-heading)">265,90 ribu jiwa (6,42% dari total penduduk)</strong>. Seluruh kendali data sensitif, verifikasi bansos, dan visibilitas modul dikunci khusus Admin.
          </p>

          <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <button type="button" class="btn-sdgs btn-sdgs-primary" onclick="goToPetaKecamatan()">
              <i class="fa-solid fa-map-location-dot"></i> Eksplorasi Peta 29 Kecamatan
            </button>

            <?php if ($sdgs_is_admin): ?>
              <button type="button" class="btn-sdgs btn-sdgs-emerald" onclick="openPendudukModal()">
                <i class="fa-solid fa-user-plus"></i> + Input Warga (Admin)
              </button>
              <button type="button" class="btn-sdgs" onclick="printOfficialSdgsReport('LAP-EKSEKUTIF-BPS-2026')">
                <i class="fa-solid fa-file-pdf" style="color:var(--sdgs-red)"></i> Cetak Laporan PDF
              </button>
            <?php else: ?>
              <button type="button" class="btn-sdgs" onclick="switchSdgsModule('mod-pengaduan', true)">
                <i class="fa-solid fa-paper-plane" style="color:var(--amber)"></i> Lapor / Lacak Pengaduan
              </button>
              <button type="button" class="btn-sdgs" onclick="openAdminLoginModal()">
                <i class="fa-solid fa-shield-halved" style="color:var(--accent)"></i> Masuk Panel Admin
              </button>
            <?php endif; ?>

            <a href="sdgs-demo.php?export_csv=bps_kecamatan" class="btn-sdgs">
              <i class="fa-solid fa-file-csv" style="color:var(--emerald)"></i> Unduh Dataset BPS (CSV)
            </a>
          </div>
        </div>

        <!-- 4 Kotak Indikator Makro Resmi BPS 2026 -->
        <div class="bps-highlight-grid">
          <div class="bps-stat-box primary-bps">
            <div class="bps-stat-label">
              <span>PENDUDUK MISKIN (BPS)</span>
              <span class="pill-badge crimson" style="font-size:10px;">Resmi BPS 2026</span>
            </div>
            <div class="bps-stat-value" id="kpiBpsJumlah">265,90 <small style="font-size:14px;color:var(--text-muted)">Ribu Jiwa</small></div>
            <div class="bps-stat-meta">
              <span style="color:var(--emerald);font-weight:700;"><i class="fa-solid fa-arrow-trend-down"></i> -0,53 rb jiwa</span> dari 2024 (266,43 rb)
            </div>
          </div>

          <div class="bps-stat-box primary-bps">
            <div class="bps-stat-label">
              <span>PERSENTASE KEMISKINAN</span>
              <span class="pill-badge emerald" style="font-size:10px;">Turun -0,13%</span>
            </div>
            <div class="bps-stat-value" id="kpiBpsPersen">6,42%</div>
            <div class="bps-stat-meta">
              Tahun 2024: <strong>6,55%</strong> • Target 2026: <strong>5,98%</strong>
            </div>
          </div>

          <div class="bps-stat-box">
            <div class="bps-stat-label">
              <span>GARIS KEMISKINAN DAERAH</span>
              <i class="fa-solid fa-wallet" style="color:var(--amber)"></i>
            </div>
            <div class="bps-stat-value" id="kpiBpsGk" style="font-size:22px;">Rp <?= number_format((int)$sdgs_cfg['garis_kemiskinan'], 0, ',', '.'); ?></div>
            <div class="bps-stat-meta">Per Kapita / Bulan • P1: 0,94 | P2: 0,21</div>
          </div>

          <div class="bps-stat-box">
            <div class="bps-stat-label">
              <span>PENDIDIKAN & KESEHATAN</span>
              <i class="fa-solid fa-heart-pulse" style="color:var(--accent)"></i>
            </div>
            <div class="bps-stat-value" id="kpiBpsIpm" style="font-size:19px;">IPM 75,04 • RLS 9,86 Thn</div>
            <div class="bps-stat-meta">Sanitasi Layak: <strong>89,45%</strong> • Air Layak: <strong>93,80%</strong></div>
          </div>
        </div>
      </div>
    </section>

    <!-- 2. EMPAT KARTU SUMBER DATA RESMI -->
    <section class="sources-grid" aria-label="Sumber Resmi Data SDGs Kabupaten Tangerang">
      <?php foreach ($SDGS_SUMBER_RESMI as $src): ?>
        <div class="source-card">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: center; gap: 6px;">
              <span class="mono" style="font-size: 11px; color: var(--accent); font-weight: 600;"><?= htmlspecialchars($src['kode']); ?></span>
              <span class="pill-badge emerald" style="font-size: 10.5px;"><?= htmlspecialchars($src['badge']); ?></span>
            </div>
            <div class="source-title"><?= htmlspecialchars($src['judul']); ?></div>
            <div style="font-size: 11.5px; color: var(--text-dim); margin: 2px 0 6px;"><?= htmlspecialchars($src['instansi']); ?></div>
            <p class="source-desc"><?= htmlspecialchars($src['cakupan']); ?></p>
          </div>
          <div style="padding-top: 8px; border-top: 1px solid var(--border-subtle); display: flex; justify-content: space-between; align-items: center;">
            <span class="mono" style="font-size: 11px; color: var(--text-dim);"><?= htmlspecialchars($src['rilis']); ?></span>
            <a href="<?= htmlspecialchars($src['url']); ?>" target="_blank" rel="noopener noreferrer" class="btn-sdgs btn-sdgs-sm" style="padding: 4px 10px; font-size: 11.5px;">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> Sumber Resmi
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    </section>

    <!-- 3. GLOBAL INTERACTIVE FILTER BAR -->
    <section class="global-filter-bar" aria-label="Filter Interaktif Wilayah, Tahun, dan Indikator">
      <div class="filter-group">
        <span class="mono" style="font-size: 12px; font-weight: 700; color: var(--accent);">
          <i class="fa-solid fa-sliders"></i> FILTER INTERAKTIF:
        </span>

        <select id="globalFilterKecamatan" class="filter-control" aria-label="Filter Kecamatan">
          <option value="">Semua Wilayah (29 Kecamatan Kab. Tangerang)</option>
          <?php foreach ($SDGS_KECAMATAN_29 as $k): ?>
            <option value="<?= htmlspecialchars($k['nama']); ?>">
              Kec. <?= htmlspecialchars($k['nama']); ?> — <?= $k['persen']; ?>% (<?= $k['miskin_ribu']; ?> rb jiwa • Zona <?= $k['zona']; ?>)
            </option>
          <?php endforeach; ?>
        </select>

        <select id="globalFilterTahun" class="filter-control" aria-label="Filter Periode Tahun">
          <option value="2025" selected>Tahun 2025 (Rilis Resmi BPS 2026 — 265,90 rb / 6,42%)</option>
          <option value="2026">Tahun 2026 (Proyeksi & Target RKPD — 252,40 rb / 5,98%)</option>
          <option value="2024">Tahun 2024 (Data BPS — 266,43 rb / 6,55%)</option>
          <option value="2023">Tahun 2023 (Data BPS — 276,33 rb / 6,93%)</option>
          <option value="2022">Tahun 2022 (Data BPS — 270,52 rb / 6,92%)</option>
          <option value="2021">Tahun 2021 (Data BPS — 272,35 rb / 7,12%)</option>
          <option value="2020">Tahun 2020 (Data BPS — 242,02 rb / 6,23%)</option>
        </select>

        <select id="globalFilterIndikator" class="filter-control" aria-label="Filter Indikator Terkait">
          <option value="all">Indikator: Komposit SDGs (IPM, Sanitasi & Pengangguran)</option>
          <option value="pendidikan">Indikator Pendidikan (Rata-rata Lama Sekolah & IPM)</option>
          <option value="kesehatan">Indikator Kesehatan & Sanitasi Layak (%)</option>
          <option value="pendapatan">Indikator Pendapatan (Garis Kemiskinan Rp/Kapita & TPT)</option>
        </select>
      </div>

      <div class="filter-group">
        <button type="button" id="btnResetGlobalFilter" class="btn-sdgs btn-sdgs-sm">
          <i class="fa-solid fa-rotate-left"></i> Reset Filter
        </button>
      </div>
    </section>

    <!-- 4. WORKSPACE UTAMA: SIDEBAR 10 MODUL & PANEL KONTEN -->
    <div class="workspace-grid">

      <!-- SIDEBAR NAVIGASI 10 MODUL -->
      <aside class="module-sidebar" aria-label="Navigasi 10 Modul SDGs">
        <div class="module-nav-title">
          <span><i class="fa-solid fa-layer-group" style="color:var(--sdgs-red)"></i> 10 MODUL SISTEM SDGs 1</span>
          <span class="pill-badge <?= $sdgs_is_admin ? 'emerald' : ''; ?>"><?= $sdgs_is_admin ? 'ADMIN' : 'PUBLIK'; ?></span>
        </div>

        <div class="module-nav-list">
          <?php if (sdgs_mod_visible('show_mod_monitoring', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn active" data-target="mod-monitoring">
              <i class="fa-solid fa-chart-pie"></i>
              <span>7. Monitoring & Data BPS</span>
              <span class="mod-count">2026</span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_penduduk', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-penduduk">
              <i class="fa-solid fa-id-card"></i>
              <span>1. Pendataan Penduduk</span>
              <span class="mod-count"><?= count($list_penduduk); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_bansos', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-bansos">
              <i class="fa-solid fa-hand-holding-heart"></i>
              <span>2. Bantuan Sosial (Bansos)</span>
              <span class="mod-count"><?= count($list_bansos); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_umkm', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-umkm">
              <i class="fa-solid fa-store"></i>
              <span>3. Program UMKM Binaan</span>
              <span class="mod-count"><?= count($list_umkm); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_loker', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-loker">
              <i class="fa-solid fa-briefcase"></i>
              <span>4. Bursa Lowongan Kerja</span>
              <span class="mod-count"><?= count($list_loker); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_pelatihan', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-pelatihan">
              <i class="fa-solid fa-graduation-cap"></i>
              <span>5. Pelatihan & Sertifikat</span>
              <span class="mod-count"><?= count($list_pelatihan); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_donasi', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-donasi">
              <i class="fa-solid fa-circle-dollar-to-slot"></i>
              <span>6. Donasi & Crowdfunding</span>
              <span class="mod-count"><?= count($list_kampanye); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_pengaduan', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-pengaduan">
              <i class="fa-solid fa-triangle-exclamation"></i>
              <span>8. Pengaduan & Lacak</span>
              <span class="mod-count"><?= count($list_pengaduan); ?></span>
            </button>
          <?php endif; ?>

          <?php if (sdgs_mod_visible('show_mod_peta', $sdgs_cfg, $sdgs_is_admin)): ?>
            <button type="button" class="module-tab-btn" data-target="mod-peta">
              <i class="fa-solid fa-map-location-dot"></i>
              <span>9. Peta 29 Kecamatan</span>
              <span class="mod-count">29</span>
            </button>
          <?php endif; ?>

          <button type="button" class="module-tab-btn" data-target="mod-admin">
            <i class="fa-solid fa-shield-halved"></i>
            <span>10. Admin Control & PDF</span>
            <span class="mod-count"><?= $sdgs_is_admin ? 'OPEN' : 'LOCK'; ?></span>
          </button>
        </div>

        <div style="margin-top: 16px; padding: 12px; border-radius: 10px; background: var(--bg-secondary); border: 1px solid var(--border-subtle); font-size: 12px; color: var(--text-muted);">
          <?php if ($sdgs_is_admin): ?>
            <div style="font-weight: 700; color: var(--emerald); margin-bottom: 4px;">
              <i class="fa-solid fa-lock-open"></i> Kontrol Admin Aktif
            </div>
            Anda login sebagai <strong><?= htmlspecialchars($_SESSION['admin_name'] ?? 'PadukaIbnu'); ?></strong>. Semua tombol Tambah, Edit, Verifikasi, Hapus & Visibilitas terbuka.
          <?php else: ?>
            <div style="font-weight: 700; color: var(--text-heading); margin-bottom: 4px;">
              <i class="fa-solid fa-shield-halved" style="color:var(--accent)"></i> Proteksi Publik Aktif
            </div>
            Edit data, verifikasi bansos, dan NIK penuh dikunci khusus Admin.
            <button type="button" class="btn-sdgs btn-sdgs-sm" style="width:100%;margin-top:8px;" onclick="openAdminLoginModal()">
              <i class="fa-solid fa-right-to-bracket"></i> Login Admin
            </button>
          <?php endif; ?>
        </div>
      </aside>

      <!-- AREA KONTEN 10 MODUL -->
      <div class="module-content-area">

        <!-- =================================================================
             MODUL 7: MONITORING SDGs GOAL 1 & ANALITIK RESMI BPS 2020-2026
             ================================================================= -->
        <section class="module-pane active" id="mod-monitoring">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge crimson" style="margin-bottom:6px;"><i class="fa-solid fa-chart-line"></i> MODUL 7 // MONITORING & STATISTIK MAKRO</span>
                <h2 class="panel-title">Dashboard Monitoring SDGs Goal 1 — Kabupaten Tangerang (BPS 2026)</h2>
                <p class="panel-subtitle">Visualisasi tren penurunan angka kemiskinan, indikator pendidikan, kesehatan, pendapatan, serta realisasi intervensi daerah.</p>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="goToPetaKecamatan()">
                  <i class="fa-solid fa-map"></i> Buka Peta Sebaran
                </button>
                <?php if ($sdgs_is_admin): ?>
                  <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="printOfficialSdgsReport('MONITORING-BPS-2026')">
                    <i class="fa-solid fa-print"></i> Cetak Laporan BPS
                  </button>
                <?php endif; ?>
              </div>
            </div>

            <div class="kpi-row-4">
              <div class="kpi-box">
                <div class="bps-stat-label"><span>INDIVIDU DESIL 1 (DTSEN 2026)</span><i class="fa-solid fa-users-viewfinder" style="color:var(--sdgs-red)"></i></div>
                <div class="bps-stat-value" style="font-size:23px;"><?= number_format($SDGS_OFFICIAL_META['desil1_dtsen_jiwa'], 0, ',', '.'); ?> <small style="font-size:12px">Jiwa</small></div>
                <div class="bps-stat-meta">Sasaran Prioritas Kemiskinan Ekstrem</div>
              </div>
              <div class="kpi-box cyan">
                <div class="bps-stat-label"><span>CAKUPAN VERIFIKASI BANSOS</span><i class="fa-solid fa-hand-holding-heart" style="color:var(--accent)"></i></div>
                <div class="bps-stat-value" style="font-size:23px;"><?= $rasio_bansos_valid; ?>%</div>
                <div class="bps-stat-meta"><?= $bansos_verified_count; ?> dari <?= count($list_bansos); ?> Penyaluran Terverifikasi</div>
              </div>
              <div class="kpi-box amber">
                <div class="bps-stat-label"><span>OMZET UMKM BINAAN / BLN</span><i class="fa-solid fa-store" style="color:var(--amber)"></i></div>
                <div class="bps-stat-value" style="font-size:23px;">Rp <?= number_format($total_omzet_umkm / 1000000, 1, ',', '.'); ?> <small style="font-size:12px">Juta</small></div>
                <div class="bps-stat-meta"><?= count($list_umkm); ?> Unit Usaha Pra-Sejahtera Aktif</div>
              </div>
              <div class="kpi-box emerald">
                <div class="bps-stat-label"><span>DANA DONASI CROWDFUNDING</span><i class="fa-solid fa-circle-dollar-to-slot" style="color:var(--emerald)"></i></div>
                <div class="bps-stat-value" style="font-size:23px;">Rp <?= number_format($total_donasi_terkumpul / 1000000, 1, ',', '.'); ?> <small style="font-size:12px">Juta</small></div>
                <div class="bps-stat-meta">Tersalurkan: Rp <?= number_format($total_donasi_tersalurkan, 0, ',', '.'); ?></div>
              </div>
            </div>

            <div class="charts-grid-2">
              <div class="chart-card">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:8px;">
                  <div>
                    <h3 style="font-size:15.5px;">Tren Penduduk Miskin (Ribu Jiwa) & Persentase Kemiskinan (%)</h3>
                    <div style="font-size:12px;color:var(--text-muted);">Kabupaten Tangerang Tahun 2020–2026 (Sumber: BPS Kab. Tangerang)</div>
                  </div>
                  <span class="pill-badge crimson">2025: 265,90 rb (6,42%)</span>
                </div>
                <div style="height:290px;position:relative;">
                  <canvas id="bpsTrendChart"></canvas>
                </div>
              </div>

              <div class="chart-card">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:8px;">
                  <div>
                    <h3 style="font-size:15.5px;">Korelasi Indikator SDGs (IPM, Pendidikan, Sanitasi & Pendapatan)</h3>
                    <div style="font-size:12px;color:var(--text-muted);">Gunakan dropdown filter untuk mengganti dimensi indikator</div>
                  </div>
                  <span class="pill-badge cyan">Multi-Indikator</span>
                </div>
                <div style="height:290px;position:relative;">
                  <canvas id="sdgsCorrelationChart"></canvas>
                </div>
              </div>
            </div>

            <div style="margin-top:18px;">
              <h3 style="font-size:16px;margin-bottom:10px;">
                <i class="fa-solid fa-table-list" style="color:var(--accent)"></i> Tabel Indikator Makro Kemiskinan & Pembangunan Kabupaten Tangerang (2020–2026)
              </h3>
              <div class="sdgs-table-wrap">
                <table class="sdgs-table">
                  <thead>
                    <tr>
                      <th>Tahun</th>
                      <th>Penduduk Miskin</th>
                      <th>Persentase</th>
                      <th>Garis Kemiskinan</th>
                      <th>Indeks P1 / P2</th>
                      <th>IPM</th>
                      <th>RLS</th>
                      <th>Sanitasi</th>
                      <th>TPT</th>
                      <th>Status & Keterangan Sumber</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($SDGS_TREN_TAHUNAN as $yr => $tr): ?>
                      <tr style="<?= $yr === 2025 ? 'background:var(--sdgs-red-soft);font-weight:600;' : ''; ?>">
                        <td class="mono"><strong><?= $tr['tahun']; ?></strong></td>
                        <td class="mono"><strong><?= number_format($tr['miskin_ribu'], 2, ',', '.'); ?> rb</strong></td>
                        <td class="mono">
                          <span class="pill-badge <?= $yr === 2025 ? 'crimson' : ($yr === 2026 ? 'emerald' : ''); ?>">
                            <?= number_format($tr['persen'], 2, ',', '.'); ?>%
                          </span>
                        </td>
                        <td class="mono">Rp <?= number_format($tr['gk'], 0, ',', '.'); ?></td>
                        <td class="mono"><?= $tr['p1']; ?> / <?= $tr['p2']; ?></td>
                        <td class="mono"><?= number_format($tr['ipm'], 2, ',', '.'); ?></td>
                        <td class="mono"><?= $tr['rls']; ?> Thn</td>
                        <td class="mono"><?= $tr['sanitasi']; ?>%</td>
                        <td class="mono"><?= $tr['tpt']; ?>%</td>
                        <td>
                          <span style="font-size:12px;color:var(--text-main);display:block;"><?= htmlspecialchars($tr['status']); ?></span>
                          <span style="font-size:11.5px;color:var(--text-muted);"><?= htmlspecialchars($tr['catatan']); ?></span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 1: PENDATAAN MASYARAKAT MISKIN (CRUD KHUSUS ADMIN)
             ================================================================= -->
        <section class="module-pane" id="mod-penduduk">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge crimson" style="margin-bottom:6px;"><i class="fa-solid fa-id-card"></i> MODUL 1 // BY NAME BY ADDRESS (DTSEN)</span>
                <h2 class="panel-title">1. Pendataan Masyarakat Miskin & Verifikasi NIK</h2>
                <p class="panel-subtitle">Basis data NIK (kode 3603), alamat, pekerjaan, penghasilan, tanggungan, dan status Desil. <?= $sdgs_is_admin ? 'Mode Admin: NIK lengkap & fitur kelola aktif.' : 'Mode Publik: NIK otomatis disamarkan demi privasi warga.'; ?></p>
              </div>
              <?php if ($sdgs_is_admin): ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                  <a href="sdgs-demo.php?export_csv=penduduk" class="btn-sdgs btn-sdgs-sm">
                    <i class="fa-solid fa-file-csv" style="color:var(--emerald)"></i> Export CSV
                  </a>
                  <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="openPendudukModal()">
                    <i class="fa-solid fa-user-plus"></i> + Tambah Data Penduduk
                  </button>
                </div>
              <?php else: ?>
                <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="openAdminLoginModal()">
                  <i class="fa-solid fa-lock" style="color:var(--accent)"></i> Login Admin untuk Kelola Data
                </button>
              <?php endif; ?>
            </div>

            <div class="table-toolbar">
              <div class="search-input-wrap">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" data-table-search="wrapTabelPenduduk" placeholder="Cari NIK, nama warga, desa, kecamatan, atau pekerjaan...">
              </div>
              <select class="filter-control" data-table-select="wrapTabelPenduduk">
                <option value="">Semua Status Desil</option>
                <option value="Desil 1">Desil 1 (Kemiskinan Ekstrem)</option>
                <option value="Desil 2">Desil 2 (Miskin)</option>
                <option value="Desil 3">Desil 3 (Rentan Miskin)</option>
              </select>
            </div>

            <div class="sdgs-table-wrap" id="wrapTabelPenduduk">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>NIK (Kode 3603)</th>
                    <th>Nama Lengkap</th>
                    <th>Alamat Desa & Kecamatan</th>
                    <th>Pekerjaan</th>
                    <th>Penghasilan / Bln</th>
                    <th>Tanggungan</th>
                    <th>Pendapatan / Kapita</th>
                    <th>Status Ekonomi</th>
                    <th style="text-align:right;">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($list_penduduk as $p):
                    $per_kap = round((int)$p['penghasilan'] / max(1, (int)$p['tanggungan']));
                    $badge_desil = strpos($p['status_ekonomi'], 'Desil 1') !== false ? 'crimson' : (strpos($p['status_ekonomi'], 'Desil 2') !== false ? 'amber' : 'cyan');
                    $p_safe = $p;
                    $p_safe['nik'] = sdgs_display_nik($p['nik'], $sdgs_is_admin, $mask_nik);
                  ?>
                    <tr data-kecamatan="<?= htmlspecialchars($p['kecamatan']); ?>">
                      <td class="mono" style="font-size:12.5px;"><?= htmlspecialchars($p_safe['nik']); ?></td>
                      <td>
                        <strong><?= htmlspecialchars($p['nama']); ?></strong>
                        <div style="font-size:11.5px;color:var(--text-muted);"><?= $p['jk'] === 'P' ? 'Perempuan' : 'Laki-laki'; ?> • <?= (int)$p['usia']; ?> Thn • <?= htmlspecialchars($p['pendidikan']); ?></div>
                      </td>
                      <td>
                        <div><?= htmlspecialchars($p['alamat_desa']); ?></div>
                        <div class="mono" style="font-size:11.5px;color:var(--accent);">Kec. <?= htmlspecialchars($p['kecamatan']); ?></div>
                      </td>
                      <td><?= htmlspecialchars($p['pekerjaan']); ?></td>
                      <td class="mono">Rp <?= number_format((int)$p['penghasilan'], 0, ',', '.'); ?></td>
                      <td class="mono"><?= (int)$p['tanggungan']; ?> Jiwa</td>
                      <td class="mono" style="color:<?= $per_kap < (int)$sdgs_cfg['garis_kemiskinan'] ? '#FB7185' : 'var(--emerald)'; ?>">
                        Rp <?= number_format($per_kap, 0, ',', '.'); ?>
                      </td>
                      <td><span class="pill-badge <?= $badge_desil; ?>"><?= htmlspecialchars($p['status_ekonomi']); ?></span></td>
                      <td style="text-align:right;white-space:nowrap;">
                        <button type="button" class="btn-sdgs btn-sdgs-sm" title="Analisis Indikator Keluarga" onclick='openAnalisisKeluargaModal(<?= json_encode($p_safe, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                          <i class="fa-solid fa-chart-simple" style="color:var(--accent)"></i>
                        </button>
                        <?php if ($sdgs_is_admin): ?>
                          <button type="button" class="btn-sdgs btn-sdgs-sm" title="Edit Data" onclick='openPendudukModal(<?= json_encode($p, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                            <i class="fa-solid fa-pen-to-square"></i>
                          </button>
                          <form method="POST" action="sdgs-demo.php#mod-penduduk" style="display:inline;" onsubmit="return confirm('Hapus data penduduk a.n <?= htmlspecialchars(addslashes($p['nama'])); ?>?');">
                            <input type="hidden" name="sdgs_action" value="delete_penduduk">
                            <input type="hidden" name="id" value="<?= (int)$p['id']; ?>">
                            <button type="submit" class="btn-sdgs btn-sdgs-sm" title="Hapus"><i class="fa-solid fa-trash" style="color:var(--sdgs-red)"></i></button>
                          </form>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 2: BANTUAN SOSIAL (VERIFIKASI & SALURKAN KHUSUS ADMIN)
             ================================================================= -->
        <section class="module-pane" id="mod-bansos">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge crimson" style="margin-bottom:6px;"><i class="fa-solid fa-hand-holding-heart"></i> MODUL 2 // DISTRIBUSI & VERIFIKASI BANSOS</span>
                <h2 class="panel-title">2. Penyaluran Bantuan Sosial (PKH, BPNT, BLT-DD & PBI)</h2>
                <p class="panel-subtitle">Transparansi penerima bansos, jenis bantuan, jadwal penyaluran, dan status verifikasi. Aksi verifikasi & cetak nota khusus Admin.</p>
              </div>
              <?php if ($sdgs_is_admin): ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                  <a href="sdgs-demo.php?export_csv=bansos" class="btn-sdgs btn-sdgs-sm">
                    <i class="fa-solid fa-file-csv" style="color:var(--emerald)"></i> Export CSV
                  </a>
                  <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="openBansosModal()">
                    <i class="fa-solid fa-plus"></i> + Jadwalkan Penyaluran
                  </button>
                </div>
              <?php endif; ?>
            </div>

            <div class="table-toolbar">
              <div class="search-input-wrap">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" data-table-search="wrapTabelBansos" placeholder="Cari kode bansos, nama penerima, jenis bantuan, atau kecamatan...">
              </div>
              <select class="filter-control" data-table-select="wrapTabelBansos">
                <option value="">Semua Status Penyaluran</option>
                <option value="Disalurkan">Disalurkan</option>
                <option value="Terverifikasi">Terverifikasi</option>
                <option value="Menunggu Verifikasi">Menunggu Verifikasi</option>
              </select>
            </div>

            <div class="sdgs-table-wrap" id="wrapTabelBansos">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>Kode Bansos</th>
                    <th>Penerima & NIK</th>
                    <th>Kecamatan</th>
                    <th>Jenis Program Bantuan</th>
                    <th>Nominal / Paket</th>
                    <th>Jadwal & Tahap</th>
                    <th>Status Verifikasi</th>
                    <?php if ($sdgs_is_admin): ?><th style="text-align:right;">Kontrol Admin</th><?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($list_bansos as $b):
                    $st_cls = $b['status_verifikasi'] === 'Disalurkan' ? 'emerald' : ($b['status_verifikasi'] === 'Terverifikasi' ? 'cyan' : 'amber');
                  ?>
                    <tr data-kecamatan="<?= htmlspecialchars($b['kecamatan']); ?>">
                      <td class="mono"><strong><?= htmlspecialchars($b['kode_bansos']); ?></strong></td>
                      <td>
                        <strong><?= htmlspecialchars($b['nama_penerima']); ?></strong>
                        <div class="mono" style="font-size:11.5px;color:var(--text-muted);">NIK: <?= htmlspecialchars(sdgs_display_nik($b['nik_penerima'], $sdgs_is_admin, $mask_nik)); ?></div>
                      </td>
                      <td>Kec. <?= htmlspecialchars($b['kecamatan']); ?></td>
                      <td><?= htmlspecialchars($b['jenis_bantuan']); ?></td>
                      <td class="mono"><strong><?= htmlspecialchars($b['nominal_paket']); ?></strong></td>
                      <td>
                        <div><?= htmlspecialchars($b['jadwal_penyaluran']); ?></div>
                        <div style="font-size:11.5px;color:var(--text-muted);"><?= htmlspecialchars($b['tahap']); ?></div>
                      </td>
                      <td><span class="pill-badge <?= $st_cls; ?>"><?= htmlspecialchars($b['status_verifikasi']); ?></span></td>
                      <?php if ($sdgs_is_admin): ?>
                        <td style="text-align:right;white-space:nowrap;">
                          <?php if ($b['status_verifikasi'] !== 'Disalurkan'): ?>
                            <form method="POST" action="sdgs-demo.php#mod-bansos" style="display:inline;">
                              <input type="hidden" name="sdgs_action" value="update_bansos_status">
                              <input type="hidden" name="id" value="<?= (int)$b['id']; ?>">
                              <input type="hidden" name="status_verifikasi" value="Disalurkan">
                              <button type="submit" class="btn-sdgs btn-sdgs-emerald btn-sdgs-sm"><i class="fa-solid fa-check-double"></i> Salurkan</button>
                            </form>
                          <?php endif; ?>
                          <button type="button" class="btn-sdgs btn-sdgs-sm" title="Cetak Nota Penyaluran" onclick='printBuktiBansos(<?= json_encode($b, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                            <i class="fa-solid fa-receipt" style="color:var(--amber)"></i> Nota
                          </button>
                          <button type="button" class="btn-sdgs btn-sdgs-sm" title="Edit" onclick='openBansosModal(<?= json_encode($b, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                            <i class="fa-solid fa-pen"></i>
                          </button>
                          <form method="POST" action="sdgs-demo.php#mod-bansos" style="display:inline;" onsubmit="return confirm('Hapus data bansos ini?');">
                            <input type="hidden" name="sdgs_action" value="delete_bansos">
                            <input type="hidden" name="id" value="<?= (int)$b['id']; ?>">
                            <button type="submit" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-trash" style="color:var(--sdgs-red)"></i></button>
                          </form>
                        </td>
                      <?php endif; ?>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 3: PROGRAM UMKM BINAAN (KELOLA KHUSUS ADMIN)
             ================================================================= -->
        <section class="module-pane" id="mod-umkm">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge cyan" style="margin-bottom:6px;"><i class="fa-solid fa-store"></i> MODUL 3 // INKUBASI EKONOMI KELUARGA PRA-SEJAHTERA</span>
                <h2 class="panel-title">3. Program Pemberdayaan & Pendampingan UMKM</h2>
                <p class="panel-subtitle">Showcase UMKM binaan keluarga pra-sejahtera Kabupaten Tangerang lengkap dengan omzet usaha, pelatihan, dan status pendampingan.</p>
              </div>
              <?php if ($sdgs_is_admin): ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                  <a href="sdgs-demo.php?export_csv=umkm" class="btn-sdgs btn-sdgs-sm">
                    <i class="fa-solid fa-file-csv" style="color:var(--emerald)"></i> Export CSV
                  </a>
                  <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="openUmkmModal()">
                    <i class="fa-solid fa-plus"></i> + Daftarkan UMKM Baru
                  </button>
                </div>
              <?php endif; ?>
            </div>

            <div class="cards-grid-2" id="wrapGridUmkm">
              <?php foreach ($list_umkm as $u): ?>
                <div class="item-bento-card filterable-card" data-kecamatan="<?= htmlspecialchars($u['kecamatan']); ?>">
                  <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;">
                      <span class="mono" style="font-size:11.5px;color:var(--accent);"><?= htmlspecialchars($u['kode_umkm']); ?> • KEC. <?= strtoupper(htmlspecialchars($u['kecamatan'])); ?></span>
                      <span class="pill-badge <?= $u['status_pendampingan'] === 'Mandiri Berkembang' ? 'emerald' : 'cyan'; ?>">
                        <?= htmlspecialchars($u['status_pendampingan']); ?>
                      </span>
                    </div>
                    <h3 style="font-size:17px;margin-bottom:4px;"><?= htmlspecialchars($u['nama_usaha']); ?></h3>
                    <div style="font-size:13px;color:var(--text-muted);margin-bottom:10px;">
                      Pemilik: <strong><?= htmlspecialchars($u['pemilik']); ?></strong> • Kategori: <?= htmlspecialchars($u['kategori_usaha']); ?>
                    </div>
                    <div style="background:var(--bg-primary);border:1px solid var(--border-subtle);border-radius:8px;padding:10px 12px;font-size:12.5px;">
                      <div><strong>Omzet Bulanan:</strong> <span class="mono" style="color:var(--emerald);font-weight:700;">Rp <?= number_format((int)$u['omzet_bulanan'], 0, ',', '.'); ?> / bln</span></div>
                      <div style="margin-top:4px;color:var(--text-muted);"><strong>Intervensi & Pelatihan:</strong> <?= htmlspecialchars($u['pelatihan_diikuti']); ?></div>
                    </div>
                  </div>
                  <?php if ($sdgs_is_admin): ?>
                    <div style="display:flex;justify-content:flex-end;gap:8px;padding-top:10px;border-top:1px solid var(--border-subtle);">
                      <button type="button" class="btn-sdgs btn-sdgs-sm" onclick='openUmkmModal(<?= json_encode($u, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                        <i class="fa-solid fa-pen-to-square"></i> Edit Omzet
                      </button>
                      <form method="POST" action="sdgs-demo.php#mod-umkm" style="display:inline;" onsubmit="return confirm('Hapus UMKM ini?');">
                        <input type="hidden" name="sdgs_action" value="delete_umkm">
                        <input type="hidden" name="id" value="<?= (int)$u['id']; ?>">
                        <button type="submit" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-trash" style="color:var(--sdgs-red)"></i></button>
                      </form>
                    </div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 4: BURSA LOWONGAN KERJA (PUBLIK LAMAR CV, ADMIN KELOLA STATUS)
             ================================================================= -->
        <section class="module-pane" id="mod-loker">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge emerald" style="margin-bottom:6px;"><i class="fa-solid fa-briefcase"></i> MODUL 4 // LINK & MATCH INDUSTRI KAB. TANGERANG</span>
                <h2 class="panel-title">4. Bursa Lowongan Kerja & Penyaluran Tenaga Kerja Desil 1–3</h2>
                <p class="panel-subtitle">Warga dapat melamar dan mengunggah CV langsung. Penambahan lowongan dan pembaruan status seleksi pelamar dikontrol khusus Admin.</p>
              </div>
              <?php if ($sdgs_is_admin): ?>
                <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="openAddLokerModal()">
                  <i class="fa-solid fa-plus"></i> + Tambah Lowongan Mitra
                </button>
              <?php endif; ?>
            </div>

            <div class="cards-grid-2" style="margin-bottom:22px;">
              <?php foreach ($list_loker as $l): ?>
                <div class="item-bento-card" data-kecamatan="<?= htmlspecialchars($l['kecamatan']); ?>">
                  <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                      <span class="mono" style="font-size:11.5px;color:var(--accent);"><?= htmlspecialchars($l['kode_loker']); ?> • <?= htmlspecialchars($l['kategori']); ?></span>
                      <span class="pill-badge emerald">Kuota: <?= (int)$l['kuota']; ?> Orang</span>
                    </div>
                    <h3 style="font-size:17px;margin-bottom:4px;"><?= htmlspecialchars($l['posisi']); ?></h3>
                    <div style="font-size:13.5px;color:var(--text-main);font-weight:600;"><?= htmlspecialchars($l['perusahaan']); ?></div>
                    <div style="font-size:12.5px;color:var(--text-muted);margin-top:6px;">
                      <i class="fa-solid fa-location-dot" style="color:var(--sdgs-red)"></i> Kec. <?= htmlspecialchars($l['kecamatan']); ?> •
                      Gaji: <strong style="color:var(--emerald)"><?= htmlspecialchars($l['gaji']); ?></strong> •
                      Min: <?= htmlspecialchars($l['pendidikan_min']); ?>
                    </div>
                  </div>
                  <div style="display:flex;justify-content:space-between;align-items:center;padding-top:10px;border-top:1px solid var(--border-subtle);">
                    <span class="pill-badge">Prioritas Warga Pra-Sejahtera</span>
                    <?php if (!empty($sdgs_cfg['allow_loker_apply']) || $sdgs_is_admin): ?>
                      <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick='openApplyLokerModal(<?= json_encode($l, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                        <i class="fa-solid fa-file-arrow-up"></i> Lamar & Upload CV
                      </button>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>

            <h3 style="font-size:16px;margin-bottom:10px;"><i class="fa-solid fa-user-check" style="color:var(--accent)"></i> Data Pelamar Kerja & Tracking Status Lamaran</h3>
            <div class="sdgs-table-wrap">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>Kode Lamaran</th>
                    <th>Nama Pelamar & NIK</th>
                    <th>Posisi & Perusahaan Tujuan</th>
                    <th>Kecamatan</th>
                    <th>Berkas CV</th>
                    <th>Status Lamaran</th>
                    <?php if ($sdgs_is_admin): ?><th style="text-align:right;">Update Status (Admin)</th><?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($list_lamaran as $lm):
                    $lm_cls = $lm['status_lamaran'] === 'Diterima Bekerja' ? 'emerald' : ($lm['status_lamaran'] === 'Wawancara' ? 'amber' : 'cyan');
                  ?>
                    <tr data-kecamatan="<?= htmlspecialchars($lm['kecamatan']); ?>">
                      <td class="mono"><strong><?= htmlspecialchars($lm['kode_lamaran']); ?></strong></td>
                      <td>
                        <strong><?= htmlspecialchars($lm['nama_pelamar']); ?></strong>
                        <div class="mono" style="font-size:11.5px;color:var(--text-muted);">NIK: <?= htmlspecialchars(sdgs_display_nik($lm['nik_pelamar'], $sdgs_is_admin, $mask_nik)); ?></div>
                      </td>
                      <td>
                        <div><strong><?= htmlspecialchars($lm['posisi_dilamar']); ?></strong></div>
                        <div style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($lm['perusahaan']); ?></div>
                      </td>
                      <td>Kec. <?= htmlspecialchars($lm['kecamatan']); ?></td>
                      <td class="mono" style="font-size:12px;"><i class="fa-regular fa-file-pdf" style="color:var(--sdgs-red)"></i> <?= htmlspecialchars($lm['file_cv']); ?></td>
                      <td><span class="pill-badge <?= $lm_cls; ?>"><?= htmlspecialchars($lm['status_lamaran']); ?></span></td>
                      <?php if ($sdgs_is_admin): ?>
                        <td style="text-align:right;">
                          <form method="POST" action="sdgs-demo.php#mod-loker" style="display:inline-flex;">
                            <input type="hidden" name="sdgs_action" value="update_lamaran_status">
                            <input type="hidden" name="id" value="<?= (int)$lm['id']; ?>">
                            <select name="status_lamaran" class="filter-control" style="padding:4px 8px;font-size:11.5px;" onchange="this.form.submit()">
                              <option value="Seleksi Berkas" <?= $lm['status_lamaran']==='Seleksi Berkas'?'selected':''; ?>>Seleksi Berkas</option>
                              <option value="Wawancara" <?= $lm['status_lamaran']==='Wawancara'?'selected':''; ?>>Wawancara</option>
                              <option value="Diterima Bekerja" <?= $lm['status_lamaran']==='Diterima Bekerja'?'selected':''; ?>>Diterima Bekerja</option>
                            </select>
                          </form>
                        </td>
                      <?php endif; ?>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 5: PELATIHAN & EDUKASI VOKASI BERSERTIFIKAT
             ================================================================= -->
        <section class="module-pane" id="mod-pelatihan">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge amber" style="margin-bottom:6px;"><i class="fa-solid fa-graduation-cap"></i> MODUL 5 // PENINGKATAN KAPASITAS SDM & SERTIFIKASI</span>
                <h2 class="panel-title">5. Pelatihan Keterampilan, Edukasi Digital & Sertifikat Resmi</h2>
                <p class="panel-subtitle">Kursus keterampilan vokasi gratis, pelatihan pemasaran digital UMKM, modul materi pembelajaran, dan pencetakan sertifikat.</p>
              </div>
            </div>

            <div class="cards-grid-2" style="margin-bottom:22px;">
              <?php foreach ($list_pelatihan as $pl): ?>
                <div class="item-bento-card">
                  <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                      <span class="mono" style="font-size:11.5px;color:var(--accent);"><?= htmlspecialchars($pl['kode_pelatihan']); ?> • <?= htmlspecialchars($pl['kategori']); ?></span>
                      <span class="pill-badge amber"><?= htmlspecialchars($pl['durasi']); ?></span>
                    </div>
                    <h3 style="font-size:16.5px;margin-bottom:4px;"><?= htmlspecialchars($pl['judul']); ?></h3>
                    <div style="font-size:12.5px;color:var(--text-muted);margin-bottom:10px;">
                      Penyelenggara: <strong><?= htmlspecialchars($pl['penyelenggara']); ?></strong> • Kuota: <?= (int)$pl['kuota']; ?> Peserta
                    </div>
                    <div style="font-size:12px;color:var(--emerald);">
                      <i class="fa-solid fa-certificate"></i> <?= htmlspecialchars($pl['sertifikat']); ?>
                    </div>
                  </div>
                  <div style="display:flex;gap:8px;flex-wrap:wrap;padding-top:10px;border-top:1px solid var(--border-subtle);">
                    <button type="button" class="btn-sdgs btn-sdgs-sm" onclick='openMateriModal(<?= json_encode($pl, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                      <i class="fa-solid fa-book-open" style="color:var(--accent)"></i> Materi Pembelajaran
                    </button>
                    <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick='openEnrollModal(<?= json_encode($pl, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                      <i class="fa-solid fa-user-plus"></i> Daftar Pelatihan
                    </button>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>

            <h3 style="font-size:16px;margin-bottom:10px;"><i class="fa-solid fa-award" style="color:var(--amber)"></i> Daftar Lulusan & Cetak Sertifikat Pelatihan</h3>
            <div class="sdgs-table-wrap">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>Nomor Sertifikat</th>
                    <th>Nama Peserta & NIK</th>
                    <th>Kecamatan</th>
                    <th>Program Pelatihan</th>
                    <th>Status Kelulusan</th>
                    <th style="text-align:right;">Cetak Sertifikat</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($list_peserta as $ps):
                    $ps_safe = $ps;
                    $ps_safe['nik_peserta'] = sdgs_display_nik($ps['nik_peserta'], $sdgs_is_admin, $mask_nik);
                  ?>
                    <tr data-kecamatan="<?= htmlspecialchars($ps['kecamatan']); ?>">
                      <td class="mono"><strong><?= htmlspecialchars($ps['no_sertifikat']); ?></strong></td>
                      <td>
                        <strong><?= htmlspecialchars($ps['nama_peserta']); ?></strong>
                        <div class="mono" style="font-size:11.5px;color:var(--text-muted);">NIK: <?= htmlspecialchars($ps_safe['nik_peserta']); ?></div>
                      </td>
                      <td>Kec. <?= htmlspecialchars($ps['kecamatan']); ?></td>
                      <td><?= htmlspecialchars($ps['judul_pelatihan']); ?></td>
                      <td><span class="pill-badge emerald"><i class="fa-solid fa-check"></i> <?= htmlspecialchars($ps['status_peserta']); ?></span></td>
                      <td style="text-align:right;">
                        <button type="button" class="btn-sdgs btn-sdgs-sm" onclick='printSertifikatPelatihan(<?= json_encode($ps_safe, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                          <i class="fa-solid fa-print" style="color:var(--amber)"></i> Cetak Sertifikat
                        </button>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 6: DONASI & CROWDFUNDING SOSIAL (PAYMENT GATEWAY QRIS/VA)
             ================================================================= -->
        <section class="module-pane" id="mod-donasi">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge emerald" style="margin-bottom:6px;"><i class="fa-solid fa-circle-dollar-to-slot"></i> MODUL 6 // CROWDFUNDING & TRANSPARANSI DANA</span>
                <h2 class="panel-title">6. Donasi & Crowdfunding Sosial (Payment Gateway QRIS & VA)</h2>
                <p class="panel-subtitle">Masyarakat dapat berdonasi melalui QRIS/VA/E-Wallet dan memantau laporan penggunaan dana. Pembuatan kampanye baru dikontrol khusus Admin.</p>
              </div>
              <?php if ($sdgs_is_admin): ?>
                <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="openAddKampanyeModal()">
                  <i class="fa-solid fa-plus"></i> + Buat Kampanye Bantuan (Admin)
                </button>
              <?php endif; ?>
            </div>

            <div class="cards-grid-3" style="margin-bottom:24px;">
              <?php foreach ($list_kampanye as $km):
                $pct = min(100, round(((int)$km['dana_terkumpul'] / max(1, (int)$km['target_dana'])) * 100));
              ?>
                <div class="item-bento-card" data-kecamatan="<?= htmlspecialchars($km['kecamatan']); ?>">
                  <div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                      <span class="mono" style="font-size:11px;color:var(--accent);"><?= htmlspecialchars($km['kode_kampanye']); ?> • KEC. <?= strtoupper(htmlspecialchars($km['kecamatan'])); ?></span>
                      <span class="pill-badge <?= $pct >= 100 ? 'emerald' : 'crimson'; ?>"><?= $pct; ?>% Tercapai</span>
                    </div>
                    <h3 style="font-size:16px;margin-bottom:6px;"><?= htmlspecialchars($km['judul']); ?></h3>
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:10px;">
                      Sasaran: <strong><?= htmlspecialchars($km['penerima_manfaat']); ?></strong>
                    </div>

                    <div class="progress-track">
                      <div class="progress-fill" style="width: <?= $pct; ?>%;"></div>
                    </div>
                    <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:12px;">
                      <span>Terkumpul: <strong class="mono" style="color:var(--emerald)">Rp <?= number_format((int)$km['dana_terkumpul'], 0, ',', '.'); ?></strong></span>
                      <span class="mono" style="color:var(--text-muted)">Target: Rp <?= number_format((int)$km['target_dana'], 0, ',', '.'); ?></span>
                    </div>

                    <div style="background:var(--bg-primary);border:1px solid var(--border-subtle);border-radius:8px;padding:10px;font-size:11.5px;color:var(--text-muted);">
                      <div style="font-weight:700;color:var(--text-heading);margin-bottom:3px;">
                        <i class="fa-solid fa-file-invoice-dollar" style="color:var(--emerald)"></i> Laporan Penggunaan Dana (Tersalurkan Rp <?= number_format((int)$km['dana_tersalurkan'], 0, ',', '.'); ?>):
                      </div>
                      <?= nl2br(htmlspecialchars($km['laporan_penggunaan'])); ?>
                    </div>
                  </div>

                  <?php if (!empty($sdgs_cfg['allow_donasi']) || $sdgs_is_admin): ?>
                    <button type="button" class="btn-sdgs btn-sdgs-primary" style="width:100%;" onclick='openDonasiGatewayModal(<?= json_encode($km, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                      <i class="fa-solid fa-qrcode"></i> Donasi via QRIS / Virtual Account
                    </button>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>

            <h3 style="font-size:16px;margin-bottom:10px;"><i class="fa-solid fa-clock-rotate-left" style="color:var(--emerald)"></i> Riwayat Transaksi Donasi Masuk</h3>
            <div class="sdgs-table-wrap">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>Kode Transaksi</th>
                    <th>Nama Donatur</th>
                    <th>Kampanye Bantuan</th>
                    <th>Metode Payment Gateway</th>
                    <th>Nominal Donasi</th>
                    <th>Pesan & Doa</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($list_donasi as $dn): ?>
                    <tr>
                      <td class="mono"><strong><?= htmlspecialchars($dn['kode_donasi']); ?></strong></td>
                      <td><strong><?= htmlspecialchars($dn['nama_donatur']); ?></strong></td>
                      <td><?= htmlspecialchars($dn['judul_kampanye']); ?></td>
                      <td><span class="pill-badge cyan"><i class="fa-solid fa-credit-card"></i> <?= htmlspecialchars($dn['metode_pembayaran']); ?></span></td>
                      <td class="mono" style="color:var(--emerald);font-weight:700;">Rp <?= number_format((int)$dn['nominal'], 0, ',', '.'); ?></td>
                      <td style="font-size:12.5px;color:var(--text-muted);">"<?= htmlspecialchars($dn['pesan']); ?>"</td>
                      <td><span class="pill-badge emerald"><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($dn['status_transaksi']); ?></span></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 8: PENGADUAN MASYARAKAT & LACAK TIKET (UPDATE KHUSUS ADMIN)
             ================================================================= -->
        <section class="module-pane" id="mod-pengaduan">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge amber" style="margin-bottom:6px;"><i class="fa-solid fa-triangle-exclamation"></i> MODUL 8 // WHISTLEBLOWING & TRACKING TIKET PENGADUAN</span>
                <h2 class="panel-title">8. Pengaduan Masyarakat & Lacak Status Tindak Lanjut</h2>
                <p class="panel-subtitle">Warga dapat mengirim laporan & melacak nomor tiket. Pembaruan status tindak lanjut petugas dikunci khusus Admin.</p>
              </div>
            </div>

            <div class="charts-grid-2" style="margin-bottom:22px;">
              <div class="chart-card">
                <h3 style="font-size:16px;margin-bottom:12px;"><i class="fa-solid fa-paper-plane" style="color:var(--sdgs-red)"></i> Formulir Pengaduan Masyarakat Baru</h3>
                <form method="POST" action="sdgs-demo.php#mod-pengaduan">
                  <input type="hidden" name="sdgs_action" value="submit_pengaduan">
                  <div class="form-row-2">
                    <div class="form-group-sdgs">
                      <label>Nama Pelapor (Boleh Dikosongkan / Anonim)</label>
                      <input type="text" name="nama_pelapor" class="form-input-sdgs" placeholder="Tulis nama atau biarkan kosong...">
                    </div>
                    <div class="form-group-sdgs">
                      <label>NIK Terkait (Opsional)</label>
                      <input type="text" name="nik_terkait" class="form-input-sdgs mono" maxlength="16" placeholder="3603...">
                    </div>
                  </div>
                  <div class="form-row-2">
                    <div class="form-group-sdgs">
                      <label>Kecamatan Lokasi *</label>
                      <select name="kecamatan" class="form-input-sdgs">
                        <?php foreach ($SDGS_KECAMATAN_29 as $k): ?>
                          <option value="<?= htmlspecialchars($k['nama']); ?>">Kec. <?= htmlspecialchars($k['nama']); ?></option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                    <div class="form-group-sdgs">
                      <label>Desa / Kelurahan & RT/RW *</label>
                      <input type="text" name="lokasi_desa" class="form-input-sdgs" placeholder="Contoh: Ds. Surya Bahari RT 02/03" required>
                    </div>
                  </div>
                  <div class="form-group-sdgs">
                    <label>Kategori Pengaduan *</label>
                    <select name="kategori_aduan" class="form-input-sdgs">
                      <option value="Bantuan Tidak Tepat Sasaran">Bantuan Tidak Tepat Sasaran (Inclusion Error)</option>
                      <option value="Warga Miskin Belum Terdata (Exclusion Error)">Warga Miskin Belum Terdata (Exclusion Error)</option>
                      <option value="Keterlambatan / Kendala Pencairan Bansos">Keterlambatan / Kendala Pencairan Bansos</option>
                      <option value="Sinkronisasi Data Kependudukan / NIK">Sinkronisasi Data Kependudukan / NIK</option>
                    </select>
                  </div>
                  <div class="form-group-sdgs">
                    <label>Kronologi / Rincian Laporan Pengaduan *</label>
                    <textarea name="isi_laporan" class="form-input-sdgs" rows="3" placeholder="Jelaskan kondisi warga atau ketidaksesuaian penyaluran bantuan secara lengkap..." required></textarea>
                  </div>
                  <button type="submit" class="btn-sdgs btn-sdgs-primary" style="width:100%;">
                    <i class="fa-solid fa-ticket"></i> Kirim Laporan & Dapatkan Nomor Tiket
                  </button>
                </form>
              </div>

              <div class="chart-card">
                <h3 style="font-size:16px;margin-bottom:10px;"><i class="fa-solid fa-magnifying-glass-location" style="color:var(--accent)"></i> Lacak Nomor Tiket Pengaduan</h3>
                <div class="search-input-wrap" style="max-width:100%;margin-bottom:16px;">
                  <i class="fa-solid fa-ticket"></i>
                  <input type="text" data-table-search="wrapTabelPengaduan" placeholder="Ketik Nomor Tiket (misal: ADU-2026-001), kecamatan, atau desa...">
                </div>

                <div style="background:var(--bg-primary);border:1px solid var(--border-subtle);border-radius:10px;padding:16px;font-size:13px;">
                  <div class="mono" style="font-size:11.5px;color:var(--accent);margin-bottom:10px;">STANDAR SLA PENANGANAN PENGADUAN (4 TAHAP):</div>
                  <div style="display:flex;flex-direction:column;gap:10px;">
                    <div><span class="pill-badge cyan">Tahap 1</span> <strong>Laporan Diterima:</strong> Pencatatan tiket otomatis di Command Center.</div>
                    <div><span class="pill-badge amber">Tahap 2</span> <strong>Verifikasi Lapangan:</strong> Ground-check oleh TKSK & Pendamping PKH Kecamatan.</div>
                    <div><span class="pill-badge crimson">Tahap 3</span> <strong>Tindak Lanjut Dinsos:</strong> Musyawarah Desa/Kelurahan & pemutakhiran DTSEN.</div>
                    <div><span class="pill-badge emerald">Tahap 4</span> <strong>Selesai Ditangani:</strong> Pengalihan/pengaktifan bantuan tepat sasaran.</div>
                  </div>
                </div>
              </div>
            </div>

            <div class="sdgs-table-wrap" id="wrapTabelPengaduan">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>Nomor Tiket</th>
                    <th>Pelapor & Lokasi</th>
                    <th>Kategori & Isi Laporan</th>
                    <th>Status Penanganan</th>
                    <th>Catatan Tindak Lanjut Resmi</th>
                    <?php if ($sdgs_is_admin): ?><th style="text-align:right;">Aksi Admin</th><?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($list_pengaduan as $ad):
                    $ad_cls = $ad['status_aduan'] === 'Selesai Ditangani' ? 'emerald' : ($ad['status_aduan'] === 'Laporan Diterima' ? 'cyan' : 'amber');
                  ?>
                    <tr data-kecamatan="<?= htmlspecialchars($ad['kecamatan']); ?>">
                      <td class="mono"><strong><?= htmlspecialchars($ad['kode_tiket']); ?></strong></td>
                      <td>
                        <strong><?= htmlspecialchars($ad['nama_pelapor']); ?></strong>
                        <div style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($ad['lokasi_desa']); ?>, Kec. <?= htmlspecialchars($ad['kecamatan']); ?></div>
                      </td>
                      <td style="max-width:300px;">
                        <div style="font-weight:700;color:var(--text-heading);"><?= htmlspecialchars($ad['kategori_aduan']); ?></div>
                        <div style="font-size:12.5px;color:var(--text-muted);"><?= htmlspecialchars($ad['isi_laporan']); ?></div>
                      </td>
                      <td><span class="pill-badge <?= $ad_cls; ?>"><?= htmlspecialchars($ad['status_aduan']); ?></span></td>
                      <td style="max-width:290px;font-size:12.5px;color:var(--text-main);"><?= htmlspecialchars($ad['tindak_lanjut']); ?></td>
                      <?php if ($sdgs_is_admin): ?>
                        <td style="text-align:right;white-space:nowrap;">
                          <button type="button" class="btn-sdgs btn-sdgs-sm" onclick='openTindakLanjutModal(<?= json_encode($ad, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                            <i class="fa-solid fa-pen-clip" style="color:var(--amber)"></i> Update
                          </button>
                          <form method="POST" action="sdgs-demo.php#mod-pengaduan" style="display:inline;" onsubmit="return confirm('Hapus tiket pengaduan ini?');">
                            <input type="hidden" name="sdgs_action" value="delete_pengaduan">
                            <input type="hidden" name="id" value="<?= (int)$ad['id']; ?>">
                            <button type="submit" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-trash" style="color:var(--sdgs-red)"></i></button>
                          </form>
                        </td>
                      <?php endif; ?>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 9: PEMETAAN SPASIAL WILAYAH (29 KECAMATAN KAB. TANGERANG)
             ================================================================= -->
        <section class="module-pane" id="mod-peta">
          <div class="panel-card">
            <div class="panel-header">
              <div>
                <span class="pill-badge cyan" style="margin-bottom:6px;"><i class="fa-solid fa-map-location-dot"></i> MODUL 9 // GIS & PEMETAAN SPASIAL 29 KECAMATAN</span>
                <h2 class="panel-title">9. Peta Sebaran Kemiskinan 29 Kecamatan Kabupaten Tangerang (BPS 2026)</h2>
                <p class="panel-subtitle">Peta interaktif Leaflet.js dan matriks 29 kecamatan yang terkalibrasi dengan angka resmi BPS Kabupaten Tangerang: <strong>265,90 ribu jiwa (6,42%)</strong>.</p>
              </div>
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                <select class="filter-control" onchange="if(this.value) selectKecamatanDetail(this.value);" aria-label="Pilih Cepat Kecamatan di Peta">
                  <option value="">🎯 Loncat Cepat ke Kecamatan di Peta...</option>
                  <?php foreach ($SDGS_KECAMATAN_29 as $k): ?>
                    <option value="<?= htmlspecialchars($k['nama']); ?>">Kec. <?= htmlspecialchars($k['nama']); ?> (<?= $k['persen']; ?>% • Zona <?= $k['zona']; ?>)</option>
                  <?php endforeach; ?>
                </select>
                <span class="pill-badge crimson">● Merah (&ge; 7,2%)</span>
                <span class="pill-badge amber">● Kuning (5,5–7,1%)</span>
                <span class="pill-badge emerald">● Hijau (&lt; 5,5%)</span>
              </div>
            </div>

            <div class="map-split-grid" style="margin-bottom:22px;">
              <div>
                <div id="sdgsMapCanvas"></div>
              </div>
              <div class="kec-detail-box" id="kecamatanDetailPanel"></div>
            </div>

            <div class="table-toolbar">
              <div class="search-input-wrap">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" data-table-search="wrapTabelKecamatan" placeholder="Cari nama kecamatan, kode BPS, desa, atau fokus intervensi...">
              </div>
              <select class="filter-control" data-table-select="wrapTabelKecamatan">
                <option value="">Semua Zona Prioritas (29 Kecamatan)</option>
                <option value="Zona Merah">Zona Merah (Prioritas Tinggi)</option>
                <option value="Zona Kuning">Zona Kuning (Prioritas Menengah)</option>
                <option value="Zona Hijau">Zona Hijau (Terkendali)</option>
              </select>
            </div>

            <div class="sdgs-table-wrap" id="wrapTabelKecamatan">
              <table class="sdgs-table">
                <thead>
                  <tr>
                    <th>Kode BPS</th>
                    <th>Kecamatan</th>
                    <th>Zona</th>
                    <th>% Miskin</th>
                    <th>Penduduk Miskin</th>
                    <th>KK Desil 1</th>
                    <th>Bansos</th>
                    <th>RLS</th>
                    <th>Sanitasi</th>
                    <th style="text-align:right;">Peta</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($SDGS_KECAMATAN_29 as $k):
                    $z_cls = $k['zona'] === 'Merah' ? 'crimson' : ($k['zona'] === 'Kuning' ? 'amber' : 'emerald');
                  ?>
                    <tr data-kecamatan="<?= htmlspecialchars($k['nama']); ?>" style="cursor:pointer;" onclick="goToPetaKecamatan('<?= htmlspecialchars($k['nama']); ?>')">
                      <td class="mono"><?= htmlspecialchars($k['kode']); ?></td>
                      <td><strong>Kec. <?= htmlspecialchars($k['nama']); ?></strong></td>
                      <td><span class="pill-badge <?= $z_cls; ?>">Zona <?= htmlspecialchars($k['zona']); ?></span></td>
                      <td class="mono"><strong><?= number_format($k['persen'], 2, ',', '.'); ?>%</strong></td>
                      <td class="mono"><?= number_format($k['miskin_ribu'], 2, ',', '.'); ?> rb jiwa</td>
                      <td class="mono"><?= number_format($k['desil1_kk'], 0, ',', '.'); ?> KK</td>
                      <td class="mono"><?= number_format($k['bansos_kk'], 0, ',', '.'); ?> KK</td>
                      <td class="mono"><?= $k['rls']; ?> Thn</td>
                      <td class="mono"><?= $k['sanitasi']; ?>%</td>
                      <td style="text-align:right;">
                        <button type="button" class="btn-sdgs btn-sdgs-sm" onclick="event.stopPropagation();goToPetaKecamatan('<?= htmlspecialchars($k['nama']); ?>')">
                          <i class="fa-solid fa-crosshairs" style="color:var(--accent)"></i> Fokus
                        </button>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <!-- =================================================================
             MODUL 10: ADMIN EXECUTIVE CONTROL, VISIBILITAS MODUL & CETAK PDF
             ================================================================= -->
        <section class="module-pane" id="mod-admin">
          <div class="panel-card">
            <?php if (!$sdgs_is_admin): ?>
              <div style="text-align: center; padding: 48px 20px; max-width: 520px; margin: 0 auto;">
                <div style="width: 68px; height: 68px; border-radius: 18px; background: var(--sdgs-red-soft); border: 1px solid var(--border-sdgs); color: var(--sdgs-red); font-size: 28px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px;">
                  <i class="fa-solid fa-shield-halved"></i>
                </div>
                <h2 style="font-size: 22px; margin-bottom: 8px;">Area Terbatas Khusus Admin</h2>
                <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 22px; line-height: 1.6;">
                  Panel Kontrol Eksekutif SDGs (pengaturan visibilitas modul, privasi NIK, verifikasi bansos, edit/hapus data warga, export dataset sensitif, dan cetak laporan PDF resmi) hanya dapat diakses oleh pemilik/administrator yang telah terautentikasi.
                </p>
                <div style="display: flex; justify-content: center; gap: 10px; flex-wrap: wrap;">
                  <button type="button" class="btn-sdgs btn-sdgs-primary" onclick="openAdminLoginModal()">
                    <i class="fa-solid fa-right-to-bracket"></i> Login Admin SDGs
                  </button>
                  <a href="admin/login.php" class="btn-sdgs">
                    <i class="fa-solid fa-sliders"></i> Login via Admin Portofolio
                  </a>
                </div>
              </div>
            <?php else: ?>
              <div class="panel-header">
                <div>
                  <span class="pill-badge emerald" style="margin-bottom:6px;"><i class="fa-solid fa-shield-halved"></i> MODUL 10 // KONTROL PENUH ADMIN SDGs (TERAUTENTIKASI)</span>
                  <h2 class="panel-title">10. Admin Control Center, Visibilitas Modul & Laporan PDF</h2>
                  <p class="panel-subtitle">Atur modul mana saja yang tampil untuk publik, kontrol sensor NIK, ekspor dataset CSV Excel, dan cetak dokumen PDF A4 resmi.</p>
                </div>
                <form method="POST" action="sdgs-demo.php">
                  <input type="hidden" name="sdgs_action" value="sdgs_admin_logout">
                  <button type="submit" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-right-from-bracket" style="color:var(--sdgs-red)"></i> Logout Admin</button>
                </form>
              </div>

              <!-- Kontrol Visibilitas & Privasi (Persis seperti Portofolio Admin) -->
              <form method="POST" action="sdgs-demo.php#mod-admin" style="background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: 12px; padding: 20px; margin-bottom: 22px;">
                <input type="hidden" name="sdgs_action" value="save_sdgs_settings">
                <div style="display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; margin-bottom: 14px;">
                  <div>
                    <h3 style="font-size: 16px;"><i class="fa-solid fa-eye-slash" style="color: var(--accent);"></i> Kontrol Visibilitas Modul & Privasi Publik</h3>
                    <p style="font-size: 12.5px; color: var(--text-muted);">Centang untuk menampilkan modul ke pengunjung publik, hilangkan centang untuk menyembunyikan.</p>
                  </div>
                  <button type="submit" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan SDGs
                  </button>
                </div>

                <div class="form-row-2" style="margin-bottom: 14px;">
                  <div class="form-group-sdgs" style="margin-bottom:0;">
                    <label>Nama Instansi / Header Sistem</label>
                    <input type="text" name="nama_instansi" class="form-input-sdgs" value="<?= htmlspecialchars($sdgs_cfg['nama_instansi']); ?>">
                  </div>
                  <div class="form-group-sdgs" style="margin-bottom:0;">
                    <label>Standar Garis Kemiskinan BPS (Rp / Kapita / Bulan)</label>
                    <input type="number" name="garis_kemiskinan" class="form-input-sdgs mono" value="<?= (int)$sdgs_cfg['garis_kemiskinan']; ?>" step="500">
                  </div>
                </div>

                <div class="vis-switch-grid">
                  <label class="vis-switch-item"><span><i class="fa-solid fa-user-secret" style="color:var(--emerald)"></i> Sensor NIK di Mode Publik</span><input type="checkbox" name="mask_nik_public" value="1" <?= !empty($sdgs_cfg['mask_nik_public']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Izinkan Publik Berdonasi (QRIS)</span><input type="checkbox" name="allow_donasi" value="1" <?= !empty($sdgs_cfg['allow_donasi']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Izinkan Publik Melamar Kerja</span><input type="checkbox" name="allow_loker_apply" value="1" <?= !empty($sdgs_cfg['allow_loker_apply']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Izinkan Publik Kirim Pengaduan</span><input type="checkbox" name="allow_pengaduan" value="1" <?= !empty($sdgs_cfg['allow_pengaduan']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 1 (Penduduk)</span><input type="checkbox" name="show_mod_penduduk" value="1" <?= !empty($sdgs_cfg['show_mod_penduduk']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 2 (Bansos)</span><input type="checkbox" name="show_mod_bansos" value="1" <?= !empty($sdgs_cfg['show_mod_bansos']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 3 (UMKM)</span><input type="checkbox" name="show_mod_umkm" value="1" <?= !empty($sdgs_cfg['show_mod_umkm']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 4 (Loker)</span><input type="checkbox" name="show_mod_loker" value="1" <?= !empty($sdgs_cfg['show_mod_loker']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 5 (Pelatihan)</span><input type="checkbox" name="show_mod_pelatihan" value="1" <?= !empty($sdgs_cfg['show_mod_pelatihan']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 6 (Donasi)</span><input type="checkbox" name="show_mod_donasi" value="1" <?= !empty($sdgs_cfg['show_mod_donasi']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 7 (Monitoring)</span><input type="checkbox" name="show_mod_monitoring" value="1" <?= !empty($sdgs_cfg['show_mod_monitoring']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 8 (Pengaduan)</span><input type="checkbox" name="show_mod_pengaduan" value="1" <?= !empty($sdgs_cfg['show_mod_pengaduan']) ? 'checked' : ''; ?>></label>
                  <label class="vis-switch-item"><span>Tampilkan Modul 9 (Peta 29 Kec.)</span><input type="checkbox" name="show_mod_peta" value="1" <?= !empty($sdgs_cfg['show_mod_peta']) ? 'checked' : ''; ?>></label>
                </div>
              </form>

              <!-- 3 Kartu Aksi Eksekutif Admin -->
              <div class="cards-grid-3">
                <div class="item-bento-card">
                  <div>
                    <span class="pill-badge crimson"><i class="fa-solid fa-file-pdf"></i> Laporan Resmi A4</span>
                    <h3 style="font-size:16.5px;margin:8px 0 4px;">Cetak Laporan Eksekutif PDF</h3>
                    <p style="font-size:12.5px;color:var(--text-muted);">Cetak laporan lengkap dengan Kop Kabupaten Tangerang, data resmi BPS 2026 (265,90 rb / 6,42%), dan tabel 29 kecamatan.</p>
                  </div>
                  <button type="button" class="btn-sdgs btn-sdgs-primary btn-sdgs-sm" onclick="printOfficialSdgsReport('LAP-EKSEKUTIF-SDGS1-2026')">
                    <i class="fa-solid fa-print"></i> Cetak Laporan Eksekutif PDF
                  </button>
                </div>

                <div class="item-bento-card">
                  <div>
                    <span class="pill-badge emerald"><i class="fa-solid fa-file-csv"></i> Export Excel CSV</span>
                    <h3 style="font-size:16.5px;margin:8px 0 4px;">Unduh Dataset Lengkap (Admin)</h3>
                    <p style="font-size:12.5px;color:var(--text-muted);">Unduh seluruh dataset termasuk data penduduk & bansos dalam format CSV siap buka di Microsoft Excel.</p>
                  </div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                    <a href="sdgs-demo.php?export_csv=bps_kecamatan" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-download"></i> 29 Kec.</a>
                    <a href="sdgs-demo.php?export_csv=penduduk" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-download"></i> Penduduk</a>
                    <a href="sdgs-demo.php?export_csv=bansos" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-download"></i> Bansos</a>
                    <a href="sdgs-demo.php?export_csv=umkm" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-download"></i> UMKM</a>
                  </div>
                </div>

                <div class="item-bento-card">
                  <div>
                    <span class="pill-badge cyan"><i class="fa-solid fa-database"></i> Manajemen Data & Pintasan</span>
                    <h3 style="font-size:16.5px;margin:8px 0 4px;">Reset Data & Lintas Panel Admin</h3>
                    <p style="font-size:12.5px;color:var(--text-muted);">Terhubung satu sesi dengan Admin Portofolio & dapat mereset data simulasi kapan saja.</p>
                  </div>
                  <div style="display:flex;flex-direction:column;gap:8px;">
                    <form method="POST" action="sdgs-demo.php#mod-admin" onsubmit="return confirm('Reset seluruh data operasional 10 modul ke kondisi awal?');">
                      <input type="hidden" name="sdgs_action" value="reset_demo_data">
                      <button type="submit" class="btn-sdgs btn-sdgs-sm" style="width:100%;">
                        <i class="fa-solid fa-rotate"></i> Reset Data Simulasi ke Default
                      </button>
                    </form>
                    <a href="admin/index.php" class="btn-sdgs btn-sdgs-accent btn-sdgs-sm">
                      <i class="fa-solid fa-sliders"></i> Ke Admin Portofolio Utama
                    </a>
                  </div>
                </div>
              </div>
            <?php endif; ?>
          </div>
        </section>

      </div>
    </div>

    <!-- ==================== FOOTER REFERENSI RESMI ==================== -->
    <footer style="margin-top: 28px; padding: 22px 24px; background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap;">
      <div style="max-width: 820px;">
        <div style="font-weight: 700; color: var(--text-heading); font-size: 14px; margin-bottom: 4px;">
          <i class="fa-solid fa-landmark" style="color:var(--sdgs-red)"></i> Referensi Resmi Data Kemiskinan & Indikator SDGs Kabupaten Tangerang 2026
        </div>
        <p style="font-size: 12.5px; color: var(--text-muted); line-height: 1.6;">
          1. <strong>BPS Kabupaten Tangerang (25 Sep 2026):</strong> <a href="https://tangerangkab.bps.go.id/id/publication/2026/09/25/4b93050c79a46661b2074554/statistik-daerah-kabupaten-tangerang-2026.html" target="_blank" rel="noopener">Statistik Daerah Kabupaten Tangerang 2026</a> (Penduduk miskin 2025: 265,90 ribu jiwa / 6,42%).<br>
          2. <strong>BPS Kabupaten Tangerang (27 Feb 2026):</strong> <a href="https://tangerangkab.bps.go.id/id/publication/2026/02/27/2280e138d371f310a3d97399/kabupaten-tangerang-dalam-angka-2026.html" target="_blank" rel="noopener">Kabupaten Tangerang Dalam Angka 2026</a> •
          3. <strong>Open Data:</strong> <a href="https://opendata.tangerangkab.go.id/" target="_blank" rel="noopener">opendata.tangerangkab.go.id</a> •
          4. <strong>Kemenko PM:</strong> <a href="http://dashboard-dtsen.pemberdayaan.go.id/" target="_blank" rel="noopener">Dashboard DTSEN 2026</a>.
        </p>
      </div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <a href="index.php" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-user-tie"></i> Portofolio <?= htmlspecialchars($s_portofolio['nama']); ?></a>
        <a href="http://localhost/cakjoyo" target="_blank" class="btn-sdgs btn-sdgs-sm"><i class="fa-solid fa-bowl-food" style="color:var(--amber)"></i> Aplikasi Soto Cak Joyo</a>
      </div>
    </footer>

  </main>

  <!-- ==================== FLOATING BAR KHUSUS ADMIN SDGs (SAMA DENGAN PORTOFOLIO) ==================== -->
  <?php if ($sdgs_is_admin): ?>
    <div class="sdgs-admin-floating">
      <span><i class="fa-solid fa-shield-halved" style="color:#10B981;"></i> <strong>Mode Admin SDGs Aktif</strong></span>
      <span style="opacity:0.35;">|</span>
      <button type="button" class="btn-sdgs btn-sdgs-sm" style="padding:4px 10px;" onclick="switchSdgsModule('mod-admin', true)">Visibilitas & PDF</button>
      <button type="button" class="btn-sdgs btn-sdgs-sm" style="padding:4px 10px;" onclick="openPendudukModal()">+ Warga</button>
      <button type="button" class="btn-sdgs btn-sdgs-sm" style="padding:4px 10px;" onclick="openBansosModal()">+ Bansos</button>
      <form method="POST" action="sdgs-demo.php" style="display:inline;">
        <input type="hidden" name="sdgs_action" value="sdgs_admin_logout">
        <button type="submit" class="btn-sdgs btn-sdgs-sm" style="padding:4px 10px;border-color:rgba(244,63,94,0.4);color:#FDA4AF;">Keluar Admin</button>
      </form>
    </div>
  <?php endif; ?>

  <!-- ==================== UNIVERSAL MODAL OVERLAY ==================== -->
  <div class="sdgs-modal-overlay" id="sdgsModalOverlay" role="dialog" aria-modal="true">
    <div class="sdgs-modal-box">
      <div class="sdgs-modal-header">
        <h3 id="sdgsModalTitle" style="font-size: 17px;">Detail Modul</h3>
        <button type="button" class="icon-btn-sdgs" onclick="closeSdgsModal()" aria-label="Tutup Modal">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="sdgs-modal-body" id="sdgsModalBody"></div>
    </div>
  </div>

  <div class="sdgs-toast-wrap" id="sdgsToastWrap"></div>
  <div id="officialPrintArea"></div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>
    window.SDGS_SERVER_DATA = {
      meta: <?= json_encode($SDGS_OFFICIAL_META, JSON_UNESCAPED_UNICODE); ?>,
      tren: <?= json_encode($SDGS_TREN_TAHUNAN, JSON_UNESCAPED_UNICODE); ?>,
      kecamatan: <?= json_encode($SDGS_KECAMATAN_29, JSON_UNESCAPED_UNICODE); ?>,
      isAdmin: <?= $sdgs_is_admin ? 'true' : 'false'; ?>
    };
  </script>
  <script src="sdgs/assets/sdgs-app.js"></script>

  <?php if (!empty($sdgs_flash)):
    list($fl_type, $fl_msg) = explode(':', $sdgs_flash, 2);
  ?>
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        showSdgsToast(<?= json_encode($fl_msg); ?>, <?= $fl_type === 'error' ? 'true' : 'false'; ?>);
      });
    </script>
  <?php endif; ?>
</body>
</html>
