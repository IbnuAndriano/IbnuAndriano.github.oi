<?php
/**
 * KONEKSI DATABASE & HYBRID PERSISTENCE ENGINE — PORTOFOLIO IBNU ANDRIANO
 * Dual-Engine: MySQL (db_portofolio) + Persistent Local JSON DB (uploads/local_db.json)
 * Menjamin 100% seluruh fitur Simpan Profil, Upload Foto/CV, Visibilitas & CRUD
 * langsung berhasil tanpa pernah gagal meskipun MySQL di XAMPP sedang mati.
 */

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

// Konfigurasi Database MySQL
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "db_portofolio";

mysqli_report(MYSQLI_REPORT_OFF);

$koneksi = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$koneksi) {
    // Coba koneksi ke 127.0.0.1 atau buat database otomatis jika server MySQL menyala
    $server_check = @mysqli_connect($db_host, $db_user, $db_pass);
    if (!$server_check) {
        $server_check = @mysqli_connect("127.0.0.1", $db_user, $db_pass);
        if ($server_check) {
            $db_host = "127.0.0.1";
        }
    }
    if ($server_check) {
        @mysqli_query($server_check, "CREATE DATABASE IF NOT EXISTS `$db_name` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $koneksi = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);
        @mysqli_close($server_check);
    }
}

// ============================================================================
// 1. PERSISTENT LOCAL JSON DATABASE ENGINE (uploads/local_db.json)
// ============================================================================
define('LOCAL_DB_FILE', __DIR__ . '/uploads/local_db.json');

function get_default_settings_data() {
    return [
        'id' => 1,
        'nama' => 'Ibnu Andriano',
        'tagline' => 'Mahasiswa Sistem Informasi & Web Developer',
        'hero_headline' => 'Bangun Sistem Web yang Rapi, Fungsional, dan Siap Dipakai.',
        'hero_desc' => 'Mahasiswa S1 Sistem Informasi di Universitas Bina Bangsa yang fokus ngoding aplikasi web berbasis PHP, MySQL, dan JavaScript. Terbiasa kerja rapi dari pengalaman di bidang administrasi & operasional logistik, plus hobi motoran jarak jauh buat jaga fokus.',
        'roles_typewriter' => 'Full-Stack Web Developer,Mahasiswa S1 Sistem Informasi,Backend & Database Dev,Weekend Rider (Beat Deluxe)',
        'availability_text' => 'Open untuk Magang (Internship), Projek Web & Kerja Full-Time',
        'kampus' => 'Universitas Bina Bangsa',
        'prodi' => 'S1 Sistem Informasi',
        'semester' => 'Semester 3 (Aktif)',
        'nim' => '23110001',
        'ipk' => '3.82 / 4.00',
        'asal' => 'Ds. Surya Bahari, Kec. Pakuhaji, Kab. Tangerang, Banten',
        'whatsapp' => '081367219097',
        'email' => 'ibnuandrianoofficial@gmail.com',
        'instagram' => '@padukaarajaaa',
        'linkbio' => 'https://linkbio.co/ibnushop',
        'github' => 'https://github.com/ibnuandriano',
        'linkedin' => 'https://linkedin.com/in/ibnuandriano',
        'avatar_url' => 'uploads/foto_ibnu.jpg',
        'motor_image_url' => 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=800&q=80',
        'cv_url' => '#',
        'show_availability' => 1,
        'show_hero_stats' => 1,
        'show_photo' => 1,
        'show_about' => 1,
        'show_academic_detail' => 1,
        'show_services' => 1,
        'show_experience' => 1,
        'show_projects' => 1,
        'show_skills' => 1,
        'show_education' => 1,
        'show_certificates' => 1,
        'show_motor' => 1,
        'show_gallery' => 1,
        'show_documents' => 1,
        'show_cv' => 1,
        'show_contact' => 1,
        'show_social_links' => 1,
        'show_terminal' => 1
    ];
}

function get_default_experiences_data() {
    return [
        [
            'id' => 1,
            'posisi' => 'Staff Administrasi',
            'instansi' => 'Pantura Studio',
            'jenis' => 'Pengalaman Kerja',
            'lokasi' => 'Kab. Tangerang, Banten',
            'periode' => 'Januari - Agustus 2026',
            'deskripsi' => 'Menangani operasional administrasi harian, pelayanan pelanggan, pencatatan transaksi keuangan, serta pengolahan foto sesuai target harian.',
            'pencapaian' => "Melayani kebutuhan administrasi dan komunikasi pelanggan secara ramah dan responsif\nMelakukan pendataan transaksi harian dan menyusun rekap laporan keuangan\nMemproses editing foto pelanggan secara cepat dan teliti sesuai target harian\nMenjaga kerapihan dokumen dan area kerja sesuai SOP",
            'urutan' => 1,
            'is_visible' => 1
        ],
        [
            'id' => 2,
            'posisi' => 'Operator / Sortir Barang (Logistik)',
            'instansi' => 'J&T Express',
            'jenis' => 'Pengalaman Kerja',
            'lokasi' => 'Kab. Tangerang, Banten',
            'periode' => 'Juli 2025 - Januari 2026',
            'deskripsi' => 'Bertanggung jawab atas proses inbound, outbound, pemindaian barcode resi, penyortiran paket berdasarkan rute wilayah, dan kontrol kualitas gudang.',
            'pencapaian' => "Menangani alur Inbound dan Outbound paket sesuai SOP Gudang\nMengoperasikan Handheld Scanner (Barcode Scanning) untuk akurasi pelacakan\nMelakukan sorting paket per kecamatan/wilayah dengan cepat dan minim selisih\nMengelola manifes pengiriman serta quality control barang",
            'urutan' => 2,
            'is_visible' => 1
        ],
        [
            'id' => 3,
            'posisi' => 'Full-Stack Web Developer',
            'instansi' => 'Aplikasi E-Commerce Soto Lamongan Cak Joyo (Projek Semester 3)',
            'jenis' => 'Projek Aplikasi Web',
            'lokasi' => 'Tangerang, Banten',
            'periode' => '2025 - Sekarang',
            'deskripsi' => 'Merancang dan membangun aplikasi web pemesanan kuliner khas Lamongan lengkap dengan keranjang belanja real-time, payment gateway QRIS/VA, cetak struk nota, dan dashboard admin.',
            'pencapaian' => "Membangun katalog menu dinamis, filter kategori, dan keranjang belanja interaktif\nMengintegrasikan pembayaran QRIS, Virtual Account, E-Wallet, dan manajemen meja\nMerancang fitur lacak pesanan pelanggan dan cetak nota invoice digital",
            'urutan' => 3,
            'is_visible' => 1
        ],
        [
            'id' => 4,
            'posisi' => 'System Analyst & Backend Developer',
            'instansi' => 'SIPANDU SDGs Goal 1 Kab. Tangerang (Projek Semester 2)',
            'jenis' => 'Rekayasa Sistem Informasi',
            'lokasi' => 'Universitas Bina Bangsa',
            'periode' => '2025',
            'deskripsi' => 'Mengembangkan 10 modul sistem informasi pengentasan kemiskinan Kabupaten Tangerang berbasis data resmi BPS 2026 (265,90 ribu jiwa / 6,42%), Open Data, dan DTSEN.',
            'pencapaian' => "Merancang skema database MySQL 10 modul layanan publik (Penduduk, Bansos, UMKM, Loker, Pelatihan, Donasi, Pengaduan, Peta 29 Kecamatan)\nMengintegrasikan visualisasi grafik tren BPS Chart.js dan peta spasial Leaflet.js\nMenyusun fitur ekspor dataset CSV Excel dan cetak laporan resmi PDF A4",
            'urutan' => 4,
            'is_visible' => 1
        ]
    ];
}

function get_default_projects_data() {
    return [
        [
            'id' => 1,
            'judul' => 'SIPANDU SDGs Goal 1: Tanpa Kemiskinan — Kab. Tangerang 2026',
            'semester' => 'Projek Semester 2',
            'kategori' => 'Sistem Informasi & GIS',
            'deskripsi_singkat' => 'Platform web penanggulangan kemiskinan Kabupaten Tangerang berbasis data resmi BPS 2026 (265,90 ribu jiwa / 6,42%), Open Data, dan DTSEN Kemenko PM dengan 10 modul fungsional terintegrasi.',
            'fitur_list' => "1. Pendataan Masyarakat Miskin (Validasi NIK 3603, penghasilan, tanggungan, Desil DTSEN)\n2. Penyaluran Bantuan Sosial (PKH, BPNT, BLT-DD, jadwal, verifikasi & cetak nota)\n3. Program UMKM Binaan (Pendaftaran usaha, monitoring omzet, pelatihan & pendampingan)\n4. Bursa Lowongan Kerja (Info loker mitra industri Tangerang, lamar & upload CV)\n5. Pelatihan & Edukasi Digital (Materi kursus vokasi & cetak sertifikat resmi)\n6. Donasi & Crowdfunding Sosial (Payment Gateway QRIS/VA & transparansi dana)\n7. Monitoring SDGs & Data BPS 2026 (Grafik tren 2020-2026 & korelasi IPM/Sanitasi)\n8. Pengaduan Masyarakat (Form laporan salah sasaran & lacak nomor tiket 4 tahap)\n9. Pemetaan Spasial Wilayah (Peta interaktif Leaflet.js 29 Kecamatan Kab. Tangerang)\n10. Admin Executive Control (Export CSV Excel & Cetak Laporan Resmi PDF A4)",
            'tech_stack' => 'PHP Native, MySQL, Chart.js, Leaflet GIS, Payment Gateway, Print PDF',
            'link_demo' => 'sdgs-demo.php',
            'link_hosting' => '',
            'link_repo' => '#',
            'gambar' => 'default_project.jpg',
            'is_featured' => 1,
            'urutan' => 1,
            'is_visible' => 1
        ],
        [
            'id' => 2,
            'judul' => 'Aplikasi Web Penjualan & POS Soto Lamongan Cak Joyo',
            'semester' => 'Projek Semester 3',
            'kategori' => 'E-Commerce UMKM & POS',
            'deskripsi_singkat' => 'Aplikasi pemesanan kuliner dan kasir digital untuk UMKM Soto Lamongan Cak Joyo. Dilengkapi keranjang belanja real-time, payment gateway QRIS & Virtual Account, lacak pesanan, manajemen meja, dan cetak nota.',
            'fitur_list' => "1. Katalog Menu Dinamis & Filter Kategori Soto/Rawon/Rabeg\n2. Keranjang Belanja Real-Time & Kalkulasi Subtotal Otomatis\n3. Checkout Multi-Metode (QRIS Dinamis, Virtual Account Bank, E-Wallet, COD)\n4. Pelacakan Status Pesanan Real-Time & Manajemen Meja Otomatis\n5. Cetak Struk / Nota Digital Pelanggan\n6. Panel Admin Manajemen Menu, Pesanan & Laporan Penjualan",
            'tech_stack' => 'PHP Native, MySQL, JavaScript ES6+, Bootstrap 5, QRIS Payment Gateway',
            'link_demo' => 'http://localhost/cakjoyo',
            'link_hosting' => '',
            'link_repo' => '#',
            'gambar' => 'default_project.jpg',
            'is_featured' => 1,
            'urutan' => 2,
            'is_visible' => 1
        ],
        [
            'id' => 3,
            'judul' => 'Sistem Manajemen Inventaris & Stok Gudang',
            'semester' => 'Studi Kasus Sistem Informasi',
            'kategori' => 'Inventory & Gudang',
            'deskripsi_singkat' => 'Aplikasi kontrol stok barang masuk dan keluar (inbound/outbound), peringatan stok menipis otomatis, dan rekapitulasi laporan gudang bulanan.',
            'fitur_list' => "1. Master Data Barang & Kategori\n2. Pencatatan Barang Masuk (Inbound) & Keluar (Outbound)\n3. Notifikasi Stok Minimum Otomatis\n4. Cetak Rekapitulasi Stok PDF",
            'tech_stack' => 'PHP Native, MySQL, JavaScript, Bootstrap 5',
            'link_demo' => '#',
            'link_hosting' => '',
            'link_repo' => '#',
            'gambar' => 'default_project.jpg',
            'is_featured' => 0,
            'urutan' => 3,
            'is_visible' => 1
        ],
        [
            'id' => 4,
            'judul' => 'Beat Deluxe Telemetry & Service Tracker',
            'semester' => 'Side Project',
            'kategori' => 'Automotive Utility App',
            'deskripsi_singkat' => 'Web app pencatat jadwal servis berkala Honda Beat Deluxe, pengingat ganti oli mesin/gardan berdasarkan odometer, dan kalkulator konsumsi BBM touring.',
            'fitur_list' => "1. Log Odometer & Pengingat Servis Rutin\n2. Riwayat Ganti Oli Mesin, Gardan & CVT\n3. Kalkulator Efisiensi BBM (Km/Liter)\n4. Checklist Perlengkapan Touring",
            'tech_stack' => 'JavaScript ES6+, LocalStorage, Chart.js, Modern CSS',
            'link_demo' => '#',
            'link_hosting' => '',
            'link_repo' => '#',
            'gambar' => 'default_project.jpg',
            'is_featured' => 0,
            'urutan' => 4,
            'is_visible' => 1
        ]
    ];
}

function get_default_skills_data() {
    return [
        ['id' => 1, 'nama' => 'PHP (Native & OOP)', 'kategori' => 'backend', 'level' => 90, 'deskripsi' => 'Pengembangan backend aplikasi web, autentikasi sesi, REST/JSON handler, dan integrasi CRUD database.', 'icon' => 'fa-brands fa-php', 'urutan' => 1, 'is_visible' => 1],
        ['id' => 2, 'nama' => 'MySQL & Desain Database', 'kategori' => 'backend', 'level' => 88, 'deskripsi' => 'Perancangan ERD, normalisasi tabel relasional, optimasi query SQL, dan manajemen phpMyAdmin.', 'icon' => 'fa-solid fa-database', 'urutan' => 2, 'is_visible' => 1],
        ['id' => 3, 'nama' => 'JavaScript (ES6+ & DOM)', 'kategori' => 'frontend', 'level' => 86, 'deskripsi' => 'Interaktivitas UI, Fetch/AJAX tanpa reload, integrasi Chart.js, Leaflet GIS, dan manipulasi DOM.', 'icon' => 'fa-brands fa-js', 'urutan' => 3, 'is_visible' => 1],
        ['id' => 4, 'nama' => 'HTML5, CSS3 & Bootstrap 5', 'kategori' => 'frontend', 'level' => 92, 'deskripsi' => 'Layout modern responsif dengan CSS Grid, Flexbox, Bento UI, dark/light mode, dan optimasi mobile.', 'icon' => 'fa-brands fa-html5', 'urutan' => 4, 'is_visible' => 1],
        ['id' => 5, 'nama' => 'Python & Logika Algoritma', 'kategori' => 'backend', 'level' => 80, 'deskripsi' => 'Dasar struktur data, automasi skrip pengolahan data, dan pemecahan masalah komputasi.', 'icon' => 'fa-brands fa-python', 'urutan' => 5, 'is_visible' => 1],
        ['id' => 6, 'nama' => 'Git, GitHub & VS Code', 'kategori' => 'tools', 'level' => 85, 'deskripsi' => 'Version control, manajemen repositori kode, debugging, dan workflow pengembangan modern.', 'icon' => 'fa-brands fa-git-alt', 'urutan' => 6, 'is_visible' => 1],
        ['id' => 7, 'nama' => 'XAMPP, Apache & Deployment', 'kategori' => 'tools', 'level' => 90, 'deskripsi' => 'Setup environment server lokal, konfigurasi database MySQL/MariaDB, dan deployment ke web hosting.', 'icon' => 'fa-solid fa-server', 'urutan' => 7, 'is_visible' => 1],
        ['id' => 8, 'nama' => 'Microsoft Office (Excel, Word, PPT)', 'kategori' => 'tools', 'level' => 90, 'deskripsi' => 'Pengolahan data administrasi & rumus laporan keuangan di Excel, dokumen resmi Word, dan presentasi.', 'icon' => 'fa-solid fa-file-excel', 'urutan' => 8, 'is_visible' => 1],
        ['id' => 9, 'nama' => 'Administrasi, Logistik & Teamwork', 'kategori' => 'rider', 'level' => 90, 'deskripsi' => 'Pengalaman nyata menangani administrasi harian, inbound-outbound gudang, barcode scanning, dan komunikasi tim.', 'icon' => 'fa-solid fa-people-group', 'urutan' => 9, 'is_visible' => 1]
    ];
}

function get_default_education_data() {
    return [
        ['id' => 1, 'jenjang' => 'Sarjana (S1)', 'institusi' => 'Universitas Bina Bangsa', 'jurusan' => 'Sistem Informasi', 'periode' => '2025 - Sekarang', 'status' => 'Mahasiswa Aktif', 'deskripsi' => 'Fokus pada Rekayasa Perangkat Lunak, Analisis & Perancangan Sistem Informasi, Manajemen Basis Data, dan Pemrograman Web.', 'urutan' => 1, 'is_visible' => 1],
        ['id' => 2, 'jenjang' => 'SMA / Sederajat', 'institusi' => 'SMA Yustika', 'jurusan' => 'Ilmu Pengetahuan Sosial (IPS)', 'periode' => '2022 - 2025', 'status' => 'Lulus', 'deskripsi' => 'Menyelesaikan pendidikan menengah atas dengan aktif di kegiatan sekolah dan pengembangan minat teknologi.', 'urutan' => 2, 'is_visible' => 1],
        ['id' => 3, 'jenjang' => 'SMP / Sederajat', 'institusi' => 'SMP Negeri 3 Pakuhaji', 'jurusan' => 'Pendidikan Menengah Pertama', 'periode' => '2019 - 2022', 'status' => 'Lulus', 'deskripsi' => 'Mengenal dasar pengoperasian perangkat komputer dan jaringan.', 'urutan' => 3, 'is_visible' => 1],
        ['id' => 4, 'jenjang' => 'SD / Sederajat', 'institusi' => 'SD Negeri Buaran Mangga II', 'jurusan' => 'Pendidikan Dasar', 'periode' => '2013 - 2019', 'status' => 'Lulus', 'deskripsi' => 'Menyelesaikan pendidikan dasar di Kecamatan Pakuhaji, Kabupaten Tangerang.', 'urutan' => 4, 'is_visible' => 1]
    ];
}

function get_default_certificates_data() {
    return [
        ['id' => 1, 'judul' => 'Junior Web Developer & PHP Back-End Development', 'penerbit' => 'IT Academy & Universitas Bina Bangsa', 'tahun' => '2025', 'deskripsi' => 'Sertifikasi kompetensi pembuatan aplikasi web dinamis dengan PHP Native/OOP, autentikasi sesi, dan keamanan CRUD MySQL.', 'link_kredensial' => '#', 'icon' => 'fa-solid fa-code', 'is_visible' => 1],
        ['id' => 2, 'judul' => 'Relational Database Design & SQL Query Optimization', 'penerbit' => 'Database Academy Foundation', 'tahun' => '2025', 'deskripsi' => 'Perancangan ERD, normalisasi tabel relasional 1NF–3NF, dan optimasi query SQL untuk aplikasi skala menengah.', 'link_kredensial' => '#', 'icon' => 'fa-solid fa-database', 'is_visible' => 1],
        ['id' => 3, 'judul' => 'Modern JavaScript DOM & Interactive Web UI', 'penerbit' => 'Frontend Development Institute', 'tahun' => '2024', 'deskripsi' => 'Pengembangan antarmuka interaktif, manipulasi DOM, Fetch API asynchronous, dan visualisasi data.', 'link_kredensial' => '#', 'icon' => 'fa-brands fa-js', 'is_visible' => 1],
        ['id' => 4, 'judul' => 'Defensive Riding & Touring Endurance', 'penerbit' => 'Banten Riders Community', 'tahun' => '2024', 'deskripsi' => 'Keselamatan berkendara jarak jauh, manajemen fokus di jalan raya, dan perawatan teknis kendaraan.', 'link_kredensial' => '#', 'icon' => 'fa-solid fa-motorcycle', 'is_visible' => 1]
    ];
}

function get_default_motor_data() {
    return [
        'id' => 1,
        'model' => 'Honda Beat Deluxe eSP',
        'tahun' => '2023',
        'odometer' => '14.850 KM',
        'rute_favorit' => 'Jalur Pantura & Kawasan BSD City',
        'tujuan_terjauh' => 'Bandung, Jawa Barat',
        'sunmori_spots' => 'KP3B (Serang) & BSD City (Tangerang)',
        'partner_riding' => 'Aryanto',
        'riding_style' => 'Defensive Riding, Smooth Throttle & High Focus',
        'deskripsi' => 'Partner setia buat mobilitas ngampus di Universitas Bina Bangsa sekaligus pelepas penat lewat touring jarak jauh dan sunmori bareng teman.'
    ];
}

function get_default_gear_data() {
    return [
        ['id' => 1, 'nama_gear' => 'Helm Standar SNI / DOT Full Face', 'kategori' => 'Proteksi', 'status' => 1, 'is_visible' => 1],
        ['id' => 2, 'nama_gear' => 'Jaket Riding Windproof & Body Protector', 'kategori' => 'Proteksi', 'status' => 1, 'is_visible' => 1],
        ['id' => 3, 'nama_gear' => 'Sarung Tangan Riding Anti-Slip', 'kategori' => 'Proteksi', 'status' => 1, 'is_visible' => 1],
        ['id' => 4, 'nama_gear' => 'Jas Hujan Setelan Waterproof', 'kategori' => 'Cuaca', 'status' => 1, 'is_visible' => 1],
        ['id' => 5, 'nama_gear' => 'Tool Kit Kunci Pas & Peralatan Darurat', 'kategori' => 'Teknis', 'status' => 1, 'is_visible' => 1],
        ['id' => 6, 'nama_gear' => 'Power Bank 20.000 mAh & Holder Navigasi', 'kategori' => 'Elektronik', 'status' => 1, 'is_visible' => 1],
        ['id' => 7, 'nama_gear' => 'Kotak P3K Mini & Obat Pribadi', 'kategori' => 'Medis', 'status' => 1, 'is_visible' => 1],
        ['id' => 8, 'nama_gear' => 'SIM C, STNK Aktif & e-Money', 'kategori' => 'Dokumen', 'status' => 1, 'is_visible' => 1]
    ];
}

function get_default_gallery_data() {
    return [
        ['id' => 1, 'judul' => 'Ngoding & Setup Sistem Database', 'gambar_url' => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80', 'kategori' => 'coding', 'caption' => 'Sesi garap projek web PHP & perancangan skema database MySQL.', 'is_visible' => 1],
        ['id' => 2, 'judul' => 'Touring Jalur Pantura — Bandung', 'gambar_url' => 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=800&q=80', 'kategori' => 'motor', 'caption' => 'Perjalanan jauh bareng Beat Deluxe melintasi rute Pantura menuju Bandung.', 'is_visible' => 1],
        ['id' => 3, 'judul' => 'Sunmori Pagi BSD City & KP3B', 'gambar_url' => 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=800&q=80', 'kategori' => 'sunmori', 'caption' => 'Sunday Morning Ride bareng Aryanto sebelum balik fokus kuliah dan ngoding.', 'is_visible' => 1]
    ];
}

function load_local_db() {
    $dir = dirname(LOCAL_DB_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $defaults = [
        'site_settings'   => get_default_settings_data(),
        'experiences'     => get_default_experiences_data(),
        'projects'        => get_default_projects_data(),
        'skills'          => get_default_skills_data(),
        'education'       => get_default_education_data(),
        'certificates'    => get_default_certificates_data(),
        'motor_telemetry' => get_default_motor_data(),
        'gear_checklist'  => get_default_gear_data(),
        'gallery'         => get_default_gallery_data(),
        'documents'       => [],
        'messages'        => [
            [
                'id' => 1,
                'nama' => 'Rekan Developer Tangerang',
                'kontak' => 'rekan@dev.id',
                'pesan' => 'Halo Ibnu! Projek Cak Joyo dan SDGs Kabupaten Tangerang-nya mantap dan rapi banget. Sukses terus kuliahnya di UNIBA!',
                'status_baca' => 1,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ],
        'admin_users'     => [
            [
                'id' => 1,
                'username' => 'PadukaIbnu',
                'password' => '$2y$10$S5063T08mvIYB/w0Zx5PRuaOvKwu5dF8KO4XBDQ20yBoIcgkl6.IW', // Ibnu@3097
                'nama_lengkap' => 'Ibnu Andriano',
                'email' => 'ibnuandrianoofficial@gmail.com'
            ]
        ]
    ];

    if (file_exists(LOCAL_DB_FILE)) {
        $raw = @file_get_contents(LOCAL_DB_FILE);
        $data = @json_decode($raw, true);
        if (is_array($data)) {
            foreach ($defaults as $k => $v) {
                if (!isset($data[$k]) || !is_array($data[$k])) {
                    $data[$k] = $v;
                }
            }
            // Pastikan semua key default site_settings tersedia
            foreach ($defaults['site_settings'] as $sk => $sv) {
                if (!array_key_exists($sk, $data['site_settings']) || $data['site_settings'][$sk] === null) {
                    $data['site_settings'][$sk] = $sv;
                }
            }
            // Perbaiki format email lama jika tidak ada '@'
            if (isset($data['site_settings']['email']) && strpos($data['site_settings']['email'], '@') === false) {
                $data['site_settings']['email'] = 'ibnuandrianoofficial@gmail.com';
            }
            return $data;
        }
    }
    @file_put_contents(LOCAL_DB_FILE, json_encode($defaults, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    return $defaults;
}

function save_local_db($data) {
    $dir = dirname(LOCAL_DB_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return @file_put_contents(LOCAL_DB_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
}

// ============================================================================
// 2. AUTO-MIGRATION & SYNC MYSQL JIKA MYSQL AKTIF
// ============================================================================
if ($koneksi) {
    mysqli_set_charset($koneksi, "utf8mb4");

    $check_table = @mysqli_query($koneksi, "SHOW TABLES LIKE 'site_settings'");
    if (!$check_table || mysqli_num_rows($check_table) === 0) {
        $sql_file = __DIR__ . '/database.sql';
        if (file_exists($sql_file)) {
            $sql_commands = file_get_contents($sql_file);
            if ($koneksi->multi_query($sql_commands)) {
                do {
                    if ($res = $koneksi->store_result()) {
                        $res->free();
                    }
                } while ($koneksi->more_results() && $koneksi->next_result());
            }
        }
    }

    $settings_cols = [
        'availability_text'    => "ALTER TABLE site_settings ADD COLUMN availability_text VARCHAR(180) DEFAULT 'Open untuk Magang (Internship), Projek Web & Kerja Full-Time'",
        'show_availability'    => "ALTER TABLE site_settings ADD COLUMN show_availability TINYINT(1) DEFAULT 1",
        'show_hero_stats'      => "ALTER TABLE site_settings ADD COLUMN show_hero_stats TINYINT(1) DEFAULT 1",
        'show_photo'           => "ALTER TABLE site_settings ADD COLUMN show_photo TINYINT(1) DEFAULT 1",
        'show_about'           => "ALTER TABLE site_settings ADD COLUMN show_about TINYINT(1) DEFAULT 1",
        'show_academic_detail' => "ALTER TABLE site_settings ADD COLUMN show_academic_detail TINYINT(1) DEFAULT 1",
        'show_services'        => "ALTER TABLE site_settings ADD COLUMN show_services TINYINT(1) DEFAULT 1",
        'show_experience'      => "ALTER TABLE site_settings ADD COLUMN show_experience TINYINT(1) DEFAULT 1",
        'show_projects'        => "ALTER TABLE site_settings ADD COLUMN show_projects TINYINT(1) DEFAULT 1",
        'show_skills'          => "ALTER TABLE site_settings ADD COLUMN show_skills TINYINT(1) DEFAULT 1",
        'show_education'       => "ALTER TABLE site_settings ADD COLUMN show_education TINYINT(1) DEFAULT 1",
        'show_certificates'    => "ALTER TABLE site_settings ADD COLUMN show_certificates TINYINT(1) DEFAULT 1",
        'show_motor'           => "ALTER TABLE site_settings ADD COLUMN show_motor TINYINT(1) DEFAULT 1",
        'show_gallery'         => "ALTER TABLE site_settings ADD COLUMN show_gallery TINYINT(1) DEFAULT 1",
        'show_documents'       => "ALTER TABLE site_settings ADD COLUMN show_documents TINYINT(1) DEFAULT 1",
        'show_cv'              => "ALTER TABLE site_settings ADD COLUMN show_cv TINYINT(1) DEFAULT 1",
        'show_contact'         => "ALTER TABLE site_settings ADD COLUMN show_contact TINYINT(1) DEFAULT 1",
        'show_social_links'    => "ALTER TABLE site_settings ADD COLUMN show_social_links TINYINT(1) DEFAULT 1",
        'show_terminal'        => "ALTER TABLE site_settings ADD COLUMN show_terminal TINYINT(1) DEFAULT 1",
        'motor_image_url'      => "ALTER TABLE site_settings ADD COLUMN motor_image_url TEXT NULL"
    ];

    foreach ($settings_cols as $col_name => $alter_query) {
        $chk = @mysqli_query($koneksi, "SHOW COLUMNS FROM site_settings LIKE '$col_name'");
        if ($chk && mysqli_num_rows($chk) === 0) {
            @mysqli_query($koneksi, $alter_query);
        }
    }

    $table_upgrades = [
        ['projects', 'link_hosting', "ALTER TABLE projects ADD COLUMN link_hosting VARCHAR(255) DEFAULT NULL"],
        ['projects', 'is_visible', "ALTER TABLE projects ADD COLUMN is_visible TINYINT(1) DEFAULT 1"],
        ['skills', 'is_visible', "ALTER TABLE skills ADD COLUMN is_visible TINYINT(1) DEFAULT 1"],
        ['education', 'is_visible', "ALTER TABLE education ADD COLUMN is_visible TINYINT(1) DEFAULT 1"],
        ['certificates', 'is_visible', "ALTER TABLE certificates ADD COLUMN is_visible TINYINT(1) DEFAULT 1"],
        ['gallery', 'is_visible', "ALTER TABLE gallery ADD COLUMN is_visible TINYINT(1) DEFAULT 1"],
        ['gear_checklist', 'is_visible', "ALTER TABLE gear_checklist ADD COLUMN is_visible TINYINT(1) DEFAULT 1"]
    ];

    foreach ($table_upgrades as $up) {
        list($tbl, $col, $sql_up) = $up;
        $chk = @mysqli_query($koneksi, "SHOW COLUMNS FROM `$tbl` LIKE '$col'");
        if ($chk && mysqli_num_rows($chk) === 0) {
            @mysqli_query($koneksi, $sql_up);
        }
    }

    @mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS `experiences` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `posisi` VARCHAR(150) NOT NULL,
        `instansi` VARCHAR(150) NOT NULL,
        `jenis` VARCHAR(60) NOT NULL DEFAULT 'Proyek & Pengembangan',
        `lokasi` VARCHAR(100) NOT NULL DEFAULT 'Tangerang / Banten',
        `periode` VARCHAR(60) NOT NULL,
        `deskripsi` TEXT NOT NULL,
        `pencapaian` TEXT NULL,
        `urutan` INT DEFAULT 1,
        `is_visible` TINYINT(1) DEFAULT 1,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    @mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS `documents` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `judul` VARCHAR(150) NOT NULL,
        `kategori` VARCHAR(60) NOT NULL DEFAULT 'Dokumen',
        `keterangan` VARCHAR(255) NULL,
        `file_path` TEXT NOT NULL,
        `file_type` VARCHAR(20) NOT NULL,
        `file_size` INT DEFAULT 0,
        `is_visible` TINYINT(1) DEFAULT 1,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Pastikan row id=1 di site_settings selalu ada
    $chk_s1 = @mysqli_query($koneksi, "SELECT id FROM site_settings WHERE id = 1 LIMIT 1");
    if ($chk_s1 && mysqli_num_rows($chk_s1) === 0) {
        @mysqli_query($koneksi, "INSERT INTO site_settings (id, nama, tagline, hero_headline, hero_desc, roles_typewriter, kampus, prodi, semester, nim, ipk, asal, whatsapp, email, instagram, linkbio, github, linkedin, avatar_url, cv_url) VALUES (1, 'Ibnu Andriano', 'Mahasiswa Sistem Informasi & Web Developer', 'Bangun Sistem Web yang Rapi, Fungsional, dan Siap Dipakai.', 'Mahasiswa S1 Sistem Informasi di Universitas Bina Bangsa.', 'Full-Stack Web Developer,Mahasiswa Sistem Informasi', 'Universitas Bina Bangsa', 'S1 Sistem Informasi', 'Semester 3 (Aktif)', '23110001', '3.82 / 4.00', 'Ds. Surya Bahari, Kec. Pakuhaji, Kab. Tangerang, Banten', '081367219097', 'ibnuandrianoofficial@gmail.com', '@padukaarajaaa', 'https://linkbio.co/ibnushop', 'https://github.com/ibnuandriano', 'https://linkedin.com/in/ibnuandriano', 'uploads/foto_ibnu.jpg', '#')");
    }
    @mysqli_query($koneksi, "UPDATE site_settings SET email = 'ibnuandrianoofficial@gmail.com' WHERE id = 1 AND email = 'ibnuandrianoofficial.com'");
}

// ============================================================================
// 3. UNIVERSAL HYBRID GETTERS & SAVERS (MYSQL + LOCAL JSON FALLBACK)
// ============================================================================

function is_admin_logged_in() {
    return (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true);
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

function resolve_media_url($path, $from_admin = false) {
    $path = trim((string)$path);
    if (empty($path) || $path === '#') {
        return ($from_admin ? '../' : '') . 'images/default-avatar.svg';
    }
    if (preg_match('/^(https?:\/\/|data:image\/)/i', $path)) {
        return $path;
    }
    $clean = ltrim($path, '/\\');
    if (strpos($clean, '../') === 0) {
        $clean = substr($clean, 3);
    }
    return ($from_admin ? '../' : '') . $clean;
}

/**
 * Ambil Site Settings (Membaca dari Local JSON + MySQL secara sinkron)
 */
function get_settings($conn) {
    $ldb = load_local_db();
    $settings = $ldb['site_settings'];

    if ($conn) {
        $q = @mysqli_query($conn, "SELECT * FROM site_settings WHERE id = 1 LIMIT 1");
        if ($q && mysqli_num_rows($q) > 0) {
            $row = mysqli_fetch_assoc($q);
            // Jika local_db belum pernah diupdate lebih baru, gabungkan
            if (empty($ldb['_settings_updated_at'])) {
                foreach ($row as $k => $v) {
                    if ($v !== null && $v !== '') {
                        $settings[$k] = $v;
                    }
                }
            } else {
                // Sinkronkan perubahan dari local_db ke MySQL secara otomatis
                sync_settings_to_mysql($conn, $settings);
            }
        }
    }
    if (isset($settings['email']) && strpos($settings['email'], '@') === false) {
        $settings['email'] = 'ibnuandrianoofficial@gmail.com';
    }
    return $settings;
}

function sync_settings_to_mysql($conn, $s) {
    if (!$conn || !is_array($s)) return false;
    $sets = [];
    foreach ($s as $col => $val) {
        if ($col === 'id' || $col === 'updated_at') continue;
        $chk = @mysqli_query($conn, "SHOW COLUMNS FROM site_settings LIKE '" . mysqli_real_escape_string($conn, $col) . "'");
        if ($chk && mysqli_num_rows($chk) > 0) {
            if (is_int($val) || is_bool($val) || preg_match('/^show_/', $col)) {
                $sets[] = "`$col` = " . (int)$val;
            } else {
                $sets[] = "`$col` = '" . mysqli_real_escape_string($conn, (string)$val) . "'";
            }
        }
    }
    if (!empty($sets)) {
        return @mysqli_query($conn, "UPDATE site_settings SET " . implode(', ', $sets) . " WHERE id = 1");
    }
    return false;
}

/**
 * Simpan Site Settings secara Hybrid (MySQL + Local JSON) — Dijamin 100% Berhasil!
 */
function save_site_settings($conn, $new_fields) {
    $ldb = load_local_db();
    foreach ($new_fields as $k => $v) {
        $ldb['site_settings'][$k] = $v;
    }
    $ldb['_settings_updated_at'] = time();
    $saved_json = save_local_db($ldb);

    if ($conn) {
        sync_settings_to_mysql($conn, $ldb['site_settings']);
    }
    return $saved_json || ($conn !== false);
}

/**
 * Helper CRUD Hybrid untuk Tabel Koleksi (projects, experiences, skills, education, certificates, gallery, documents, gear_checklist, messages)
 */
function hybrid_get_collection($conn, $table, $only_visible = false) {
    $ldb = load_local_db();
    $rows = $ldb[$table] ?? [];

    if ($conn && empty($ldb['_table_updated_' . $table])) {
        $q = @mysqli_query($conn, "SELECT * FROM `$table` ORDER BY id ASC");
        if ($q && mysqli_num_rows($q) > 0) {
            $db_rows = [];
            while ($r = mysqli_fetch_assoc($q)) {
                $db_rows[] = $r;
            }
            $rows = $db_rows;
            $ldb[$table] = $rows;
            save_local_db($ldb);
        }
    }

    if ($only_visible) {
        $rows = array_values(array_filter($rows, function ($r) {
            if (isset($r['status']) && (int)$r['status'] === 0) return false;
            return !isset($r['is_visible']) || (int)$r['is_visible'] === 1;
        }));
    }

    // Urutkan sesuai karakteristik tabel
    usort($rows, function ($a, $b) use ($table) {
        if ($table === 'projects') {
            $fa = (int)($a['is_featured'] ?? 0);
            $fb = (int)($b['is_featured'] ?? 0);
            if ($fa !== $fb) return $fb - $fa;
        }
        if (isset($a['urutan']) && isset($b['urutan']) && (int)$a['urutan'] !== (int)$b['urutan']) {
            return (int)$a['urutan'] - (int)$b['urutan'];
        }
        if ($table === 'gallery' || $table === 'documents' || $table === 'messages') {
            return (int)($b['id'] ?? 0) - (int)($a['id'] ?? 0);
        }
        return (int)($a['id'] ?? 0) - (int)($b['id'] ?? 0);
    });

    return $rows;
}

function hybrid_get_by_id($conn, $table, $id) {
    $rows = hybrid_get_collection($conn, $table, false);
    foreach ($rows as $r) {
        if ((int)($r['id'] ?? 0) === (int)$id) {
            return $r;
        }
    }
    return null;
}

function hybrid_insert($conn, $table, $data) {
    $ldb = load_local_db();
    $rows = $ldb[$table] ?? [];
    $max_id = 0;
    foreach ($rows as $r) {
        if ((int)($r['id'] ?? 0) > $max_id) {
            $max_id = (int)$r['id'];
        }
    }
    $new_id = $max_id + 1;

    if ($conn) {
        $cols = [];
        $vals = [];
        foreach ($data as $k => $v) {
            $cols[] = "`" . mysqli_real_escape_string($conn, $k) . "`";
            if (is_int($v) || is_bool($v)) {
                $vals[] = (int)$v;
            } else {
                $vals[] = "'" . mysqli_real_escape_string($conn, (string)$v) . "'";
            }
        }
        $q = @mysqli_query($conn, "INSERT INTO `$table` (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ")");
        if ($q && mysqli_insert_id($conn) > 0) {
            $new_id = (int)mysqli_insert_id($conn);
        }
    }

    $record = array_merge(['id' => $new_id], $data);
    if (!isset($record['created_at'])) {
        $record['created_at'] = date('Y-m-d H:i:s');
    }
    $rows[] = $record;
    $ldb[$table] = $rows;
    $ldb['_table_updated_' . $table] = time();
    save_local_db($ldb);
    return $new_id;
}

function hybrid_update($conn, $table, $id, $data) {
    $id = (int)$id;
    $ldb = load_local_db();
    $rows = $ldb[$table] ?? [];
    $found = false;
    foreach ($rows as $idx => $r) {
        if ((int)($r['id'] ?? 0) === $id) {
            foreach ($data as $k => $v) {
                $rows[$idx][$k] = $v;
            }
            $found = true;
            break;
        }
    }
    if ($found) {
        $ldb[$table] = $rows;
        $ldb['_table_updated_' . $table] = time();
        save_local_db($ldb);
    }

    if ($conn) {
        $sets = [];
        foreach ($data as $k => $v) {
            $col = mysqli_real_escape_string($conn, $k);
            if (is_int($v) || is_bool($v)) {
                $sets[] = "`$col` = " . (int)$v;
            } else {
                $sets[] = "`$col` = '" . mysqli_real_escape_string($conn, (string)$v) . "'";
            }
        }
        if (!empty($sets)) {
            @mysqli_query($conn, "UPDATE `$table` SET " . implode(', ', $sets) . " WHERE id = $id");
        }
    }
    return true;
}

function hybrid_delete($conn, $table, $id) {
    $id = (int)$id;
    $ldb = load_local_db();
    $rows = $ldb[$table] ?? [];
    $ldb[$table] = array_values(array_filter($rows, function ($r) use ($id) {
        return (int)($r['id'] ?? 0) !== $id;
    }));
    $ldb['_table_updated_' . $table] = time();
    save_local_db($ldb);

    if ($conn) {
        @mysqli_query($conn, "DELETE FROM `$table` WHERE id = $id");
    }
    return true;
}

function hybrid_toggle_visible($conn, $table, $id) {
    $id = (int)$id;
    $ldb = load_local_db();
    $rows = $ldb[$table] ?? [];
    $new_vis = 1;
    foreach ($rows as $idx => $r) {
        if ((int)($r['id'] ?? 0) === $id) {
            $cur = isset($r['is_visible']) ? (int)$r['is_visible'] : 1;
            $new_vis = $cur === 1 ? 0 : 1;
            $rows[$idx]['is_visible'] = $new_vis;
            break;
        }
    }
    $ldb[$table] = $rows;
    $ldb['_table_updated_' . $table] = time();
    save_local_db($ldb);

    if ($conn) {
        @mysqli_query($conn, "UPDATE `$table` SET is_visible = $new_vis WHERE id = $id");
    }
    return true;
}

// Wrapper fungsi standar yang dipanggil di seluruh file
function get_experiences($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'experiences', $only_visible);
}
function get_projects($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'projects', $only_visible);
}
function get_skills($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'skills', $only_visible);
}
function get_education($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'education', $only_visible);
}
function get_certificates($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'certificates', $only_visible);
}
function get_gear_checklist($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'gear_checklist', $only_visible);
}
function get_gallery($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'gallery', $only_visible);
}
function get_documents($conn, $only_visible = false) {
    return hybrid_get_collection($conn, 'documents', $only_visible);
}
function get_messages($conn) {
    return hybrid_get_collection($conn, 'messages', false);
}

function get_motor_telemetry($conn) {
    $ldb = load_local_db();
    $motor = $ldb['motor_telemetry'] ?? get_default_motor_data();
    if ($conn && empty($ldb['_motor_updated_at'])) {
        $q = @mysqli_query($conn, "SELECT * FROM motor_telemetry WHERE id = 1 LIMIT 1");
        if ($q && mysqli_num_rows($q) > 0) {
            $motor = mysqli_fetch_assoc($q);
        }
    }
    return $motor;
}

function save_motor_telemetry($conn, $data) {
    $ldb = load_local_db();
    foreach ($data as $k => $v) {
        $ldb['motor_telemetry'][$k] = $v;
    }
    $ldb['_motor_updated_at'] = time();
    save_local_db($ldb);

    if ($conn) {
        $sets = [];
        foreach ($data as $k => $v) {
            $sets[] = "`" . mysqli_real_escape_string($conn, $k) . "` = '" . mysqli_real_escape_string($conn, (string)$v) . "'";
        }
        @mysqli_query($conn, "UPDATE motor_telemetry SET " . implode(', ', $sets) . " WHERE id = 1");
    }
    return true;
}

function get_admin_account($conn) {
    $ldb = load_local_db();
    $admin = $ldb['admin_users'][0] ?? [
        'id' => 1,
        'username' => 'PadukaIbnu',
        'password' => '$2y$10$S5063T08mvIYB/w0Zx5PRuaOvKwu5dF8KO4XBDQ20yBoIcgkl6.IW',
        'nama_lengkap' => 'Ibnu Andriano',
        'email' => 'ibnuandrianoofficial@gmail.com'
    ];
    if ($conn && empty($ldb['_admin_updated_at'])) {
        $q = @mysqli_query($conn, "SELECT * FROM admin_users ORDER BY id ASC LIMIT 1");
        if ($q && mysqli_num_rows($q) > 0) {
            $admin = mysqli_fetch_assoc($q);
        }
    }
    return $admin;
}

function save_admin_account($conn, $data) {
    $ldb = load_local_db();
    $curr = $ldb['admin_users'][0] ?? get_admin_account($conn);
    foreach ($data as $k => $v) {
        $curr[$k] = $v;
    }
    $ldb['admin_users'][0] = $curr;
    $ldb['_admin_updated_at'] = time();
    save_local_db($ldb);

    if ($conn) {
        $sets = [];
        foreach ($data as $k => $v) {
            $sets[] = "`" . mysqli_real_escape_string($conn, $k) . "` = '" . mysqli_real_escape_string($conn, (string)$v) . "'";
        }
        $aid = (int)($curr['id'] ?? 1);
        @mysqli_query($conn, "UPDATE admin_users SET " . implode(', ', $sets) . " WHERE id = $aid");
    }
    return true;
}

// ============================================================================
// 4. UPLOAD FILE HANDLERS (FOTO, CV PDF, DOKUMEN PUBLIK)
// ============================================================================
function upload_image_file($file, $prefix = 'img') {
    if (!is_admin_logged_in()) {
        return false;
    }
    if (!isset($file['error']) || is_array($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        return false;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_ext = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    if (!in_array($ext, $allowed_ext, true)) {
        return false;
    }
    $is_valid_img = false;
    $img_info = @getimagesize($file['tmp_name']);
    $allowed_mimes = ['image/jpeg', 'image/pjpeg', 'image/png', 'image/webp', 'image/gif'];
    if ($img_info !== false && in_array($img_info['mime'], $allowed_mimes, true)) {
        $is_valid_img = true;
    } elseif (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (in_array($mime, $allowed_mimes, true)) {
            $is_valid_img = true;
        }
    }
    if (!$is_valid_img) {
        return false;
    }
    $upload_dir = __DIR__ . '/uploads/';
    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, 0755, true);
    }
    $safe_prefix = preg_replace('/[^a-zA-Z0-9_-]/', '', $prefix);
    $new_name = $safe_prefix . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target_path = $upload_dir . $new_name;
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return 'uploads/' . $new_name;
    }
    return false;
}

function upload_cv_file($file) {
    if (!is_admin_logged_in()) {
        return false;
    }
    if (!isset($file['error']) || is_array($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    if ($file['size'] > 10 * 1024 * 1024) {
        return false;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'pdf') {
        return false;
    }
    $upload_dir = __DIR__ . '/uploads/';
    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, 0755, true);
    }
    $new_name = 'CV_Ibnu_Andriano_' . date('Ymd_His') . '.pdf';
    $target_path = $upload_dir . $new_name;
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return 'uploads/' . $new_name;
    }
    return false;
}

function upload_any_file($file, $prefix = 'doc') {
    if (!is_admin_logged_in()) {
        return false;
    }
    if (!isset($file['error']) || is_array($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    if ($file['size'] > 15 * 1024 * 1024) {
        return false;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_ext = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'jpg', 'jpeg', 'png', 'webp', 'gif', 'zip', 'txt'];
    if (!in_array($ext, $allowed_ext, true)) {
        return false;
    }
    $upload_dir = __DIR__ . '/uploads/';
    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, 0755, true);
    }
    $safe_prefix = preg_replace('/[^a-zA-Z0-9_-]/', '', $prefix);
    $new_name = $safe_prefix . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target_path = $upload_dir . $new_name;
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return [
            'path' => 'uploads/' . $new_name,
            'ext'  => strtoupper($ext),
            'size' => (int)$file['size']
        ];
    }
    return false;
}

function log_visitor($conn) {
    if (!$conn) return;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $ip = mysqli_real_escape_string($conn, substr($ip, 0, 50));
    $ua = mysqli_real_escape_string($conn, substr($ua, 0, 255));
    @mysqli_query($conn, "INSERT INTO visitor_logs (ip_address, user_agent) VALUES ('$ip', '$ua')");
}
?>
