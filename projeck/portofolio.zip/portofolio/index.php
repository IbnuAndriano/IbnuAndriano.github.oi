<?php
/**
 * PORTOFOLIO EKSEKUTIF IBNU ANDRIANO
 * Professional Software Engineering & Information Systems Portfolio
 * Dynamic PHP + MySQL, Granular Admin Visibility Control, Strict Media Protection & ATS Resume Engine
 */

require_once __DIR__ . '/koneksi.php';

// Pastikan perubahan dari Admin langsung tampil tanpa cache browser
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// 1. Handle Contact Form Submission (AJAX JSON & Standard POST)
$contact_alert = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $nama = trim($_POST['nama'] ?? '');
    $kontak = trim($_POST['kontak'] ?? '');
    $pesan = trim($_POST['pesan'] ?? '');
    $is_ajax = !empty($_POST['ajax_request']) || (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

    if (!empty($nama) && !empty($pesan)) {
        $new_msg_id = hybrid_insert($koneksi, 'messages', [
            'nama'        => $nama,
            'kontak'      => $kontak,
            'pesan'       => $pesan,
            'status_baca' => 0,
            'created_at'  => date('Y-m-d H:i:s')
        ]);
        $msg_text = "Terima kasih $nama, pesan kamu sudah masuk dan tersimpan di inbox Ibnu!";

        if ($is_ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'success', 'message' => $msg_text, 'id' => $new_msg_id]);
            exit;
        }
        $contact_alert = "success:" . $msg_text;
    } else {
        $err_text = "Mohon lengkapi nama dan isi pesan Anda.";
        if ($is_ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['status' => 'error', 'message' => $err_text]);
            exit;
        }
        $contact_alert = "error:" . $err_text;
    }
}

// 2. Log Visitor View
log_visitor($koneksi);

// 3. Fetch Dynamic Data (Filtered by is_visible = 1 for Public View)
$s = get_settings($koneksi);
$experiences = get_experiences($koneksi, true);
$projects = get_projects($koneksi, true);
$skills = get_skills($koneksi, true);
$education = get_education($koneksi, true);
$certificates = get_certificates($koneksi, true);
$motor = get_motor_telemetry($koneksi);
$gears = get_gear_checklist($koneksi, true);
$gallery = get_gallery($koneksi, true);
$documents = get_documents($koneksi, true);

$is_admin = is_admin_logged_in();

// Split Featured vs Standard Projects dynamically
$featured_projects = [];
$standard_projects = [];
foreach ($projects as $pr) {
    if (!empty($pr['is_featured'])) {
        $featured_projects[] = $pr;
    } else {
        $standard_projects[] = $pr;
    }
}

// Prepare Typewriter Roles Array
$roles_list = array_values(array_filter(array_map('trim', explode(',', $s['roles_typewriter'] ?? ''))));
if (empty($roles_list)) {
    $roles_list = ['Full-Stack Web Developer', 'Information Systems Specialist'];
}

// Resolve Avatar & Motor Image URLs safely
$avatar_src = resolve_media_url($s['avatar_url'], false);
$motor_src = !empty($s['motor_image_url']) ? resolve_media_url($s['motor_image_url'], false) : '';
$wa_clean = '62' . ltrim(preg_replace('/[^0-9]/', '', $s['whatsapp']), '0');
$has_custom_cv = !empty($s['cv_url']) && $s['cv_url'] !== '#';

// Helper for Skill Tier Label (Replaces arbitrary percentage bars)
function get_skill_tier_label($level) {
    $lvl = (int)$level;
    if ($lvl >= 88) return 'Core Competency';
    if ($lvl >= 80) return 'Production Ready';
    return 'Proficient';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title><?= htmlspecialchars($s['nama']); ?> — <?= htmlspecialchars($s['tagline']); ?></title>
  <meta name="description" content="Portofolio resmi <?= htmlspecialchars($s['nama']); ?> — <?= htmlspecialchars($s['tagline']); ?>. Studi kasus pengembangan sistem informasi, aplikasi web full-stack, dan rekam jejak profesional.">
  <meta name="author" content="<?= htmlspecialchars($s['nama']); ?>">
  <meta name="theme-color" content="#090B10">

  <!-- Typography: Plus Jakarta Sans, Space Grotesk, JetBrains Mono -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">

  <!-- Font Awesome 6 -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <!-- Main Architectural Stylesheet -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- ==================== NAVIGATION BAR ==================== -->
  <header class="navbar" id="navbar">
    <div class="container nav-container">
      <a href="#hero" class="brand">
        <span class="brand-mark">IA</span>
        <span><?= htmlspecialchars($s['nama']); ?></span>
      </a>

      <nav aria-label="Navigasi Utama">
        <ul class="nav-menu" id="navMenu">
          <?php if (!empty($s['show_about'])): ?>
            <li><a href="#about" class="nav-link">Tentang</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_services'])): ?>
            <li><a href="#capabilities" class="nav-link">Fokus</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_experience']) && !empty($experiences)): ?>
            <li><a href="#experience" class="nav-link">Pengalaman</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_projects']) && !empty($projects)): ?>
            <li><a href="#projects" class="nav-link">Projek</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_skills']) && !empty($skills)): ?>
            <li><a href="#skills" class="nav-link">Tech Stack</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_education']) && !empty($education)): ?>
            <li><a href="#education" class="nav-link">Pendidikan</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_certificates']) && !empty($certificates)): ?>
            <li><a href="#certificates" class="nav-link">Sertifikat</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_motor'])): ?>
            <li><a href="#motor" class="nav-link">Motoran</a></li>
          <?php endif; ?>
          <?php if (!empty($s['show_contact'])): ?>
            <li><a href="#contact" class="nav-link">Kontak</a></li>
          <?php endif; ?>
        </ul>
      </nav>

      <div class="nav-actions">
        <button class="icon-btn" id="themeToggle" title="Ganti Mode Gelap / Terang" aria-label="Toggle Theme">
          <i class="fa-solid fa-sun"></i>
        </button>

        <?php if (!empty($s['show_cv'])): ?>
          <a href="#cv" class="btn btn-primary btn-sm open-cv-modal">
            <i class="fa-regular fa-file-lines"></i> CV / Resume
          </a>
        <?php endif; ?>

        <a href="admin/index.php" class="btn btn-secondary btn-sm" title="Panel Admin Pemilik">
          <i class="fa-solid fa-sliders"></i> Admin
        </a>

        <button class="menu-toggle" id="menuToggle" aria-label="Buka Menu">
          <i class="fa-solid fa-bars"></i>
        </button>
      </div>
    </div>
  </header>

  <!-- ==================== HERO SECTION ==================== -->
  <section class="hero-section" id="hero">
    <div class="container">
      <div class="hero-layout">
        <!-- Left Column: Value Proposition -->
        <div>
          <?php if (!empty($s['show_availability']) && !empty($s['availability_text'])): ?>
            <div class="availability-pill">
              <span class="status-dot"></span>
              <span><?= htmlspecialchars($s['availability_text']); ?></span>
            </div>
          <?php endif; ?>

          <div class="hero-name-label">
            <span><?= htmlspecialchars($s['nama']); ?></span>
            <span>•</span>
            <span><?= htmlspecialchars($s['tagline']); ?></span>
          </div>

          <h1 class="hero-headline">
            <?= htmlspecialchars($s['hero_headline']); ?>
          </h1>

          <div class="typewriter-line">
            <span class="typewriter-prefix">Fokus:</span>
            <span id="typeText"></span>
            <span class="cursor-caret"></span>
          </div>

          <p class="hero-description">
            <?= nl2br(htmlspecialchars($s['hero_desc'])); ?>
          </p>

          <div class="hero-cta-group">
            <?php if (!empty($s['show_projects']) && !empty($projects)): ?>
              <a href="#projects" class="btn btn-accent">
                <i class="fa-solid fa-layer-group"></i> Lihat Projek & Karya
              </a>
            <?php endif; ?>

            <a href="sdgs-demo.php" target="_blank" class="btn btn-secondary" title="Demo 10 Modul SDGs Kab. Tangerang 2026">
              <i class="fa-solid fa-chart-pie" style="color:var(--rose)"></i> Demo SDGs 2026
            </a>

            <a href="http://localhost/cakjoyo" target="_blank" class="btn btn-secondary" title="Aplikasi Web Soto Lamongan Cak Joyo">
              <i class="fa-solid fa-bowl-food" style="color:var(--amber)"></i> Web Cak Joyo
            </a>

            <?php if (!empty($s['show_cv'])): ?>
              <button type="button" class="btn btn-secondary open-cv-modal">
                <i class="fa-solid fa-file-pdf"></i> Buka CV ATS
              </button>
            <?php endif; ?>
          </div>

          <?php if (!empty($s['show_hero_stats'])): ?>
            <div class="metrics-strip">
              <div class="metric-box">
                <span class="metric-value"><?= count($projects); ?> Projek</span>
                <span class="metric-label">Web App & Sistem Informasi</span>
              </div>
              <div class="metric-box">
                <span class="metric-value"><?= count($skills); ?> Stack</span>
                <span class="metric-label">PHP, MySQL, JS & Tools</span>
              </div>
              <?php if (!empty($s['show_academic_detail']) && !empty($s['ipk'])): ?>
                <div class="metric-box">
                  <span class="metric-value"><?= htmlspecialchars(explode('/', $s['ipk'])[0]); ?></span>
                  <span class="metric-label">IPK S1 Sistem Informasi</span>
                </div>
              <?php endif; ?>
              <div class="metric-box">
                <span class="metric-value"><?= htmlspecialchars($motor['model'] ?? 'Beat Deluxe'); ?></span>
                <span class="metric-label">Daily Ride & Touring</span>
              </div>
            </div>
          <?php endif; ?>
        </div>

        <!-- Right Column: Profile Card -->
        <div>
          <div class="executive-profile-card">
            <div class="profile-identity-top">
              <?php if (!empty($s['show_photo'])): ?>
                <div class="profile-avatar-frame">
                  <img src="<?= htmlspecialchars($avatar_src); ?>" alt="Foto Profil <?= htmlspecialchars($s['nama']); ?>" class="profile-avatar-img">
                </div>
              <?php endif; ?>
              <div class="profile-identity-meta">
                <h2><?= htmlspecialchars($s['nama']); ?></h2>
                <p><?= htmlspecialchars($s['prodi']); ?> — <?= htmlspecialchars($s['kampus']); ?></p>
                <span class="pill-badge accent">
                  <i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($s['asal']); ?>
                </span>
              </div>
            </div>

            <div class="profile-quick-facts">
              <div class="fact-row">
                <span>Fokus Ngoding</span>
                <strong>PHP Native, MySQL & JS</strong>
              </div>
              <div class="fact-row">
                <span>Kampus</span>
                <strong><?= htmlspecialchars($s['kampus']); ?></strong>
              </div>
              <?php if (!empty($s['show_academic_detail'])): ?>
                <div class="fact-row">
                  <span>Program Studi</span>
                  <strong><?= htmlspecialchars($s['prodi']); ?> (<?= htmlspecialchars($s['semester']); ?>)</strong>
                </div>
                <?php if (!empty($s['ipk'])): ?>
                  <div class="fact-row">
                    <span>IPK Saat Ini</span>
                    <strong style="color: var(--emerald);"><?= htmlspecialchars($s['ipk']); ?></strong>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="fact-row">
                <span>Hobi Luar Layar</span>
                <strong>Motoran & Touring Jarak Jauh</strong>
              </div>
            </div>

            <?php if (!empty($s['show_social_links'])): ?>
              <div class="profile-social-strip">
                <?php if (!empty($s['whatsapp'])): ?>
                  <a href="https://wa.me/<?= $wa_clean; ?>" target="_blank" rel="noopener" class="social-chip">
                    <i class="fa-brands fa-whatsapp" style="color:var(--emerald)"></i> WhatsApp
                  </a>
                <?php endif; ?>
                <?php if (!empty($s['instagram'])): ?>
                  <a href="https://instagram.com/<?= htmlspecialchars(ltrim($s['instagram'], '@')); ?>" target="_blank" rel="noopener" class="social-chip">
                    <i class="fa-brands fa-instagram" style="color:var(--rose)"></i> <?= htmlspecialchars($s['instagram']); ?>
                  </a>
                <?php endif; ?>
                <?php if (!empty($s['github']) && $s['github'] !== '#'): ?>
                  <a href="<?= htmlspecialchars($s['github']); ?>" target="_blank" rel="noopener" class="social-chip">
                    <i class="fa-brands fa-github"></i> GitHub
                  </a>
                <?php endif; ?>
                <?php if (!empty($s['linkedin']) && $s['linkedin'] !== '#'): ?>
                  <a href="<?= htmlspecialchars($s['linkedin']); ?>" target="_blank" rel="noopener" class="social-chip">
                    <i class="fa-brands fa-linkedin"></i> LinkedIn
                  </a>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Interactive Dev Terminal (Controlled by show_terminal) -->
      <?php if (!empty($s['show_terminal'])): ?>
        <div class="console-card">
          <div class="console-topbar">
            <div class="console-dots">
              <span class="console-dot" style="background:#EF4444;"></span>
              <span class="console-dot" style="background:#F59E0B;"></span>
              <span class="console-dot" style="background:#10B981;"></span>
            </div>
            <span class="mono" style="font-size: 12px; color: #94A3B8;">ibnu@dev-workspace:~ — Quick CLI</span>
            <span class="mono" style="font-size: 11px; color: #10B981;">● ONLINE</span>
          </div>
          <div class="console-body" id="terminalBody">
            <div><span style="color:#38BDF8;font-weight:600;">$ whoami</span></div>
            <div style="color:#E2E8F0;margin-bottom:8px;"><?= htmlspecialchars($s['nama']); ?> • <?= htmlspecialchars($s['prodi']); ?> (<?= htmlspecialchars($s['kampus']); ?>) • <?= htmlspecialchars($s['asal']); ?></div>
            <div><span style="color:#38BDF8;font-weight:600;">$ ls projects/ --featured</span></div>
            <div style="color:#94A3B8;">[Sem 2] SIPANDU SDGs Goal 1 Kab. Tangerang 2026 (10 Modul + Peta 29 Kecamatan) &nbsp;|&nbsp; [Sem 3] Web E-Commerce Soto Lamongan Cak Joyo (PHP + MySQL + QRIS)</div>
          </div>
          <div class="console-actions">
            <button type="button" class="console-btn" data-cmd="profile">whoami</button>
            <button type="button" class="console-btn" data-cmd="architecture">stack</button>
            <button type="button" class="console-btn" data-cmd="projects">projects</button>
            <button type="button" class="console-btn" data-cmd="contact">contact</button>
            <button type="button" class="console-btn" data-cmd="clear">clear</button>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <!-- ==================== FOKUS KEAHLIAN ==================== -->
  <?php if (!empty($s['show_services'])): ?>
  <section class="section" id="capabilities">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">What I Do</span>
        <h2 class="section-title">Yang Biasa Saya Kerjakan</h2>
        <p class="section-subtitle">Mulai dari ngerancang tabel database, bikin fitur CRUD backend PHP, sampai ngerapihin tampilan web biar nyaman dipakai.</p>
      </div>

      <div class="capabilities-grid">
        <div class="capability-card">
          <div class="capability-icon"><i class="fa-solid fa-code"></i></div>
          <h3>Web App Development</h3>
          <p>Bikin aplikasi web utuh dari nol pakai PHP Native, MySQL, dan JavaScript yang ringan, cepat, dan gampang dikelola.</p>
          <ul class="capability-list">
            <li><i class="fa-solid fa-check"></i> Sistem Login, Session & Panel Admin CRUD</li>
            <li><i class="fa-solid fa-check"></i> UI Responsif Dark/Light Mode</li>
            <li><i class="fa-solid fa-check"></i> Form Interaktif & Cetak Nota / Laporan PDF</li>
          </ul>
        </div>

        <div class="capability-card">
          <div class="capability-icon"><i class="fa-solid fa-database"></i></div>
          <h3>Database & Backend</h3>
          <p>Menyusun struktur tabel MySQL yang rapi supaya data transaksi, stok, maupun data warga tersimpan aman dan gampang dicari.</p>
          <ul class="capability-list">
            <li><i class="fa-solid fa-check"></i> Perancangan ERD & Relasi Tabel</li>
            <li><i class="fa-solid fa-check"></i> Query SQL, Filter & Pencarian Cepat</li>
            <li><i class="fa-solid fa-check"></i> Export Data ke CSV Excel & Backup</li>
          </ul>
        </div>

        <div class="capability-card">
          <div class="capability-icon"><i class="fa-solid fa-diagram-project"></i></div>
          <h3>Analisis Sistem & Administrasi</h3>
          <p>Berbekal kuliah Sistem Informasi dan pengalaman kerja di studio & logistik, terbiasa menerjemahkan alur kerja nyata jadi fitur aplikasi.</p>
          <ul class="capability-list">
            <li><i class="fa-solid fa-check"></i> Analisis Alur Proses Bisnis & SOP</li>
            <li><i class="fa-solid fa-check"></i> Pengolahan Data Excel & Rekap Transaksi</li>
            <li><i class="fa-solid fa-check"></i> Dokumentasi Sistem yang Jelas</li>
          </ul>
        </div>

        <div class="capability-card">
          <div class="capability-icon"><i class="fa-solid fa-bolt"></i></div>
          <h3>Fitur Modern & Visualisasi</h3>
          <p>Menambahkan fitur yang bikin web terasa hidup, mulai dari grafik statistik, peta interaktif, sampai simulasi pembayaran digital.</p>
          <ul class="capability-list">
            <li><i class="fa-solid fa-check"></i> Checkout & Simulasi Payment Gateway QRIS</li>
            <li><i class="fa-solid fa-check"></i> Grafik Statistik Interaktif (Chart.js)</li>
            <li><i class="fa-solid fa-check"></i> Peta Sebaran Wilayah (Leaflet.js)</li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== TENTANG SAYA ==================== -->
  <?php if (!empty($s['show_about'])): ?>
  <section class="section" id="about">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">About Me</span>
        <h2 class="section-title">Kenalan Lebih Dekat</h2>
        <p class="section-subtitle">Anak Sistem Informasi yang suka ngulik kode, terbiasa kerja rapi di lapangan, dan hobi motoran buat nyegerin pikiran.</p>
      </div>

      <div class="about-container-grid">
        <div class="about-narrative">
          <p>
            Halo! Saya <strong><?= htmlspecialchars($s['nama']); ?></strong>, mahasiswa <strong><?= htmlspecialchars($s['prodi']); ?></strong> di <strong><?= htmlspecialchars($s['kampus']); ?></strong> yang tinggal di <?= htmlspecialchars($s['asal']); ?>.
          </p>
          <p>
            Saya suka bikin aplikasi web yang beneran berfungsi penuh dari depan sampai belakang — bukan cuma tampilan statis, tapi punya database yang jalan, dashboard admin yang bisa dipakai kontrol semua konten, sampai fitur cetak laporan dan nota.
          </p>
          <p>
            Selain kuliah dan ngoding, saya punya pengalaman kerja langsung sebagai <strong>Staff Administrasi di Pantura Studio</strong> dan <strong>Operator Logistik di J&amp;T Express</strong>. Di waktu luang, saya hobi riding dan touring naik <strong><?= htmlspecialchars($motor['model'] ?? 'Honda Beat Deluxe'); ?></strong> — karena buat saya, fokus di jalanan aspal dan fokus mecahin bug di kodingan itu sama-sama butuh ketenangan dan ketelitian.
          </p>
        </div>

        <div class="about-highlights-box">
          <div class="about-highlight-row">
            <div class="about-highlight-icon"><i class="fa-solid fa-laptop-code"></i></div>
            <div>
              <h4>Fokus Praktek & Projek Nyata</h4>
              <p>Senang belajar lewat bikin projek langsung seperti Sistem SDGs 10 Modul Kabupaten Tangerang dan Web Penjualan Soto Lamongan Cak Joyo.</p>
            </div>
          </div>

          <div class="about-highlight-row">
            <div class="about-highlight-icon"><i class="fa-solid fa-briefcase"></i></div>
            <div>
              <h4>Terbiasa Kerja Disiplin & Rapi</h4>
              <p>Pengalaman di bagian administrasi dan gudang logistik bikin saya terbiasa kerja sesuai target harian, teliti, dan komunikatif.</p>
            </div>
          </div>

          <div class="about-highlight-row">
            <div class="about-highlight-icon"><i class="fa-solid fa-motorcycle"></i></div>
            <div>
              <h4>Mentalitas Rider Jarak Jauh</h4>
              <p>Hobi touring jalur Pantura sampai Bandung dan sunmori ke BSD/KP3B ngajarin daya tahan fisik, persiapan matang, dan fokus tinggi.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== PENGALAMAN & REKAM JEJAK ==================== -->
  <?php if (!empty($s['show_experience']) && !empty($experiences)): ?>
  <section class="section" id="experience">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Experience & Track Record</span>
        <h2 class="section-title">Pengalaman Kerja & Projek</h2>
        <p class="section-subtitle">Rekam jejak kerja di dunia operasional, administrasi, serta pengembangan projek aplikasi web.</p>
      </div>

      <div class="experience-list">
        <?php foreach ($experiences as $exp): 
          $achievements = array_filter(array_map('trim', preg_split('/\r?\n/', $exp['pencapaian'] ?? '')));
        ?>
          <div class="experience-card">
            <div class="exp-meta">
              <span class="exp-period"><?= htmlspecialchars($exp['periode']); ?></span>
              <span class="exp-location"><i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($exp['lokasi']); ?></span>
              <span class="exp-type-badge"><?= htmlspecialchars($exp['jenis']); ?></span>
            </div>

            <div class="exp-body">
              <h3><?= htmlspecialchars($exp['posisi']); ?></h3>
              <div class="exp-company"><?= htmlspecialchars($exp['instansi']); ?></div>
              <p class="exp-desc"><?= nl2br(htmlspecialchars($exp['deskripsi'])); ?></p>

              <?php if (!empty($achievements)): ?>
                <ul class="exp-achievements">
                  <?php foreach ($achievements as $ach): ?>
                    <li>
                      <i class="fa-solid fa-check"></i>
                      <span><?= htmlspecialchars(preg_replace('/^[-•\d.]+\s*/', '', $ach)); ?></span>
                    </li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== PROYEK & STUDI KASUS (100% DATABASE DRIVEN) ==================== -->
  <?php if (!empty($s['show_projects']) && !empty($projects)): ?>
  <section class="section" id="projects">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Featured Projects</span>
        <h2 class="section-title">Karya & Projek Aplikasi Web</h2>
        <p class="section-subtitle">Projek aplikasi web dan sistem informasi yang dibangun lengkap dengan database, panel admin, dan fitur interaktif.</p>
      </div>

      <div class="projects-stack">
        <!-- Featured Case Studies -->
        <?php foreach ($featured_projects as $fp): 
          $fitur_lines = array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $fp['fitur_list'] ?? ''))));
          $stack_items = array_values(array_filter(array_map('trim', explode(',', $fp['tech_stack'] ?? ''))));
          $has_custom_thumb = !empty($fp['gambar']) && $fp['gambar'] !== 'default_project.jpg';
          $thumb_url = $has_custom_thumb ? resolve_media_url($fp['gambar'], false) : '';
          $preview_url_label = (!empty($fp['link_hosting']) && $fp['link_hosting'] !== '#')
              ? $fp['link_hosting']
              : ((!empty($fp['link_demo']) && $fp['link_demo'] !== '#') ? $fp['link_demo'] : 'production-app.local');
        ?>
          <article class="case-study-card">
            <div class="case-study-top">
              <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <span class="pill-badge accent">
                  <i class="fa-solid fa-star"></i> Studi Kasus Unggulan
                </span>
                <span class="pill-badge">
                  <?= htmlspecialchars($fp['kategori']); ?>
                </span>
              </div>
              <span class="mono" style="font-size: 12px; color: var(--text-dim);">
                <?= htmlspecialchars($fp['semester']); ?>
              </span>
            </div>

            <div class="case-study-grid">
              <div>
                <h3 class="case-study-title"><?= htmlspecialchars($fp['judul']); ?></h3>
                <p class="case-study-desc"><?= nl2br(htmlspecialchars($fp['deskripsi_singkat'])); ?></p>

                <?php if (!empty($fitur_lines)): ?>
                  <div class="feature-modules-grid">
                    <?php foreach (array_slice($fitur_lines, 0, 10) as $fl): ?>
                      <div class="module-item">
                        <i class="fa-solid fa-circle-check"></i>
                        <span><?= htmlspecialchars(preg_replace('/^\d+\.\s*/', '', $fl)); ?></span>
                      </div>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>

                <?php if (!empty($stack_items)): ?>
                  <div class="tech-tags-row">
                    <?php foreach ($stack_items as $st): ?>
                      <span class="tech-tag"><?= htmlspecialchars($st); ?></span>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>

                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                  <?php if (!empty($fp['link_hosting']) && $fp['link_hosting'] !== '#'): ?>
                    <a href="<?= htmlspecialchars($fp['link_hosting']); ?>" target="_blank" rel="noopener" class="btn btn-accent btn-sm">
                      <i class="fa-solid fa-globe"></i> Kunjungi Website Resmi
                    </a>
                  <?php endif; ?>

                  <?php if (!empty($fp['link_demo']) && $fp['link_demo'] !== '#'): ?>
                    <a href="<?= htmlspecialchars($fp['link_demo']); ?>" target="_blank" rel="noopener" class="btn btn-primary btn-sm">
                      <i class="fa-solid fa-arrow-up-right-from-square"></i> Buka Demo Aplikasi
                    </a>
                  <?php endif; ?>

                  <?php if (!empty($fp['link_repo']) && $fp['link_repo'] !== '#'): ?>
                    <a href="<?= htmlspecialchars($fp['link_repo']); ?>" target="_blank" rel="noopener" class="btn btn-secondary btn-sm">
                      <i class="fa-brands fa-github"></i> Kode Sumber
                    </a>
                  <?php endif; ?>

                  <button type="button" class="btn btn-secondary btn-sm view-project-detail" data-project="<?= htmlspecialchars(json_encode($fp), ENT_QUOTES, 'UTF-8'); ?>">
                    <i class="fa-solid fa-file-lines"></i> Rincian Arsitektur
                  </button>
                </div>
              </div>

              <!-- Right Preview Panel -->
              <div class="project-preview-panel">
                <div class="preview-browser-bar">
                  <div class="console-dots">
                    <span class="console-dot" style="background:#EF4444;"></span>
                    <span class="console-dot" style="background:#F59E0B;"></span>
                    <span class="console-dot" style="background:#10B981;"></span>
                  </div>
                  <div class="preview-url-box"><?= htmlspecialchars($preview_url_label); ?></div>
                </div>
                <div class="preview-canvas">
                  <?php if ($has_custom_thumb): ?>
                    <img src="<?= htmlspecialchars($thumb_url); ?>" alt="<?= htmlspecialchars($fp['judul']); ?>" class="project-thumb-img">
                  <?php else: ?>
                    <div style="width: 60px; height: 60px; border-radius: 14px; background: var(--accent-soft); border: 1px solid var(--border-accent); color: var(--accent); display: flex; align-items: center; justify-content: center; font-size: 26px; margin-bottom: 14px;">
                      <i class="fa-solid fa-cubes-stacked"></i>
                    </div>
                  <?php endif; ?>
                  <h4 style="font-size: 17px; margin-bottom: 6px;"><?= htmlspecialchars($fp['judul']); ?></h4>
                  <p style="font-size: 13px; color: var(--text-dim); max-width: 300px; margin-bottom: 14px;">
                    <?= htmlspecialchars($fp['kategori']); ?> • <?= count($fitur_lines); ?> Modul Fungsional
                  </p>
                  <span class="pill-badge emerald">
                    <i class="fa-solid fa-check-double"></i> Production-Ready Schema
                  </span>
                </div>
              </div>
            </div>
          </article>
        <?php endforeach; ?>

        <!-- Standard Projects Grid -->
        <?php if (!empty($standard_projects)): ?>
          <div class="standard-projects-grid">
            <?php foreach ($standard_projects as $sp): 
              $sp_stack = array_values(array_filter(array_map('trim', explode(',', $sp['tech_stack'] ?? ''))));
              $sp_has_thumb = !empty($sp['gambar']) && $sp['gambar'] !== 'default_project.jpg';
            ?>
              <article class="project-card-compact">
                <div>
                  <?php if ($sp_has_thumb): ?>
                    <div style="height: 170px; border-radius: 8px; overflow: hidden; margin-bottom: 16px; border: 1px solid var(--border-subtle);">
                      <img src="<?= htmlspecialchars(resolve_media_url($sp['gambar'], false)); ?>" alt="<?= htmlspecialchars($sp['judul']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                  <?php endif; ?>
                  <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-bottom: 10px;">
                    <span class="pill-badge"><?= htmlspecialchars($sp['kategori']); ?></span>
                    <span class="mono" style="font-size: 11.5px; color: var(--text-dim);"><?= htmlspecialchars($sp['semester']); ?></span>
                  </div>
                  <h3 style="font-size: 19px; margin-bottom: 8px;"><?= htmlspecialchars($sp['judul']); ?></h3>
                  <p style="font-size: 14px; color: var(--text-muted); margin-bottom: 16px; line-height: 1.6;">
                    <?= htmlspecialchars($sp['deskripsi_singkat']); ?>
                  </p>
                  <div class="tech-tags-row" style="margin-bottom: 18px;">
                    <?php foreach ($sp_stack as $t): ?>
                      <span class="tech-tag"><?= htmlspecialchars($t); ?></span>
                    <?php endforeach; ?>
                  </div>
                </div>

                <div style="display: flex; gap: 8px; flex-wrap: wrap; padding-top: 14px; border-top: 1px solid var(--border-subtle);">
                  <?php if (!empty($sp['link_hosting']) && $sp['link_hosting'] !== '#'): ?>
                    <a href="<?= htmlspecialchars($sp['link_hosting']); ?>" target="_blank" rel="noopener" class="btn btn-accent btn-sm">
                      <i class="fa-solid fa-globe"></i> Website Live
                    </a>
                  <?php endif; ?>
                  <?php if (!empty($sp['link_demo']) && $sp['link_demo'] !== '#'): ?>
                    <a href="<?= htmlspecialchars($sp['link_demo']); ?>" target="_blank" rel="noopener" class="btn btn-secondary btn-sm">
                      <i class="fa-solid fa-arrow-up-right-from-square"></i> Demo
                    </a>
                  <?php endif; ?>
                  <button type="button" class="btn btn-secondary btn-sm view-project-detail" data-project="<?= htmlspecialchars(json_encode($sp), ENT_QUOTES, 'UTF-8'); ?>">
                    <i class="fa-solid fa-circle-info"></i> Detail Spesifikasi
                  </button>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== KEAHLIAN & TECH STACK ==================== -->
  <?php if (!empty($s['show_skills']) && !empty($skills)): ?>
  <section class="section" id="skills">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Technical Stack</span>
        <h2 class="section-title">Keahlian Teknis & Perangkat Kerja</h2>
        <p class="section-subtitle">Teknologi pemrograman, manajemen basis data, serta instrumen pengembangan sistem yang digunakan secara aktif.</p>
      </div>

      <div class="skills-filter-bar">
        <button type="button" class="filter-btn active" data-filter="all">Semua Kategori</button>
        <button type="button" class="filter-btn" data-filter="backend">Backend & Database</button>
        <button type="button" class="filter-btn" data-filter="frontend">Frontend & UI</button>
        <button type="button" class="filter-btn" data-filter="tools">System & Dev Tools</button>
        <button type="button" class="filter-btn" data-filter="rider">Soft Skills & Operasional</button>
      </div>

      <div class="skills-grid">
        <?php foreach ($skills as $sk): ?>
          <div class="skill-card" data-category="<?= htmlspecialchars($sk['kategori']); ?>">
            <div class="skill-card-head">
              <div class="skill-icon-box">
                <i class="<?= htmlspecialchars($sk['icon']); ?>"></i>
              </div>
              <span class="skill-tier-tag"><?= get_skill_tier_label($sk['level']); ?></span>
            </div>
            <h4><?= htmlspecialchars($sk['nama']); ?></h4>
            <p><?= htmlspecialchars($sk['deskripsi']); ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== RIWAYAT PENDIDIKAN ==================== -->
  <?php if (!empty($s['show_education']) && !empty($education)): ?>
  <section class="section" id="education">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Academic Background</span>
        <h2 class="section-title">Riwayat Pendidikan Formal</h2>
        <p class="section-subtitle">Perjalanan akademik yang membangun fondasi logika pemrograman, analisis sistem informasi, dan etika kerja.</p>
      </div>

      <div class="timeline-list">
        <?php foreach ($education as $ed): ?>
          <div class="timeline-card">
            <div>
              <span class="mono" style="font-size: 13px; color: var(--accent); font-weight: 600; display: block; margin-bottom: 4px;">
                <?= htmlspecialchars($ed['periode']); ?>
              </span>
              <span class="pill-badge emerald" style="margin-top: 4px;">
                <?= htmlspecialchars($ed['status']); ?>
              </span>
            </div>
            <div>
              <span class="mono" style="font-size: 12px; color: var(--text-dim); text-transform: uppercase;">
                <?= htmlspecialchars($ed['jenjang']); ?> — <?= htmlspecialchars($ed['jurusan']); ?>
              </span>
              <h3 style="font-size: 20px; margin: 4px 0 8px;"><?= htmlspecialchars($ed['institusi']); ?></h3>
              <p style="font-size: 14.5px; color: var(--text-muted); line-height: 1.65;">
                <?= htmlspecialchars($ed['deskripsi']); ?>
              </p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== SERTIFIKAT & LISENSI ==================== -->
  <?php if (!empty($s['show_certificates']) && !empty($certificates)): ?>
  <section class="section" id="certificates">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Verified Credentials</span>
        <h2 class="section-title">Sertifikasi & Pelatihan Kompetensi</h2>
        <p class="section-subtitle">Bukti penguasaan materi teknis dan sertifikasi pelatihan resmi yang telah diselesaikan.</p>
      </div>

      <div class="certificates-grid">
        <?php foreach ($certificates as $c): ?>
          <div class="cert-card">
            <div>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;">
                <div class="skill-icon-box" style="color: var(--amber);">
                  <i class="<?= htmlspecialchars($c['icon'] ?? 'fa-solid fa-award'); ?>"></i>
                </div>
                <span class="mono" style="font-size: 12px; color: var(--text-dim);"><?= htmlspecialchars($c['tahun']); ?></span>
              </div>
              <div class="mono" style="font-size: 11.5px; color: var(--accent); text-transform: uppercase; margin-bottom: 6px;">
                <?= htmlspecialchars($c['penerbit']); ?>
              </div>
              <h4 style="font-size: 17px; margin-bottom: 8px;"><?= htmlspecialchars($c['judul']); ?></h4>
              <p style="font-size: 13.5px; color: var(--text-muted); line-height: 1.55;">
                <?= htmlspecialchars($c['deskripsi']); ?>
              </p>
            </div>

            <button type="button" class="btn btn-secondary btn-sm view-cert-btn"
              data-cert-name="<?= htmlspecialchars($c['judul']); ?>"
              data-cert-issuer="<?= htmlspecialchars($c['penerbit']); ?>"
              data-cert-date="<?= htmlspecialchars($c['tahun']); ?>"
              data-cert-desc="<?= htmlspecialchars($c['deskripsi']); ?>"
              data-cert-link="<?= htmlspecialchars($c['link_kredensial'] ?? '#'); ?>">
              <i class="fa-regular fa-eye"></i> Detail Kredensial
            </button>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== AKTIVITAS LUAR RUANG & GALERI (OPTIONAL VIA ADMIN) ==================== -->
  <?php if (!empty($s['show_motor'])): ?>
  <section class="section" id="motor">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Life Outside Code</span>
        <h2 class="section-title">Cerita Motoran, Touring & Galeri</h2>
        <p class="section-subtitle">Ngelepas penat habis ngoding lewat perjalanan jauh, sunmori pagi, dan ngerawat kuda besi andalan.</p>
      </div>

      <div class="motor-tabs">
        <button type="button" class="motor-tab-btn active" data-tab="tab-touring">
          <i class="fa-solid fa-route"></i> Eksplorasi & Touring
        </button>
        <button type="button" class="motor-tab-btn" data-tab="tab-motor-spec">
          <i class="fa-solid fa-motorcycle"></i> Spesifikasi Kendaraan
        </button>
        <?php if (!empty($gears)): ?>
          <button type="button" class="motor-tab-btn" data-tab="tab-gear">
            <i class="fa-solid fa-shield-heart"></i> Standar Keselamatan
          </button>
        <?php endif; ?>
        <?php if (!empty($s['show_gallery']) && !empty($gallery)): ?>
          <button type="button" class="motor-tab-btn" data-tab="tab-gallery">
            <i class="fa-regular fa-images"></i> Galeri Dokumentasi
          </button>
        <?php endif; ?>
      </div>

      <!-- Panel 1: Touring & Route + Foto Kendaraan Utama -->
      <div class="motor-panel active" id="tab-touring">
        <?php if (!empty($motor_src)): ?>
          <div style="margin-bottom: 22px; border-radius: var(--radius-md); overflow: hidden; border: 1px solid var(--border-subtle); max-height: 360px; position: relative;">
            <img src="<?= htmlspecialchars($motor_src); ?>" alt="<?= htmlspecialchars($motor['model']); ?>" style="width: 100%; height: 320px; object-fit: cover; display: block;">
            <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 14px 20px; background: linear-gradient(to top, rgba(9,11,16,0.9), transparent); color: #F8FAFC;">
              <strong style="font-size: 16px;"><?= htmlspecialchars($motor['model']); ?></strong>
              <span style="font-size: 12.5px; color: #CBD5E1; margin-left: 10px;">Odometer: <?= htmlspecialchars($motor['odometer']); ?></span>
            </div>
          </div>
        <?php endif; ?>
        <div class="telemetry-grid">
          <div class="telemetry-card">
            <div class="telemetry-icon"><i class="fa-solid fa-road"></i></div>
            <div class="telemetry-info">
              <span>Jalur Utama</span>
              <h4><?= htmlspecialchars($motor['rute_favorit']); ?></h4>
            </div>
          </div>
          <div class="telemetry-card">
            <div class="telemetry-icon"><i class="fa-solid fa-location-crosshairs"></i></div>
            <div class="telemetry-info">
              <span>Jangkauan Terjauh</span>
              <h4><?= htmlspecialchars($motor['tujuan_terjauh']); ?></h4>
            </div>
          </div>
          <div class="telemetry-card">
            <div class="telemetry-icon"><i class="fa-solid fa-compass"></i></div>
            <div class="telemetry-info">
              <span>Karakter Berkendara</span>
              <h4><?= htmlspecialchars($motor['riding_style']); ?></h4>
            </div>
          </div>
        </div>
        <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 22px;">
          <p style="color: var(--text-muted); font-size: 15px; line-height: 1.75;">
            <?= nl2br(htmlspecialchars($motor['deskripsi'])); ?>
          </p>
        </div>
      </div>

      <!-- Panel 2: Vehicle Spec -->
      <div class="motor-panel" id="tab-motor-spec">
        <?php if (!empty($motor_src)): ?>
          <div style="margin-bottom: 22px; border-radius: var(--radius-md); overflow: hidden; border: 1px solid var(--border-subtle); max-height: 360px; position: relative;">
            <img src="<?= htmlspecialchars($motor_src); ?>" alt="<?= htmlspecialchars($motor['model']); ?>" style="width: 100%; height: 340px; object-fit: cover; display: block;">
          </div>
        <?php endif; ?>
        <div class="telemetry-grid">
          <div class="telemetry-card">
            <div class="telemetry-icon"><i class="fa-solid fa-motorcycle"></i></div>
            <div class="telemetry-info">
              <span>Unit Kendaraan</span>
              <h4><?= htmlspecialchars($motor['model']); ?></h4>
            </div>
          </div>
          <div class="telemetry-card">
            <div class="telemetry-icon"><i class="fa-regular fa-calendar-check"></i></div>
            <div class="telemetry-info">
              <span>Tahun Operasional</span>
              <h4>Sejak <?= htmlspecialchars($motor['tahun']); ?></h4>
            </div>
          </div>
          <div class="telemetry-card">
            <div class="telemetry-icon"><i class="fa-solid fa-gauge-high"></i></div>
            <div class="telemetry-info">
              <span>Jarak Tempuh (Odometer)</span>
              <h4><?= htmlspecialchars($motor['odometer']); ?></h4>
            </div>
          </div>
        </div>
      </div>

      <!-- Panel 3: Safety Gear -->
      <?php if (!empty($gears)): ?>
      <div class="motor-panel" id="tab-gear">
        <div class="gear-grid">
          <?php foreach ($gears as $g): ?>
            <div class="gear-item">
              <div class="gear-checkbox"><i class="fa-solid fa-check"></i></div>
              <div>
                <strong style="display: block; font-size: 13.5px; color: var(--text-heading);"><?= htmlspecialchars($g['nama_gear']); ?></strong>
                <span class="mono" style="font-size: 11px; color: var(--text-dim);"><?= htmlspecialchars($g['kategori']); ?></span>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- Panel 4: Documentation Gallery (Read-Only for Visitors) -->
      <?php if (!empty($s['show_gallery']) && !empty($gallery)): ?>
      <div class="motor-panel" id="tab-gallery">
        <div class="gallery-grid">
          <?php foreach ($gallery as $gal): ?>
            <div class="gallery-card">
              <div class="gallery-img-box">
                <img src="<?= htmlspecialchars(resolve_media_url($gal['gambar_url'], false)); ?>" alt="<?= htmlspecialchars($gal['judul']); ?>">
                <span class="pill-badge accent" style="position: absolute; top: 10px; right: 10px; background: rgba(9,11,16,0.85);">
                  <?= strtoupper(htmlspecialchars($gal['kategori'])); ?>
                </span>
              </div>
              <div style="padding: 16px;">
                <h4 style="font-size: 15.5px; margin-bottom: 6px;"><?= htmlspecialchars($gal['judul']); ?></h4>
                <p style="font-size: 13px; color: var(--text-muted);"><?= htmlspecialchars($gal['caption']); ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== STANDALONE GALLERY IF MOTOR IS HIDDEN BUT GALLERY IS ENABLED ==================== -->
  <?php if (empty($s['show_motor']) && !empty($s['show_gallery']) && !empty($gallery)): ?>
  <section class="section" id="gallery">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Documentation</span>
        <h2 class="section-title">Galeri Dokumentasi & Kegiatan</h2>
        <p class="section-subtitle">Dokumentasi kegiatan pengembangan sistem, aktivitas akademik, dan eksplorasi.</p>
      </div>
      <div class="gallery-grid">
        <?php foreach ($gallery as $gal): ?>
          <div class="gallery-card">
            <div class="gallery-img-box">
              <img src="<?= htmlspecialchars(resolve_media_url($gal['gambar_url'], false)); ?>" alt="<?= htmlspecialchars($gal['judul']); ?>">
            </div>
            <div style="padding: 16px;">
              <h4 style="font-size: 15.5px; margin-bottom: 6px;"><?= htmlspecialchars($gal['judul']); ?></h4>
              <p style="font-size: 13px; color: var(--text-muted);"><?= htmlspecialchars($gal['caption']); ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== DOKUMEN & BERKAS PUBLIK (DARI DATABASE) ==================== -->
  <?php if (!empty($s['show_documents']) && !empty($documents)): ?>
  <section class="section" id="documents">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Verified Documents</span>
        <h2 class="section-title">Dokumen, Berkas & Lampiran Resmi</h2>
        <p class="section-subtitle">Dokumen pendukung, lampiran portofolio, maupun berkas resmi yang dapat ditinjau dan diunduh langsung.</p>
      </div>

      <div class="certificates-grid">
        <?php foreach ($documents as $doc): 
          $doc_url = resolve_media_url($doc['file_path'], false);
          $ftype = strtoupper($doc['file_type'] ?? 'FILE');
          $fsize = !empty($doc['file_size']) ? number_format($doc['file_size'] / 1024, 1) . ' KB' : '';
          $icon_cls = ($ftype === 'PDF') ? 'fa-solid fa-file-pdf' : (in_array($ftype, ['JPG','JPEG','PNG','WEBP','GIF']) ? 'fa-regular fa-file-image' : 'fa-regular fa-file-lines');
        ?>
          <div class="cert-card">
            <div>
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                <div class="skill-icon-box" style="color: var(--accent);">
                  <i class="<?= $icon_cls; ?>"></i>
                </div>
                <span class="pill-badge"><?= htmlspecialchars($ftype); ?> <?= $fsize ? '• ' . $fsize : ''; ?></span>
              </div>
              <div class="mono" style="font-size: 11.5px; color: var(--accent); text-transform: uppercase; margin-bottom: 6px;">
                <?= htmlspecialchars($doc['kategori']); ?>
              </div>
              <h4 style="font-size: 17px; margin-bottom: 8px;"><?= htmlspecialchars($doc['judul']); ?></h4>
              <?php if (!empty($doc['keterangan'])): ?>
                <p style="font-size: 13.5px; color: var(--text-muted); line-height: 1.55;">
                  <?= htmlspecialchars($doc['keterangan']); ?>
                </p>
              <?php endif; ?>
            </div>

            <div style="display: flex; gap: 8px; margin-top: 8px;">
              <a href="<?= htmlspecialchars($doc_url); ?>" target="_blank" rel="noopener" class="btn btn-secondary btn-sm" style="flex: 1;">
                <i class="fa-regular fa-eye"></i> Lihat
              </a>
              <a href="<?= htmlspecialchars($doc_url); ?>" download class="btn btn-accent btn-sm" style="flex: 1;">
                <i class="fa-solid fa-download"></i> Unduh
              </a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== RESUME / CV ATS SECTION ==================== -->
  <?php if (!empty($s['show_cv'])): ?>
  <section class="section" id="cv">
    <div class="container">
      <div class="cv-banner-card">
        <div class="cv-banner-copy">
          <span class="section-eyebrow" style="margin-bottom: 8px;">Curriculum Vitae</span>
          <h3>Unduh atau Cetak Resume Standar ATS</h3>
          <p>
            Ringkasan formal kualifikasi akademik, pengalaman implementasi sistem, studi kasus proyek, dan kompetensi teknis <?= htmlspecialchars($s['nama']); ?> dalam format siap cetak A4 untuk pengajuan magang maupun rekrutmen kerja.
          </p>
        </div>

        <div class="cv-banner-actions">
          <a href="cv.php" target="_blank" class="btn btn-accent">
            <i class="fa-regular fa-file-lines"></i> Buka CV Siap Cetak (A4)
          </a>
          <button type="button" class="btn btn-primary open-cv-modal">
            <i class="fa-regular fa-eye"></i> Pratinjau Cepat
          </button>
          <?php if ($has_custom_cv): ?>
            <a href="<?= htmlspecialchars(resolve_media_url($s['cv_url'], false)); ?>" download class="btn btn-secondary">
              <i class="fa-solid fa-download"></i> Unduh File CV Resmi
            </a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== KONTAK & KOLABORASI ==================== -->
  <?php if (!empty($s['show_contact'])): ?>
  <section class="section" id="contact">
    <div class="container">
      <div class="section-header">
        <span class="section-eyebrow">Direct Contact</span>
        <h2 class="section-title">Hubungi untuk Rekrutmen & Kolaborasi</h2>
        <p class="section-subtitle">Silakan hubungi melalui saluran resmi di bawah ini atau kirimkan pesan langsung untuk diskusi peluang magang, pekerjaan, maupun pengembangan sistem.</p>
      </div>

      <div class="contact-grid">
        <?php if (!empty($s['show_social_links'])): ?>
        <div class="contact-channels">
          <!-- Email -->
          <div class="channel-card">
            <div class="channel-left">
              <div class="channel-icon"><i class="fa-regular fa-envelope"></i></div>
              <div class="channel-meta">
                <span>Email Korespondensi</span>
                <strong><?= htmlspecialchars($s['email']); ?></strong>
              </div>
            </div>
            <div style="display: flex; gap: 6px;">
              <a href="mailto:<?= htmlspecialchars($s['email']); ?>" class="btn btn-primary btn-sm">Kirim Email</a>
              <button type="button" class="btn btn-secondary btn-sm copy-btn" data-copy="<?= htmlspecialchars($s['email']); ?>" title="Salin Email">
                <i class="fa-regular fa-copy"></i>
              </button>
            </div>
          </div>

          <!-- WhatsApp -->
          <div class="channel-card">
            <div class="channel-left">
              <div class="channel-icon" style="color: var(--emerald);"><i class="fa-brands fa-whatsapp"></i></div>
              <div class="channel-meta">
                <span>WhatsApp Bisnis / Langsung</span>
                <strong><?= htmlspecialchars($s['whatsapp']); ?></strong>
              </div>
            </div>
            <div style="display: flex; gap: 6px;">
              <a href="https://wa.me/<?= $wa_clean; ?>?text=<?= urlencode('Halo ' . $s['nama'] . ', saya meninjau portofolio Anda dan ingin berdiskusi lebih lanjut.'); ?>" target="_blank" rel="noopener" class="btn btn-emerald btn-sm">
                Hubungi
              </a>
              <button type="button" class="btn btn-secondary btn-sm copy-btn" data-copy="<?= htmlspecialchars($s['whatsapp']); ?>" title="Salin Nomor">
                <i class="fa-regular fa-copy"></i>
              </button>
            </div>
          </div>

          <!-- LinkedIn -->
          <?php if (!empty($s['linkedin']) && $s['linkedin'] !== '#'): ?>
          <div class="channel-card">
            <div class="channel-left">
              <div class="channel-icon"><i class="fa-brands fa-linkedin-in"></i></div>
              <div class="channel-meta">
                <span>Jaringan Profesional</span>
                <strong>LinkedIn Profile</strong>
              </div>
            </div>
            <a href="<?= htmlspecialchars($s['linkedin']); ?>" target="_blank" rel="noopener" class="btn btn-secondary btn-sm">
              Buka Profil <i class="fa-solid fa-arrow-up-right-from-square"></i>
            </a>
          </div>
          <?php endif; ?>

          <!-- GitHub -->
          <?php if (!empty($s['github']) && $s['github'] !== '#'): ?>
          <div class="channel-card">
            <div class="channel-left">
              <div class="channel-icon"><i class="fa-brands fa-github"></i></div>
              <div class="channel-meta">
                <span>Repositori Kode</span>
                <strong>GitHub Profile</strong>
              </div>
            </div>
            <a href="<?= htmlspecialchars($s['github']); ?>" target="_blank" rel="noopener" class="btn btn-secondary btn-sm">
              Lihat Repo <i class="fa-solid fa-arrow-up-right-from-square"></i>
            </a>
          </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Direct Database Message Form -->
        <div class="contact-form-card">
          <h3 style="font-size: 20px; margin-bottom: 6px;">Kirim Pesan Langsung</h3>
          <p style="font-size: 13.5px; color: var(--text-muted); margin-bottom: 22px;">
            Pesan yang Anda kirimkan akan langsung masuk ke kotak masuk utama <?= htmlspecialchars($s['nama']); ?>.
          </p>

          <form method="POST" action="index.php#contact" id="contactForm">
            <input type="hidden" name="send_message" value="1">

            <div class="form-group">
              <label class="form-label" for="formName">Nama Lengkap / Instansi</label>
              <input type="text" name="nama" id="formName" class="form-control" placeholder="Contoh: Budi Santoso — HRD PT Teknologi Nusantara" required>
            </div>

            <div class="form-group">
              <label class="form-label" for="formEmail">Kontak Balasan (Email atau Nomor WhatsApp)</label>
              <input type="text" name="kontak" id="formEmail" class="form-control" placeholder="email@perusahaan.com atau 0812xxxx" required>
            </div>

            <div class="form-group">
              <label class="form-label" for="formMessage">Subjek & Isi Pesan</label>
              <textarea name="pesan" id="formMessage" class="form-control" placeholder="Tuliskan maksud kerja sama, undangan wawancara magang/kerja, atau diskusi proyek..." required></textarea>
            </div>

            <button type="submit" class="btn btn-accent" style="width: 100%; padding: 12px;">
              <i class="fa-solid fa-paper-plane"></i> Kirim Pesan Resmi
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <!-- ==================== FOOTER ==================== -->
  <footer class="footer">
    <div class="container footer-inner">
      <div class="footer-copy">
        <strong><?= htmlspecialchars($s['nama']); ?></strong> — <?= htmlspecialchars($s['tagline']); ?>.
        <span style="display: block; font-size: 12.5px; margin-top: 2px;">
          © <?= date('Y'); ?> Seluruh hak cipta dilindungi. <?= htmlspecialchars($s['asal']); ?>.
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 12px;">
        <a href="#hero" class="btn btn-secondary btn-sm">
          <i class="fa-solid fa-arrow-up"></i> Ke Atas
        </a>
        <?php if (!$is_admin): ?>
          <a href="admin/login.php" class="discreet-admin-link" title="Pengelolaan Pemilik">
            <i class="fa-solid fa-lock"></i>
          </a>
        <?php endif; ?>
      </div>
    </div>
  </footer>

  <!-- ==================== FLOATING BAR KHUSUS ADMIN YANG SEDANG LOGIN ==================== -->
  <?php if ($is_admin): ?>
    <div class="admin-floating-bar">
      <span><i class="fa-solid fa-shield-halved" style="color:#10B981;"></i> Mode Admin Aktif</span>
      <span>|</span>
      <a href="admin/visibilitas.php"><i class="fa-solid fa-eye"></i> Visibilitas</a>
      <a href="admin/galeri.php"><i class="fa-solid fa-camera"></i> Kelola Foto</a>
      <a href="admin/profil.php"><i class="fa-solid fa-user-pen"></i> Edit Profil</a>
      <a href="admin/index.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
    </div>
  <?php endif; ?>

  <!-- ==================== HIDDEN CV MODAL TEMPLATE ==================== -->
  <template id="cvModalTemplate">
    <div style="font-family: var(--font-sans); color: var(--text-main);">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 14px; padding-bottom: 18px; border-bottom: 1px solid var(--border-strong); margin-bottom: 18px;">
        <div>
          <h2 style="font-size: 24px; margin-bottom: 4px;"><?= htmlspecialchars($s['nama']); ?></h2>
          <p style="color: var(--accent); font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?= htmlspecialchars($s['tagline']); ?></p>
          <p style="font-size: 12.5px; color: var(--text-muted);">
            <?= htmlspecialchars($s['asal']); ?> • <?= htmlspecialchars($s['email']); ?> • <?= htmlspecialchars($s['whatsapp']); ?>
          </p>
        </div>
        <div style="display: flex; gap: 8px;">
          <a href="cv.php" target="_blank" class="btn btn-accent btn-sm">
            <i class="fa-solid fa-print"></i> Buka & Cetak CV (A4)
          </a>
          <?php if ($has_custom_cv): ?>
            <a href="<?= htmlspecialchars(resolve_media_url($s['cv_url'], false)); ?>" download class="btn btn-secondary btn-sm">
              <i class="fa-solid fa-download"></i> File PDF
            </a>
          <?php endif; ?>
        </div>
      </div>

      <div style="margin-bottom: 18px;">
        <h4 style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--accent); margin-bottom: 6px;">Ringkasan Eksekutif</h4>
        <p style="font-size: 13.5px; color: var(--text-muted); line-height: 1.65;">
          <?= htmlspecialchars($s['hero_desc']); ?>
        </p>
      </div>

      <?php if (!empty($experiences)): ?>
      <div style="margin-bottom: 18px;">
        <h4 style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--accent); margin-bottom: 8px;">Pengalaman & Implementasi Sistem</h4>
        <?php foreach ($experiences as $e): ?>
          <div style="margin-bottom: 12px;">
            <div style="display: flex; justify-content: space-between; font-weight: 600; font-size: 14px; color: var(--text-heading);">
              <span><?= htmlspecialchars($e['posisi']); ?> — <?= htmlspecialchars($e['instansi']); ?></span>
              <span class="mono" style="font-size: 12px; color: var(--text-dim);"><?= htmlspecialchars($e['periode']); ?></span>
            </div>
            <p style="font-size: 13px; color: var(--text-muted); margin-top: 3px;"><?= htmlspecialchars($e['deskripsi']); ?></p>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if (!empty($projects)): ?>
      <div style="margin-bottom: 18px;">
        <h4 style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--accent); margin-bottom: 8px;">Proyek & Studi Kasus Utama</h4>
        <?php foreach ($projects as $p): ?>
          <div style="margin-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; font-weight: 600; font-size: 13.5px; color: var(--text-heading);">
              <span><?= htmlspecialchars($p['judul']); ?></span>
              <span class="mono" style="font-size: 11.5px; color: var(--text-dim);"><?= htmlspecialchars($p['tech_stack']); ?></span>
            </div>
            <p style="font-size: 12.5px; color: var(--text-muted); margin-top: 2px;"><?= htmlspecialchars($p['deskripsi_singkat']); ?></p>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if (!empty($education)): ?>
      <div style="margin-bottom: 18px;">
        <h4 style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--accent); margin-bottom: 8px;">Pendidikan</h4>
        <?php foreach ($education as $ed): ?>
          <div style="display: flex; justify-content: space-between; font-size: 13.5px; margin-bottom: 6px;">
            <span><strong><?= htmlspecialchars($ed['institusi']); ?></strong> — <?= htmlspecialchars($ed['jenjang']); ?> <?= htmlspecialchars($ed['jurusan']); ?></span>
            <span class="mono" style="font-size: 12px; color: var(--text-dim);"><?= htmlspecialchars($ed['periode']); ?></span>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <div>
        <h4 style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--accent); margin-bottom: 6px;">Keahlian Teknis</h4>
        <p style="font-size: 13px; color: var(--text-muted); line-height: 1.6;">
          <?php
            $skill_names = array_map(function($item) { return $item['nama']; }, $skills);
            echo htmlspecialchars(implode(' • ', $skill_names));
          ?>
        </p>
      </div>
    </div>
  </template>

  <!-- ==================== FORMAL A4 ATS RESUME FOR @MEDIA PRINT ==================== -->
  <div class="ats-print-only" id="atsPrintableResume">
    <div class="ats-header">
      <h1><?= htmlspecialchars($s['nama']); ?></h1>
      <p><?= htmlspecialchars($s['tagline']); ?></p>
      <p>
        <?= htmlspecialchars($s['asal']); ?> | Telp/WA: <?= htmlspecialchars($s['whatsapp']); ?> | Email: <?= htmlspecialchars($s['email']); ?>
        <?php if (!empty($s['linkedin']) && $s['linkedin'] !== '#'): ?> | <?= htmlspecialchars($s['linkedin']); ?><?php endif; ?>
      </p>
    </div>

    <div class="ats-section">
      <div class="ats-section-title">Ringkasan Profesional</div>
      <p><?= htmlspecialchars($s['hero_desc']); ?></p>
    </div>

    <?php if (!empty($experiences)): ?>
    <div class="ats-section">
      <div class="ats-section-title">Pengalaman Proyek & Rekam Jejak</div>
      <?php foreach ($experiences as $e): 
        $ach_list = array_filter(array_map('trim', preg_split('/\r?\n/', $e['pencapaian'] ?? '')));
      ?>
        <div class="ats-item">
          <div class="ats-item-head">
            <span><?= htmlspecialchars($e['posisi']); ?></span>
            <span><?= htmlspecialchars($e['periode']); ?></span>
          </div>
          <div class="ats-item-sub">
            <span><?= htmlspecialchars($e['instansi']); ?> (<?= htmlspecialchars($e['jenis']); ?>)</span>
            <span><?= htmlspecialchars($e['lokasi']); ?></span>
          </div>
          <p><?= htmlspecialchars($e['deskripsi']); ?></p>
          <?php if (!empty($ach_list)): ?>
            <ul class="ats-bullets">
              <?php foreach ($ach_list as $al): ?>
                <li><?= htmlspecialchars(preg_replace('/^[-•\d.]+\s*/', '', $al)); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($projects)): ?>
    <div class="ats-section">
      <div class="ats-section-title">Studi Kasus & Proyek Perangkat Lunak</div>
      <?php foreach ($projects as $p): ?>
        <div class="ats-item">
          <div class="ats-item-head">
            <span><?= htmlspecialchars($p['judul']); ?></span>
            <span><?= htmlspecialchars($p['kategori']); ?></span>
          </div>
          <div class="ats-item-sub">
            <span>Teknologi: <?= htmlspecialchars($p['tech_stack']); ?></span>
            <span><?= htmlspecialchars($p['semester']); ?></span>
          </div>
          <p><?= htmlspecialchars($p['deskripsi_singkat']); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($education)): ?>
    <div class="ats-section">
      <div class="ats-section-title">Pendidikan</div>
      <?php foreach ($education as $ed): ?>
        <div class="ats-item">
          <div class="ats-item-head">
            <span><?= htmlspecialchars($ed['institusi']); ?></span>
            <span><?= htmlspecialchars($ed['periode']); ?></span>
          </div>
          <div class="ats-item-sub">
            <span><?= htmlspecialchars($ed['jenjang']); ?> — <?= htmlspecialchars($ed['jurusan']); ?></span>
            <span><?= htmlspecialchars($ed['status']); ?></span>
          </div>
          <p><?= htmlspecialchars($ed['deskripsi']); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($skills)): ?>
    <div class="ats-section">
      <div class="ats-section-title">Kompetensi Teknis</div>
      <p>
        <?php
          $sk_summary = [];
          foreach ($skills as $sk) {
              $sk_summary[] = $sk['nama'] . ' (' . $sk['deskripsi'] . ')';
          }
          echo htmlspecialchars(implode('; ', $sk_summary));
        ?>
      </p>
    </div>
    <?php endif; ?>

    <?php if (!empty($certificates)): ?>
    <div class="ats-section">
      <div class="ats-section-title">Sertifikasi & Pelatihan</div>
      <?php foreach ($certificates as $c): ?>
        <div class="ats-item">
          <div class="ats-item-head">
            <span><?= htmlspecialchars($c['judul']); ?> — <?= htmlspecialchars($c['penerbit']); ?></span>
            <span><?= htmlspecialchars($c['tahun']); ?></span>
          </div>
          <p><?= htmlspecialchars($c['deskripsi']); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- ==================== MODAL & TOAST CONTAINERS ==================== -->
  <div class="modal-overlay" id="modalOverlay">
    <div class="modal-content-box">
      <div class="modal-header">
        <h3 id="modalTitle" style="font-size: 18px;">Detail Informasi</h3>
        <button type="button" class="modal-close-btn" id="modalClose" aria-label="Tutup">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="modal-body" id="modalBody"></div>
    </div>
  </div>

  <div class="toast-container" id="toastContainer"></div>

  <!-- Pass Dynamic PHP Data to Client Script -->
  <script>
    window.PORTFOLIO_ROLES = <?= json_encode($roles_list, JSON_UNESCAPED_UNICODE); ?>;
    window.PORTFOLIO_CONSOLE = {
      profile: <?= json_encode($s['nama'] . " — " . $s['tagline'] . "\nDomisili: " . $s['asal'] . "\nInstitusi: " . $s['kampus'] . " (" . $s['prodi'] . ")", JSON_UNESCAPED_UNICODE); ?>,
      architecture: "1. Presentation Layer: Semantic HTML5, Modern CSS Grid, Vanilla ES6+\n2. Application Layer: Modular PHP Native/OOP, Session Auth, CSRF & MIME Guard\n3. Data Layer: Relational MySQL/MariaDB (InnoDB, utf8mb4, Prepared Statements)",
      projects: <?= json_encode(implode("\n", array_map(function($p) { return "• [" . $p['kategori'] . "] " . $p['judul'] . " (" . $p['tech_stack'] . ")"; }, $projects)), JSON_UNESCAPED_UNICODE); ?>,
      contact: <?= json_encode("Email: " . $s['email'] . " | WhatsApp: " . $s['whatsapp'] . " | LinkedIn: " . $s['linkedin'], JSON_UNESCAPED_UNICODE); ?>
    };
  </script>
  <script src="js/script.js"></script>

  <?php if (!empty($contact_alert)):
    list($st_code, $st_msg) = explode(':', $contact_alert, 2);
  ?>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        if (window.showToast) {
          window.showToast(<?= json_encode($st_msg); ?>, <?= json_encode($st_code === 'success' ? 'fa-solid fa-circle-check' : 'fa-solid fa-circle-exclamation'); ?>);
        }
      });
    </script>
  <?php endif; ?>
</body>
</html>
