# Portofolio Eksekutif Ibnu Andriano — Full-Stack & Information Systems

Aplikasi Web Portofolio Profesional dengan **Arsitektur Database MySQL Dinamis**, **Kontrol Visibilitas Granular (Tampilkan/Sembunyikan Semua Bagian & Item)**, **Proteksi Media Khusus Admin**, serta **Generator Resume / CV Standar ATS Siap Cetak**.

---

## ✨ Keunggulan & Fitur Utama

1. **Desain Eksekutif & Timeless (Siap Dipakai Selamanya)**
   - Dirancang khusus untuk kebutuhan melamar **Magang (Internship)**, **Rekrutmen Kerja Full-Time**, **Freelance**, maupun **Studi Kasus Akademik/Profesional**.
   - Dilengkapi **Theme Switcher (Dark Slate & Editorial Light Mode)** yang bersih, bebas dari gimmick suara/animasi berlebihan, dan menggunakan tipografi standar industri.
2. **Kontrol Visibilitas Penuh oleh Admin (`admin/visibilitas.php`)**
   - Admin memiliki **16 Sakelar Visibilitas Bagian** (Foto Profil, Status Ketersediaan Kerja, Metrik Hero, Detail NIM/IPK, Profil, Fokus Kompetensi, Pengalaman, Proyek, Tech Stack, Pendidikan, Sertifikasi, CV ATS, Kontak, Sosial Media, Aktivitas Otomotif, Galeri, dan Konsol).
   - Dilengkapi **4 Preset 1-Klik** (termasuk *Mode Melamar Kerja / Magang* yang otomatis menyembunyikan bagian hobi agar 100% formal korporat).
   - Setiap item individual pada **Proyek, Pengalaman, Skill, Pendidikan (misal: menyembunyikan SD/SMP), Sertifikat, dan Foto Galeri** juga dapat disembunyikan atau ditampilkan dengan 1 klik tanpa menghapus data.
3. **Proteksi Foto & Media Ketat (Admin-Only Access)**
   - Pengunjung publik **tidak memiliki akses sedikitpun** untuk mengganti foto profil, mengunggah gambar, atau melihat tombol edit admin.
   - Penggantian foto profil, foto proyek, dokumen CV PDF, dan galeri hanya dapat dilakukan oleh Admin yang telah terautentikasi melalui sesi server (`admin/profil.php` & `admin/galeri.php`).
4. **Built-in ATS Resume & PDF Generator**
   - Saat menekan tombol **Cetak / Simpan PDF (ATS)**, sistem otomatis merender dokumen **Curriculum Vitae A4 Standar Harvard/ATS** hitam-putih yang bersih dari seluruh data database aktif.

---

## 🔑 Akses Panel Admin

- **URL Login Admin**: `http://localhost/portofolio/admin/login.php`
- **Username Default**: `PadukaIbnu`
- **Password Default**: `Ibnu@3097`
*(Username dan password dapat diubah kapan saja melalui menu **Akun & Keamanan Admin** di `admin/akun.php`).*
