<?php
$page_title = 'Kelola Riwayat Pendidikan';
require_once __DIR__ . '/header.php';

$msg = '';
$err = '';
$edit_edu = null;

if (isset($_GET['toggle_vis'])) {
    $tid = (int)$_GET['toggle_vis'];
    hybrid_toggle_visible($koneksi, 'education', $tid);
    $msg = "Visibilitas jenjang pendidikan berhasil diperbarui!";
}

if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    hybrid_delete($koneksi, 'education', $del_id);
    $msg = "Riwayat pendidikan berhasil dihapus!";
}

if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_edu = hybrid_get_by_id($koneksi, 'education', $edit_id);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $jenjang = trim($_POST['jenjang'] ?? '');
    $institusi = trim($_POST['institusi'] ?? '');
    $jurusan = trim($_POST['jurusan'] ?? '');
    $periode = trim($_POST['periode'] ?? '');
    $status = trim($_POST['status'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $urutan = (int)($_POST['urutan'] ?? 1);
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;

    $payload = [
        'jenjang'    => $jenjang,
        'institusi'  => $institusi,
        'jurusan'    => $jurusan,
        'periode'    => $periode,
        'status'     => $status,
        'deskripsi'  => $deskripsi,
        'urutan'     => $urutan,
        'is_visible' => $is_visible
    ];

    if ($id > 0) {
        hybrid_update($koneksi, 'education', $id, $payload);
        $msg = "Riwayat pendidikan '$institusi' berhasil diperbarui!";
        $edit_edu = null;
    } else {
        hybrid_insert($koneksi, 'education', $payload);
        $msg = "Pendidikan '$institusi' berhasil ditambahkan!";
    }
}

$education = get_education($koneksi, false);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<?php if (!empty($err)): ?>
  <div class="alert-success" style="background: rgba(244,63,94,0.12); border-color: rgba(244,63,94,0.3); color: var(--rose);">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($err); ?>
  </div>
<?php endif; ?>

<div class="dash-card">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-graduation-cap" style="color: var(--cyan);"></i>
      <?= $edit_edu ? 'Edit Pendidikan: ' . htmlspecialchars($edit_edu['institusi']) : 'Tambah Riwayat Pendidikan Baru'; ?>
    </h3>
    <?php if ($edit_edu): ?>
      <a href="education.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="education.php">
    <?php if ($edit_edu): ?>
      <input type="hidden" name="id" value="<?= $edit_edu['id']; ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Tingkat / Jenjang</label>
        <input type="text" name="jenjang" class="form-control" placeholder="Sarjana (S1), SMA, SMP..." value="<?= htmlspecialchars($edit_edu['jenjang'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Nama Perguruan Tinggi / Sekolah</label>
        <input type="text" name="institusi" class="form-control" placeholder="Universitas Bina Bangsa..." value="<?= htmlspecialchars($edit_edu['institusi'] ?? ''); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Jurusan / Program Studi</label>
        <input type="text" name="jurusan" class="form-control" placeholder="Sistem Informasi, MIPA..." value="<?= htmlspecialchars($edit_edu['jurusan'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Periode Tahun</label>
        <input type="text" name="periode" class="form-control" placeholder="2023 - Sekarang" value="<?= htmlspecialchars($edit_edu['periode'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Status / Capaian</label>
        <input type="text" name="status" class="form-control" placeholder="Mahasiswa Aktif (IPK 3.82) / Lulus" value="<?= htmlspecialchars($edit_edu['status'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Urutan Tampil</label>
        <input type="number" name="urutan" class="form-control" value="<?= htmlspecialchars($edit_edu['urutan'] ?? 1); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Deskripsi Fokus Studi / Kualifikasi</label>
      <textarea name="deskripsi" class="form-control" rows="2" required><?= htmlspecialchars($edit_edu['deskripsi'] ?? ''); ?></textarea>
    </div>

    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
      <input type="checkbox" id="is_visible" name="is_visible" value="1" <?= (!isset($edit_edu['is_visible']) || !empty($edit_edu['is_visible'])) ? 'checked' : ''; ?> style="width: 18px; height: 18px;">
      <label for="is_visible" style="color: #fff; cursor: pointer;">Tampilkan jenjang ini di Halaman Publik & Resume ATS (Tips: Anda dapat menyembunyikan SD/SMP saat melamar kerja korporat)</label>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> <?= $edit_edu ? 'Simpan Perubahan' : 'Tambah Pendidikan'; ?>
    </button>
  </form>
</div>

<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-timeline" style="color: var(--emerald);"></i> Daftar Riwayat Pendidikan</h3>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Jenjang</th>
          <th>Institusi</th>
          <th>Jurusan</th>
          <th>Periode</th>
          <th>Visibilitas Publik</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($education as $ed): 
          $vis = !isset($ed['is_visible']) || !empty($ed['is_visible']);
        ?>
          <tr style="<?= !$vis ? 'opacity: 0.55;' : ''; ?>">
            <td><strong style="color: var(--cyan);"><?= htmlspecialchars($ed['jenjang']); ?></strong></td>
            <td><strong><?= htmlspecialchars($ed['institusi']); ?></strong></td>
            <td><?= htmlspecialchars($ed['jurusan']); ?></td>
            <td class="mono" style="font-size: 12px;"><?= htmlspecialchars($ed['periode']); ?></td>
            <td>
              <?php if (isset($ed['id'])): ?>
                <a href="education.php?toggle_vis=<?= $ed['id']; ?>" class="btn <?= $vis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm">
                  <i class="fa-solid <?= $vis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                  <?= $vis ? 'Tampil' : 'Disembunyikan'; ?>
                </a>
              <?php endif; ?>
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <?php if (isset($ed['id'])): ?>
                  <a href="education.php?edit=<?= $ed['id']; ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                  <a href="education.php?del=<?= $ed['id']; ?>" onclick="return confirm('Hapus riwayat ini?');" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
