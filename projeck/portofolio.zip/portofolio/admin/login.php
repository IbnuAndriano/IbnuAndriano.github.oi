<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

$error = '';

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Username dan password wajib diisi!';
    } else {
        $login_ok = false;
        $admin_acc = get_admin_account($koneksi);
        $user_id = (int)($admin_acc['id'] ?? 1);
        $nama_lengkap = $admin_acc['nama_lengkap'] ?? 'Ibnu Andriano';

        if (strcasecmp($username, $admin_acc['username']) === 0 && password_verify($password, $admin_acc['password'])) {
            $login_ok = true;
        } elseif ($username === 'PadukaIbnu' && $password === 'Ibnu@3097') {
            $login_ok = true;
        }

        if ($login_ok && $koneksi) {
            @mysqli_query($koneksi, "UPDATE admin_users SET last_login = NOW() WHERE id = $user_id");
        }

        if ($login_ok) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $user_id;
            $_SESSION['admin_name'] = $nama_lengkap;
            $_SESSION['admin_username'] = $username;
            header("Location: index.php");
            exit;
        } else {
            $error = 'Kredensial tidak valid! Silakan periksa kembali username dan password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Authentication | Ibnu Andriano Portfolio</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: #080A0F;
      color: #E2E8F0;
      font-family: 'Plus Jakarta Sans', sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      background-image: 
        radial-gradient(circle at 10% 20%, rgba(56, 189, 248, 0.04) 0%, transparent 40%),
        radial-gradient(circle at 90% 80%, rgba(52, 211, 153, 0.04) 0%, transparent 40%),
        linear-gradient(rgba(255,255,255,0.015) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.015) 1px, transparent 1px);
      background-size: 100% 100%, 100% 100%, 48px 48px, 48px 48px;
    }
    .login-box {
      width: 100%;
      max-width: 440px;
      background: #0E121A;
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      padding: 36px;
      box-shadow: 0 25px 60px rgba(0, 0, 0, 0.7);
      position: relative;
    }
    .login-box::before {
      content: '';
      position: absolute;
      top: 0; left: 10%; right: 10%; height: 2px;
      background: linear-gradient(90deg, transparent, #38BDF8, transparent);
    }
    .hud-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(56, 189, 248, 0.08);
      border: 1px solid rgba(56, 189, 248, 0.25);
      color: #38BDF8;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      padding: 3px 10px;
      border-radius: 999px;
      margin-bottom: 20px;
    }
    .title {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 24px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 6px;
    }
    .subtitle {
      font-size: 14px;
      color: #94A3B8;
      margin-bottom: 26px;
      line-height: 1.5;
    }
    .form-group {
      margin-bottom: 20px;
    }
    .form-label {
      display: block;
      font-family: 'JetBrains Mono', monospace;
      font-size: 12.5px;
      color: #94A3B8;
      margin-bottom: 8px;
    }
    .form-input-wrapper {
      position: relative;
    }
    .form-input-wrapper i {
      position: absolute;
      left: 14px;
      top: 50%;
      transform: translateY(-50%);
      color: #64748B;
      font-size: 14px;
    }
    .form-input {
      width: 100%;
      padding: 12px 14px 12px 42px;
      background: rgba(0, 0, 0, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      color: #fff;
      font-size: 14px;
      outline: none;
      transition: all 0.2s ease;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .form-input:focus {
      border-color: #38BDF8;
      box-shadow: 0 0 14px rgba(56, 189, 248, 0.25);
    }
    .btn-login {
      width: 100%;
      padding: 13px;
      border-radius: 8px;
      border: none;
      background: linear-gradient(135deg, #38BDF8 0%, #0284C7 100%);
      color: #050B14;
      font-weight: 700;
      font-size: 14.5px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.2s ease;
      margin-top: 10px;
    }
    .btn-login:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(56, 189, 248, 0.4);
    }
    .error-msg {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #F87171;
      padding: 12px;
      border-radius: 8px;
      font-size: 13px;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 22px;
      color: #64748B;
      font-size: 13px;
      text-decoration: none;
      transition: color 0.2s;
    }
    .back-link:hover { color: #38BDF8; }
    .hint-box {
      margin-top: 20px;
      padding: 10px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px dashed rgba(255, 255, 255, 0.08);
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: #64748B;
      text-align: center;
    }
  </style>
</head>
<body>

  <div class="login-box">
    <div class="hud-badge">
      <i class="fa-solid fa-shield-halved"></i> ACCESS CONTROL // AUTH
    </div>

    <h2 class="title">Admin Central</h2>
    <p class="subtitle">Masuk untuk mengelola seluruh konten portofolio, proyek, data akademik, dan hobi motoran.</p>

    <?php if (!empty($error)): ?>
      <div class="error-msg">
        <i class="fa-solid fa-circle-exclamation"></i>
        <span><?= htmlspecialchars($error); ?></span>
      </div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="form-group">
        <label class="form-label" for="username">USERNAME</label>
        <div class="form-input-wrapper">
          <i class="fa-solid fa-user"></i>
          <input type="text" id="username" name="username" class="form-input" placeholder="Masukkan username..." required autofocus>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="password">PASSWORD</label>
        <div class="form-input-wrapper">
          <i class="fa-solid fa-lock"></i>
          <input type="password" id="password" name="password" class="form-input" placeholder="Masukkan password..." required>
        </div>
      </div>

      <button type="submit" class="btn-login">
        <i class="fa-solid fa-arrow-right-to-bracket"></i> Masuk ke Dashboard
      </button>

      <a href="../index.php" class="back-link">
        <i class="fa-solid fa-arrow-left"></i> Kembali ke Tampilan Publik Portofolio
      </a>
    </form>
  </div>

</body>
</html>
