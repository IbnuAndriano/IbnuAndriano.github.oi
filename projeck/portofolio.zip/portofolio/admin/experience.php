<?php
$page_title = 'Kelola Pengalaman Kerja, Magang & Organisasi';
require_once __DIR__ . '/header.php';

$msg = '';
$edit_exp = null;

// Toggle Visibilitas Per Item Pengalaman
if (isset($_GET['toggle_vis'])) {
    $tid = (int)$_GET['toggle_vis'];
    hybrid_toggle_visible($koneksi, 'experiences', $tid);
    $msg = "Status tampil item pengalaman berhasil diubah!";
}

// Hapus Pengalaman
if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    hybrid_delete($koneksi, 'experiences', $del_id);
    $msg = "Data pengalaman berhasil dihapus!";
}

// Mode Edit
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_exp = hybrid_get_by_id($koneksi, 'experiences', $edit_id);
}

// Simpan Tambah / Edit
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $posisi = trim($_POST['posisi'] ?? '');
    $instansi = trim($_POST['instansi'] ?? '');
    $jenis = trim($_POST['jenis'] ?? 'Magang / Internship');
    $lokasi = trim($_POST['lokasi'] ?? '');
    $periode = trim($_POST['periode'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $pencapaian = trim($_POST['pencapaian'] ?? '');
    $urutan = (int)($_POST['urutan'] ?? 1);
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;

    $payload = [
        'posisi'     => $posisi,
        'instansi'   => $instansi,
        'jenis'      => $jenis,
        'lokasi'     => $lokasi,
        'periode'    => $periode,
        'deskripsi'  => $deskripsi,
        'pencapaian' => $pencapaian,
        'urutan'     => $urutan,
        'is_visible' => $is_visible
    ];

    if ($id > 0) {
        hybrid_update($koneksi, 'experiences', $id, $payload);
        $msg = "Data pengalaman '$posisi' berhasil diperbarui!";
        $edit_exp = null;
    } else {
        hybrid_insert($koneksi, 'experiences', $payload);
        $msg = "Pengalaman baru '$posisi' berhasil ditambahkan!";
    }
}

$experiences = get_experiences($koneksi, false);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<div class="dash-card">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-briefcase" style="color: var(--cyan);"></i>
      <?= $edit_exp ? 'Edit Pengalaman: ' . htmlspecialchars($edit_exp['posisi']) : 'Tambah Pengalaman Kerja / Magang / Proyek / Organisasi'; ?>
    </h3>
    <?php if ($edit_exp): ?>
      <a href="experience.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="experience.php">
    <?php if ($edit_exp): ?>
      <input type="hidden" name="id" value="<?= $edit_exp['id']; ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Posisi / Jabatan / Peran</label>
        <input type="text" name="posisi" class="form-control" placeholder="Contoh: Web Developer Intern, Full-Stack Developer..." value="<?= htmlspecialchars($edit_exp['posisi'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Nama Perusahaan / Instansi / Organisasi</label>
        <input type="text" name="instansi" class="form-control" placeholder="Contoh: PT Teknologi Indonesia, Dinas Sosial..." value="<?= htmlspecialchars($edit_exp['instansi'] ?? ''); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Kategori Pengalaman</label>
        <select name="jenis" class="form-control" required>
          <?php
            $jenis_opts = ['Magang / Internship', 'Full-Time / Kontrak', 'Project-Based / Implementasi', 'Freelance / Konsultan', 'Rekayasa Sistem Informasi', 'Organisasi & Kepemimpinan', 'Akademik & Riset Teknis'];
            $curr_jenis = $edit_exp['jenis'] ?? 'Magang / Internship';
            foreach ($jenis_opts as $jo):
          ?>
            <option value="<?= htmlspecialchars($jo); ?>" <?= ($curr_jenis === $jo) ? 'selected' : ''; ?>><?= htmlspecialchars($jo); ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Periode Waktu</label>
        <input type="text" name="periode" class="form-control" placeholder="Contoh: Jan 2025 - Sekarang" value="<?= htmlspecialchars($edit_exp['periode'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Lokasi</label>
        <input type="text" name="lokasi" class="form-control" placeholder="Contoh: Tangerang, Banten / Hybrid" value="<?= htmlspecialchars($edit_exp['lokasi'] ?? 'Tangerang, Banten'); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Urutan Tampil</label>
        <input type="number" name="urutan" class="form-control" value="<?= htmlspecialchars($edit_exp['urutan'] ?? 1); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Deskripsi Tanggung Jawab Utama</label>
      <textarea name="deskripsi" class="form-control" rows="2" placeholder="Ringkasan peran dan tanggung jawab Anda..." required><?= htmlspecialchars($edit_exp['deskripsi'] ?? ''); ?></textarea>
    </div>

    <div class="form-group">
      <label class="form-label">Poin Pencapaian / Kontribusi Nyata (Satu per baris, otomatis tampil di Web & CV ATS)</label>
      <textarea name="pencapaian" class="form-control" rows="3" placeholder="Membangun modul autentikasi dan dashboard laporan&#10;Meningkatkan efisiensi pencatatan transaksi sebesar 40%"><?= htmlspecialchars($edit_exp['pencapaian'] ?? ''); ?></textarea>
    </div>

    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
      <input type="checkbox" id="is_visible" name="is_visible" value="1" <?= (!isset($edit_exp['is_visible']) || !empty($edit_exp['is_visible'])) ? 'checked' : ''; ?> style="width: 18px; height: 18px;">
      <label for="is_visible" style="color: #fff; cursor: pointer;">Tampilkan pengalaman ini di Halaman Publik & Resume ATS</label>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> <?= $edit_exp ? 'Simpan Perubahan' : 'Tambahkan Pengalaman'; ?>
    </button>
  </form>
</div>

<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-list-check" style="color: var(--emerald);"></i> Daftar Pengalaman & Rekam Jejak</h3>
    <span class="mono" style="font-size: 12px; color: var(--admin-dim);">Total: <?= count($experiences); ?> Item</span>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Periode</th>
          <th>Posisi & Instansi</th>
          <th>Kategori</th>
          <th>Visibilitas Publik</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($experiences as $ex): 
          $vis = !isset($ex['is_visible']) || !empty($ex['is_visible']);
        ?>
          <tr style="<?= !$vis ? 'opacity: 0.55;' : ''; ?>">
            <td class="mono" style="font-size: 12px; color: var(--cyan);"><?= htmlspecialchars($ex['periode']); ?></td>
            <td>
              <strong style="color: #fff;"><?= htmlspecialchars($ex['posisi']); ?></strong>
              <div style="font-size: 12.5px; color: var(--admin-muted);"><?= htmlspecialchars($ex['instansi']); ?> • <?= htmlspecialchars($ex['lokasi']); ?></div>
            </td>
            <td><span class="mono" style="font-size: 11.5px;"><?= htmlspecialchars($ex['jenis']); ?></span></td>
            <td>
              <?php if (isset($ex['id'])): ?>
                <a href="experience.php?toggle_vis=<?= $ex['id']; ?>" class="btn <?= $vis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm" title="Klik untuk Tampilkan/Sembunyikan">
                  <i class="fa-solid <?= $vis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                  <?= $vis ? 'Tampil' : 'Disembunyikan'; ?>
                </a>
              <?php endif; ?>
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <?php if (isset($ex['id'])): ?>
                  <a href="experience.php?edit=<?= $ex['id']; ?>" class="btn btn-secondary btn-sm" title="Edit"><i class="fa-solid fa-pen-to-square"></i></a>
                  <a href="experience.php?del=<?= $ex['id']; ?>" onclick="return confirm('Hapus data pengalaman ini?');" class="btn btn-danger btn-sm" title="Hapus"><i class="fa-solid fa-trash"></i></a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
