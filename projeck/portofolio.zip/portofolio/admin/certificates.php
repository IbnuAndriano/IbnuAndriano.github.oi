<?php
$page_title = 'Kelola Sertifikasi & Lisensi';
require_once __DIR__ . '/header.php';

$msg = '';
$edit_cert = null;

if (isset($_GET['toggle_vis'])) {
    $tid = (int)$_GET['toggle_vis'];
    hybrid_toggle_visible($koneksi, 'certificates', $tid);
    $msg = "Status visibilitas sertifikat berhasil diperbarui!";
}

if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    hybrid_delete($koneksi, 'certificates', $del_id);
    $msg = "Sertifikat berhasil dihapus!";
}

if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_cert = hybrid_get_by_id($koneksi, 'certificates', $edit_id);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $judul = trim($_POST['judul'] ?? '');
    $penerbit = trim($_POST['penerbit'] ?? '');
    $tahun = trim($_POST['tahun'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $link = trim($_POST['link'] ?? '#');
    $icon = trim($_POST['icon'] ?? 'fa-solid fa-award');
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;

    $payload = [
        'judul'           => $judul,
        'penerbit'        => $penerbit,
        'tahun'           => $tahun,
        'deskripsi'       => $deskripsi,
        'link_kredensial' => $link,
        'icon'            => $icon,
        'is_visible'      => $is_visible
    ];

    if ($id > 0) {
        hybrid_update($koneksi, 'certificates', $id, $payload);
        $msg = "Sertifikat '$judul' berhasil diperbarui!";
        $edit_cert = null;
    } else {
        hybrid_insert($koneksi, 'certificates', $payload);
        $msg = "Sertifikat baru '$judul' berhasil ditambahkan!";
    }
}

$certs = get_certificates($koneksi, false);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<div class="dash-card">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-award" style="color: var(--amber);"></i>
      <?= $edit_cert ? 'Edit Sertifikat: ' . htmlspecialchars($edit_cert['judul']) : 'Tambah Sertifikat / Lisensi Baru'; ?>
    </h3>
    <?php if ($edit_cert): ?>
      <a href="certificates.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="certificates.php">
    <?php if ($edit_cert): ?>
      <input type="hidden" name="id" value="<?= $edit_cert['id']; ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nama Sertifikasi / Pelatihan</label>
        <input type="text" name="judul" class="form-control" placeholder="Contoh: Junior Web Developer & PHP Back-End..." value="<?= htmlspecialchars($edit_cert['judul'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Lembaga Penerbit</label>
        <input type="text" name="penerbit" class="form-control" placeholder="Contoh: BNSP / Dicoding / IT Academy..." value="<?= htmlspecialchars($edit_cert['penerbit'] ?? ''); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Tahun Penerbitan</label>
        <input type="text" name="tahun" class="form-control" value="<?= htmlspecialchars($edit_cert['tahun'] ?? date('Y')); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">FontAwesome Icon</label>
        <input type="text" name="icon" class="form-control" value="<?= htmlspecialchars($edit_cert['icon'] ?? 'fa-solid fa-award'); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Link Kredensial / Bukti Online (Opsional)</label>
        <input type="text" name="link" class="form-control" value="<?= htmlspecialchars($edit_cert['link_kredensial'] ?? '#'); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Deskripsi Kompetensi</label>
      <textarea name="deskripsi" class="form-control" rows="2" required><?= htmlspecialchars($edit_cert['deskripsi'] ?? ''); ?></textarea>
    </div>

    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
      <input type="checkbox" id="is_visible" name="is_visible" value="1" <?= (!isset($edit_cert['is_visible']) || !empty($edit_cert['is_visible'])) ? 'checked' : ''; ?> style="width: 18px; height: 18px;">
      <label for="is_visible" style="color: #fff; cursor: pointer;">Tampilkan sertifikat ini di Halaman Publik & Resume ATS</label>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> <?= $edit_cert ? 'Simpan Perubahan' : 'Tambah Sertifikat'; ?>
    </button>
  </form>
</div>

<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-medal" style="color: var(--cyan);"></i> Daftar Sertifikat & Lisensi</h3>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Icon</th>
          <th>Judul Sertifikat</th>
          <th>Penerbit</th>
          <th>Tahun</th>
          <th>Visibilitas Publik</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($certs as $c): 
          $vis = !isset($c['is_visible']) || !empty($c['is_visible']);
        ?>
          <tr style="<?= !$vis ? 'opacity: 0.55;' : ''; ?>">
            <td><i class="<?= htmlspecialchars($c['icon'] ?? 'fa-solid fa-award'); ?>" style="font-size: 20px; color: var(--amber);"></i></td>
            <td>
              <strong style="color: #fff;"><?= htmlspecialchars($c['judul']); ?></strong>
              <div style="font-size: 12px; color: var(--admin-dim);"><?= htmlspecialchars($c['deskripsi']); ?></div>
            </td>
            <td><span class="mono" style="font-size: 12px; color: var(--cyan);"><?= htmlspecialchars($c['penerbit']); ?></span></td>
            <td><?= htmlspecialchars($c['tahun']); ?></td>
            <td>
              <?php if (isset($c['id'])): ?>
                <a href="certificates.php?toggle_vis=<?= $c['id']; ?>" class="btn <?= $vis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm">
                  <i class="fa-solid <?= $vis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                  <?= $vis ? 'Tampil' : 'Disembunyikan'; ?>
                </a>
              <?php endif; ?>
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <?php if (isset($c['id'])): ?>
                  <a href="certificates.php?edit=<?= $c['id']; ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                  <a href="certificates.php?del=<?= $c['id']; ?>" onclick="return confirm('Hapus sertifikat ini?');" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
