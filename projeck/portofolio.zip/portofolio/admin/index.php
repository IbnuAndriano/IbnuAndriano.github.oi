<?php
$page_title = 'Workspace & Control Center';
require_once __DIR__ . '/header.php';

$s = get_settings($koneksi);
$all_projects = get_projects($koneksi, false);
$all_exp = get_experiences($koneksi, false);
$all_skills = get_skills($koneksi, false);
$all_messages = get_messages($koneksi);

$count_projects = count($all_projects);
$count_exp = count($all_exp);
$count_skills = count($all_skills);
$count_messages = count($all_messages);
$count_unread = 0;
foreach ($all_messages as $m) {
    if (empty($m['status_baca'])) $count_unread++;
}

$vis_summary = [
    'Foto Profil'          => !empty($s['show_photo']),
    'Badge Status Open'    => !empty($s['show_availability']),
    'Section Profil'       => !empty($s['show_about']),
    'Detail NIM & IPK'     => !empty($s['show_academic_detail']),
    'Fokus Kompetensi'     => !empty($s['show_services']),
    'Pengalaman & Kerja'   => !empty($s['show_experience']),
    'Projek & Karya'       => !empty($s['show_projects']),
    'Tech Stack & Skill'   => !empty($s['show_skills']),
    'Riwayat Pendidikan'   => !empty($s['show_education']),
    'Sertifikat'           => !empty($s['show_certificates']),
    'Resume CV ATS'        => !empty($s['show_cv']),
    'Kontak & Form Pesan'  => !empty($s['show_contact']),
    'Cerita Motoran'       => !empty($s['show_motor']),
    'Galeri Foto'          => !empty($s['show_gallery'])
];
$avatar_preview = resolve_media_url($s['avatar_url'], true);
?>

<!-- Welcome Profile Banner -->
<div class="dash-card" style="padding: 22px 26px; display: flex; align-items: center; justify-content: space-between; gap: 20px; flex-wrap: wrap; background: linear-gradient(135deg, rgba(19, 25, 38, 0.95), rgba(14, 18, 27, 0.95)); border-color: rgba(56, 189, 248, 0.22);">
  <div style="display: flex; align-items: center; gap: 18px;">
    <img src="<?= htmlspecialchars($avatar_preview); ?>" alt="<?= htmlspecialchars($s['nama']); ?>" style="width: 64px; height: 64px; border-radius: 16px; object-fit: cover; border: 2px solid var(--cyan);">
    <div>
      <span class="mono" style="font-size: 11.5px; color: var(--cyan); font-weight: 600;">WELCOME BACK // OWNER WORKSPACE</span>
      <h3 style="font-size: 20px; color: #fff; margin: 2px 0 4px;"><?= htmlspecialchars($s['nama']); ?></h3>
      <p style="font-size: 13px; color: var(--admin-muted); margin: 0;">
        <?= htmlspecialchars($s['prodi']); ?> — <?= htmlspecialchars($s['kampus']); ?> • <span style="color: var(--emerald);"><?= htmlspecialchars($s['availability_text']); ?></span>
      </p>
    </div>
  </div>
  <div style="display: flex; gap: 10px; flex-wrap: wrap;">
    <a href="profil.php" class="btn btn-primary">
      <i class="fa-solid fa-user-pen"></i> Edit Profil & CV
    </a>
    <a href="visibilitas.php" class="btn btn-secondary">
      <i class="fa-solid fa-sliders"></i> Atur Visibilitas
    </a>
    <a href="../index.php" target="_blank" class="btn btn-secondary">
      <i class="fa-solid fa-arrow-up-right-from-square"></i> Buka Website
    </a>
  </div>
</div>

<!-- Metrics Strip -->
<div class="stats-grid">
  <div class="stat-box">
    <div class="stat-icon"><i class="fa-solid fa-layer-group"></i></div>
    <div class="stat-data">
      <span>Projek Terdaftar</span>
      <h4><?= $count_projects; ?></h4>
    </div>
  </div>

  <div class="stat-box">
    <div class="stat-icon green"><i class="fa-solid fa-briefcase"></i></div>
    <div class="stat-data">
      <span>Pengalaman & Kerja</span>
      <h4><?= $count_exp; ?></h4>
    </div>
  </div>

  <div class="stat-box">
    <div class="stat-icon amber"><i class="fa-solid fa-code"></i></div>
    <div class="stat-data">
      <span>Tech Stack & Skill</span>
      <h4><?= $count_skills; ?></h4>
    </div>
  </div>

  <div class="stat-box">
    <div class="stat-icon rose"><i class="fa-solid fa-envelope"></i></div>
    <div class="stat-data">
      <span>Inbox Pesan</span>
      <h4><?= $count_messages; ?> <?= $count_unread > 0 ? '<small style="font-size:12px;color:var(--rose);">(' . $count_unread . ' baru)</small>' : ''; ?></h4>
    </div>
  </div>
</div>

<div class="form-row">
  <!-- Quick Actions Bento -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-bolt" style="color: var(--amber);"></i> Pintasan Kelola Konten</h3>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
      <a href="profil.php" class="btn btn-secondary" style="padding: 14px 16px; justify-content: flex-start;">
        <i class="fa-solid fa-id-card" style="color: var(--cyan);"></i> Edit Bio, Kampus & CV
      </a>
      <a href="galeri.php" class="btn btn-secondary" style="padding: 14px 16px; justify-content: flex-start;">
        <i class="fa-solid fa-camera" style="color: var(--emerald);"></i> Upload Foto & File Publik
      </a>
      <a href="projects.php" class="btn btn-secondary" style="padding: 14px 16px; justify-content: flex-start;">
        <i class="fa-solid fa-folder-plus" style="color: var(--cyan);"></i> Kelola Projek & Link Live
      </a>
      <a href="experience.php" class="btn btn-secondary" style="padding: 14px 16px; justify-content: flex-start;">
        <i class="fa-solid fa-briefcase" style="color: var(--amber);"></i> Kelola Pengalaman Kerja
      </a>
      <a href="skills.php" class="btn btn-secondary" style="padding: 14px 16px; justify-content: flex-start;">
        <i class="fa-solid fa-laptop-code" style="color: var(--emerald);"></i> Update Skill & Tech Stack
      </a>
      <a href="motor.php" class="btn btn-secondary" style="padding: 14px 16px; justify-content: flex-start;">
        <i class="fa-solid fa-motorcycle" style="color: var(--rose);"></i> Update Rute & Beat Deluxe
      </a>
    </div>

    <div style="display: flex; gap: 10px; flex-wrap: wrap; padding-top: 12px; border-top: 1px solid var(--admin-border);">
      <a href="../sdgs-demo.php" target="_blank" class="btn btn-secondary btn-sm" style="flex: 1;">
        <i class="fa-solid fa-chart-pie" style="color: var(--rose);"></i> Buka Demo SDGs Kab. Tangerang 2026
      </a>
      <a href="http://localhost/cakjoyo" target="_blank" class="btn btn-secondary btn-sm" style="flex: 1;">
        <i class="fa-solid fa-bowl-food" style="color: var(--amber);"></i> Buka Web Soto Cak Joyo
      </a>
    </div>
  </div>

  <!-- Live Visibility Status -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-eye" style="color: var(--cyan);"></i> Status Tampilan Publik</h3>
      <a href="visibilitas.php" class="btn btn-primary btn-sm"><i class="fa-solid fa-sliders"></i> Ubah</a>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(185px, 1fr)); gap: 9px;">
      <?php foreach ($vis_summary as $label => $is_on): ?>
        <div style="padding: 9px 12px; border-radius: 10px; background: rgba(255,255,255,0.02); border: 1px solid <?= $is_on ? 'rgba(52,211,153,0.22)' : 'rgba(244,63,94,0.22)'; ?>; display: flex; align-items: center; justify-content: space-between; font-size: 12.5px;">
          <span style="color: #E2E8F0;"><?= htmlspecialchars($label); ?></span>
          <?php if ($is_on): ?>
            <span style="color: var(--emerald); font-family: var(--font-mono); font-size: 10.5px; font-weight: 700;">ON</span>
          <?php else: ?>
            <span style="color: var(--rose); font-family: var(--font-mono); font-size: 10.5px; font-weight: 700;">OFF</span>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
