<?php
$page_title = 'Keamanan & Kredensial Akun Admin';
require_once __DIR__ . '/header.php';

$msg = '';
$err = '';

// Ambil data admin saat ini (Hybrid MySQL + Local JSON)
$admin_data = get_admin_account($koneksi);

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['update_account'])) {
    $new_username = trim($_POST['username'] ?? '');
    $nama_lengkap = trim($_POST['nama_lengkap'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $new_pass = $_POST['new_password'] ?? '';
    $conf_pass = $_POST['confirm_password'] ?? '';

    if (empty($new_username) || empty($nama_lengkap)) {
        $err = 'Username dan Nama Lengkap tidak boleh kosong!';
    } elseif (!empty($new_pass) && $new_pass !== $conf_pass) {
        $err = 'Konfirmasi password baru tidak cocok!';
    } elseif (!empty($new_pass) && strlen($new_pass) < 6) {
        $err = 'Password baru minimal harus 6 karakter!';
    } else {
        $payload = [
            'username'     => $new_username,
            'nama_lengkap' => $nama_lengkap,
            'email'        => $email
        ];
        if (!empty($new_pass)) {
            $payload['password'] = password_hash($new_pass, PASSWORD_BCRYPT);
            $msg = 'Username, profil admin, dan password berhasil diperbarui!';
        } else {
            $msg = 'Informasi akun admin berhasil diperbarui!';
        }
        save_admin_account($koneksi, $payload);

        $_SESSION['admin_username'] = $new_username;
        $_SESSION['admin_name'] = $nama_lengkap;
        $admin_data['username'] = $new_username;
        $admin_data['nama_lengkap'] = $nama_lengkap;
        $admin_data['email'] = $email;
    }
}
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<?php if (!empty($err)): ?>
  <div class="alert-success" style="background: rgba(244,63,94,0.12); border-color: rgba(244,63,94,0.3); color: var(--rose);">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($err); ?>
  </div>
<?php endif; ?>

<div class="form-row">
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-user-shield" style="color: var(--cyan);"></i> Pengaturan Login & Password Admin</h3>
    </div>

    <form method="POST" action="akun.php">
      <input type="hidden" name="update_account" value="1">

      <div class="form-group">
        <label class="form-label">Username Login Admin</label>
        <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($admin_data['username']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Nama Lengkap Admin</label>
        <input type="text" name="nama_lengkap" class="form-control" value="<?= htmlspecialchars($admin_data['nama_lengkap']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Email Admin</label>
        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($admin_data['email']); ?>" required>
      </div>

      <div style="margin: 20px 0; padding-top: 16px; border-top: 1px solid var(--admin-border);">
        <h4 style="font-size: 14px; color: var(--amber); margin-bottom: 12px;">Ganti Password (Kosongkan jika tidak ingin mengubah password)</h4>
        <div class="form-group">
          <label class="form-label">Password Baru</label>
          <input type="password" name="new_password" class="form-control" placeholder="Masukkan password baru...">
        </div>
        <div class="form-group">
          <label class="form-label">Ulangi Password Baru</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="Konfirmasi password baru...">
        </div>
      </div>

      <button type="submit" class="btn btn-primary">
        <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan Akun
      </button>
    </form>
  </div>

  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-shield-halved" style="color: var(--emerald);"></i> Status Proteksi & Hak Akses</h3>
      <span class="status-badge">SECURED</span>
    </div>

    <div style="display: flex; flex-direction: column; gap: 14px; font-size: 13.5px; color: var(--admin-muted);">
      <div style="background: rgba(16,185,129,0.06); border: 1px solid rgba(16,185,129,0.25); padding: 14px; border-radius: 8px;">
        <strong style="color: var(--emerald); display: block; margin-bottom: 4px;">
          <i class="fa-solid fa-check-circle"></i> Proteksi Penggantian Foto & Media
        </strong>
        Pengunjung publik tidak memiliki tombol, formulir, maupun script untuk mengganti foto profil, foto proyek, atau galeri. Fungsi upload di sisi server memvalidasi sesi login Admin secara ketat.
      </div>

      <div style="background: rgba(56,189,248,0.06); border: 1px solid rgba(56,189,248,0.25); padding: 14px; border-radius: 8px;">
        <strong style="color: var(--cyan); display: block; margin-bottom: 4px;">
          <i class="fa-solid fa-check-circle"></i> Proteksi Direktori Uploads (.htaccess)
        </strong>
        Folder <code>uploads/</code> dilindungi dari eksekusi script berbahaya dan hanya mengizinkan file gambar serta dokumen PDF resmi yang tervalidasi MIME-type.
      </div>

      <div style="background: rgba(245,158,11,0.06); border: 1px solid rgba(245,158,11,0.25); padding: 14px; border-radius: 8px;">
        <strong style="color: var(--amber); display: block; margin-bottom: 4px;">
          <i class="fa-solid fa-check-circle"></i> Kendali Visibilitas Penuh
        </strong>
        Seluruh section maupun item individual (Proyek, Pengalaman, Skill, Pendidikan, Sertifikat, Foto) dapat disembunyikan dari publik kapan saja tanpa menghapus data dari database.
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
