<?php
$page_title = 'Kelola Portofolio Proyek & Studi Kasus';
require_once __DIR__ . '/header.php';

$msg = '';
$err = '';
$edit_data = null;

// Toggle Visibilitas Proyek Individual
if (isset($_GET['toggle_vis'])) {
    $tid = (int)$_GET['toggle_vis'];
    hybrid_toggle_visible($koneksi, 'projects', $tid);
    $msg = "Status visibilitas proyek berhasil diperbarui!";
}

// Handle Delete
if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    hybrid_delete($koneksi, 'projects', $del_id);
    $msg = "Proyek ID #$del_id berhasil dihapus!";
}

// Handle Edit Mode
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_data = hybrid_get_by_id($koneksi, 'projects', $edit_id);
}

// Handle Form Submit (Add or Update)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $judul = trim($_POST['judul'] ?? '');
    $semester = trim($_POST['semester'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $fitur_list = trim($_POST['fitur_list'] ?? '');
    $tech_stack = trim($_POST['tech_stack'] ?? '');
    $link_demo = trim($_POST['link_demo'] ?? '');
    $link_hosting = trim($_POST['link_hosting'] ?? '');
    $link_repo = trim($_POST['link_repo'] ?? '');
    $gambar = trim($_POST['existing_gambar'] ?? 'default_project.jpg');
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;
    $urutan = (int)($_POST['urutan'] ?? 1);

    // Upload Gambar Screenshot Proyek (Opsional)
    if (!empty($_FILES['project_img']['name'])) {
        $uploaded = upload_image_file($_FILES['project_img'], 'proj');
        if ($uploaded) {
            $gambar = $uploaded;
        } else {
            $err = 'Gagal mengunggah gambar proyek! Pastikan format JPG/PNG/WEBP < 5MB.';
        }
    } elseif (!empty($_POST['gambar_url'])) {
        $gambar = trim($_POST['gambar_url']);
    }

    if (empty($err)) {
        $payload = [
            'judul'             => $judul,
            'semester'          => $semester,
            'kategori'          => $kategori,
            'deskripsi_singkat' => $deskripsi,
            'fitur_list'        => $fitur_list,
            'tech_stack'        => $tech_stack,
            'link_demo'         => $link_demo,
            'link_hosting'      => $link_hosting,
            'link_repo'         => $link_repo,
            'gambar'            => $gambar,
            'is_featured'       => $is_featured,
            'urutan'            => $urutan,
            'is_visible'        => $is_visible
        ];
        if ($id > 0) {
            hybrid_update($koneksi, 'projects', $id, $payload);
            $msg = "Proyek '$judul' berhasil diperbarui!";
            $edit_data = null;
        } else {
            hybrid_insert($koneksi, 'projects', $payload);
            $msg = "Proyek baru '$judul' berhasil ditambahkan!";
        }
    }
}

$projects = get_projects($koneksi, false);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<?php if (!empty($err)): ?>
  <div class="alert-success" style="background: rgba(244,63,94,0.12); border-color: rgba(244,63,94,0.3); color: var(--rose);">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($err); ?>
  </div>
<?php endif; ?>

<div class="dash-card">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-folder-plus" style="color: var(--cyan);"></i>
      <?= $edit_data ? 'Edit Proyek: ' . htmlspecialchars($edit_data['judul']) : 'Tambah Proyek / Studi Kasus Baru'; ?>
    </h3>
    <?php if ($edit_data): ?>
      <a href="projects.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="projects.php" enctype="multipart/form-data">
    <?php if ($edit_data): ?>
      <input type="hidden" name="id" value="<?= $edit_data['id']; ?>">
      <input type="hidden" name="existing_gambar" value="<?= htmlspecialchars($edit_data['gambar'] ?? 'default_project.jpg'); ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Judul Proyek / Sistem</label>
        <input type="text" name="judul" class="form-control" placeholder="Contoh: Sistem Informasi Terpadu SDGs..." value="<?= htmlspecialchars($edit_data['judul'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Konteks / Label Kontribusi</label>
        <input type="text" name="semester" class="form-control" placeholder="Contoh: Studi Kasus Pemerintahan / Implementasi UMKM / Proyek Magang" value="<?= htmlspecialchars($edit_data['semester'] ?? ''); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Kategori Proyek</label>
        <input type="text" name="kategori" class="form-control" placeholder="Contoh: E-Commerce & POS, Enterprise System..." value="<?= htmlspecialchars($edit_data['kategori'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Tech Stack (Pisahkan dengan koma)</label>
        <input type="text" name="tech_stack" class="form-control" placeholder="PHP Native, MySQL, JavaScript, Bootstrap..." value="<?= htmlspecialchars($edit_data['tech_stack'] ?? ''); ?>" required>
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Deskripsi Studi Kasus & Solusi Sistem</label>
      <textarea name="deskripsi" class="form-control" rows="3" required><?= htmlspecialchars($edit_data['deskripsi_singkat'] ?? ''); ?></textarea>
    </div>

    <div class="form-group">
      <label class="form-label">Daftar Modul / Fitur Fungsional (Satu per baris)</label>
      <textarea name="fitur_list" class="form-control" rows="4" placeholder="1. Modul Pendataan & Validasi&#10;2. Dashboard Analitik Real-time"><?= htmlspecialchars($edit_data['fitur_list'] ?? ''); ?></textarea>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Unggah Screenshot / Gambar Proyek (Khusus Admin — Opsional)</label>
        <input type="file" name="project_img" class="form-control" accept="image/*">
      </div>

      <div class="form-group">
        <label class="form-label">Atau URL Gambar Screenshot</label>
        <input type="text" name="gambar_url" class="form-control" placeholder="Opsional: https://... atau uploads/..." value="<?= (isset($edit_data['gambar']) && $edit_data['gambar'] !== 'default_project.jpg') ? htmlspecialchars($edit_data['gambar']) : ''; ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">URL Website Resmi / Live Hosting (Opsional)</label>
        <input type="text" name="link_hosting" class="form-control" placeholder="https://..." value="<?= htmlspecialchars($edit_data['link_hosting'] ?? ''); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">URL Demo Aplikasi</label>
        <input type="text" name="link_demo" class="form-control" placeholder="sdgs-demo.php atau http://localhost/cakjoyo" value="<?= htmlspecialchars($edit_data['link_demo'] ?? ''); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">URL Repositori GitHub</label>
        <input type="text" name="link_repo" class="form-control" placeholder="https://github.com/..." value="<?= htmlspecialchars($edit_data['link_repo'] ?? '#'); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">Urutan Tampil</label>
        <input type="number" name="urutan" class="form-control" value="<?= htmlspecialchars($edit_data['urutan'] ?? 1); ?>">
      </div>
    </div>

    <div style="display: flex; flex-wrap: wrap; gap: 24px; margin-bottom: 20px;">
      <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; color: #fff;">
        <input type="checkbox" name="is_featured" value="1" <?= (!empty($edit_data['is_featured'])) ? 'checked' : ''; ?> style="width: 18px; height: 18px;">
        <span>Tampilkan sebagai <strong>Studi Kasus Unggulan (Featured Besar)</strong></span>
      </label>

      <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; color: var(--emerald);">
        <input type="checkbox" name="is_visible" value="1" <?= (!isset($edit_data['is_visible']) || !empty($edit_data['is_visible'])) ? 'checked' : ''; ?> style="width: 18px; height: 18px;">
        <span><strong>Tampilkan Proyek Ini ke Publik</strong> (Uncheck untuk menyembunyikan)</span>
      </label>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> <?= $edit_data ? 'Simpan Perubahan Proyek' : 'Tambahkan Proyek'; ?>
    </button>
  </form>
</div>

<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-list-check" style="color: var(--emerald);"></i> Daftar Seluruh Proyek</h3>
    <span class="mono" style="font-size: 12px; color: var(--admin-dim);">Total: <?= count($projects); ?> Proyek</span>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Konteks</th>
          <th>Judul Proyek</th>
          <th>Tech Stack</th>
          <th>Tipe</th>
          <th>Visibilitas Publik</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($projects as $p): 
          $vis = !isset($p['is_visible']) || !empty($p['is_visible']);
        ?>
          <tr style="<?= !$vis ? 'opacity: 0.55;' : ''; ?>">
            <td>
              <span class="mono" style="font-size: 11px; color: var(--cyan);">
                <?= htmlspecialchars($p['semester']); ?>
              </span>
            </td>
            <td>
              <strong style="color: #fff;"><?= htmlspecialchars($p['judul']); ?></strong>
              <div style="font-size: 12px; color: var(--admin-dim);"><?= htmlspecialchars($p['kategori']); ?></div>
            </td>
            <td><span class="mono" style="font-size: 11.5px; color: var(--admin-muted);"><?= htmlspecialchars($p['tech_stack']); ?></span></td>
            <td>
              <?php if (!empty($p['is_featured'])): ?>
                <span style="color: var(--amber); font-weight: 600; font-size: 12px;"><i class="fa-solid fa-star"></i> Featured</span>
              <?php else: ?>
                <span style="color: var(--admin-dim); font-size: 12px;">Standard</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="projects.php?toggle_vis=<?= $p['id']; ?>" class="btn <?= $vis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm" title="Klik untuk Sembunyikan/Tampilkan">
                <i class="fa-solid <?= $vis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                <?= $vis ? 'Tampil' : 'Disembunyikan'; ?>
              </a>
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <a href="projects.php?edit=<?= $p['id']; ?>" class="btn btn-secondary btn-sm" title="Edit"><i class="fa-solid fa-pen-to-square"></i></a>
                <a href="projects.php?del=<?= $p['id']; ?>" onclick="return confirm('Yakin ingin menghapus proyek ini?');" class="btn btn-danger btn-sm" title="Hapus"><i class="fa-solid fa-trash"></i></a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
