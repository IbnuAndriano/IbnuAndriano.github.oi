<?php
$page_title = 'Kelola Foto, Media & File (Tambah, Edit, Hapus — Admin Only)';
require_once __DIR__ . '/header.php';

$msg = '';
$err = '';
$edit_gal = null;
$edit_doc = null;

// Toggle Visibilitas Dokumen / File Publik
if (isset($_GET['toggle_doc_vis'])) {
    $tid = (int)$_GET['toggle_doc_vis'];
    hybrid_toggle_visible($koneksi, 'documents', $tid);
    $msg = "Status tampil file di website publik berhasil diperbarui!";
}

// Mode Edit Dokumen / File Publik
if (isset($_GET['edit_doc'])) {
    $did = (int)$_GET['edit_doc'];
    $edit_doc = hybrid_get_by_id($koneksi, 'documents', $did);
}

// Hapus Dokumen / File Publik dari Database & Server
if (isset($_GET['del_doc'])) {
    $did = (int)$_GET['del_doc'];
    $rd = hybrid_get_by_id($koneksi, 'documents', $did);
    if ($rd && !empty($rd['file_path'])) {
        $ft = __DIR__ . '/../' . $rd['file_path'];
        if (strpos($rd['file_path'], 'uploads/') === 0 && file_exists($ft)) {
            @unlink($ft);
        }
    }
    hybrid_delete($koneksi, 'documents', $did);
    $msg = "File berhasil dihapus dari database dan server!";
}

// Simpan Tambah / Edit Dokumen / File Publik ke Database
if (isset($_POST['save_document'])) {
    $doc_id = isset($_POST['doc_id']) ? (int)$_POST['doc_id'] : 0;
    $judul = trim($_POST['doc_judul'] ?? '');
    $kategori = trim($_POST['doc_kategori'] ?? 'Dokumen');
    $keterangan = trim($_POST['doc_keterangan'] ?? '');
    $is_visible = isset($_POST['doc_visible']) ? 1 : 0;

    $file_path = trim($_POST['existing_doc_path'] ?? '');
    $file_type = trim($_POST['existing_doc_type'] ?? 'FILE');
    $file_size = (int)($_POST['existing_doc_size'] ?? 0);

    if (!empty($_FILES['doc_file']['name'])) {
        $up = upload_any_file($_FILES['doc_file'], 'file');
        if ($up) {
            if (!empty($file_path) && strpos($file_path, 'uploads/') === 0) {
                $old_f = __DIR__ . '/../' . $file_path;
                if (file_exists($old_f)) @unlink($old_f);
            }
            $file_path = $up['path'];
            $file_type = $up['ext'];
            $file_size = $up['size'];
        } else {
            $err = "Gagal mengunggah file! Format diizinkan: PDF, DOC/DOCX, XLS/XLSX, PPT/PPTX, JPG, PNG, WEBP, ZIP (Maks 15MB).";
        }
    }

    if (empty($err) && !empty($judul) && !empty($file_path)) {
        $payload = [
            'judul'      => $judul,
            'kategori'   => $kategori,
            'keterangan' => $keterangan,
            'file_path'  => $file_path,
            'file_type'  => $file_type,
            'file_size'  => $file_size,
            'is_visible' => $is_visible
        ];
        if ($doc_id > 0) {
            hybrid_update($koneksi, 'documents', $doc_id, $payload);
            $msg = "File '$judul' berhasil diperbarui!";
            $edit_doc = null;
        } else {
            hybrid_insert($koneksi, 'documents', $payload);
            $msg = "File '$judul' berhasil diunggah dan langsung tampil di website publik!";
        }
    } elseif (empty($err)) {
        $err = "Mohon isi judul dokumen dan pilih file yang akan diunggah!";
    }
}

// Toggle Visibilitas Foto Galeri Individual
if (isset($_GET['toggle_vis'])) {
    $tid = (int)$_GET['toggle_vis'];
    hybrid_toggle_visible($koneksi, 'gallery', $tid);
    $msg = "Status tampil foto di galeri berhasil diperbarui!";
}

// Mode Edit Item Galeri
if (isset($_GET['edit_gallery'])) {
    $eid = (int)$_GET['edit_gallery'];
    $edit_gal = hybrid_get_by_id($koneksi, 'gallery', $eid);
}

// Hapus Foto Profil (Reset ke default)
if (isset($_GET['del_avatar'])) {
    $s_curr = get_settings($koneksi);
    if (!empty($s_curr['avatar_url']) && strpos($s_curr['avatar_url'], 'uploads/') === 0 && $s_curr['avatar_url'] !== 'uploads/foto_ibnu.jpg') {
        $f = __DIR__ . '/../' . $s_curr['avatar_url'];
        if (file_exists($f)) @unlink($f);
    }
    save_site_settings($koneksi, ['avatar_url' => 'images/default-avatar.svg']);
    $msg = "Foto profil berhasil dihapus!";
}

// Hapus Foto Kendaraan
if (isset($_GET['del_motor_img'])) {
    $s_curr = get_settings($koneksi);
    if (!empty($s_curr['motor_image_url']) && strpos($s_curr['motor_image_url'], 'uploads/') === 0) {
        $f = __DIR__ . '/../' . $s_curr['motor_image_url'];
        if (file_exists($f)) @unlink($f);
    }
    save_site_settings($koneksi, ['motor_image_url' => '']);
    $msg = "Foto kendaraan berhasil dihapus!";
}

// Hapus File Fisik Langsung di Folder uploads/
if (isset($_GET['del_file'])) {
    $fname = basename($_GET['del_file']);
    $fpath = __DIR__ . '/../uploads/' . $fname;
    if ($fname && $fname !== '.htaccess' && $fname !== 'local_db.json' && file_exists($fpath) && is_file($fpath)) {
        @unlink($fpath);
        $msg = "File '$fname' berhasil dihapus dari server!";
    }
}

// 1. Handle Foto Profil Update / Upload
if (isset($_POST['update_avatar'])) {
    $avatar_path = '';
    $show_photo = isset($_POST['show_photo']) ? 1 : 0;

    if (!empty($_FILES['avatar_file']['name'])) {
        $uploaded = upload_image_file($_FILES['avatar_file'], 'avatar');
        if ($uploaded) {
            $avatar_path = $uploaded;
        } else {
            $err = "Gagal mengunggah foto profil! Pastikan format JPG/PNG/WEBP dan ukuran < 5MB.";
        }
    } elseif (!empty($_POST['avatar_url'])) {
        $avatar_path = trim($_POST['avatar_url']);
    }

    if (empty($err) && !empty($avatar_path)) {
        save_site_settings($koneksi, [
            'avatar_url' => $avatar_path,
            'show_photo' => $show_photo
        ]);
        $msg = "Foto profil pribadi berhasil diperbarui dan disimpan!";
    } elseif (empty($err)) {
        $err = "Mohon pilih file foto dari komputer atau masukkan URL gambar terlebih dahulu!";
    }
}

// 2. Handle Foto Motor Update / Upload
if (isset($_POST['update_motor_img'])) {
    $motor_path = '';
    $show_motor_now = isset($_POST['show_motor_now']) ? 1 : 0;

    if (!empty($_FILES['motor_file']['name'])) {
        $uploaded = upload_image_file($_FILES['motor_file'], 'motor');
        if ($uploaded) {
            $motor_path = $uploaded;
        } else {
            $err = "Gagal mengunggah foto kendaraan! Pastikan format JPG/PNG/WEBP dan ukuran < 5MB.";
        }
    } elseif (!empty($_POST['motor_url'])) {
        $motor_path = trim($_POST['motor_url']);
    }

    if (empty($err) && !empty($motor_path)) {
        save_site_settings($koneksi, [
            'motor_image_url' => $motor_path,
            'show_motor'      => $show_motor_now
        ]);
        $msg = "Foto kendaraan berhasil diperbarui dan disimpan!";
    } elseif (empty($err)) {
        $err = "Mohon pilih file foto kendaraan atau masukkan URL gambar terlebih dahulu!";
    }
}

// 3. Handle Tambah / Edit Foto Galeri
if (isset($_POST['save_gallery'])) {
    $gid = isset($_POST['gal_id']) ? (int)$_POST['gal_id'] : 0;
    $judul = trim($_POST['judul'] ?? '');
    $kategori = trim($_POST['kategori'] ?? 'coding');
    $caption = trim($_POST['caption'] ?? '');
    $img_path = trim($_POST['existing_gambar_url'] ?? '');

    if (!empty($_FILES['gallery_file']['name'])) {
        $uploaded = upload_image_file($_FILES['gallery_file'], 'galeri');
        if ($uploaded) {
            if (!empty($img_path) && strpos($img_path, 'uploads/') === 0) {
                $old_f = __DIR__ . '/../' . $img_path;
                if (file_exists($old_f)) @unlink($old_f);
            }
            $img_path = $uploaded;
        } else {
            $err = "Gagal mengunggah foto galeri! Periksa format dan ukuran file.";
        }
    } elseif (!empty($_POST['gambar_url'])) {
        $img_path = trim($_POST['gambar_url']);
    }

    if (empty($err) && !empty($img_path) && !empty($judul)) {
        $payload = [
            'judul'      => $judul,
            'gambar_url' => $img_path,
            'kategori'   => $kategori,
            'caption'    => $caption,
            'is_visible' => 1
        ];
        if ($gid > 0) {
            hybrid_update($koneksi, 'gallery', $gid, $payload);
            $msg = "Foto galeri '$judul' berhasil diperbarui!";
            $edit_gal = null;
        } else {
            hybrid_insert($koneksi, 'gallery', $payload);
            $msg = "Foto galeri baru '$judul' berhasil ditambahkan!";
        }
    } elseif (empty($err)) {
        $err = "Mohon pilih file foto / masukkan URL gambar dan isi judul foto!";
    }
}

// 4. Handle Delete Foto Galeri
if (isset($_GET['del_gallery'])) {
    $del_id = (int)$_GET['del_gallery'];
    $r = hybrid_get_by_id($koneksi, 'gallery', $del_id);
    if ($r && !empty($r['gambar_url'])) {
        $file_target = __DIR__ . '/../' . $r['gambar_url'];
        if (strpos($r['gambar_url'], 'uploads/') === 0 && file_exists($file_target)) {
            @unlink($file_target);
        }
    }
    hybrid_delete($koneksi, 'gallery', $del_id);
    $msg = "Foto galeri berhasil dihapus!";
}

$s = get_settings($koneksi);
$gallery_items = get_gallery($koneksi, false);
$documents_list = get_documents($koneksi, false);
$avatar_preview = resolve_media_url($s['avatar_url'], true);
$motor_preview = !empty($s['motor_image_url']) ? resolve_media_url($s['motor_image_url'], true) : '';

// Scan semua file yang ada di folder uploads/
$uploaded_files = [];
$uploads_dir = __DIR__ . '/../uploads/';
if (is_dir($uploads_dir)) {
    foreach (scandir($uploads_dir) as $fn) {
        if ($fn !== '.' && $fn !== '..' && $fn !== '.htaccess' && is_file($uploads_dir . $fn)) {
            $uploaded_files[] = [
                'name' => $fn,
                'size' => filesize($uploads_dir . $fn),
                'mtime' => filemtime($uploads_dir . $fn),
                'ext' => strtolower(pathinfo($fn, PATHINFO_EXTENSION))
            ];
        }
    }
}
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<?php if (!empty($err)): ?>
  <div class="alert-success" style="background: rgba(244,63,94,0.15); border-color: rgba(244,63,94,0.3); color: #F87171;">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($err); ?>
  </div>
<?php endif; ?>

<div class="form-row">
  <!-- Card Foto Profil -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-user-shield" style="color: var(--cyan);"></i> Foto Profil Pribadi</h3>
      <span class="status-badge">ADMIN ONLY</span>
    </div>

    <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 20px;">
      <div style="width: 96px; height: 96px; border-radius: 50%; overflow: hidden; border: 2px solid var(--cyan); flex-shrink: 0; background: #0B0F17;">
        <img src="<?= htmlspecialchars($avatar_preview); ?>" alt="Avatar" style="width: 100%; height: 100%; object-fit: cover;">
      </div>
      <div>
        <h5 style="color: #fff; margin-bottom: 4px;"><?= htmlspecialchars($s['nama']); ?></h5>
        <span style="font-size: 12px; color: var(--admin-dim); display: block; margin-bottom: 8px;">
          Hanya Admin yang dapat menambah, mengganti, atau menghapus foto profil ini.
        </span>
        <?php if ($s['avatar_url'] !== 'images/default-avatar.svg'): ?>
          <a href="galeri.php?del_avatar=1" onclick="return confirm('Hapus foto profil ini?');" class="btn btn-danger btn-sm">
            <i class="fa-solid fa-trash"></i> Hapus Foto
          </a>
        <?php endif; ?>
      </div>
    </div>

    <form method="POST" action="galeri.php" enctype="multipart/form-data">
      <input type="hidden" name="update_avatar" value="1">
      <div class="form-group">
        <label class="form-label">Unggah / Ganti Foto Profil</label>
        <input type="file" name="avatar_file" class="form-control" accept="image/*">
      </div>

      <div class="form-group">
        <label class="form-label">Atau Path / URL Gambar</label>
        <input type="text" name="avatar_url" class="form-control" value="<?= htmlspecialchars($s['avatar_url']); ?>">
      </div>

      <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
        <input type="checkbox" id="show_photo_chk" name="show_photo" value="1" <?= !empty($s['show_photo']) ? 'checked' : ''; ?> style="width: 17px; height: 17px;">
        <label for="show_photo_chk" style="color: #fff; cursor: pointer; font-size: 13.5px;">Tampilkan Foto Profil di Website Publik</label>
      </div>

      <button type="submit" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-floppy-disk"></i> Simpan Foto Profil
      </button>
    </form>
  </div>

  <!-- Card Foto Kendaraan -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-motorcycle" style="color: var(--amber);"></i> Foto Kendaraan & Aktivitas</h3>
      <span class="status-badge" style="color: var(--amber); border-color: rgba(251,191,36,0.3);">ADMIN ONLY</span>
    </div>

    <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 20px;">
      <div style="width: 130px; height: 88px; border-radius: 8px; overflow: hidden; border: 2px solid var(--amber); flex-shrink: 0; background: #000;">
        <?php if ($motor_preview): ?>
          <img src="<?= htmlspecialchars($motor_preview); ?>" alt="Motor" style="width: 100%; height: 100%; object-fit: cover;">
        <?php endif; ?>
      </div>
      <div>
        <h5 style="color: #fff; margin-bottom: 4px;">Foto Spesifikasi Kendaraan</h5>
        <span style="font-size: 12px; color: var(--admin-dim); display: block; margin-bottom: 8px;">
          Tampil pada tab Spesifikasi Kendaraan jika section Aktivitas diaktifkan.
        </span>
        <?php if (!empty($s['motor_image_url'])): ?>
          <a href="galeri.php?del_motor_img=1" onclick="return confirm('Hapus foto kendaraan ini?');" class="btn btn-danger btn-sm">
            <i class="fa-solid fa-trash"></i> Hapus Foto
          </a>
        <?php endif; ?>
      </div>
    </div>

    <form method="POST" action="galeri.php" enctype="multipart/form-data">
      <input type="hidden" name="update_motor_img" value="1">
      <div class="form-group">
        <label class="form-label">Unggah / Ganti Foto Kendaraan</label>
        <input type="file" name="motor_file" class="form-control" accept="image/*">
      </div>

      <div class="form-group">
        <label class="form-label">Atau URL Gambar</label>
        <input type="text" name="motor_url" class="form-control" value="<?= htmlspecialchars($s['motor_image_url'] ?? ''); ?>">
      </div>

      <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
        <input type="checkbox" id="show_motor_chk" name="show_motor_now" value="1" <?= !empty($s['show_motor']) ? 'checked' : ''; ?> style="width: 17px; height: 17px;">
        <label for="show_motor_chk" style="color: #fff; cursor: pointer; font-size: 13.5px;">Tampilkan Section Aktivitas & Foto Kendaraan di Website Publik</label>
      </div>

      <button type="submit" class="btn btn-secondary btn-sm">
        <i class="fa-solid fa-floppy-disk"></i> Simpan Foto Kendaraan
      </button>
    </form>
  </div>
</div>

<!-- Tambah / Edit Foto Galeri -->
<div class="dash-card">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-images" style="color: var(--emerald);"></i>
      <?= $edit_gal ? 'Edit Foto Galeri: ' . htmlspecialchars($edit_gal['judul']) : 'Tambah Dokumentasi Baru ke Galeri'; ?>
    </h3>
    <?php if ($edit_gal): ?>
      <a href="galeri.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="galeri.php" enctype="multipart/form-data">
    <input type="hidden" name="save_gallery" value="1">
    <?php if ($edit_gal): ?>
      <input type="hidden" name="gal_id" value="<?= $edit_gal['id']; ?>">
      <input type="hidden" name="existing_gambar_url" value="<?= htmlspecialchars($edit_gal['gambar_url']); ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Judul Dokumentasi</label>
        <input type="text" name="judul" class="form-control" placeholder="Contoh: Pengembangan Sistem Database, Kegiatan Kampus..." value="<?= htmlspecialchars($edit_gal['judul'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Kategori</label>
        <select name="kategori" class="form-control" required>
          <?php
            $kat_opts = ['coding' => 'Pengembangan Sistem & Kuliah', 'proyek' => 'Implementasi Proyek', 'sertifikasi' => 'Seminar & Sertifikasi', 'motor' => 'Eksplorasi & Touring', 'sunmori' => 'Morning Ride'];
            $cur_kat = $edit_gal['kategori'] ?? 'coding';
            foreach ($kat_opts as $kval => $klab):
          ?>
            <option value="<?= $kval; ?>" <?= ($cur_kat === $kval) ? 'selected' : ''; ?>><?= $klab; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label"><?= $edit_gal ? 'Ganti File Foto (Opsional)' : 'Pilih File Foto dari Komputer'; ?></label>
        <input type="file" name="gallery_file" class="form-control" accept="image/*">
      </div>

      <div class="form-group">
        <label class="form-label">Atau URL Gambar Web</label>
        <input type="text" name="gambar_url" class="form-control" placeholder="https://..." value="<?= htmlspecialchars($edit_gal['gambar_url'] ?? ''); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Keterangan / Caption</label>
      <input type="text" name="caption" class="form-control" placeholder="Ringkasan konteks kegiatan..." value="<?= htmlspecialchars($edit_gal['caption'] ?? ''); ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> <?= $edit_gal ? 'Simpan Perubahan Foto' : 'Unggah & Tambahkan ke Galeri'; ?>
    </button>
  </form>
</div>

<!-- Daftar Foto di Galeri dengan Tombol Edit, Sembunyikan, & Hapus -->
<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-photo-film" style="color: var(--cyan);"></i> Daftar Foto di Galeri</h3>
    <span class="mono" style="font-size: 12px; color: var(--admin-dim);">Total: <?= count($gallery_items); ?> Foto</span>
  </div>

  <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px;">
    <?php foreach ($gallery_items as $gi): 
      $img_src = resolve_media_url($gi['gambar_url'], true);
      $vis = !isset($gi['is_visible']) || !empty($gi['is_visible']);
    ?>
      <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--admin-border); border-radius: 10px; overflow: hidden; display: flex; flex-direction: column; <?= !$vis ? 'opacity: 0.55;' : ''; ?>">
        <div style="width: 100%; height: 165px; background: #000; overflow: hidden; position: relative;">
          <img src="<?= htmlspecialchars($img_src); ?>" alt="<?= htmlspecialchars($gi['judul']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
          <span style="position: absolute; top: 8px; left: 8px; background: rgba(0,0,0,0.75); color: var(--cyan); font-family: var(--font-mono); font-size: 10px; padding: 2px 8px; border-radius: 4px; text-transform: uppercase;">
            <?= htmlspecialchars($gi['kategori']); ?>
          </span>
        </div>
        <div style="padding: 14px; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <h5 style="color: #fff; font-size: 15px; margin-bottom: 4px;"><?= htmlspecialchars($gi['judul']); ?></h5>
            <p style="color: var(--admin-muted); font-size: 12.5px; line-height: 1.4; margin-bottom: 12px;"><?= htmlspecialchars($gi['caption']); ?></p>
          </div>
          <div style="display: flex; justify-content: space-between; gap: 6px;">
            <?php if (isset($gi['id'])): ?>
              <a href="galeri.php?toggle_vis=<?= $gi['id']; ?>" class="btn <?= $vis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm" style="flex: 1;">
                <i class="fa-solid <?= $vis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                <?= $vis ? 'Tampil' : 'Hidden'; ?>
              </a>
              <a href="galeri.php?edit_gallery=<?= $gi['id']; ?>" class="btn btn-secondary btn-sm" title="Edit Foto & Keterangan">
                <i class="fa-solid fa-pen-to-square"></i>
              </a>
              <a href="galeri.php?del_gallery=<?= $gi['id']; ?>" onclick="return confirm('Hapus foto ini secara permanen?');" class="btn btn-danger btn-sm" title="Hapus">
                <i class="fa-solid fa-trash"></i>
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Unggah & Kelola File / Dokumen Publik (Tersimpan Langsung ke Database) -->
<div class="dash-card" id="docManager">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-file-arrow-up" style="color: var(--cyan);"></i>
      <?= $edit_doc ? 'Edit File Publik: ' . htmlspecialchars($edit_doc['judul']) : 'Unggah File / Dokumen ke Database (Langsung Tampil di Website Publik)'; ?>
    </h3>
    <?php if ($edit_doc): ?>
      <a href="galeri.php#docManager" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="galeri.php#docManager" enctype="multipart/form-data" style="margin-bottom: 24px;">
    <input type="hidden" name="save_document" value="1">
    <?php if ($edit_doc): ?>
      <input type="hidden" name="doc_id" value="<?= $edit_doc['id']; ?>">
      <input type="hidden" name="existing_doc_path" value="<?= htmlspecialchars($edit_doc['file_path']); ?>">
      <input type="hidden" name="existing_doc_type" value="<?= htmlspecialchars($edit_doc['file_type']); ?>">
      <input type="hidden" name="existing_doc_size" value="<?= (int)$edit_doc['file_size']; ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Judul File / Dokumen</label>
        <input type="text" name="doc_judul" class="form-control" placeholder="Contoh: CV Resmi Ibnu Andriano, Sertifikat Pelatihan, Transkrip..." value="<?= htmlspecialchars($edit_doc['judul'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Kategori</label>
        <select name="doc_kategori" class="form-control">
          <?php
            $dk_opts = ['CV & Resume', 'Sertifikat & Ijazah', 'Portofolio Proyek', 'Dokumen Pendukung', 'Lampiran Foto'];
            $cur_dk = $edit_doc['kategori'] ?? 'CV & Resume';
            foreach ($dk_opts as $dko):
          ?>
            <option value="<?= htmlspecialchars($dko); ?>" <?= ($cur_dk === $dko) ? 'selected' : ''; ?>><?= htmlspecialchars($dko); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label"><?= $edit_doc ? 'Ganti File (Opsional — PDF, Word, Excel, Gambar, ZIP)' : 'Pilih File dari Perangkat (PDF, Word, Excel, Gambar, ZIP)'; ?></label>
        <input type="file" name="doc_file" class="form-control" <?= $edit_doc ? '' : 'required'; ?>>
      </div>

      <div class="form-group">
        <label class="form-label">Keterangan Singkat</label>
        <input type="text" name="doc_keterangan" class="form-control" placeholder="Deskripsi singkat isi file untuk dilihat pengunjung/HRD..." value="<?= htmlspecialchars($edit_doc['keterangan'] ?? ''); ?>">
      </div>
    </div>

    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
      <input type="checkbox" id="doc_visible_chk" name="doc_visible" value="1" <?= (!isset($edit_doc['is_visible']) || !empty($edit_doc['is_visible'])) ? 'checked' : ''; ?> style="width: 17px; height: 17px;">
      <label for="doc_visible_chk" style="color: #fff; cursor: pointer; font-size: 13.5px;">Tampilkan File Ini di Halaman Publik Website (Dapat Dilihat & Diunduh Orang Lain)</label>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-cloud-arrow-up"></i> <?= $edit_doc ? 'Simpan Perubahan File' : 'Unggah & Simpan ke Database'; ?>
    </button>
  </form>

  <?php if (!empty($documents_list)): ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Judul File</th>
            <th>Kategori</th>
            <th>Tipe & Ukuran</th>
            <th>Visibilitas Publik</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($documents_list as $doc):
            $dvis = !empty($doc['is_visible']);
          ?>
            <tr style="<?= !$dvis ? 'opacity: 0.55;' : ''; ?>">
              <td>
                <strong style="color: #fff;"><?= htmlspecialchars($doc['judul']); ?></strong>
                <?php if (!empty($doc['keterangan'])): ?>
                  <div style="font-size: 12px; color: var(--admin-dim);"><?= htmlspecialchars($doc['keterangan']); ?></div>
                <?php endif; ?>
              </td>
              <td><span class="mono" style="font-size: 11.5px;"><?= htmlspecialchars($doc['kategori']); ?></span></td>
              <td class="mono" style="font-size: 12px;">
                <span class="status-badge"><?= htmlspecialchars($doc['file_type']); ?></span>
                <?= number_format($doc['file_size'] / 1024, 1); ?> KB
              </td>
              <td>
                <a href="galeri.php?toggle_doc_vis=<?= $doc['id']; ?>#docManager" class="btn <?= $dvis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm">
                  <i class="fa-solid <?= $dvis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                  <?= $dvis ? 'Tampil' : 'Disembunyikan'; ?>
                </a>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="../<?= htmlspecialchars($doc['file_path']); ?>" target="_blank" class="btn btn-secondary btn-sm" title="Lihat / Unduh"><i class="fa-solid fa-eye"></i></a>
                  <a href="galeri.php?edit_doc=<?= $doc['id']; ?>#docManager" class="btn btn-secondary btn-sm" title="Edit / Ganti File"><i class="fa-solid fa-pen-to-square"></i></a>
                  <a href="galeri.php?del_doc=<?= $doc['id']; ?>#docManager" onclick="return confirm('Hapus file ini dari database dan server?');" class="btn btn-danger btn-sm" title="Hapus"><i class="fa-solid fa-trash"></i></a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<!-- File Manager: Semua File & Foto di Folder uploads/ -->
<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-folder-open" style="color: var(--amber);"></i> Semua File & Foto Tersimpan di Server (uploads/)</h3>
    <span class="mono" style="font-size: 12px; color: var(--admin-dim);"><?= count($uploaded_files); ?> File</span>
  </div>

  <?php if (empty($uploaded_files)): ?>
    <p style="color: var(--admin-dim); font-size: 13.5px;">Belum ada file yang diunggah ke folder <code>uploads/</code>.</p>
  <?php else: ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Nama File</th>
            <th>Tipe</th>
            <th>Ukuran</th>
            <th>Tanggal Unggah</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($uploaded_files as $uf): ?>
            <tr>
              <td class="mono" style="font-size: 12.5px; color: #fff;"><?= htmlspecialchars($uf['name']); ?></td>
              <td><span class="status-badge"><?= strtoupper(htmlspecialchars($uf['ext'])); ?></span></td>
              <td class="mono" style="font-size: 12px;"><?= number_format($uf['size'] / 1024, 1); ?> KB</td>
              <td class="mono" style="font-size: 12px; color: var(--admin-dim);"><?= date('d/m/Y H:i', $uf['mtime']); ?></td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="../uploads/<?= rawurlencode($uf['name']); ?>" target="_blank" class="btn btn-secondary btn-sm" title="Lihat File"><i class="fa-solid fa-eye"></i></a>
                  <a href="galeri.php?del_file=<?= urlencode($uf['name']); ?>" onclick="return confirm('Hapus permanen file <?= htmlspecialchars($uf['name']); ?>?');" class="btn btn-danger btn-sm" title="Hapus File"><i class="fa-solid fa-trash"></i> Hapus</a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
