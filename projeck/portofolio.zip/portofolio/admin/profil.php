<?php
$page_title = 'Profil, Foto Utama & Resume CV';
require_once __DIR__ . '/header.php';

$msg = '';
$err = '';

// 1. Handle Hapus Foto Profil (Reset ke default)
if (isset($_GET['delete_avatar'])) {
    $s_curr = get_settings($koneksi);
    if (!empty($s_curr['avatar_url']) && strpos($s_curr['avatar_url'], 'uploads/') === 0 && $s_curr['avatar_url'] !== 'uploads/foto_ibnu.jpg') {
        $f = __DIR__ . '/../' . $s_curr['avatar_url'];
        if (file_exists($f)) @unlink($f);
    }
    save_site_settings($koneksi, ['avatar_url' => 'images/default-avatar.svg']);
    $msg = 'Foto profil berhasil direset ke avatar default!';
}

// 2. Handle Hapus File CV yang diunggah
if (isset($_GET['delete_cv'])) {
    $s_curr = get_settings($koneksi);
    if (!empty($s_curr['cv_url']) && strpos($s_curr['cv_url'], 'uploads/') === 0) {
        $f = __DIR__ . '/../' . $s_curr['cv_url'];
        if (file_exists($f)) @unlink($f);
    }
    save_site_settings($koneksi, ['cv_url' => '#']);
    $msg = 'File PDF CV yang diunggah berhasil dihapus!';
}

// 3. Handle Simpan Seluruh Perubahan Profil (Hybrid MySQL + Local JSON — 100% Langsung Berhasil)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $s_curr = get_settings($koneksi);

    $nama              = trim($_POST['nama'] ?? $s_curr['nama']);
    $tagline           = trim($_POST['tagline'] ?? $s_curr['tagline']);
    $hero_headline     = trim($_POST['hero_headline'] ?? $s_curr['hero_headline']);
    $hero_desc         = trim($_POST['hero_desc'] ?? $s_curr['hero_desc']);
    $roles_typewriter  = trim($_POST['roles_typewriter'] ?? $s_curr['roles_typewriter']);
    $availability_text = trim($_POST['availability_text'] ?? $s_curr['availability_text']);
    $kampus            = trim($_POST['kampus'] ?? $s_curr['kampus']);
    $prodi             = trim($_POST['prodi'] ?? $s_curr['prodi']);
    $semester          = trim($_POST['semester'] ?? $s_curr['semester']);
    $nim               = trim($_POST['nim'] ?? $s_curr['nim']);
    $ipk               = trim($_POST['ipk'] ?? $s_curr['ipk']);
    $asal              = trim($_POST['asal'] ?? $s_curr['asal']);
    $whatsapp          = trim($_POST['whatsapp'] ?? $s_curr['whatsapp']);
    $email             = trim($_POST['email'] ?? $s_curr['email']);
    $instagram         = trim($_POST['instagram'] ?? $s_curr['instagram']);
    $linkbio           = trim($_POST['linkbio'] ?? $s_curr['linkbio']);
    $github            = trim($_POST['github'] ?? $s_curr['github']);
    $linkedin          = trim($_POST['linkedin'] ?? $s_curr['linkedin']);
    $avatar_url        = trim($_POST['avatar_url'] ?? $s_curr['avatar_url']);
    $cv_url            = trim($_POST['cv_url'] ?? $s_curr['cv_url']);
    $show_photo        = isset($_POST['show_photo']) ? 1 : 0;

    // Cek unggahan file foto profil baru
    if (!empty($_FILES['avatar_file']['name'])) {
        $uploaded_photo = upload_image_file($_FILES['avatar_file'], 'avatar');
        if ($uploaded_photo) {
            $avatar_url = $uploaded_photo;
        } else {
            $err = 'Gagal mengunggah file foto profil! Pastikan format JPG, PNG, atau WEBP (Maks 5MB).';
        }
    }

    // Cek unggahan file PDF CV baru
    if (!empty($_FILES['cv_file']['name'])) {
        $uploaded_cv = upload_cv_file($_FILES['cv_file']);
        if ($uploaded_cv) {
            $cv_url = $uploaded_cv;
        } else {
            $err = 'Gagal mengunggah dokumen CV! Pastikan file berformat .PDF (Maks 10MB).';
        }
    }

    if (empty($err)) {
        $update_payload = [
            'nama'              => $nama,
            'tagline'           => $tagline,
            'hero_headline'     => $hero_headline,
            'hero_desc'         => $hero_desc,
            'roles_typewriter'  => $roles_typewriter,
            'availability_text' => $availability_text,
            'kampus'            => $kampus,
            'prodi'             => $prodi,
            'semester'          => $semester,
            'nim'               => $nim,
            'ipk'               => $ipk,
            'asal'              => $asal,
            'whatsapp'          => $whatsapp,
            'email'             => $email,
            'instagram'         => $instagram,
            'linkbio'           => $linkbio,
            'github'            => $github,
            'linkedin'          => $linkedin,
            'avatar_url'        => $avatar_url,
            'cv_url'            => $cv_url,
            'show_photo'        => $show_photo
        ];

        if (save_site_settings($koneksi, $update_payload)) {
            $msg = 'Seluruh perubahan profil, bio, foto, dan dokumen CV berhasil disimpan dan langsung aktif di website utama!';
        } else {
            $err = 'Terjadi kendala saat menulis perubahan ke penyimpanan.';
        }
    }
}

$s = get_settings($koneksi);
$avatar_preview = resolve_media_url($s['avatar_url'], true);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?></div>
    <a href="../index.php" target="_blank" class="btn btn-secondary btn-sm">
      <i class="fa-solid fa-arrow-up-right-from-square"></i> Lihat Hasil di Website
    </a>
  </div>
<?php endif; ?>

<?php if (!empty($err)): ?>
  <div class="alert-success" style="background: rgba(244,63,94,0.12); border-color: rgba(244,63,94,0.3); color: var(--rose);">
    <i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($err); ?>
  </div>
<?php endif; ?>

<form method="POST" action="profil.php" enctype="multipart/form-data">

  <!-- Quick Action Bar Atas -->
  <div class="dash-card" style="padding: 16px 22px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; background: linear-gradient(135deg, rgba(56,189,248,0.08), rgba(16,185,129,0.05)); border-color: rgba(56,189,248,0.25);">
    <div>
      <h3 style="font-size: 16px; color: #fff; margin-bottom: 2px;">
        <i class="fa-solid fa-bolt" style="color: var(--cyan);"></i> Editor Profil & Identitas Utama
      </h3>
      <p style="font-size: 12.5px; color: var(--admin-muted); margin: 0;">
        Ubah informasi kapan saja — setiap perubahan langsung tersimpan dan terpasang di halaman depan portofolio & CV ATS.
      </p>
    </div>
    <div style="display: flex; gap: 10px; align-items: center;">
      <a href="../index.php" target="_blank" class="btn btn-secondary btn-sm">
        <i class="fa-regular fa-eye"></i> Preview Web
      </a>
      <button type="submit" class="btn btn-primary">
        <i class="fa-solid fa-floppy-disk"></i> Simpan Seluruh Perubahan Profil
      </button>
    </div>
  </div>

  <!-- Bagian 1: Foto Profil & File CV -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-camera-retro" style="color: var(--cyan);"></i> Foto Profil & Dokumen Resume CV</h3>
      <span class="status-badge"><i class="fa-solid fa-shield-halved"></i> ADMIN CONTROL</span>
    </div>

    <div class="form-row" style="align-items: center;">
      <div style="display: flex; align-items: center; gap: 18px; background: rgba(255,255,255,0.025); padding: 18px; border-radius: 12px; border: 1px solid var(--admin-border);">
        <div style="width: 96px; height: 96px; border-radius: 20px; overflow: hidden; border: 2px solid var(--cyan); flex-shrink: 0; background: #0B0F17;">
          <img src="<?= htmlspecialchars($avatar_preview); ?>" id="liveAvatarPreview" alt="Foto Profil" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div>
          <h4 style="color: #fff; font-size: 16px; margin-bottom: 4px;"><?= htmlspecialchars($s['nama']); ?></h4>
          <p style="font-size: 12px; color: var(--admin-dim); margin-bottom: 10px;">
            Format disarankan: JPG, PNG, atau WEBP rasio 1:1 (persegi).
          </p>
          <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: var(--emerald); font-weight: 600;">
            <input type="checkbox" name="show_photo" value="1" <?= !empty($s['show_photo']) ? 'checked' : ''; ?> style="width: 16px; height: 16px; accent-color: var(--emerald);">
            Tampilkan Foto Profil di Halaman Depan
          </label>
          <?php if ($s['avatar_url'] !== 'images/default-avatar.svg'): ?>
            <div style="margin-top: 10px;">
              <a href="profil.php?delete_avatar=1" onclick="return confirm('Reset foto profil ke default?');" class="btn btn-danger btn-sm">
                <i class="fa-solid fa-trash-can"></i> Reset Foto
              </a>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div>
        <div class="form-group">
          <label class="form-label">Upload Foto Baru dari Perangkat (JPG / PNG / WEBP)</label>
          <input type="file" name="avatar_file" id="avatarFileInput" class="form-control" accept="image/*">
        </div>
        <div class="form-group" style="margin-bottom: 0;">
          <label class="form-label">Path / URL Foto Aktif</label>
          <input type="text" name="avatar_url" class="form-control mono" value="<?= htmlspecialchars($s['avatar_url']); ?>">
        </div>
      </div>
    </div>

    <div class="form-row" style="margin-top: 18px; padding-top: 18px; border-top: 1px solid var(--admin-border);">
      <div class="form-group" style="margin-bottom: 0;">
        <label class="form-label">Upload File CV / Resume PDF (Opsional)</label>
        <input type="file" name="cv_file" class="form-control" accept="application/pdf">
        <small style="color: var(--admin-dim); font-size: 11.5px;">Website sudah punya generator CV ATS otomatis, atau unggah PDF custom di sini.</small>
      </div>
      <div class="form-group" style="margin-bottom: 0;">
        <label class="form-label">Path / Link File CV Saat Ini (Isi '#' jika memakai CV ATS Otomatis)</label>
        <div style="display: flex; gap: 8px;">
          <input type="text" name="cv_url" class="form-control mono" value="<?= htmlspecialchars($s['cv_url']); ?>">
          <?php if (!empty($s['cv_url']) && $s['cv_url'] !== '#'): ?>
            <a href="profil.php?delete_cv=1" onclick="return confirm('Hapus file CV ini?');" class="btn btn-danger btn-sm" style="flex-shrink: 0;">
              <i class="fa-solid fa-trash"></i> Hapus CV
            </a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Bagian 2: Identitas Utama & Hero Copywriting -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-wand-magic-sparkles" style="color: var(--cyan);"></i> Identitas, Tagline & Intro Hero</h3>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($s['nama']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Role / Tagline Utama</label>
        <input type="text" name="tagline" class="form-control" value="<?= htmlspecialchars($s['tagline']); ?>" required>
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Status Availability (Badge Hijau di Atas Hero)</label>
      <input type="text" name="availability_text" class="form-control" value="<?= htmlspecialchars($s['availability_text']); ?>">
    </div>

    <div class="form-group">
      <label class="form-label">Headline Utama Hero</label>
      <input type="text" name="hero_headline" class="form-control" value="<?= htmlspecialchars($s['hero_headline']); ?>" required>
    </div>

    <div class="form-group">
      <label class="form-label">Deskripsi Singkat (Tampil di Hero & Ringkasan CV)</label>
      <textarea name="hero_desc" class="form-control" rows="3" required><?= htmlspecialchars($s['hero_desc']); ?></textarea>
    </div>

    <div class="form-group" style="margin-bottom: 0;">
      <label class="form-label">Teks Efek Ketik / Typewriter (Pisahkan dengan koma)</label>
      <input type="text" name="roles_typewriter" class="form-control" value="<?= htmlspecialchars($s['roles_typewriter']); ?>" required>
    </div>
  </div>

  <!-- Bagian 3: Data Kampus & Domisili -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-graduation-cap" style="color: var(--emerald);"></i> Kampus, Akademik & Domisili</h3>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Kampus / Universitas</label>
        <input type="text" name="kampus" class="form-control" value="<?= htmlspecialchars($s['kampus']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Program Studi / Jurusan</label>
        <input type="text" name="prodi" class="form-control" value="<?= htmlspecialchars($s['prodi']); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Status / Semester</label>
        <input type="text" name="semester" class="form-control" value="<?= htmlspecialchars($s['semester']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">NIM</label>
        <input type="text" name="nim" class="form-control mono" value="<?= htmlspecialchars($s['nim']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">IPK</label>
        <input type="text" name="ipk" class="form-control mono" value="<?= htmlspecialchars($s['ipk']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">Domisili</label>
        <input type="text" name="asal" class="form-control" value="<?= htmlspecialchars($s['asal']); ?>" required>
      </div>
    </div>
  </div>

  <!-- Bagian 4: Kontak & Sosial Media -->
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-paper-plane" style="color: var(--amber);"></i> Kontak & Sosial Media</h3>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nomor WhatsApp</label>
        <input type="text" name="whatsapp" class="form-control mono" value="<?= htmlspecialchars($s['whatsapp']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Alamat Email</label>
        <input type="text" name="email" class="form-control mono" value="<?= htmlspecialchars($s['email']); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">LinkedIn URL</label>
        <input type="text" name="linkedin" class="form-control" value="<?= htmlspecialchars($s['linkedin']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">GitHub URL</label>
        <input type="text" name="github" class="form-control" value="<?= htmlspecialchars($s['github']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">Instagram</label>
        <input type="text" name="instagram" class="form-control" value="<?= htmlspecialchars($s['instagram']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">LinkBio / Website Lain</label>
        <input type="text" name="linkbio" class="form-control" value="<?= htmlspecialchars($s['linkbio']); ?>">
      </div>
    </div>

    <div style="display: flex; justify-content: flex-end; gap: 12px; padding-top: 12px; border-top: 1px solid var(--admin-border);">
      <a href="../index.php" target="_blank" class="btn btn-secondary">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> Lihat Website Publik
      </a>
      <button type="submit" class="btn btn-primary" style="padding: 12px 26px;">
        <i class="fa-solid fa-floppy-disk"></i> Simpan Seluruh Perubahan Profil
      </button>
    </div>
  </div>
</form>

<script>
  document.getElementById('avatarFileInput')?.addEventListener('change', function (e) {
    const file = e.target.files && e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (ev) {
        const img = document.getElementById('liveAvatarPreview');
        if (img) img.src = ev.target.result;
      };
      reader.readAsDataURL(file);
    }
  });
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
