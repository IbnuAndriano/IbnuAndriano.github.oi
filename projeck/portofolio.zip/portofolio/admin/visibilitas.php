<?php
$page_title = 'Kontrol Visibilitas Publik (Tampilkan / Sembunyikan Semua Elemen)';
require_once __DIR__ . '/header.php';

$msg = '';

// Daftar lengkap 16 sakelar visibilitas publik
$toggle_keys = [
    'show_availability',
    'show_photo',
    'show_hero_stats',
    'show_about',
    'show_academic_detail',
    'show_services',
    'show_experience',
    'show_projects',
    'show_skills',
    'show_education',
    'show_certificates',
    'show_cv',
    'show_contact',
    'show_social_links',
    'show_motor',
    'show_gallery',
    'show_documents',
    'show_terminal'
];

// Handle Preset Cepat (1-Klik Mode Lamaran Kerja/Magang, Lengkap, dll.)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['apply_preset'])) {
    $preset = $_POST['apply_preset'];
    $values = [];

    if ($preset === 'formal_recruitment') {
        // Fokus 100% Formal Melamar Magang / Kerja (Sembunyikan Motoran & Terminal)
        $values = [
            'show_availability' => 1, 'show_photo' => 1, 'show_hero_stats' => 1,
            'show_about' => 1, 'show_academic_detail' => 1, 'show_services' => 1,
            'show_experience' => 1, 'show_projects' => 1, 'show_skills' => 1,
            'show_education' => 1, 'show_certificates' => 1, 'show_cv' => 1,
            'show_contact' => 1, 'show_social_links' => 1,
            'show_motor' => 0, 'show_gallery' => 0, 'show_documents' => 1, 'show_terminal' => 0
        ];
        $msg = "Mode Formal Melamar Magang & Kerja berhasil diterapkan! Bagian hobi otomatis disembunyikan untuk tampilan korporat.";
    } elseif ($preset === 'all_visible') {
        foreach ($toggle_keys as $k) $values[$k] = 1;
        $msg = "Mode Portofolio Lengkap diterapkan! Seluruh bagian ditampilkan ke publik.";
    } elseif ($preset === 'executive_minimal') {
        $values = [
            'show_availability' => 1, 'show_photo' => 1, 'show_hero_stats' => 1,
            'show_about' => 0, 'show_academic_detail' => 0, 'show_services' => 1,
            'show_experience' => 1, 'show_projects' => 1, 'show_skills' => 1,
            'show_education' => 0, 'show_certificates' => 0, 'show_cv' => 1,
            'show_contact' => 1, 'show_social_links' => 1,
            'show_motor' => 0, 'show_gallery' => 0, 'show_documents' => 1, 'show_terminal' => 0
        ];
        $msg = "Mode Ringkas Eksekutif berhasil diterapkan!";
    } elseif ($preset === 'hide_all') {
        foreach ($toggle_keys as $k) $values[$k] = 0;
        $msg = "Seluruh bagian berhasil disembunyikan dari publik (Mode Privat).";
    }

    if (!empty($values)) {
        save_site_settings($koneksi, $values);
    }
}

// Handle Custom Manual Toggle Save
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['save_visibility'])) {
    $values = [];
    foreach ($toggle_keys as $col) {
        $values[$col] = isset($_POST[$col]) ? 1 : 0;
    }
    save_site_settings($koneksi, $values);
    $msg = "Pengaturan visibilitas tampilan publik berhasil disimpan!";
}

$s = get_settings($koneksi);

$toggle_definitions = [
    [
        'group' => 'Identitas Utama & Hero Section',
        'items' => [
            ['key' => 'show_photo', 'icon' => 'fa-solid fa-camera', 'color' => 'var(--cyan)', 'title' => 'Foto Profil Pribadi', 'desc' => 'Tampilkan atau sembunyikan foto profil di kartu identitas utama. (Hanya admin yang dapat mengganti foto).'],
            ['key' => 'show_availability', 'icon' => 'fa-solid fa-circle-check', 'color' => 'var(--emerald)', 'title' => 'Badge Status Ketersediaan Kerja/Magang', 'desc' => 'Menampilkan indikator "Terbuka untuk Magang, Kerja Full-Time & Proyek" di bagian atas Hero.'],
            ['key' => 'show_hero_stats', 'icon' => 'fa-solid fa-chart-simple', 'color' => 'var(--cyan)', 'title' => 'Metrik Ringkasan Hero', 'desc' => 'Baris ringkasan jumlah proyek, teknologi, dan indikator di bawah tombol utama Hero.'],
            ['key' => 'show_academic_detail', 'icon' => 'fa-solid fa-id-card', 'color' => 'var(--amber)', 'title' => 'Detail Akademik (NIM, Status Semester & IPK)', 'desc' => 'Sangat berguna: matikan sakelar ini saat Anda sudah lulus atau tidak ingin menampilkan NIM/Semester ke publik.'],
            ['key' => 'show_terminal', 'icon' => 'fa-solid fa-terminal', 'color' => 'var(--cyan)', 'title' => 'Konsol Ringkasan Arsitektur di Hero', 'desc' => 'Kotak konsol interaktif ringkasan profil teknis di bagian bawah Hero.']
        ]
    ],
    [
        'group' => 'Bagian Inti Rekrutmen (Magang & Kerja)',
        'items' => [
            ['key' => 'show_about', 'icon' => 'fa-solid fa-user-tie', 'color' => 'var(--cyan)', 'title' => 'Section Profil & Pendekatan Kerja (About)', 'desc' => 'Narasi eksekutif latar belakang dan prinsip rekayasa perangkat lunak Anda.'],
            ['key' => 'show_services', 'icon' => 'fa-solid fa-cubes', 'color' => 'var(--emerald)', 'title' => 'Section Fokus Kompetensi & Solusi Sistem', 'desc' => 'Empat pilar keahlian utama (Full-Stack Web, Database Engineering, System Analysis, Integrasi).'],
            ['key' => 'show_experience', 'icon' => 'fa-solid fa-briefcase', 'color' => 'var(--amber)', 'title' => 'Section Pengalaman Kerja, Magang & Rekam Jejak', 'desc' => 'Daftar pengalaman implementasi sistem, magang, proyek, dan pencapaian.'],
            ['key' => 'show_projects', 'icon' => 'fa-solid fa-layer-group', 'color' => 'var(--cyan)', 'title' => 'Section Proyek & Studi Kasus Portofolio', 'desc' => 'Seluruh daftar karya proyek aplikasi web (Item per proyek juga bisa disembunyikan di menu Proyek).'],
            ['key' => 'show_skills', 'icon' => 'fa-solid fa-code', 'color' => 'var(--emerald)', 'title' => 'Section Keahlian Teknis (Tech Stack)', 'desc' => 'Kartu kompetensi bahasa pemrograman, database, dan tools pengembangan.'],
            ['key' => 'show_education', 'icon' => 'fa-solid fa-graduation-cap', 'color' => 'var(--amber)', 'title' => 'Section Riwayat Pendidikan Formal', 'desc' => 'Timeline riwayat pendidikan (Tiap jenjang SD/SMP/SMA/S1 juga bisa disembunyikan satu-persatu di menu Pendidikan).'],
            ['key' => 'show_certificates', 'icon' => 'fa-solid fa-award', 'color' => 'var(--amber)', 'title' => 'Section Sertifikasi & Pelatihan', 'desc' => 'Daftar sertifikat kompetensi dan lisensi resmi.'],
            ['key' => 'show_cv', 'icon' => 'fa-solid fa-file-pdf', 'color' => 'var(--cyan)', 'title' => 'Section & Tombol Resume / CV Standar ATS', 'desc' => 'Tombol pratinjau CV, cetak PDF format ATS A4, dan unduh file CV resmi.']
        ]
    ],
    [
        'group' => 'Bagian Lifestyle, Galeri & Saluran Kontak',
        'items' => [
            ['key' => 'show_motor', 'icon' => 'fa-solid fa-motorcycle', 'color' => 'var(--rose)', 'title' => 'Section Aktivitas Luar Ruang & Otomotif', 'desc' => 'Bagian hobi eksplorasi jarak jauh & spesifikasi kendaraan (Disarankan OFF saat melamar perusahaan korporat formal).'],
            ['key' => 'show_gallery', 'icon' => 'fa-solid fa-images', 'color' => 'var(--emerald)', 'title' => 'Galeri Foto & Dokumentasi Kegiatan', 'desc' => 'Menampilkan dokumentasi foto kegiatan (Tiap foto juga bisa disembunyikan di menu Kelola Foto).'],
            ['key' => 'show_documents', 'icon' => 'fa-solid fa-file-arrow-down', 'color' => 'var(--cyan)', 'title' => 'Section Dokumen & File Publik', 'desc' => 'Menampilkan daftar file (PDF, Word, Sertifikat, Lampiran) yang Anda unggah ke database agar dapat dilihat/diunduh orang lain.'],
            ['key' => 'show_contact', 'icon' => 'fa-solid fa-envelope', 'color' => 'var(--cyan)', 'title' => 'Section Kontak & Formulir Pesan Pengunjung', 'desc' => 'Formulir pengiriman pesan langsung ke database admin dan informasi kontak.'],
            ['key' => 'show_social_links', 'icon' => 'fa-solid fa-share-nodes', 'color' => 'var(--emerald)', 'title' => 'Tombol Saluran Langsung (WhatsApp, Email, LinkedIn, GitHub)', 'desc' => 'Kartu dan tautan cepat ke jejaring profesional dan kontak langsung.']
        ]
    ]
];
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<!-- Preset Mode Cepat -->
<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-wand-magic-sparkles" style="color: var(--amber);"></i> Preset Mode Tampilan Cepat (1-Klik)</h3>
    <span class="status-badge">INSTANT PROFILE MODE</span>
  </div>
  <p style="color: var(--admin-muted); font-size: 13.5px; margin-bottom: 18px;">
    Pilih mode prasetel di bawah ini untuk menyesuaikan tampilan portofolio yang dilihat orang lain/rekruter secara instan sesuai kebutuhan Anda saat ini:
  </p>

  <form method="POST" action="visibilitas.php" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 12px;">
    <button type="submit" name="apply_preset" value="formal_recruitment" class="btn btn-primary" style="padding: 14px; justify-content: flex-start; text-align: left;">
      <i class="fa-solid fa-user-tie" style="font-size: 18px;"></i>
      <div>
        <div style="font-weight: 700;">Mode Melamar Kerja / Magang</div>
        <div style="font-size: 11px; opacity: 0.8; font-weight: 400;">Tampilan formal HRD (Sembunyikan Hobi & Terminal)</div>
      </div>
    </button>

    <button type="submit" name="apply_preset" value="all_visible" class="btn btn-secondary" style="padding: 14px; justify-content: flex-start; text-align: left;">
      <i class="fa-solid fa-globe" style="font-size: 18px; color: var(--emerald);"></i>
      <div>
        <div style="font-weight: 700;">Tampilkan Semua Bagian</div>
        <div style="font-size: 11px; color: var(--admin-dim); font-weight: 400;">Mode lengkap termasuk aktivitas & galeri</div>
      </div>
    </button>

    <button type="submit" name="apply_preset" value="executive_minimal" class="btn btn-secondary" style="padding: 14px; justify-content: flex-start; text-align: left;">
      <i class="fa-solid fa-bolt" style="font-size: 18px; color: var(--amber);"></i>
      <div>
        <div style="font-weight: 700;">Mode Ringkas Eksekutif</div>
        <div style="font-size: 11px; color: var(--admin-dim); font-weight: 400;">Fokus Pengalaman, Proyek, Skill, CV & Kontak</div>
      </div>
    </button>

    <button type="submit" name="apply_preset" value="hide_all" class="btn btn-danger" style="padding: 14px; justify-content: flex-start; text-align: left;" onclick="return confirm('Sembunyikan seluruh section dari pengunjung publik?');">
      <i class="fa-solid fa-eye-slash" style="font-size: 18px;"></i>
      <div>
        <div style="font-weight: 700;">Sembunyikan Semua (Privat)</div>
        <div style="font-size: 11px; opacity: 0.85; font-weight: 400;">Nonaktifkan seluruh bagian sekaligus</div>
      </div>
    </button>
  </form>
</div>

<!-- Sakelar Manual Detail Per Bagian -->
<form method="POST" action="visibilitas.php">
  <input type="hidden" name="save_visibility" value="1">

  <?php foreach ($toggle_definitions as $group): ?>
    <div class="dash-card">
      <div class="card-title-bar">
        <h3><i class="fa-solid fa-sliders" style="color: var(--cyan);"></i> <?= htmlspecialchars($group['group']); ?></h3>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(330px, 1fr)); gap: 16px;">
        <?php foreach ($group['items'] as $item): 
          $k = $item['key'];
          $checked = !empty($s[$k]);
        ?>
          <div style="background: rgba(255,255,255,0.025); border: 1px solid <?= $checked ? 'rgba(56,189,248,0.28)' : 'var(--admin-border)'; ?>; border-radius: 10px; padding: 16px 18px; display: flex; align-items: center; justify-content: space-between; gap: 16px;">
            <div>
              <h4 style="font-size: 15px; color: #fff; margin-bottom: 4px; display: flex; align-items: center; gap: 8px;">
                <i class="<?= $item['icon']; ?>" style="color: <?= $item['color']; ?>;"></i>
                <span><?= htmlspecialchars($item['title']); ?></span>
              </h4>
              <p style="font-size: 12.5px; color: var(--admin-dim); line-height: 1.45;">
                <?= htmlspecialchars($item['desc']); ?>
              </p>
            </div>
            <label class="switch-ui">
              <input type="checkbox" name="<?= $k; ?>" value="1" <?= $checked ? 'checked' : ''; ?>>
              <span class="slider round"></span>
            </label>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>

  <div style="position: sticky; bottom: 20px; background: rgba(13, 16, 23, 0.95); border: 1px solid var(--cyan); padding: 16px 24px; border-radius: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; box-shadow: 0 15px 35px rgba(0,0,0,0.7); backdrop-filter: blur(12px);">
    <span style="color: #fff; font-size: 13.5px;">
      <i class="fa-solid fa-shield-halved" style="color: var(--emerald);"></i> Perubahan visibilitas langsung berlaku untuk seluruh pengunjung website publik.
    </span>
    <button type="submit" class="btn btn-primary" style="padding: 11px 24px;">
      <i class="fa-solid fa-floppy-disk"></i> Simpan Pengaturan Visibilitas
    </button>
  </div>
</form>

<style>
.switch-ui {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 26px;
  flex-shrink: 0;
}
.switch-ui input {
  opacity: 0;
  width: 0;
  height: 0;
}
.slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0; right: 0; bottom: 0;
  background-color: #334155;
  transition: .25s;
  border-radius: 34px;
}
.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: .25s;
  border-radius: 50%;
}
input:checked + .slider {
  background-color: var(--cyan);
}
input:checked + .slider:before {
  transform: translateX(24px);
  background-color: #06111D;
}
</style>

<?php require_once __DIR__ . '/footer.php'; ?>
