<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($page_title ?? 'Admin Workspace'); ?> — Ibnu Andriano</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

  <!-- Sidebar Navigation -->
  <?php include __DIR__ . '/sidebar.php'; ?>

  <!-- Main Workspace -->
  <div class="admin-main">
    <header class="admin-topbar">
      <div class="topbar-left">
        <h2 class="topbar-title">
          <?= htmlspecialchars($page_title ?? 'Dashboard'); ?>
        </h2>
        <span class="status-badge">
          <i class="fa-solid fa-circle" style="font-size: 7px; color: var(--emerald);"></i>
          <?= $koneksi ? 'MYSQL + LOCAL SYNC ACTIVE' : 'HYBRID STORAGE ACTIVE'; ?>
        </span>
      </div>

      <div style="display: flex; align-items: center; gap: 10px;">
        <a href="../index.php" target="_blank" class="btn btn-secondary btn-sm" title="Buka Halaman Depan">
          <i class="fa-solid fa-arrow-up-right-from-square" style="color: var(--cyan);"></i> Lihat Web
        </a>
        <a href="profil.php" class="btn btn-secondary btn-sm" title="Edit Profil">
          <i class="fa-regular fa-user" style="color: var(--emerald);"></i> <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Ibnu Andriano'); ?>
        </a>
        <a href="logout.php" class="btn btn-secondary btn-sm" title="Logout">
          <i class="fa-solid fa-power-off" style="color: var(--rose);"></i>
        </a>
      </div>
    </header>

    <div class="admin-content">
