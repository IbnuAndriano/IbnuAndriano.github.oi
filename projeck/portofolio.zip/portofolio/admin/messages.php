<?php
$page_title = 'Pesan Masuk (Inbox Pengunjung)';
require_once __DIR__ . '/header.php';

$msg = '';

if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    hybrid_delete($koneksi, 'messages', $del_id);
    $msg = "Pesan ID #$del_id berhasil dihapus!";
}

if (isset($_GET['read'])) {
    $read_id = (int)$_GET['read'];
    hybrid_update($koneksi, 'messages', $read_id, ['status_baca' => 1]);
    $msg = "Pesan ID #$read_id ditandai telah dibaca.";
}

$messages = get_messages($koneksi);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-inbox" style="color: var(--cyan);"></i> Kotak Masuk Pesan Pengunjung Website</h3>
    <span class="mono" style="font-size: 12px; color: var(--admin-dim);">Total: <?= count($messages); ?> Pesan</span>
  </div>

  <?php if (empty($messages)): ?>
    <div style="text-align: center; padding: 40px; color: var(--admin-dim);">
      <i class="fa-regular fa-envelope-open" style="font-size: 40px; margin-bottom: 12px; display: block;"></i>
      Belum ada pesan masuk dari pengunjung.
    </div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Status</th>
            <th>Waktu</th>
            <th>Pengirim</th>
            <th>Kontak (Email/No. HP)</th>
            <th>Isi Pesan</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($messages as $m): ?>
            <tr style="<?= empty($m['status_baca']) ? 'background: rgba(56,189,248,0.04);' : ''; ?>">
              <td>
                <?php if (empty($m['status_baca'])): ?>
                  <span class="status-badge" style="background: rgba(244,63,94,0.15); color: var(--rose); border-color: rgba(244,63,94,0.3);">BARU</span>
                <?php else: ?>
                  <span class="status-badge" style="background: rgba(255,255,255,0.05); color: var(--admin-muted); border-color: rgba(255,255,255,0.1);">DIBACA</span>
                <?php endif; ?>
              </td>
              <td class="mono" style="font-size: 11.5px; color: var(--admin-dim);">
                <?= htmlspecialchars($m['created_at']); ?>
              </td>
              <td><strong><?= htmlspecialchars($m['nama']); ?></strong></td>
              <td><span class="mono" style="font-size: 12.5px; color: var(--cyan);"><?= htmlspecialchars($m['kontak']); ?></span></td>
              <td style="max-width: 320px; line-height: 1.5; color: #E2E8F0;">
                <?= nl2br(htmlspecialchars($m['pesan'])); ?>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <?php if (empty($m['status_baca']) && isset($m['id'])): ?>
                    <a href="messages.php?read=<?= $m['id']; ?>" class="btn btn-secondary btn-sm" title="Tandai Dibaca"><i class="fa-solid fa-check"></i></a>
                  <?php endif; ?>
                  <?php if (isset($m['id'])): ?>
                    <a href="messages.php?del=<?= $m['id']; ?>" onclick="return confirm('Hapus pesan ini?');" class="btn btn-danger btn-sm" title="Hapus"><i class="fa-solid fa-trash"></i></a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
