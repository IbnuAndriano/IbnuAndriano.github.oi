<?php
$page_title = 'Kelola Keahlian & Tech Stack';
require_once __DIR__ . '/header.php';

$msg = '';
$edit_skill = null;

if (isset($_GET['toggle_vis'])) {
    $tid = (int)$_GET['toggle_vis'];
    hybrid_toggle_visible($koneksi, 'skills', $tid);
    $msg = "Status visibilitas keahlian berhasil diperbarui!";
}

if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    hybrid_delete($koneksi, 'skills', $del_id);
    $msg = "Skill berhasil dihapus!";
}

if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_skill = hybrid_get_by_id($koneksi, 'skills', $edit_id);
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $nama = trim($_POST['nama'] ?? '');
    $kategori = trim($_POST['kategori'] ?? 'backend');
    $level = (int)($_POST['level'] ?? 85);
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $icon = trim($_POST['icon'] ?? 'fa-solid fa-code');
    $urutan = (int)($_POST['urutan'] ?? 1);
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;

    $payload = [
        'nama'       => $nama,
        'kategori'   => $kategori,
        'level'      => $level,
        'deskripsi'  => $deskripsi,
        'icon'       => $icon,
        'urutan'     => $urutan,
        'is_visible' => $is_visible
    ];

    if ($id > 0) {
        hybrid_update($koneksi, 'skills', $id, $payload);
        $msg = "Skill '$nama' berhasil diperbarui!";
        $edit_skill = null;
    } else {
        hybrid_insert($koneksi, 'skills', $payload);
        $msg = "Skill baru '$nama' berhasil ditambahkan!";
    }
}

$skills = get_skills($koneksi, false);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<div class="dash-card">
  <div class="card-title-bar">
    <h3>
      <i class="fa-solid fa-code" style="color: var(--cyan);"></i>
      <?= $edit_skill ? 'Edit Skill: ' . htmlspecialchars($edit_skill['nama']) : 'Tambah Keahlian Baru'; ?>
    </h3>
    <?php if ($edit_skill): ?>
      <a href="skills.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> Batal Edit</a>
    <?php endif; ?>
  </div>

  <form method="POST" action="skills.php">
    <?php if ($edit_skill): ?>
      <input type="hidden" name="id" value="<?= $edit_skill['id']; ?>">
    <?php endif; ?>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nama Keahlian / Teknologi</label>
        <input type="text" name="nama" class="form-control" placeholder="Contoh: PHP (Native & OOP), MySQL..." value="<?= htmlspecialchars($edit_skill['nama'] ?? ''); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Kategori</label>
        <select name="kategori" class="form-control" required>
          <option value="backend" <?= (($edit_skill['kategori'] ?? '') === 'backend') ? 'selected' : ''; ?>>Backend & Database</option>
          <option value="frontend" <?= (($edit_skill['kategori'] ?? '') === 'frontend') ? 'selected' : ''; ?>>Frontend & UI</option>
          <option value="tools" <?= (($edit_skill['kategori'] ?? '') === 'tools') ? 'selected' : ''; ?>>System & Dev Tools</option>
          <option value="rider" <?= (($edit_skill['kategori'] ?? '') === 'rider') ? 'selected' : ''; ?>>Soft Skills & Operasional</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Tingkat Kompetensi</label>
        <select name="level" class="form-control">
          <?php $lv = (int)($edit_skill['level'] ?? 90); ?>
          <option value="92" <?= ($lv >= 88) ? 'selected' : ''; ?>>Core Competency (Utama)</option>
          <option value="84" <?= ($lv >= 80 && $lv < 88) ? 'selected' : ''; ?>>Production Ready (Siap Produksi)</option>
          <option value="75" <?= ($lv < 80) ? 'selected' : ''; ?>>Proficient (Menengah)</option>
        </select>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">FontAwesome Icon Class</label>
        <input type="text" name="icon" class="form-control" placeholder="fa-brands fa-php atau fa-solid fa-database" value="<?= htmlspecialchars($edit_skill['icon'] ?? 'fa-solid fa-code'); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Urutan Tampil</label>
        <input type="number" name="urutan" class="form-control" value="<?= htmlspecialchars($edit_skill['urutan'] ?? 1); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Deskripsi Kompetensi & Implementasi</label>
      <input type="text" name="deskripsi" class="form-control" placeholder="Contoh: Arsitektur server-side, pola MVC, prepared statements..." value="<?= htmlspecialchars($edit_skill['deskripsi'] ?? ''); ?>" required>
    </div>

    <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
      <input type="checkbox" id="is_visible" name="is_visible" value="1" <?= (!isset($edit_skill['is_visible']) || !empty($edit_skill['is_visible'])) ? 'checked' : ''; ?> style="width: 18px; height: 18px;">
      <label for="is_visible" style="color: #fff; cursor: pointer;">Tampilkan keahlian ini di Halaman Publik</label>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> <?= $edit_skill ? 'Simpan Perubahan Skill' : 'Tambah Skill'; ?>
    </button>
  </form>
</div>

<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-microchip" style="color: var(--emerald);"></i> Daftar Keahlian Teknis</h3>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Icon</th>
          <th>Nama Keahlian</th>
          <th>Kategori</th>
          <th>Deskripsi</th>
          <th>Visibilitas Publik</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($skills as $sk): 
          $vis = !isset($sk['is_visible']) || !empty($sk['is_visible']);
        ?>
          <tr style="<?= !$vis ? 'opacity: 0.55;' : ''; ?>">
            <td><i class="<?= htmlspecialchars($sk['icon']); ?>" style="font-size: 20px; color: var(--cyan);"></i></td>
            <td><strong><?= htmlspecialchars($sk['nama']); ?></strong></td>
            <td><span class="mono" style="font-size: 11px;"><?= strtoupper(htmlspecialchars($sk['kategori'])); ?></span></td>
            <td style="color: var(--admin-dim); font-size: 12.5px;"><?= htmlspecialchars($sk['deskripsi']); ?></td>
            <td>
              <?php if (isset($sk['id'])): ?>
                <a href="skills.php?toggle_vis=<?= $sk['id']; ?>" class="btn <?= $vis ? 'btn-secondary' : 'btn-danger'; ?> btn-sm">
                  <i class="fa-solid <?= $vis ? 'fa-eye' : 'fa-eye-slash'; ?>"></i>
                  <?= $vis ? 'Tampil' : 'Disembunyikan'; ?>
                </a>
              <?php endif; ?>
            </td>
            <td>
              <div style="display: flex; gap: 6px;">
                <?php if (isset($sk['id'])): ?>
                  <a href="skills.php?edit=<?= $sk['id']; ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>
                  <a href="skills.php?del=<?= $sk['id']; ?>" onclick="return confirm('Hapus skill ini?');" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
