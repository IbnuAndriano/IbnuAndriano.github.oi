<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar">
  <div class="sidebar-brand">
    <div class="brand-title">
      <i class="fa-solid fa-shield-halved" style="color: var(--cyan);"></i>
      <span>ibnu</span>.admin
    </div>
    <span class="status-badge" style="font-size: 10px; padding: 2px 8px;">PRO</span>
  </div>

  <ul class="sidebar-menu">
    <li class="menu-category">Overview</li>
    <li>
      <a href="index.php" class="sidebar-link <?= ($current_page === 'index.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-gauge-high"></i> Dashboard Utama
      </a>
    </li>

    <li class="menu-category">Privasi & Media (Admin Only)</li>
    <li>
      <a href="visibilitas.php" class="sidebar-link <?= ($current_page === 'visibilitas.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-eye-slash"></i> Kontrol Visibilitas Publik
      </a>
    </li>
    <li>
      <a href="galeri.php" class="sidebar-link <?= ($current_page === 'galeri.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-camera-retro"></i> Kelola Foto & Galeri
      </a>
    </li>

    <li class="menu-category">Manajemen Konten Portofolio</li>
    <li>
      <a href="profil.php" class="sidebar-link <?= ($current_page === 'profil.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-user-tie"></i> Profil, Foto & File CV
      </a>
    </li>
    <li>
      <a href="experience.php" class="sidebar-link <?= ($current_page === 'experience.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-briefcase"></i> Pengalaman & Magang
      </a>
    </li>
    <li>
      <a href="projects.php" class="sidebar-link <?= ($current_page === 'projects.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-layer-group"></i> Proyek & Studi Kasus
      </a>
    </li>
    <li>
      <a href="skills.php" class="sidebar-link <?= ($current_page === 'skills.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-code"></i> Tech Stack & Skill
      </a>
    </li>
    <li>
      <a href="education.php" class="sidebar-link <?= ($current_page === 'education.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-graduation-cap"></i> Riwayat Pendidikan
      </a>
    </li>
    <li>
      <a href="certificates.php" class="sidebar-link <?= ($current_page === 'certificates.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-award"></i> Sertifikasi & Lisensi
      </a>
    </li>
    <li>
      <a href="motor.php" class="sidebar-link <?= ($current_page === 'motor.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-motorcycle"></i> Aktivitas & Otomotif
      </a>
    </li>

    <li class="menu-category">Interaksi & Keamanan</li>
    <li>
      <a href="messages.php" class="sidebar-link <?= ($current_page === 'messages.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-envelope"></i> Pesan Masuk (Inbox)
      </a>
    </li>
    <li>
      <a href="akun.php" class="sidebar-link <?= ($current_page === 'akun.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-lock"></i> Akun & Keamanan Admin
      </a>
    </li>

    <li class="menu-category">Pratinjau & Sistem Terkait</li>
    <li>
      <a href="../index.php" target="_blank" class="sidebar-link">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> Lihat Tampilan Publik
      </a>
    </li>
    <li>
      <a href="../sdgs-demo.php#mod-admin" target="_blank" class="sidebar-link">
        <i class="fa-solid fa-chart-pie" style="color: var(--rose);"></i> Admin SDGs Kab. Tangerang
      </a>
    </li>
    <li>
      <a href="http://localhost/cakjoyo/admin" target="_blank" class="sidebar-link">
        <i class="fa-solid fa-bowl-food" style="color: var(--amber);"></i> Admin Soto Cak Joyo
      </a>
    </li>
  </ul>

  <div class="sidebar-footer">
    <a href="logout.php" class="btn btn-danger btn-sm" style="width: 100%;">
      <i class="fa-solid fa-right-from-bracket"></i> Keluar (Logout)
    </a>
  </div>
</aside>
