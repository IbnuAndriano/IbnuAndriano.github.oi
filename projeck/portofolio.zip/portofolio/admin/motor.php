<?php
$page_title = 'Kontrol Hobi Motoran & Gear';
require_once __DIR__ . '/header.php';

$msg = '';

// Handle Gear Checklist Add
if (isset($_POST['add_gear'])) {
    $nama_gear = trim($_POST['nama_gear'] ?? '');
    $kategori_gear = trim($_POST['kategori_gear'] ?? 'Proteksi');
    if (!empty($nama_gear)) {
        hybrid_insert($koneksi, 'gear_checklist', [
            'nama_gear' => $nama_gear,
            'kategori'  => $kategori_gear,
            'status'    => 1,
            'is_visible'=> 1
        ]);
        $msg = "Perlengkapan '$nama_gear' berhasil ditambahkan ke checklist!";
    }
}

// Handle Gear Delete
if (isset($_GET['del_gear'])) {
    $gid = (int)$_GET['del_gear'];
    hybrid_delete($koneksi, 'gear_checklist', $gid);
    $msg = "Item gear berhasil dihapus!";
}

// Handle Telemetry Update
if (isset($_POST['update_telemetry'])) {
    $model = trim($_POST['model'] ?? '');
    $tahun = trim($_POST['tahun'] ?? '');
    $odometer = trim($_POST['odometer'] ?? '');
    $rute = trim($_POST['rute_favorit'] ?? '');
    $terjauh = trim($_POST['tujuan_terjauh'] ?? '');
    $sunmori = trim($_POST['sunmori_spots'] ?? '');
    $partner = trim($_POST['partner_riding'] ?? '');
    $style = trim($_POST['riding_style'] ?? '');
    $desc = trim($_POST['deskripsi'] ?? '');

    save_motor_telemetry($koneksi, [
        'model'          => $model,
        'tahun'          => $tahun,
        'odometer'       => $odometer,
        'rute_favorit'   => $rute,
        'tujuan_terjauh' => $terjauh,
        'sunmori_spots'  => $sunmori,
        'partner_riding' => $partner,
        'riding_style'   => $style,
        'deskripsi'      => $desc
    ]);
    $msg = "Data telemetri motor dan rute touring berhasil diperbarui!";
}

$motor = get_motor_telemetry($koneksi);
$gears = get_gear_checklist($koneksi);
?>

<?php if (!empty($msg)): ?>
  <div class="alert-success">
    <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg); ?>
  </div>
<?php endif; ?>

<!-- Spek Kuda Besi & Telemetry -->
<form method="POST" action="motor.php">
  <input type="hidden" name="update_telemetry" value="1">
  <div class="dash-card">
    <div class="card-title-bar">
      <h3><i class="fa-solid fa-gauge-high" style="color: var(--amber);"></i> Spesifikasi Kuda Besi & Rute Touring</h3>
      <span class="status-badge" style="background: rgba(251,191,36,0.1); border-color: rgba(251,191,36,0.3); color: var(--amber);">RIDER TELEMETRY</span>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Model Motor</label>
        <input type="text" name="model" class="form-control" value="<?= htmlspecialchars($motor['model']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Tahun Pemakaian / Riding Sejak</label>
        <input type="text" name="tahun" class="form-control" value="<?= htmlspecialchars($motor['tahun']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Total Jarak Tempuh (Odometer)</label>
        <input type="text" name="odometer" class="form-control" value="<?= htmlspecialchars($motor['odometer']); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Rute Touring Favorit</label>
        <input type="text" name="rute_favorit" class="form-control" value="<?= htmlspecialchars($motor['rute_favorit']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Tujuan Touring Terjauh</label>
        <input type="text" name="tujuan_terjauh" class="form-control" value="<?= htmlspecialchars($motor['tujuan_terjauh']); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Titik Kumpul Sunmori (Sunday Morning Ride)</label>
        <input type="text" name="sunmori_spots" class="form-control" value="<?= htmlspecialchars($motor['sunmori_spots']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Rekan Riding (Partner)</label>
        <input type="text" name="partner_riding" class="form-control" value="<?= htmlspecialchars($motor['partner_riding']); ?>" required>
      </div>

      <div class="form-group">
        <label class="form-label">Gaya Berkendara (Riding Style)</label>
        <input type="text" name="riding_style" class="form-control" value="<?= htmlspecialchars($motor['riding_style']); ?>" required>
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Filosofi / Catatan Riding</label>
      <textarea name="deskripsi" class="form-control" rows="2" required><?= htmlspecialchars($motor['deskripsi']); ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="fa-solid fa-floppy-disk"></i> Simpan Data Motoran
    </button>
  </div>
</form>

<!-- Kelola Gear Checklist -->
<div class="dash-card">
  <div class="card-title-bar">
    <h3><i class="fa-solid fa-list-check" style="color: var(--cyan);"></i> Kelola Checklist Perlengkapan Touring</h3>
  </div>

  <form method="POST" action="motor.php" style="margin-bottom: 24px; background: rgba(255,255,255,0.02); padding: 16px; border-radius: 8px; border: 1px solid var(--admin-border);">
    <input type="hidden" name="add_gear" value="1">
    <div class="form-row" style="align-items: flex-end;">
      <div class="form-group" style="margin-bottom: 0;">
        <label class="form-label">Nama Perlengkapan / Alat</label>
        <input type="text" name="nama_gear" class="form-control" placeholder="Contoh: Lampu Cadangan, Tool Kit..." required>
      </div>

      <div class="form-group" style="margin-bottom: 0;">
        <label class="form-label">Kategori</label>
        <input type="text" name="kategori_gear" class="form-control" placeholder="Proteksi / Teknis / Elektronik" value="Proteksi" required>
      </div>

      <button type="submit" class="btn btn-primary" style="height: 42px;">
        <i class="fa-solid fa-plus"></i> Tambah Gear
      </button>
    </div>
  </form>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Nama Perlengkapan</th>
          <th>Kategori</th>
          <th>Status di Website</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($gears as $g): ?>
          <tr>
            <td><strong><?= htmlspecialchars($g['nama_gear']); ?></strong></td>
            <td><span class="mono" style="font-size: 11px;"><?= htmlspecialchars($g['kategori']); ?></span></td>
            <td><span class="status-badge"><i class="fa-solid fa-check"></i> Aktif Tampil</span></td>
            <td>
              <?php if (isset($g['id'])): ?>
                <a href="motor.php?del_gear=<?= $g['id']; ?>" onclick="return confirm('Hapus item gear ini?');" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Hapus</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
