/**
 * JAVASCRIPT INTERACTION ENGINE - PORTOFOLIO EKSEKUTIF IBNU ANDRIANO
 * Clean, Fast, Professional UI Logic (No Audio Gimmicks, Strict Read-Only Public Media)
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Theme Switcher (Dark Slate <-> Editorial Light)
  const themeToggle = document.getElementById('themeToggle');
  const THEME_KEY = 'ibnu_portfolio_theme';

  function applyTheme(theme) {
    if (theme === 'light') {
      document.documentElement.setAttribute('data-theme', 'light');
      if (themeToggle) {
        themeToggle.innerHTML = '<i class="fa-solid fa-moon"></i>';
        themeToggle.setAttribute('title', 'Beralih ke Mode Gelap');
      }
    } else {
      document.documentElement.removeAttribute('data-theme');
      if (themeToggle) {
        themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
        themeToggle.setAttribute('title', 'Beralih ke Mode Terang');
      }
    }
  }

  try {
    const savedTheme = localStorage.getItem(THEME_KEY);
    if (savedTheme) {
      applyTheme(savedTheme);
    }
  } catch (e) {}

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
      const next = current === 'light' ? 'dark' : 'light';
      applyTheme(next);
      try {
        localStorage.setItem(THEME_KEY, next);
      } catch (e) {}
    });
  }

  // 2. Mobile Navigation Menu
  const menuToggle = document.getElementById('menuToggle');
  const navMenu = document.getElementById('navMenu');
  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
      const isOpen = navMenu.classList.contains('active');
      menuToggle.innerHTML = isOpen ? '<i class="fa-solid fa-xmark"></i>' : '<i class="fa-solid fa-bars"></i>';
    });

    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
      });
    });
  }

  // Navbar elevation on scroll
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', () => {
    if (!navbar) return;
    if (window.scrollY > 24) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // 3. Dynamic Typewriter from Database Settings
  const typeText = document.getElementById('typeText');
  if (typeText) {
    const rawRoles = Array.isArray(window.PORTFOLIO_ROLES) && window.PORTFOLIO_ROLES.length > 0
      ? window.PORTFOLIO_ROLES
      : ['Full-Stack Web Developer', 'Information Systems Specialist', 'Relational Database Architect'];

    let roleIndex = 0;
    let charIndex = 0;
    let isDeleting = false;

    function runTypewriter() {
      const currentRole = rawRoles[roleIndex] || '';
      if (isDeleting) {
        typeText.textContent = currentRole.substring(0, charIndex - 1);
        charIndex--;
      } else {
        typeText.textContent = currentRole.substring(0, charIndex + 1);
        charIndex++;
      }

      let delay = isDeleting ? 35 : 75;

      if (!isDeleting && charIndex === currentRole.length) {
        isDeleting = true;
        delay = 2200;
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        roleIndex = (roleIndex + 1) % rawRoles.length;
        delay = 350;
      }

      setTimeout(runTypewriter, delay);
    }
    runTypewriter();
  }

  // 4. Interactive Architecture Console (If enabled by Admin)
  const termBody = document.getElementById('terminalBody');
  const termButtons = document.querySelectorAll('.console-btn');

  if (termBody && termButtons.length > 0) {
    const CONSOLE_DATA = window.PORTFOLIO_CONSOLE || {};
    termButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const cmd = btn.getAttribute('data-cmd');
        if (cmd === 'clear') {
          termBody.innerHTML = '<div style="color:#94A3B8;">Konsol dibersihkan. Pilih perintah di bawah untuk melihat ringkasan teknis.</div>';
          return;
        }
        const content = CONSOLE_DATA[cmd];
        if (content) {
          const block = document.createElement('div');
          block.style.marginTop = '10px';
          block.style.paddingTop = '8px';
          block.style.borderTop = '1px dashed rgba(255,255,255,0.08)';
          block.innerHTML = `<div style="color:#38BDF8;font-weight:600;">$ ${cmd}</div><div style="color:#E2E8F0;white-space:pre-wrap;margin-top:4px;">${content}</div>`;
          termBody.appendChild(block);
          termBody.scrollTop = termBody.scrollHeight;
        }
      });
    });
  }

  // 5. Skills Category Filter
  const filterBtns = document.querySelectorAll('.filter-btn');
  const skillCards = document.querySelectorAll('.skill-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const target = btn.getAttribute('data-filter');

      skillCards.forEach(card => {
        if (target === 'all' || card.getAttribute('data-category') === target) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // 6. Lifestyle / Motor Section Tabs
  const motorTabBtns = document.querySelectorAll('.motor-tab-btn');
  const motorPanels = document.querySelectorAll('.motor-panel');

  motorTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      motorTabBtns.forEach(b => b.classList.remove('active'));
      motorPanels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const tabId = btn.getAttribute('data-tab');
      const panel = document.getElementById(tabId);
      if (panel) panel.classList.add('active');
    });
  });

  // 7. Toast Notification Helper
  const toastContainer = document.getElementById('toastContainer');
  function showToast(message, icon = 'fa-solid fa-circle-check') {
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = 'toast show';
    toast.innerHTML = `<i class="${icon}" style="color: var(--accent);"></i> <span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 250);
    }, 3200);
  }
  window.showToast = showToast;

  // 8. Copy to Clipboard Buttons
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const text = btn.getAttribute('data-copy');
      if (!text) return;
      navigator.clipboard.writeText(text).then(() => {
        showToast(`Disalin ke clipboard: ${text}`);
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check"></i>';
        setTimeout(() => { btn.innerHTML = orig; }, 1600);
      }).catch(() => {
        showToast('Gagal menyalin teks secara otomatis', 'fa-solid fa-circle-exclamation');
      });
    });
  });

  // 9. Universal Modal Controller
  const modalOverlay = document.getElementById('modalOverlay');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');
  const modalClose = document.getElementById('modalClose');

  function openModal(title, htmlContent) {
    if (!modalOverlay || !modalTitle || !modalBody) return;
    modalTitle.textContent = title;
    modalBody.innerHTML = htmlContent;
    modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    if (!modalOverlay) return;
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (modalClose) modalClose.addEventListener('click', closeModal);
  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  // Project Case Study Detail Modal (100% Dynamic from Database)
  document.querySelectorAll('.view-project-detail').forEach(btn => {
    btn.addEventListener('click', () => {
      try {
        const data = JSON.parse(btn.getAttribute('data-project'));
        const features = (data.fitur_list || '')
          .split(/\r?\n/)
          .map(f => f.trim())
          .filter(Boolean)
          .map(f => `<li style="margin-bottom:6px;">${f.replace(/^\d+\.\s*/, '')}</li>`)
          .join('');

        const stackPills = (data.tech_stack || '')
          .split(',')
          .map(s => s.trim())
          .filter(Boolean)
          .map(s => `<span class="tech-tag">${s}</span>`)
          .join('');

        let actionButtons = '';
        if (data.link_hosting && data.link_hosting !== '#') {
          actionButtons += `<a href="${data.link_hosting}" target="_blank" rel="noopener" class="btn btn-accent btn-sm"><i class="fa-solid fa-globe"></i> Kunjungi Website Live</a>`;
        }
        if (data.link_demo && data.link_demo !== '#') {
          actionButtons += `<a href="${data.link_demo}" target="_blank" rel="noopener" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-up-right-from-square"></i> Buka Demo Aplikasi</a>`;
        }
        if (data.link_repo && data.link_repo !== '#') {
          actionButtons += `<a href="${data.link_repo}" target="_blank" rel="noopener" class="btn btn-secondary btn-sm"><i class="fa-brands fa-github"></i> Repositori Kode</a>`;
        }

        const html = `
          <div>
            <div style="margin-bottom: 16px;">
              <span class="pill-badge accent" style="margin-bottom: 8px;">${data.kategori || 'Software Engineering'} — ${data.semester || ''}</span>
              <h3 style="font-size: 22px; margin-bottom: 8px;">${data.judul}</h3>
              <p style="color: var(--text-muted); font-size: 14.5px; line-height: 1.65;">${data.deskripsi_singkat}</p>
            </div>
            ${features ? `
              <div style="background: var(--bg-subtle); border: 1px solid var(--border-subtle); border-radius: 10px; padding: 18px 20px; margin-bottom: 18px;">
                <h4 style="font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--accent); margin-bottom: 10px;">Modul & Spesifikasi Fungsional</h4>
                <ol style="padding-left: 18px; color: var(--text-main); font-size: 13.5px; line-height: 1.6;">${features}</ol>
              </div>
            ` : ''}
            <div style="margin-bottom: 20px;">
              <h4 style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-dim); margin-bottom: 8px;">Teknologi & Arsitektur</h4>
              <div class="tech-tags-row" style="margin-bottom:0;">${stackPills}</div>
            </div>
            <div style="display: flex; flex-wrap: wrap; gap: 10px; padding-top: 14px; border-top: 1px solid var(--border-subtle);">
              ${actionButtons}
            </div>
          </div>
        `;
        openModal('Rincian Studi Kasus & Arsitektur Proyek', html);
      } catch (err) {}
    });
  });

  // Certificate Modal
  document.querySelectorAll('.view-cert-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const name = btn.getAttribute('data-cert-name');
      const issuer = btn.getAttribute('data-cert-issuer');
      const year = btn.getAttribute('data-cert-date');
      const desc = btn.getAttribute('data-cert-desc');
      const link = btn.getAttribute('data-cert-link');

      const linkBtn = (link && link !== '#')
        ? `<a href="${link}" target="_blank" rel="noopener" class="btn btn-accent btn-sm"><i class="fa-solid fa-up-right-from-square"></i> Buka Bukti Kredensial</a>`
        : '';

      const html = `
        <div style="padding: 6px 0;">
          <span class="pill-badge accent" style="margin-bottom: 10px;">${issuer} • ${year}</span>
          <h3 style="font-size: 21px; margin-bottom: 12px;">${name}</h3>
          <div style="background: var(--bg-subtle); border: 1px solid var(--border-subtle); padding: 16px; border-radius: 8px; margin-bottom: 18px;">
            <p style="color: var(--text-main); font-size: 14px; line-height: 1.65;">${desc}</p>
          </div>
          <div style="display: flex; gap: 10px; justify-content: flex-end;">
            ${linkBtn}
          </div>
        </div>
      `;
      openModal('Detail Sertifikasi & Lisensi Kompetensi', html);
    });
  });

  // ATS CV / Resume Modal Preview
  const cvTemplate = document.getElementById('cvModalTemplate');
  document.querySelectorAll('.open-cv-modal').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (cvTemplate) {
        openModal('Curriculum Vitae (Standar ATS & Eksekutif)', cvTemplate.innerHTML);
      }
    });
  });

  // 10. Progressive AJAX Contact Form (Saves directly to MySQL via index.php)
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Mengirim...';
      }

      try {
        const formData = new FormData(contactForm);
        formData.append('ajax_request', '1');

        const response = await fetch(contactForm.getAttribute('action') || 'index.php', {
          method: 'POST',
          body: formData,
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });

        const result = await response.json();
        if (result && result.status === 'success') {
          showToast(result.message || 'Pesan Anda berhasil dikirim!', 'fa-solid fa-circle-check');
          contactForm.reset();
        } else {
          showToast((result && result.message) || 'Mohon lengkapi nama dan isi pesan.', 'fa-solid fa-circle-exclamation');
        }
      } catch (err) {
        // Fallback to standard form submission if JSON parse fails
        contactForm.submit();
        return;
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = origBtnHtml;
        }
      }
    });
  }

  // 11. Active Navigation Scroll Spy
  const sections = document.querySelectorAll('section[id]');
  window.addEventListener('scroll', () => {
    const scrollPos = window.scrollY + 130;
    sections.forEach(sec => {
      const top = sec.offsetTop;
      const height = sec.offsetHeight;
      const id = sec.getAttribute('id');
      const link = document.querySelector(`.nav-menu a[href="#${id}"]`);
      if (link) {
        if (scrollPos >= top && scrollPos < top + height) {
          link.classList.add('active');
        } else {
          link.classList.remove('active');
        }
      }
    });
  });
});
