-- ============================================================
-- DATABASE SKEMA PORTOFOLIO EKSEKUTIF IBNU ANDRIANO
-- Database Name: db_portofolio
-- Engine: InnoDB, Charset: utf8mb4
-- ============================================================

CREATE DATABASE IF NOT EXISTS `db_portofolio` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `db_portofolio`;

-- 1. Tabel Admin
DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `nama_lengkap` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `last_login` DATETIME NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default username: PadukaIbnu, password: Ibnu@3097
INSERT INTO `admin_users` (`id`, `username`, `password`, `nama_lengkap`, `email`) VALUES
(1, 'PadukaIbnu', '$2y$10$S5063T08mvIYB/w0Zx5PRuaOvKwu5dF8KO4XBDQ20yBoIcgkl6.IW', 'Ibnu Andriano', 'ibnuandrianoofficial@gmail.com');

-- 2. Tabel Site Settings / Profile & Visibility Control
DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `id` INT PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `tagline` VARCHAR(150) NOT NULL,
  `hero_headline` VARCHAR(250) NOT NULL,
  `hero_desc` TEXT NOT NULL,
  `roles_typewriter` VARCHAR(255) NOT NULL,
  `availability_text` VARCHAR(180) DEFAULT 'Terbuka untuk Magang (Internship), Kerja Full-Time & Proyek Sistem',
  `kampus` VARCHAR(150) NOT NULL,
  `prodi` VARCHAR(100) NOT NULL,
  `semester` VARCHAR(50) NOT NULL,
  `nim` VARCHAR(50) NOT NULL,
  `ipk` VARCHAR(20) NOT NULL,
  `asal` VARCHAR(100) NOT NULL,
  `whatsapp` VARCHAR(30) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `instagram` VARCHAR(50) NOT NULL,
  `linkbio` VARCHAR(150) NOT NULL,
  `github` VARCHAR(150) NOT NULL,
  `linkedin` VARCHAR(150) NOT NULL,
  `avatar_url` TEXT NOT NULL,
  `motor_image_url` TEXT NULL,
  `cv_url` VARCHAR(255) NOT NULL,
  `show_availability` TINYINT(1) DEFAULT 1,
  `show_hero_stats` TINYINT(1) DEFAULT 1,
  `show_photo` TINYINT(1) DEFAULT 1,
  `show_about` TINYINT(1) DEFAULT 1,
  `show_academic_detail` TINYINT(1) DEFAULT 1,
  `show_services` TINYINT(1) DEFAULT 1,
  `show_experience` TINYINT(1) DEFAULT 1,
  `show_projects` TINYINT(1) DEFAULT 1,
  `show_skills` TINYINT(1) DEFAULT 1,
  `show_education` TINYINT(1) DEFAULT 1,
  `show_certificates` TINYINT(1) DEFAULT 1,
  `show_motor` TINYINT(1) DEFAULT 1,
  `show_gallery` TINYINT(1) DEFAULT 1,
  `show_cv` TINYINT(1) DEFAULT 1,
  `show_contact` TINYINT(1) DEFAULT 1,
  `show_social_links` TINYINT(1) DEFAULT 1,
  `show_terminal` TINYINT(1) DEFAULT 1,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `site_settings` (
  `id`, `nama`, `tagline`, `hero_headline`, `hero_desc`, `roles_typewriter`, `availability_text`,
  `kampus`, `prodi`, `semester`, `nim`, `ipk`, `asal`, `whatsapp`, `email`, `instagram`, `linkbio`, `github`, `linkedin`,
  `avatar_url`, `motor_image_url`, `cv_url`
) VALUES (
  1,
  'Ibnu Andriano',
  'Software Developer & Information Systems Specialist',
  'Membangun Sistem Informasi & Aplikasi Web yang Terstruktur, Cepat, dan Siap Produksi.',
  'Fokus pada rekayasa perangkat lunak berbasis web (PHP, JavaScript, SQL), perancangan basis data relasional, serta pengembangan sistem informasi end-to-end yang solutif untuk kebutuhan instansi, korporasi, dan UMKM.',
  'Full-Stack Web Developer,Information Systems Specialist,Database & Backend Engineer,Web Application Architect',
  'Terbuka untuk Magang (Internship), Kerja Full-Time & Proyek Sistem',
  'Universitas Bina Bangsa',
  'S1 Sistem Informasi',
  'Mahasiswa Aktif',
  '23110001',
  '3.82 / 4.00',
  'Kabupaten Tangerang, Banten',
  '081367219097',
  'ibnuandrianoofficial@gmail.com',
  '@padukaarajaaa',
  'https://linkbio.co/ibnushop',
  'https://github.com/ibnuandriano',
  'https://linkedin.com/in/ibnuandriano',
  'images/default-avatar.svg',
  'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=800&q=80',
  '#'
);

-- 3. Tabel Pengalaman Kerja, Magang & Organisasi (Experiences)
DROP TABLE IF EXISTS `experiences`;
CREATE TABLE `experiences` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `posisi` VARCHAR(150) NOT NULL,
  `instansi` VARCHAR(150) NOT NULL,
  `jenis` VARCHAR(60) NOT NULL DEFAULT 'Proyek & Pengembangan',
  `lokasi` VARCHAR(100) NOT NULL DEFAULT 'Tangerang, Banten',
  `periode` VARCHAR(60) NOT NULL,
  `deskripsi` TEXT NOT NULL,
  `pencapaian` TEXT NULL,
  `urutan` INT DEFAULT 1,
  `is_visible` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `experiences` (`id`, `posisi`, `instansi`, `jenis`, `lokasi`, `periode`, `deskripsi`, `pencapaian`, `urutan`, `is_visible`) VALUES
(1,
 'Full-Stack Web Developer',
 'UMKM Kuliner Soto Lamongan Cak Joyo',
 'Project-Based / Implementasi',
 'Tangerang, Banten',
 '2025 - Sekarang',
 'Merancang dan membangun sistem pemesanan kuliner berbasis web dari tahap analisis kebutuhan hingga implementasi database relasional dan panel administrasi transaksi.',
 'Membangun katalog menu dinamis, keranjang belanja interaktif, dan kalkulasi pesanan otomatis\nMengintegrasikan alur pembayaran QRIS, transfer bank, dan unggah bukti transaksi\nMerancang fitur cetak nota/invoice digital dan laporan pesanan harian bagi pengelola',
 1, 1),
(2,
 'System Analyst & Lead Back-End Developer',
 'Proyek Sistem Informasi SDGs Goal 1 (Tanpa Kemiskinan)',
 'Rekayasa Sistem Informasi',
 'Universitas Bina Bangsa',
 '2024 - 2025',
 'Memimpin perancangan skema basis data dan pengkodean 10 modul terintegrasi untuk platform pendataan masyarakat pra-sejahtera, penyaluran bantuan sosial, dan pemetaan wilayah.',
 'Merancang Entity Relationship Diagram (ERD) terstruktur untuk 10 modul layanan publik\nMengembangkan fitur validasi NIK, manajemen bantuan PKH/BLT, pendampingan UMKM, dan bursa kerja\nMenyusun dashboard analitik pemantauan penurunan angka kemiskinan berbasis grafik dan peta spasial',
 2, 1),
(3,
 'Praktikum & Pengembangan Rekayasa Perangkat Lunak',
 'Program Studi Sistem Informasi — Universitas Bina Bangsa',
 'Akademik & Riset Teknis',
 'Serang / Tangerang',
 '2023 - Sekarang',
 'Aktif mengembangkan berbagai studi kasus perangkat lunak enterprise, manajemen inventaris gudang, optimasi query SQL, serta dokumentasi analisis perancangan sistem.',
 'Mempertahankan Indeks Prestasi Kumulatif (IPK) 3.82 / 4.00 dengan fokus pada Basis Data & Pemrograman Web\nMenyelesaikan studi kasus Sistem Manajemen Inventaris Gudang dengan kontrol stok real-time dan laporan PDF',
 3, 1);

-- 4. Tabel Skills
DROP TABLE IF EXISTS `skills`;
CREATE TABLE `skills` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `kategori` ENUM('frontend', 'backend', 'tools', 'rider') NOT NULL,
  `level` INT NOT NULL DEFAULT 85,
  `deskripsi` VARCHAR(255) NOT NULL,
  `icon` VARCHAR(50) NOT NULL,
  `urutan` INT DEFAULT 0,
  `is_visible` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `skills` (`id`, `nama`, `kategori`, `level`, `deskripsi`, `icon`, `urutan`, `is_visible`) VALUES
(1, 'PHP (Native & OOP)', 'backend', 90, 'Arsitektur server-side, pola MVC, autentikasi sesi, keamanan input (prepared statements), dan pembuatan endpoint API.', 'fa-brands fa-php', 1, 1),
(2, 'MySQL & Perancangan Basis Data', 'backend', 88, 'Pemodelan ERD, normalisasi 1NF–3NF, relasi foreign key, optimasi query JOIN, dan indexing tabel.', 'fa-solid fa-database', 2, 1),
(3, 'JavaScript (ES6+ & DOM)', 'frontend', 85, 'Manipulasi DOM dinamis, Fetch API / AJAX asynchronous, validasi interaktif, dan pengelolaan state di sisi klien.', 'fa-brands fa-js', 3, 1),
(4, 'HTML5 & Modern CSS3', 'frontend', 92, 'Markup semantik standar W3C, tata letak CSS Grid & Flexbox, desain responsif lintas perangkat, dan Bootstrap/Tailwind.', 'fa-brands fa-html5', 4, 1),
(5, 'Python & Algoritma Dasar', 'backend', 78, 'Pemrograman dasar, struktur data, automasi pengolahan data, dan logika pemecahan masalah komputasi.', 'fa-brands fa-python', 5, 1),
(6, 'Git & GitHub Workflow', 'tools', 84, 'Manajemen versi kode sumber, kolaborasi repositori, branching, dan dokumentasi rilis.', 'fa-brands fa-git-alt', 6, 1),
(7, 'Lingkungan Server & Deployment', 'tools', 90, 'Konfigurasi Apache, MySQL/MariaDB, manajemen phpMyAdmin, cPanel hosting, dan debugging produksi.', 'fa-solid fa-server', 7, 1),
(8, 'Analisis Sistem & Pengujian API', 'tools', 84, 'Perancangan alur sistem (Flowchart, DFD, UML), pengujian endpoint dengan Postman, dan evaluasi kebutuhan pengguna.', 'fa-solid fa-diagram-project', 8, 1);

-- 5. Tabel Pendidikan
DROP TABLE IF EXISTS `education`;
CREATE TABLE `education` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `jenjang` VARCHAR(50) NOT NULL,
  `institusi` VARCHAR(150) NOT NULL,
  `jurusan` VARCHAR(100) NOT NULL,
  `periode` VARCHAR(50) NOT NULL,
  `status` VARCHAR(50) NOT NULL,
  `deskripsi` TEXT NOT NULL,
  `urutan` INT DEFAULT 0,
  `is_visible` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `education` (`id`, `jenjang`, `institusi`, `jurusan`, `periode`, `status`, `deskripsi`, `urutan`, `is_visible`) VALUES
(1, 'Sarjana (S1)', 'Universitas Bina Bangsa', 'Sistem Informasi', '2023 - Sekarang', 'Mahasiswa Aktif (IPK 3.82)', 'Mendalami Rekayasa Perangkat Lunak, Analisis & Perancangan Sistem Informasi, Manajemen Basis Data Relasional, Pemrograman Web, dan Arsitektur Proses Bisnis.', 1, 1),
(2, 'Sekolah Menengah Atas', 'SMAS Yustika', 'MIPA', '2020 - 2023', 'Lulus', 'Fokus pada ilmu pengetahuan alam, matematika analitis, serta aktif dalam kegiatan organisasi siswa.', 2, 1),
(3, 'Sekolah Menengah Pertama', 'SMPN 3 Pakuhaji', 'Pendidikan Menengah', '2017 - 2020', 'Lulus', 'Mengembangkan minat awal pada bidang teknologi informasi dan pengoperasian perangkat komputer.', 3, 1),
(4, 'Sekolah Dasar', 'SDN Buaran Mangga II', 'Pendidikan Dasar', '2011 - 2017', 'Lulus', 'Menyelesaikan pendidikan dasar dengan pembentukan kedisiplinan dan etos belajar.', 4, 1);

-- 6. Tabel Sertifikat
DROP TABLE IF EXISTS `certificates`;
CREATE TABLE `certificates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `judul` VARCHAR(150) NOT NULL,
  `penerbit` VARCHAR(100) NOT NULL,
  `tahun` VARCHAR(20) NOT NULL,
  `deskripsi` TEXT NOT NULL,
  `link_kredensial` VARCHAR(255) NULL,
  `icon` VARCHAR(50) DEFAULT 'fa-solid fa-award',
  `is_visible` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `certificates` (`id`, `judul`, `penerbit`, `tahun`, `deskripsi`, `link_kredensial`, `icon`, `is_visible`) VALUES
(1, 'Junior Web Developer & PHP Back-End Development', 'IT Academy & Universitas Bina Bangsa', '2025', 'Sertifikasi kompetensi perancangan aplikasi web dinamis menggunakan PHP Native/OOP, manajemen sesi autentikasi, dan keamanan operasi CRUD MySQL.', '#', 'fa-solid fa-code', 1),
(2, 'Relational Database Design & SQL Query Optimization', 'Database Academy Foundation', '2024', 'Kompetensi perancangan skema basis data relasional (ERD), normalisasi 1NF hingga 3NF, pengindeksan, serta penyusunan query SQL kompleks.', '#', 'fa-solid fa-database', 1),
(3, 'Modern JavaScript DOM & Interactive Web Interface', 'Frontend Development Institute', '2024', 'Pengembangan antarmuka web responsif, manipulasi DOM modern, komunikasi asynchronous, dan integrasi komponen interaktif.', '#', 'fa-brands fa-js', 1),
(4, 'Defensive Riding & Long-Distance Touring Safety', 'Banten Motorcycle Community', '2023', 'Pelatihan keselamatan berkendara jarak jauh, manajemen fokus dan ketahanan fisik, serta prosedur darurat di jalan raya.', '#', 'fa-solid fa-shield-halved', 1);

-- 7. Tabel Projects
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `judul` VARCHAR(150) NOT NULL,
  `semester` VARCHAR(50) NOT NULL,
  `kategori` VARCHAR(100) NOT NULL,
  `deskripsi_singkat` TEXT NOT NULL,
  `fitur_list` TEXT NOT NULL,
  `tech_stack` VARCHAR(255) NOT NULL,
  `link_demo` VARCHAR(255) NULL,
  `link_hosting` VARCHAR(255) NULL,
  `link_repo` VARCHAR(255) NULL,
  `gambar` VARCHAR(255) DEFAULT 'default_project.jpg',
  `is_featured` TINYINT(1) DEFAULT 0,
  `urutan` INT DEFAULT 0,
  `is_visible` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `projects` (`id`, `judul`, `semester`, `kategori`, `deskripsi_singkat`, `fitur_list`, `tech_stack`, `link_demo`, `link_hosting`, `link_repo`, `is_featured`, `urutan`, `is_visible`) VALUES
(1,
 'Sistem Informasi Terpadu SDGs Goal 1: Penanggulangan Kemiskinan',
 'Studi Kasus Pemerintahan',
 'Public Welfare & Information System',
 'Platform web penanggulangan kemiskinan daerah berbasis data presisi untuk pendataan penduduk pra-sejahtera, distribusi bantuan sosial terverifikasi, pembinaan UMKM, bursa kerja lokal, dan pemetaan spasial.',
 '1. Pendataan Masyarakat Pra-Sejahtera (Validasi NIK, penghasilan, tanggungan, desil ekonomi)\n2. Manajemen Bantuan Sosial (PKH, BLT, Sembako, jadwal penyaluran & verifikasi)\n3. Pemberdayaan UMKM Binaan (Pendaftaran usaha, monitoring omzet, pendampingan)\n4. Portal Lowongan Kerja (Bursa kerja mitra industri, pencarian loker, unggah CV)\n5. Pelatihan & Edukasi Vokasi (Kursus keterampilan, pelatihan digital, sertifikasi)\n6. Donasi & Crowdfunding Sosial (Pengajuan bantuan darurat & transparansi dana)\n7. Dashboard Analitik SDGs (Visualisasi tren kemiskinan Chart.js & capaian target)\n8. Kanal Pengaduan Masyarakat (Laporan bantuan tidak tepat sasaran & pelacakan status)\n9. Pemetaan Spasial Wilayah (Peta interaktif zona prioritas per kelurahan/desa)\n10. Panel Eksekutif & Cetak Laporan PDF (Manajemen hak akses & rekapitulasi resmi)',
 'PHP Native, MySQL, Bootstrap 5, Chart.js, FPDF, Leaflet GIS',
 'sdgs-demo.php',
 '',
 '#',
 1, 1, 1),
(2,
 'Platform E-Commerce & POS Kuliner Soto Lamongan Cak Joyo',
 'Implementasi UMKM',
 'E-Commerce & Point of Sale',
 'Aplikasi pemesanan kuliner dan manajemen transaksi untuk UMKM Soto Lamongan Cak Joyo. Dilengkapi katalog menu dinamis, keranjang belanja real-time, integrasi pembayaran QRIS & transfer bank, cetak invoice digital, serta dashboard admin.',
 '1. Katalog Menu Dinamis & Paket Spesial\n2. Keranjang Belanja Real-Time & Kalkulasi Otomatis\n3. Multi-Metode Pembayaran (COD, Transfer Bank, QRIS)\n4. Verifikasi Unggah Bukti Pembayaran Digital\n5. Cetak Nota / Invoice Transaksi Pelanggan\n6. Dashboard Admin Manajemen Menu, Pesanan & Laporan Penjualan',
 'PHP Native, MySQL, JavaScript ES6+, Modern CSS, QRIS Integration',
 'http://localhost/cakjoyo',
 '',
 '#',
 1, 2, 1),
(3,
 'Sistem Informasi Manajemen Inventaris & Stok Gudang',
 'Enterprise System',
 'Supply Chain & Inventory',
 'Aplikasi pengelolaan inventaris barang berbasis web untuk mengontrol mutasi barang masuk dan keluar, peringatan stok minimum otomatis, serta pencetakan laporan audit bulanan.',
 '1. Master Data Barang, Satuan & Kategori\n2. Pencatatan Transaksi Barang Masuk & Barang Keluar\n3. Peringatan Otomatis Stok Minimum (Low-Stock Alert)\n4. Ekspor Laporan Stok & Rekapitulasi PDF\n5. Manajemen Multi-Akses (Admin & Staf Gudang)',
 'PHP Native, MySQL, DataTables, Bootstrap 5',
 '#',
 '',
 '#',
 0, 3, 1),
(4,
 'Vehicle Maintenance & Fuel Telemetry Log',
 'Utility Web App',
 'Personal Utility & Analytics',
 'Aplikasi pencatatan jadwal pemeliharaan berkala kendaraan, estimasi pergantian komponen berdasarkan odometer, serta kalkulator efisiensi konsumsi bahan bakar (km/liter).',
 '1. Pencatatan Odometer & Pengingat Servis Berkala\n2. Riwayat Penggantian Oli Mesin, Transmisi & Komponen\n3. Kalkulator Efisiensi Konsumsi BBM Real-Time\n4. Visualisasi Biaya Perawatan Bulanan',
 'JavaScript ES6+, LocalStorage API, Chart.js, CSS Grid',
 '#',
 '',
 '#',
 0, 4, 1);

-- 8. Tabel Motor Specs & Telemetry
DROP TABLE IF EXISTS `motor_telemetry`;
CREATE TABLE `motor_telemetry` (
  `id` INT PRIMARY KEY,
  `model` VARCHAR(100) NOT NULL,
  `tahun` VARCHAR(10) NOT NULL,
  `odometer` VARCHAR(50) NOT NULL,
  `rute_favorit` VARCHAR(150) NOT NULL,
  `tujuan_terjauh` VARCHAR(150) NOT NULL,
  `sunmori_spots` VARCHAR(150) NOT NULL,
  `partner_riding` VARCHAR(100) NOT NULL,
  `riding_style` VARCHAR(100) NOT NULL,
  `deskripsi` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `motor_telemetry` (`id`, `model`, `tahun`, `odometer`, `rute_favorit`, `tujuan_terjauh`, `sunmori_spots`, `partner_riding`, `riding_style`, `deskripsi`) VALUES
(1,
 'Honda Beat Deluxe eSP',
 '2023',
 '14.850 KM',
 'Jalur Pantura & Kawasan BSD City',
 'Bandung, Jawa Barat',
 'KP3B (Serang) & BSD City (Tangerang)',
 'Aryanto',
 'Defensive Riding, High Focus & Endurance',
 'Kendaraan andalan untuk mobilitas harian perkuliahan di Universitas Bina Bangsa sekaligus eksplorasi perjalanan jarak jauh lintas provinsi.');

-- 9. Tabel Gear Checklist
DROP TABLE IF EXISTS `gear_checklist`;
CREATE TABLE `gear_checklist` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama_gear` VARCHAR(100) NOT NULL,
  `kategori` VARCHAR(50) NOT NULL,
  `is_mandatory` TINYINT(1) DEFAULT 1,
  `status` TINYINT(1) DEFAULT 1,
  `is_visible` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `gear_checklist` (`id`, `nama_gear`, `kategori`, `is_mandatory`, `status`, `is_visible`) VALUES
(1, 'Helm Standar SNI / DOT Full Face', 'Proteksi', 1, 1, 1),
(2, 'Jaket Windproof & Pelindung Tubuh', 'Proteksi', 1, 1, 1),
(3, 'Sarung Tangan Riding Full Finger', 'Proteksi', 1, 1, 1),
(4, 'Jas Hujan Setelan Waterproof', 'Cuaca', 1, 1, 1),
(5, 'Tool Kit Kunci Pas & Peralatan Darurat', 'Teknis', 1, 1, 1),
(6, 'Power Bank & Perangkat Navigasi', 'Elektronik', 0, 1, 1),
(7, 'Kotak P3K & Obat Pribadi', 'Medis', 0, 1, 1),
(8, 'Dokumen Lengkap (SIM C, STNK, e-Money)', 'Dokumen', 1, 1, 1);

-- 10. Tabel Gallery
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `judul` VARCHAR(150) NOT NULL,
  `gambar_url` TEXT NOT NULL,
  `kategori` VARCHAR(50) NOT NULL,
  `caption` VARCHAR(255) NOT NULL,
  `is_visible` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `gallery` (`id`, `judul`, `gambar_url`, `kategori`, `caption`, `is_visible`) VALUES
(1, 'Pengembangan Arsitektur Sistem & Database', 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80', 'coding', 'Sesi perancangan basis data relasional dan pengkodean aplikasi web.', 1),
(2, 'Eksplorasi Rute Jarak Jauh Pantura', 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=800&q=80', 'motor', 'Perjalanan lintas daerah melintasi jalur Pantura menuju Bandung.', 1),
(3, 'Morning Ride Kawasan BSD & KP3B', 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=800&q=80', 'sunmori', 'Berkendara akhir pekan menjaga kebugaran dan fokus sebelum memulai pekan kuliah.', 1);

-- 11. Tabel Pesan Masuk / Kontak
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `kontak` VARCHAR(100) NOT NULL,
  `pesan` TEXT NOT NULL,
  `status_baca` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `messages` (`id`, `nama`, `kontak`, `pesan`, `status_baca`) VALUES
(1, 'Tim Rekrutmen IT Tangerang', 'hr@techpartner.id', 'Halo Ibnu, kami meninjau studi kasus sistem SDGs dan platform e-commerce Cak Joyo yang Anda bangun. Arsitektur database dan eksekusinya sangat rapi.', 1);

-- 12. Tabel Statistik Pengunjung (Analytics)
DROP TABLE IF EXISTS `visitor_logs`;
CREATE TABLE `visitor_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ip_address` VARCHAR(50) NOT NULL,
  `user_agent` TEXT NOT NULL,
  `visited_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `visitor_logs` (`id`, `ip_address`, `user_agent`) VALUES
(1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0');
