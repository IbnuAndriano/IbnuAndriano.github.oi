<?php
/**
 * CURRICULUM VITAE (CV) RESMI — IBNU ANDRIANO
 * Format Standar Profesional (1 Halaman A4 Padat, Jelas — Siap Print)
 */
require_once __DIR__ . '/koneksi.php';

$s = get_settings($koneksi);
$experiences = get_experiences($koneksi, true);
$projects = get_projects($koneksi, true);
$skills = get_skills($koneksi, true);
$education = get_education($koneksi, true);

$avatar_src = resolve_media_url($s['avatar_url'], false);
$show_photo_default = !isset($s['show_photo']) || !empty($s['show_photo']);

// Pisahkan pengalaman kerja nyata
$work_experiences = [];
foreach ($experiences as $exp) {
    $jenis_lower = strtolower($exp['jenis'] ?? '');
    if (strpos($jenis_lower, 'kerja') !== false || strpos($jenis_lower, 'magang') !== false) {
        $work_experiences[] = $exp;
    }
}

// Kelompokkan skills
$tech_skills = [];
$office_tools = [];
$soft_skills = [];
foreach ($skills as $sk) {
    $kat = $sk['kategori'] ?? '';
    if ($kat === 'backend' || $kat === 'frontend') {
        $tech_skills[] = $sk['nama'];
    } elseif ($kat === 'tools') {
        $office_tools[] = $sk['nama'];
    } else {
        $soft_skills[] = $sk['nama'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Curriculum Vitae — <?= htmlspecialchars($s['nama']); ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --ink: #0F172A;
      --ink-sub: #1E293B;
      --ink-muted: #475569;
      --line: #CBD5E1;
      --accent: #1E3A8A;
      --paper: #FFFFFF;
      --desk: #E2E8F0;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: var(--desk);
      color: var(--ink);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 11.2px;
      line-height: 1.4;
      padding: 24px 16px 40px;
      -webkit-font-smoothing: antialiased;
    }

    .cv-toolbar {
      max-width: 210mm;
      margin: 0 auto 14px;
      background: #0F172A;
      color: #F8FAFC;
      padding: 10px 16px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 10px;
    }

    .toolbar-actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }

    .tb-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 7px 13px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      border: 1px solid rgba(255, 255, 255, 0.16);
      background: rgba(255, 255, 255, 0.08);
      color: #FFFFFF;
      text-decoration: none;
    }
    .tb-btn.primary { background: #0284C7; border-color: #0284C7; }

    /* A4 Single-Page Sheet */
    .cv-sheet {
      width: 100%;
      max-width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      background: var(--paper);
      padding: 12mm 15mm;
      box-shadow: 0 12px 32px rgba(15, 23, 42, 0.14);
      border-radius: 3px;
    }

    /* Prominent Curriculum Vitae Title Bar */
    .cv-doc-title-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2.5px solid var(--accent);
      padding-bottom: 6px;
      margin-bottom: 12px;
    }

    .cv-doc-title {
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 0.22em;
      text-transform: uppercase;
      color: var(--accent);
    }

    .cv-doc-sub {
      font-size: 10px;
      font-weight: 600;
      color: var(--ink-muted);
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }

    .cv-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 18px;
      border-bottom: 1.5px solid var(--ink);
      padding-bottom: 12px;
      margin-bottom: 12px;
    }

    .cv-header-text { flex: 1; }

    .cv-name {
      font-size: 23px;
      font-weight: 800;
      letter-spacing: 0.02em;
      text-transform: uppercase;
      color: var(--ink);
      line-height: 1.1;
      margin-bottom: 3px;
    }

    .cv-role {
      font-size: 12.5px;
      font-weight: 600;
      color: var(--accent);
      margin-bottom: 6px;
    }

    .cv-contact-line {
      display: flex;
      flex-wrap: wrap;
      gap: 5px 14px;
      font-size: 10.6px;
      color: var(--ink-sub);
      font-weight: 500;
    }

    .cv-contact-item {
      display: inline-flex;
      align-items: center;
      gap: 5px;
    }

    .cv-contact-item svg {
      width: 12px;
      height: 12px;
      flex-shrink: 0;
      color: var(--ink);
    }

    .cv-photo-box {
      width: 72px;
      height: 90px;
      border-radius: 4px;
      overflow: hidden;
      border: 1.5px solid #94A3B8;
      flex-shrink: 0;
      background: #F8FAFC;
    }
    .cv-photo-box img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .cv-photo-box.hidden { display: none; }

    .cv-section { margin-bottom: 11px; }

    .cv-section-title {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      color: var(--accent);
      border-bottom: 1px solid var(--line);
      padding-bottom: 3px;
      margin-bottom: 6px;
    }

    .cv-summary {
      font-size: 11.2px;
      color: var(--ink-sub);
      text-align: justify;
      line-height: 1.48;
    }

    .cv-entry { margin-bottom: 8px; page-break-inside: avoid; }
    .cv-entry:last-child { margin-bottom: 0; }

    .cv-entry-head {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 10px;
    }

    .cv-entry-title { font-size: 11.4px; font-weight: 700; color: var(--ink); }
    .cv-entry-date { font-size: 10.5px; font-weight: 600; color: var(--ink-sub); white-space: nowrap; }

    .cv-entry-desc { font-size: 10.8px; color: var(--ink-sub); line-height: 1.38; margin-top: 1px; }

    .cv-bullets { margin-left: 16px; font-size: 10.8px; color: var(--ink-sub); margin-top: 3px; }
    .cv-bullets li { margin-bottom: 2px; }

    .cv-skills-list {
      display: flex;
      flex-direction: column;
      gap: 3px;
      font-size: 10.8px;
      color: var(--ink-sub);
    }
    .cv-skills-list strong { color: var(--ink); }

    .cv-info-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 3px 12px;
      font-size: 10.6px;
      color: var(--ink-sub);
    }

    @media print {
      @page { size: A4 portrait; margin: 9mm 12mm; }
      body { background: #FFFFFF; padding: 0; }
      .cv-toolbar { display: none !important; }
      .cv-sheet { box-shadow: none; padding: 0; max-width: 100%; min-height: auto; border-radius: 0; }
    }
  </style>
</head>
<body>

  <div class="cv-toolbar">
    <span style="font-size: 12.5px;"><strong>Curriculum Vitae — 1 Halaman A4 Siap Print</strong></span>
    <div class="toolbar-actions">
      <button type="button" class="tb-btn" id="togglePhotoBtn">
        <span id="togglePhotoLabel"><?= $show_photo_default ? 'Sembunyikan Foto' : 'Tampilkan Foto'; ?></span>
      </button>
      <button type="button" class="tb-btn primary" onclick="window.print();">
        Cetak / Simpan PDF
      </button>
      <a href="index.php" class="tb-btn">
        Kembali ke Portofolio
      </a>
    </div>
  </div>

  <main class="cv-sheet">
    <!-- Judul Dokumen Jelas -->
    <div class="cv-doc-title-bar">
      <span class="cv-doc-title">Curriculum Vitae</span>
      <span class="cv-doc-sub">Resume Profesional</span>
    </div>

    <!-- Header Identitas & Kontak -->
    <header class="cv-header">
      <div class="cv-header-text">
        <h1 class="cv-name"><?= htmlspecialchars($s['nama']); ?></h1>
        <div class="cv-role"><?= htmlspecialchars($s['tagline']); ?></div>
        <div class="cv-contact-line">
          <span class="cv-contact-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
            <?= htmlspecialchars($s['whatsapp']); ?>
          </span>
          <span class="cv-contact-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
            <?= htmlspecialchars($s['email']); ?>
          </span>
          <span class="cv-contact-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
            <?= htmlspecialchars($s['asal']); ?>
          </span>
          <?php if (!empty($s['linkbio']) && $s['linkbio'] !== '#'): ?>
          <span class="cv-contact-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
            <?= htmlspecialchars($s['linkbio']); ?>
          </span>
          <?php endif; ?>
          <?php if (!empty($s['github']) && $s['github'] !== '#'): ?>
          <span class="cv-contact-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>
            <?= htmlspecialchars(str_replace('https://', '', $s['github'])); ?>
          </span>
          <?php endif; ?>
        </div>
      </div>

      <!-- Foto Profil (Tinggal Ganti Melalui Panel Admin) -->
      <div class="cv-photo-box <?= $show_photo_default ? '' : 'hidden'; ?>" id="cvPhotoBox">
        <img src="<?= htmlspecialchars($avatar_src); ?>" alt="Foto <?= htmlspecialchars($s['nama']); ?>">
      </div>
    </header>

    <section class="cv-section">
      <h2 class="cv-section-title">Ringkasan Profesional</h2>
      <p class="cv-summary"><?= htmlspecialchars($s['hero_desc']); ?></p>
    </section>

    <?php if (!empty($work_experiences)): ?>
    <section class="cv-section">
      <h2 class="cv-section-title">Pengalaman Kerja</h2>
      <?php foreach ($work_experiences as $we):
        $bullets = array_filter(array_map('trim', preg_split('/\r?\n/', $we['pencapaian'] ?? '')));
      ?>
        <div class="cv-entry">
          <div class="cv-entry-head">
            <span class="cv-entry-title"><?= htmlspecialchars($we['posisi']); ?> — <?= htmlspecialchars($we['instansi']); ?></span>
            <span class="cv-entry-date"><?= htmlspecialchars($we['periode']); ?></span>
          </div>
          <?php if (!empty($bullets)): ?>
            <ul class="cv-bullets">
              <?php foreach ($bullets as $b): ?>
                <li><?= htmlspecialchars(preg_replace('/^[-•\d.]+\s*/', '', $b)); ?></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>

    <?php if (!empty($projects)): ?>
    <section class="cv-section">
      <h2 class="cv-section-title">Proyek Pengembangan Sistem & Aplikasi Web</h2>
      <?php foreach (array_slice($projects, 0, 3) as $pr): ?>
        <div class="cv-entry">
          <div class="cv-entry-head">
            <span class="cv-entry-title"><?= htmlspecialchars($pr['judul']); ?></span>
            <span class="cv-entry-date"><?= htmlspecialchars($pr['tech_stack']); ?></span>
          </div>
          <p class="cv-entry-desc"><?= htmlspecialchars($pr['deskripsi_singkat']); ?></p>
        </div>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>

    <?php if (!empty($education)): ?>
    <section class="cv-section">
      <h2 class="cv-section-title">Pendidikan</h2>
      <?php foreach ($education as $ed): ?>
        <div class="cv-entry" style="margin-bottom: 3.5px;">
          <div class="cv-entry-head">
            <span class="cv-entry-title"><?= htmlspecialchars($ed['institusi']); ?> — <?= htmlspecialchars($ed['jenjang']); ?> (<?= htmlspecialchars($ed['jurusan']); ?>)</span>
            <span class="cv-entry-date"><?= htmlspecialchars($ed['periode']); ?> | <?= htmlspecialchars($ed['status']); ?></span>
          </div>
        </div>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>

    <section class="cv-section">
      <h2 class="cv-section-title">Keahlian Teknis & Operasional</h2>
      <div class="cv-skills-list">
        <?php if (!empty($tech_skills)): ?>
          <div><strong>Pengembangan Web & Basis Data:</strong> <?= htmlspecialchars(implode(', ', $tech_skills)); ?></div>
        <?php endif; ?>
        <?php if (!empty($office_tools)): ?>
          <div><strong>Perangkat Lunak & Perkantoran:</strong> <?= htmlspecialchars(implode(', ', $office_tools)); ?></div>
        <?php endif; ?>
        <?php if (!empty($soft_skills)): ?>
          <div><strong>Kompetensi Operasional & Komunikasi:</strong> <?= htmlspecialchars(implode(', ', $soft_skills)); ?></div>
        <?php endif; ?>
      </div>
    </section>

    <section class="cv-section" style="margin-bottom: 0;">
      <h2 class="cv-section-title">Data Diri</h2>
      <div class="cv-info-grid">
        <div><strong>TTL:</strong> Tangerang, 30 September 2007</div>
        <div><strong>Kewarganegaraan:</strong> Indonesia</div>
        <div><strong>Media Sosial:</strong> <?= htmlspecialchars($s['instagram']); ?></div>
      </div>
    </section>
  </main>

  <script>
    const togglePhotoBtn = document.getElementById('togglePhotoBtn');
    const togglePhotoLabel = document.getElementById('togglePhotoLabel');
    const cvPhotoBox = document.getElementById('cvPhotoBox');
    if (togglePhotoBtn && cvPhotoBox) {
      togglePhotoBtn.addEventListener('click', () => {
        cvPhotoBox.classList.toggle('hidden');
        const isHidden = cvPhotoBox.classList.contains('hidden');
        togglePhotoLabel.textContent = isHidden ? 'Tampilkan Foto' : 'Sembunyikan Foto';
      });
    }
  </script>
</body>
</html>
