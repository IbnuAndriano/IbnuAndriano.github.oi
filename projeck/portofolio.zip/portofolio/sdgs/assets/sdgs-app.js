/*!
 * SIPANDU SDGs GOAL 1 — KABUPATEN TANGERANG 2026
 * Interactive Client Engine: Charts, Leaflet Map 29 Kecamatan, Modals, Payment Gateway & Official PDF Print
 */
(function () {
  'use strict';

  var DATA = window.SDGS_SERVER_DATA || {};
  var trendChart = null;
  var multiChart = null;
  var leafletMap = null;
  var mapMarkers = {};

  // =========================================================================
  // 1. THEME TOGGLE (DARK / LIGHT) — DISAMAKAN DENGAN PORTOFOLIO
  // =========================================================================
  function initTheme() {
    var saved = localStorage.getItem('sdgs_theme') || localStorage.getItem('theme') || 'dark';
    applyTheme(saved);
    var btn = document.getElementById('themeToggle');
    if (btn) {
      btn.addEventListener('click', function () {
        var cur = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
        var next = cur === 'light' ? 'dark' : 'light';
        applyTheme(next);
        localStorage.setItem('sdgs_theme', next);
      });
    }
  }

  function applyTheme(theme) {
    if (theme === 'light') {
      document.documentElement.setAttribute('data-theme', 'light');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
    var icon = document.querySelector('#themeToggle i');
    if (icon) {
      icon.className = theme === 'light' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
    }
  }

  // =========================================================================
  // 2. MODULE TAB NAVIGATION (10 MODUL TERPADU + SMOOTH SCROLL KE PETA)
  // =========================================================================
  window.switchSdgsModule = function (modId, shouldScroll) {
    var btns = document.querySelectorAll('.module-tab-btn');
    var panes = document.querySelectorAll('.module-pane');
    var targetPane = document.getElementById(modId);
    if (!targetPane) return;

    btns.forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-target') === modId);
    });
    panes.forEach(function (p) {
      p.classList.toggle('active', p.id === modId);
    });
    if (history.replaceState) {
      history.replaceState(null, null, '#' + modId);
    }

    if (shouldScroll !== false) {
      var scrollEl = (modId === 'mod-peta' && document.getElementById('mod-peta')) ? document.getElementById('mod-peta') : targetPane;
      var y = scrollEl.getBoundingClientRect().top + window.pageYOffset - 82;
      window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
    }

    if (modId === 'mod-peta') {
      setTimeout(function () {
        initOrRefreshMap();
        if (leafletMap) leafletMap.invalidateSize();
      }, 180);
    }
  };

  window.goToPetaKecamatan = function (namaKec) {
    switchSdgsModule('mod-peta', true);
    setTimeout(function () {
      initOrRefreshMap();
      if (namaKec) {
        selectKecamatanDetail(namaKec);
      }
      var mapEl = document.getElementById('sdgsMapCanvas');
      if (mapEl) {
        var y = mapEl.getBoundingClientRect().top + window.pageYOffset - 110;
        window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
      }
    }, 240);
  };

  window.openAdminLoginModal = function () {
    var html =
      '<div style="background:var(--bg-secondary);border:1px solid var(--border-accent);border-radius:10px;padding:12px 14px;margin-bottom:16px;font-size:13px;color:var(--text-muted);">' +
        '<i class="fa-solid fa-shield-halved" style="color:var(--accent)"></i> Masuk dengan akun Admin Portofolio untuk membuka kontrol penuh CRUD 10 modul, melihat NIK lengkap tanpa sensor, mengatur visibilitas modul, dan mencetak laporan PDF.' +
      '</div>' +
      '<form method="POST" action="sdgs-demo.php">' +
        '<input type="hidden" name="sdgs_action" value="sdgs_admin_login">' +
        '<div class="form-group-sdgs"><label>Username Admin</label><input type="text" name="username" class="form-input-sdgs mono" placeholder="Masukkan username admin..." autocomplete="username" required></div>' +
        '<div class="form-group-sdgs"><label>Password Admin</label><input type="password" name="password" class="form-input-sdgs mono" placeholder="Masukkan password admin..." autocomplete="current-password" required></div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-right-to-bracket"></i> Login Admin SDGs</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-lock" style="color:var(--accent)"></i> Autentikasi Admin SIPANDU SDGs 1', html);
  };

  function initTabs() {
    document.querySelectorAll('.module-tab-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        switchSdgsModule(btn.getAttribute('data-target'), true);
      });
    });
    var hash = (window.location.hash || '').replace('#', '');
    if (hash && document.getElementById(hash)) {
      switchSdgsModule(hash, false);
    }
  }

  // =========================================================================
  // 3. TOAST & MODAL HELPERS
  // =========================================================================
  window.showSdgsToast = function (msg, isError) {
    var wrap = document.getElementById('sdgsToastWrap');
    if (!wrap) return;
    var el = document.createElement('div');
    el.className = 'sdgs-toast' + (isError ? ' error' : '');
    el.innerHTML = '<i class="fa-solid ' + (isError ? 'fa-triangle-exclamation text-danger' : 'fa-circle-check') + '" style="color:' + (isError ? '#F43F5E' : '#10B981') + ';font-size:16px;"></i>' +
      '<div>' + msg + '</div>';
    wrap.appendChild(el);
    setTimeout(function () { el.remove(); }, 4500);
  };

  window.openSdgsModal = function (title, bodyHtml) {
    var ov = document.getElementById('sdgsModalOverlay');
    var ttl = document.getElementById('sdgsModalTitle');
    var bdy = document.getElementById('sdgsModalBody');
    if (!ov || !ttl || !bdy) return;
    ttl.innerHTML = title;
    bdy.innerHTML = bodyHtml;
    ov.classList.add('open');
  };

  window.closeSdgsModal = function () {
    var ov = document.getElementById('sdgsModalOverlay');
    if (ov) ov.classList.remove('open');
  };

  // =========================================================================
  // 4. CHART.JS ANALYTICS (DATA RESMI BPS KAB. TANGERANG 2020-2026)
  // =========================================================================
  function initCharts() {
    if (typeof Chart === 'undefined' || !DATA.tren) return;

    var years = Object.keys(DATA.tren);
    var miskinArr = years.map(function (y) { return DATA.tren[y].miskin_ribu; });
    var persenArr = years.map(function (y) { return DATA.tren[y].persen; });

    var ctx1 = document.getElementById('bpsTrendChart');
    if (ctx1) {
      trendChart = new Chart(ctx1, {
        type: 'bar',
        data: {
          labels: years.map(function (y) { return y === '2025' ? '2025 (BPS 2026)' : (y === '2026' ? '2026 (Proyeksi)' : y); }),
          datasets: [
            {
              type: 'line',
              label: 'Persentase Penduduk Miskin (%)',
              data: persenArr,
              borderColor: '#E5243B',
              backgroundColor: 'rgba(229, 36, 59, 0.16)',
              borderWidth: 3,
              pointBackgroundColor: '#fff',
              pointBorderColor: '#E5243B',
              pointRadius: 5,
              tension: 0.32,
              yAxisID: 'y1'
            },
            {
              type: 'bar',
              label: 'Jumlah Penduduk Miskin (Ribu Jiwa)',
              data: miskinArr,
              backgroundColor: years.map(function (y) {
                if (y === '2025') return 'rgba(229, 36, 59, 0.78)';
                if (y === '2026') return 'rgba(16, 185, 129, 0.7)';
                return 'rgba(56, 189, 248, 0.45)';
              }),
              borderColor: years.map(function (y) {
                if (y === '2025') return '#E5243B';
                if (y === '2026') return '#10B981';
                return '#38BDF8';
              }),
              borderWidth: 1,
              borderRadius: 6,
              yAxisID: 'y'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { labels: { color: '#94A3B8', font: { family: 'Plus Jakarta Sans', size: 12 } } },
            tooltip: {
              callbacks: {
                afterBody: function (items) {
                  var idx = items[0].dataIndex;
                  var yr = years[idx];
                  var row = DATA.tren[yr];
                  return row ? ('Garis Kemiskinan: Rp ' + Number(row.gk).toLocaleString('id-ID') + '/kapita/bln\nStatus: ' + row.status) : '';
                }
              }
            }
          },
          scales: {
            x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(148, 163, 184, 0.08)' } },
            y: {
              position: 'left',
              min: 200,
              max: 300,
              title: { display: true, text: 'Ribu Jiwa', color: '#38BDF8' },
              ticks: { color: '#94A3B8' },
              grid: { color: 'rgba(148, 163, 184, 0.08)' }
            },
            y1: {
              position: 'right',
              min: 5.0,
              max: 8.0,
              title: { display: true, text: 'Persentase (%)', color: '#E5243B' },
              ticks: { color: '#E5243B' },
              grid: { drawOnChartArea: false }
            }
          }
        }
      });
    }

    renderMultiIndicatorChart('all');
  }

  window.renderMultiIndicatorChart = function (mode) {
    if (typeof Chart === 'undefined' || !DATA.tren) return;
    var ctx2 = document.getElementById('sdgsCorrelationChart');
    if (!ctx2) return;
    if (multiChart) multiChart.destroy();

    var years = Object.keys(DATA.tren);
    var datasets = [];

    if (mode === 'pendidikan') {
      datasets.push({
        label: 'Rata-Rata Lama Sekolah (Tahun)',
        data: years.map(function (y) { return DATA.tren[y].rls; }),
        borderColor: '#38BDF8',
        backgroundColor: 'rgba(56, 189, 248, 0.18)',
        fill: true,
        tension: 0.35
      });
      datasets.push({
        label: 'Indeks Pembangunan Manusia (IPM)',
        data: years.map(function (y) { return DATA.tren[y].ipm; }),
        borderColor: '#10B981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.35
      });
    } else if (mode === 'kesehatan') {
      datasets.push({
        label: 'Akses Sanitasi Layak (%)',
        data: years.map(function (y) { return DATA.tren[y].sanitasi; }),
        borderColor: '#10B981',
        backgroundColor: 'rgba(16, 185, 129, 0.2)',
        fill: true,
        tension: 0.35
      });
      datasets.push({
        label: 'Persentase Kemiskinan (%)',
        data: years.map(function (y) { return DATA.tren[y].persen; }),
        borderColor: '#E5243B',
        tension: 0.35
      });
    } else if (mode === 'pendapatan') {
      datasets.push({
        label: 'Garis Kemiskinan (Ribu Rp/Kapita/Bln)',
        data: years.map(function (y) { return Math.round(DATA.tren[y].gk / 1000); }),
        borderColor: '#F59E0B',
        backgroundColor: 'rgba(245, 158, 11, 0.2)',
        fill: true,
        tension: 0.35
      });
      datasets.push({
        label: 'Tingkat Pengangguran Terbuka (%)',
        data: years.map(function (y) { return DATA.tren[y].tpt; }),
        borderColor: '#E5243B',
        tension: 0.35
      });
    } else {
      datasets.push({
        label: 'IPM Kab. Tangerang',
        data: years.map(function (y) { return DATA.tren[y].ipm; }),
        borderColor: '#38BDF8',
        tension: 0.35
      });
      datasets.push({
        label: 'Akses Sanitasi Layak (%)',
        data: years.map(function (y) { return DATA.tren[y].sanitasi; }),
        borderColor: '#10B981',
        tension: 0.35
      });
      datasets.push({
        label: 'Tingkat Pengangguran Terbuka (%)',
        data: years.map(function (y) { return DATA.tren[y].tpt; }),
        borderColor: '#F59E0B',
        tension: 0.35
      });
    }

    multiChart = new Chart(ctx2, {
      type: 'line',
      data: { labels: years, datasets: datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#94A3B8', font: { family: 'Plus Jakarta Sans', size: 11.5 } } }
        },
        scales: {
          x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(148, 163, 184, 0.08)' } },
          y: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(148, 163, 184, 0.08)' } }
        }
      }
    });
  };

  // =========================================================================
  // 5. GLOBAL INTERACTIVE FILTER (WILAYAH, TAHUN, INDIKATOR)
  // =========================================================================
  function initGlobalFilters() {
    var selKec = document.getElementById('globalFilterKecamatan');
    var selThn = document.getElementById('globalFilterTahun');
    var selInd = document.getElementById('globalFilterIndikator');
    var btnReset = document.getElementById('btnResetGlobalFilter');

    function applyGlobal() {
      var kec = selKec ? selKec.value : '';
      var thn = selThn ? selThn.value : '2025';
      var ind = selInd ? selInd.value : 'all';

      // 1. Update Tahun KPI Headline
      if (DATA.tren && DATA.tren[thn]) {
        var t = DATA.tren[thn];
        var elJml = document.getElementById('kpiBpsJumlah');
        var elPrs = document.getElementById('kpiBpsPersen');
        var elGk = document.getElementById('kpiBpsGk');
        var elIpm = document.getElementById('kpiBpsIpm');
        if (elJml) elJml.innerHTML = t.miskin_ribu.toFixed(2).replace('.', ',') + ' <small style="font-size:14px;color:var(--text-muted)">Ribu Jiwa</small>';
        if (elPrs) elPrs.innerHTML = t.persen.toFixed(2).replace('.', ',') + '%';
        if (elGk) elGk.innerHTML = 'Rp ' + Number(t.gk).toLocaleString('id-ID');
        if (elIpm) elIpm.innerHTML = 'IPM ' + t.ipm.toFixed(2).replace('.', ',') + ' • RLS ' + t.rls + ' Thn';
      }

      // 2. Update Multi-Indikator Chart
      renderMultiIndicatorChart(ind);

      // 3. Filter semua baris tabel yang memiliki atribut data-kecamatan
      document.querySelectorAll('tr[data-kecamatan], .item-bento-card[data-kecamatan]').forEach(function (row) {
        var rk = row.getAttribute('data-kecamatan') || '';
        row.style.display = (!kec || rk.toLowerCase() === kec.toLowerCase()) ? '' : 'none';
      });

      // 4. Jika di peta atau kecamatan dipilih, sorot detail kecamatan tersebut
      if (kec) {
        selectKecamatanDetail(kec);
      }
    }

    if (selKec) selKec.addEventListener('change', applyGlobal);
    if (selThn) selThn.addEventListener('change', applyGlobal);
    if (selInd) selInd.addEventListener('change', applyGlobal);
    if (btnReset) {
      btnReset.addEventListener('click', function () {
        if (selKec) selKec.value = '';
        if (selThn) selThn.value = '2025';
        if (selInd) selInd.value = 'all';
        applyGlobal();
        showSdgsToast('Filter dikembalikan ke Data Utama BPS Kabupaten Tangerang 2025/2026.');
      });
    }
  }

  // =========================================================================
  // 6. LEAFLET.JS SPATIAL MAP — 29 KECAMATAN KABUPATEN TANGERANG
  // =========================================================================
  function initOrRefreshMap() {
    var box = document.getElementById('sdgsMapCanvas');
    if (!box || typeof L === 'undefined' || !DATA.kecamatan) return;

    if (leafletMap) {
      leafletMap.invalidateSize();
      return;
    }

    leafletMap = L.map('sdgsMapCanvas').setView([-6.185, 106.525], 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      attribution: '&copy; OpenStreetMap • BPS Kab. Tangerang 2026'
    }).addTo(leafletMap);

    DATA.kecamatan.forEach(function (k) {
      var color = k.zona === 'Merah' ? '#E5243B' : (k.zona === 'Kuning' ? '#F59E0B' : '#10B981');
      var marker = L.circleMarker([k.lat, k.lng], {
        radius: Math.max(9, Math.min(20, k.miskin_ribu * 1.15)),
        fillColor: color,
        color: '#ffffff',
        weight: 2,
        opacity: 1,
        fillOpacity: 0.82
      }).addTo(leafletMap);

      marker.bindPopup(
        '<div style="font-family:Plus Jakarta Sans,sans-serif;min-width:210px;color:#0F172A;">' +
        '<div style="font-size:11px;font-weight:700;color:' + color + ';text-transform:uppercase;">KECAMATAN ' + k.nama + ' (' + k.kode + ')</div>' +
        '<div style="font-size:15px;font-weight:800;margin:3px 0;">Kemiskinan: ' + k.persen + '% (' + k.miskin_ribu + ' rb jiwa)</div>' +
        '<div style="font-size:12px;color:#475569;">Desil 1 DTSEN: <b>' + k.desil1_kk + ' KK</b> • Bansos: <b>' + k.bansos_kk + ' KK</b></div>' +
        '<div style="font-size:11.5px;color:#64748B;margin-top:5px;"><b>Fokus:</b> ' + k.fokus + '</div>' +
        '</div>'
      );

      marker.on('click', function () {
        selectKecamatanDetail(k.nama);
      });
      mapMarkers[k.nama.toLowerCase()] = marker;
    });
  }

  window.selectKecamatanDetail = function (namaKec) {
    if (!DATA.kecamatan) return;
    var found = DATA.kecamatan.find(function (x) { return x.nama.toLowerCase() === String(namaKec).toLowerCase(); });
    if (!found) return;

    var badgeCls = found.zona === 'Merah' ? 'crimson' : (found.zona === 'Kuning' ? 'amber' : 'emerald');
    var panel = document.getElementById('kecamatanDetailPanel');
    if (panel) {
      panel.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:12px;">' +
          '<span class="mono" style="font-size:12px;color:var(--accent);">KODE BPS: ' + found.kode + '</span>' +
          '<span class="pill-badge ' + badgeCls + '">Zona ' + found.zona + ' (' + found.persen + '%)</span>' +
        '</div>' +
        '<h3 style="font-size:22px;margin-bottom:6px;">Kecamatan ' + found.nama + '</h3>' +
        '<p style="font-size:13px;color:var(--text-muted);margin-bottom:16px;">Fokus Intervensi: <strong>' + found.fokus + '</strong></p>' +
        '<div class="bps-highlight-grid" style="margin-bottom:16px;">' +
          '<div class="bps-stat-box"><div class="bps-stat-label">ESTIMASI PENDUDUK MISKIN</div><div class="bps-stat-value" style="font-size:21px;">' + found.miskin_ribu + ' <small style="font-size:12px">rb jiwa</small></div><div class="bps-stat-meta">Tingkat Kemiskinan: ' + found.persen + '%</div></div>' +
          '<div class="bps-stat-box"><div class="bps-stat-label">KELUARGA DESIL 1 DTSEN</div><div class="bps-stat-value" style="font-size:21px;">' + Number(found.desil1_kk).toLocaleString('id-ID') + ' <small style="font-size:12px">KK</small></div><div class="bps-stat-meta">Penerima Bansos: ' + Number(found.bansos_kk).toLocaleString('id-ID') + ' KK</div></div>' +
          '<div class="bps-stat-box"><div class="bps-stat-label">INDIKATOR PENDIDIKAN</div><div class="bps-stat-value" style="font-size:21px;">' + found.rls + ' <small style="font-size:12px">Tahun</small></div><div class="bps-stat-meta">Rata-Rata Lama Sekolah (RLS)</div></div>' +
          '<div class="bps-stat-box"><div class="bps-stat-label">SANITASI & UMKM BINAAN</div><div class="bps-stat-value" style="font-size:21px;">' + found.sanitasi + '%</div><div class="bps-stat-meta">Sanitasi Layak • ' + found.umkm + ' Unit UMKM</div></div>' +
        '</div>' +
        '<div style="background:var(--bg-primary);border:1px solid var(--border-subtle);border-radius:8px;padding:12px;font-size:12.5px;">' +
          '<div class="mono" style="font-size:11px;color:var(--text-dim);margin-bottom:4px;">CAKUPAN DESA / KELURAHAN:</div>' +
          '<div style="color:var(--text-main);">' + found.desa + '</div>' +
        '</div>';
    }

    if (leafletMap && mapMarkers[found.nama.toLowerCase()]) {
      var mk = mapMarkers[found.nama.toLowerCase()];
      leafletMap.setView([found.lat, found.lng], 12);
      mk.openPopup();
    }
  };

  // =========================================================================
  // 7. REAL-TIME TABLE SEARCH & FILTERING
  // =========================================================================
  function initTableFilters() {
    document.querySelectorAll('[data-table-search]').forEach(function (inp) {
      inp.addEventListener('input', function () {
        var targetId = inp.getAttribute('data-table-search');
        var q = inp.value.toLowerCase().trim();
        var container = document.getElementById(targetId);
        if (!container) return;
        container.querySelectorAll('tbody tr, .filterable-card').forEach(function (el) {
          var txt = el.textContent.toLowerCase();
          el.style.display = (!q || txt.indexOf(q) !== -1) ? '' : 'none';
        });
      });
    });

    document.querySelectorAll('[data-table-select]').forEach(function (sel) {
      sel.addEventListener('change', function () {
        var targetId = sel.getAttribute('data-table-select');
        var val = sel.value.toLowerCase().trim();
        var container = document.getElementById(targetId);
        if (!container) return;
        container.querySelectorAll('tbody tr, .filterable-card').forEach(function (el) {
          var txt = el.textContent.toLowerCase();
          el.style.display = (!val || txt.indexOf(val) !== -1) ? '' : 'none';
        });
      });
    });
  }

  // =========================================================================
  // 8. MODAL WORKFLOWS (PENDUDUK, BANSOS, UMKM, LOKER, PELATIHAN, DONASI, ADUAN)
  // =========================================================================
  function getKecamatanOptions(selected) {
    if (!DATA.kecamatan) return '<option value="Pakuhaji">Pakuhaji</option>';
    return DATA.kecamatan.map(function (k) {
      var s = (selected && selected.toLowerCase() === k.nama.toLowerCase()) ? ' selected' : '';
      return '<option value="' + k.nama + '"' + s + '>' + k.nama + ' (Zona ' + k.zona + ' - ' + k.persen + '%)</option>';
    }).join('');
  }

  // --- MODUL 1: MODAL FORM PENDUDUK MISKIN ---
  window.openPendudukModal = function (data) {
    var d = data || { id: 0, nik: '360318', nama: '', jk: 'L', usia: 38, alamat_desa: '', kecamatan: 'Pakuhaji', pekerjaan: 'Buruh Harian Lepas', penghasilan: 950000, tanggungan: 4, kondisi_rumah: 'Semi Permanen', pendidikan: 'SD / Sederajat', status_ekonomi: 'Desil 1 (Kemiskinan Ekstrem)' };
    var html =
      '<form method="POST" action="sdgs-demo.php#mod-penduduk">' +
        '<input type="hidden" name="sdgs_action" value="save_penduduk">' +
        '<input type="hidden" name="id" value="' + (d.id || 0) + '">' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>NIK (16 Digit — Kode Kab. Tangerang 3603) *</label><input type="text" name="nik" class="form-input-sdgs mono" maxlength="16" pattern="\\d{16}" value="' + d.nik + '" placeholder="360318..." required></div>' +
          '<div class="form-group-sdgs"><label>Nama Lengkap Kepala Keluarga / Warga *</label><input type="text" name="nama" class="form-input-sdgs" value="' + d.nama + '" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Kecamatan (29 Kecamatan Kab. Tangerang)</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions(d.kecamatan) + '</select></div>' +
          '<div class="form-group-sdgs"><label>Alamat Desa / Kelurahan & RT/RW *</label><input type="text" name="alamat_desa" class="form-input-sdgs" value="' + d.alamat_desa + '" placeholder="Contoh: Ds. Surya Bahari RT 02/03" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Pekerjaan Utama</label><input type="text" name="pekerjaan" class="form-input-sdgs" value="' + d.pekerjaan + '" required></div>' +
          '<div class="form-group-sdgs"><label>Penghasilan Keluarga / Bulan (Rp)</label><input type="number" name="penghasilan" class="form-input-sdgs" value="' + d.penghasilan + '" min="0" step="50000" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Jumlah Tanggungan Keluarga (Jiwa)</label><input type="number" name="tanggungan" class="form-input-sdgs" value="' + d.tanggungan + '" min="1" max="20" required></div>' +
          '<div class="form-group-sdgs"><label>Klasifikasi Desil DTSEN</label><select name="status_ekonomi" class="form-input-sdgs">' +
            '<option value="Desil 1 (Kemiskinan Ekstrem)"' + (d.status_ekonomi.indexOf('Desil 1') !== -1 ? ' selected' : '') + '>Desil 1 (Kemiskinan Ekstrem)</option>' +
            '<option value="Desil 2 (Miskin)"' + (d.status_ekonomi.indexOf('Desil 2') !== -1 ? ' selected' : '') + '>Desil 2 (Miskin)</option>' +
            '<option value="Desil 3 (Rentan Miskin)"' + (d.status_ekonomi.indexOf('Desil 3') !== -1 ? ' selected' : '') + '>Desil 3 (Rentan Miskin)</option>' +
          '</select></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Kondisi Fisik Rumah & Sanitasi</label><input type="text" name="kondisi_rumah" class="form-input-sdgs" value="' + (d.kondisi_rumah || 'Semi Permanen') + '"></div>' +
          '<div class="form-group-sdgs"><label>Pendidikan Terakhir</label><input type="text" name="pendidikan" class="form-input-sdgs" value="' + (d.pendidikan || 'SD / Sederajat') + '"></div>' +
        '</div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-floppy-disk"></i> Simpan ke Database MySQL</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-id-card" style="color:var(--sdgs-red)"></i> ' + (d.id ? 'Edit Data Penduduk Miskin' : 'Registrasi Penduduk Miskin Baru (DTSEN)'), html);
  };

  window.openAnalisisKeluargaModal = function (d) {
    var gk = 684500; // Garis Kemiskinan BPS Kab. Tangerang 2025/2026
    var anggota = Math.max(1, Number(d.tanggungan) || 1);
    var perKapita = Math.round((Number(d.penghasilan) || 0) / anggota);
    var selisih = gk - perKapita;
    var diBawahGk = perKapita < gk;
    var html =
      '<div class="bps-highlight-grid" style="margin-bottom:16px;">' +
        '<div class="bps-stat-box"><div class="bps-stat-label">PENGHASILAN PER KAPITA</div><div class="bps-stat-value" style="font-size:20px;color:' + (diBawahGk ? '#FB7185' : '#10B981') + '">Rp ' + perKapita.toLocaleString('id-ID') + '</div><div class="bps-stat-meta">Rp ' + Number(d.penghasilan).toLocaleString('id-ID') + ' / ' + anggota + ' jiwa</div></div>' +
        '<div class="bps-stat-box"><div class="bps-stat-label">GARIS KEMISKINAN BPS 2026</div><div class="bps-stat-value" style="font-size:20px;">Rp ' + gk.toLocaleString('id-ID') + '</div><div class="bps-stat-meta">Acuan BPS Kab. Tangerang / kapita / bln</div></div>' +
      '</div>' +
      '<div style="background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:10px;padding:16px;margin-bottom:16px;font-size:13.5px;">' +
        '<div><strong>NIK & Nama:</strong> <span class="mono">' + d.nik + '</span> — ' + d.nama + '</div>' +
        '<div><strong>Domisili:</strong> ' + d.alamat_desa + ', Kec. ' + d.kecamatan + '</div>' +
        '<div><strong>Pekerjaan & Pendidikan:</strong> ' + d.pekerjaan + ' • ' + (d.pendidikan || '-') + '</div>' +
        '<div><strong>Kondisi Hunian:</strong> ' + (d.kondisi_rumah || '-') + '</div>' +
        '<div><strong>Status Verifikasi:</strong> <span class="pill-badge crimson">' + d.status_ekonomi + '</span></div>' +
        '<div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--border-subtle);">' +
          '<strong>Rekomendasi Sistem SDGs 1:</strong> ' +
          (diBawahGk
            ? 'Pendapatan per kapita berada <b>Rp ' + selisih.toLocaleString('id-ID') + ' di bawah Garis Kemiskinan BPS</b>. Direkomendasikan menerima intervensi prioritas <b>PKH + BPNT Sembako + PBI Kesehatan</b> serta pelatihan vokasi/UMKM.'
            : 'Pendapatan mendekati ambang batas Garis Kemiskinan. Direkomendasikan masuk program <b>Pemberdayaan UMKM & Pelatihan Vokasi</b> agar tidak jatuh ke bawah garis kemiskinan.') +
        '</div>' +
      '</div>' +
      '<div style="display:flex;justify-content:flex-end;gap:10px;">' +
        '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Tutup</button>' +
      '</div>';
    openSdgsModal('<i class="fa-solid fa-magnifying-glass-chart" style="color:var(--accent)"></i> Analisis Indikator Kemiskinan Rumah Tangga', html);
  };

  // --- MODUL 2: MODAL BANSOS & CETAK STRUK PENYALURAN ---
  window.openBansosModal = function (data) {
    var d = data || { id: 0, kode_bansos: '', nik_penerima: '360318', nama_penerima: '', kecamatan: 'Pakuhaji', jenis_bantuan: 'Program Keluarga Harapan (PKH)', nominal_paket: 'Rp 750.000 / Tahap', jadwal_penyaluran: '2026-11-25', tahap: 'Tahap IV - 2026', status_verifikasi: 'Terverifikasi' };
    var html =
      '<form method="POST" action="sdgs-demo.php#mod-bansos">' +
        '<input type="hidden" name="sdgs_action" value="save_bansos">' +
        '<input type="hidden" name="id" value="' + (d.id || 0) + '">' +
        '<input type="hidden" name="kode_bansos" value="' + (d.kode_bansos || '') + '">' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>NIK Penerima (16 Digit) *</label><input type="text" name="nik_penerima" class="form-input-sdgs mono" maxlength="16" value="' + d.nik_penerima + '" required></div>' +
          '<div class="form-group-sdgs"><label>Nama Penerima Manfaat *</label><input type="text" name="nama_penerima" class="form-input-sdgs" value="' + d.nama_penerima + '" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Kecamatan</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions(d.kecamatan) + '</select></div>' +
          '<div class="form-group-sdgs"><label>Jenis Program Bantuan Sosial</label><select name="jenis_bantuan" class="form-input-sdgs">' +
            '<option value="Program Keluarga Harapan (PKH)">Program Keluarga Harapan (PKH)</option>' +
            '<option value="BPNT / Program Sembako Pangan">BPNT / Program Sembako Pangan</option>' +
            '<option value="BLT Dana Desa Kemiskinan Ekstrem">BLT Dana Desa Kemiskinan Ekstrem</option>' +
            '<option value="PBI Jaminan Kesehatan & BPNT">PBI Jaminan Kesehatan & BPNT</option>' +
            '<option value="Program Indonesia Pintar (PIP)">Program Indonesia Pintar (PIP)</option>' +
          '</select></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Nominal / Paket Bantuan</label><input type="text" name="nominal_paket" class="form-input-sdgs" value="' + d.nominal_paket + '" required></div>' +
          '<div class="form-group-sdgs"><label>Jadwal Penyaluran</label><input type="date" name="jadwal_penyaluran" class="form-input-sdgs" value="' + d.jadwal_penyaluran + '" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Tahap Penyaluran</label><input type="text" name="tahap" class="form-input-sdgs" value="' + d.tahap + '"></div>' +
          '<div class="form-group-sdgs"><label>Status Verifikasi</label><select name="status_verifikasi" class="form-input-sdgs">' +
            '<option value="Terverifikasi">Terverifikasi</option>' +
            '<option value="Disalurkan">Disalurkan</option>' +
            '<option value="Menunggu Verifikasi">Menunggu Verifikasi</option>' +
          '</select></div>' +
        '</div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-check"></i> Simpan Penyaluran Bansos</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-hand-holding-heart" style="color:var(--sdgs-red)"></i> Jadwalkan & Verifikasi Bantuan Sosial', html);
  };

  window.printBuktiBansos = function (b) {
    var area = document.getElementById('officialPrintArea');
    if (!area) return;
    area.innerHTML =
      '<div style="border:2px solid #000;padding:24px;max-width:720px;margin:0 auto;">' +
        '<div class="print-kop">' +
          '<div><h2>PEMERINTAH KABUPATEN TANGERANG — SIPANDU SDGs GOAL 1</h2><div>Bukti Resmi Penyaluran Bantuan Sosial Terverifikasi (DTSEN 2026)</div></div>' +
          '<div style="text-align:right;font-family:monospace;font-size:12px;"><strong>' + b.kode_bansos + '</strong><br>' + b.jadwal_penyaluran + '</div>' +
        '</div>' +
        '<table class="print-table">' +
          '<tr><th style="width:200px">Kode Transaksi Bansos</th><td>' + b.kode_bansos + '</td></tr>' +
          '<tr><th>NIK Penerima Manfaat</th><td>' + b.nik_penerima + '</td></tr>' +
          '<tr><th>Nama Lengkap Penerima</th><td><strong>' + b.nama_penerima + '</strong></td></tr>' +
          '<tr><th>Wilayah Kecamatan</th><td>Kecamatan ' + b.kecamatan + ', Kabupaten Tangerang</td></tr>' +
          '<tr><th>Jenis Program Bantuan</th><td>' + b.jenis_bantuan + '</td></tr>' +
          '<tr><th>Nominal / Paket Diterima</th><td><strong>' + b.nominal_paket + '</strong></td></tr>' +
          '<tr><th>Tahap & Jadwal</th><td>' + b.tahap + ' (' + b.jadwal_penyaluran + ')</td></tr>' +
          '<tr><th>Status Verifikasi</th><td>' + b.status_verifikasi + ' (Tepat Sasaran Desil 1-2)</td></tr>' +
        '</table>' +
        '<div style="margin-top:28px;display:flex;justify-content:space-between;text-align:center;font-size:11px;">' +
          '<div>Penerima Manfaat,<br><br><br><br><strong>(' + b.nama_penerima + ')</strong></div>' +
          '<div>Petugas Verifikator Dinsos,<br><br><br><br><strong>( Ibnu Andriano — Sistem Informasi )</strong></div>' +
        '</div>' +
      '</div>';
    window.print();
  };

  // --- MODUL 3: MODAL UMKM BINAAN ---
  window.openUmkmModal = function (data) {
    var d = data || { id: 0, kode_umkm: '', nama_usaha: '', pemilik: '', kecamatan: 'Pakuhaji', kategori_usaha: 'Kuliner & Olahan Hasil Laut', omzet_bulanan: 4000000, pelatihan_diikuti: 'Pelatihan Kemasan & Pembukuan QRIS', status_pendampingan: 'Aktif Didampingi' };
    var html =
      '<form method="POST" action="sdgs-demo.php#mod-umkm">' +
        '<input type="hidden" name="sdgs_action" value="save_umkm">' +
        '<input type="hidden" name="id" value="' + (d.id || 0) + '">' +
        '<input type="hidden" name="kode_umkm" value="' + (d.kode_umkm || '') + '">' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Nama Unit Usaha UMKM *</label><input type="text" name="nama_usaha" class="form-input-sdgs" value="' + d.nama_usaha + '" required></div>' +
          '<div class="form-group-sdgs"><label>Nama Pemilik Usaha *</label><input type="text" name="pemilik" class="form-input-sdgs" value="' + d.pemilik + '" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Kecamatan</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions(d.kecamatan) + '</select></div>' +
          '<div class="form-group-sdgs"><label>Sektor / Kategori UMKM</label><select name="kategori_usaha" class="form-input-sdgs">' +
            '<option value="Kuliner & Olahan Hasil Laut">Kuliner & Olahan Hasil Laut</option>' +
            '<option value="Fesyen & Konveksi">Fesyen & Konveksi</option>' +
            '<option value="Kerajinan Bambu & Kreatif">Kerajinan Bambu & Kreatif</option>' +
            '<option value="Jasa & Bengkel Otomotif">Jasa & Bengkel Otomotif</option>' +
            '<option value="Agribisnis & Perikanan">Agribisnis & Perikanan</option>' +
          '</select></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Omzet Usaha / Bulan (Rp)</label><input type="number" name="omzet_bulanan" class="form-input-sdgs" value="' + d.omzet_bulanan + '" min="0" step="100000" required></div>' +
          '<div class="form-group-sdgs"><label>Status Inkubasi & Pendampingan</label><select name="status_pendampingan" class="form-input-sdgs">' +
            '<option value="Aktif Didampingi">Aktif Didampingi</option>' +
            '<option value="Mandiri Berkembang">Mandiri Berkembang</option>' +
            '<option value="Tahap Inkubasi Awal">Tahap Inkubasi Awal</option>' +
          '</select></div>' +
        '</div>' +
        '<div class="form-group-sdgs"><label>Program Pelatihan & Bantuan Modal yang Diterima</label><input type="text" name="pelatihan_diikuti" class="form-input-sdgs" value="' + d.pelatihan_diikuti + '" required></div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-store"></i> Simpan Data UMKM</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-store" style="color:var(--accent)"></i> ' + (d.id ? 'Edit UMKM Binaan' : 'Pendaftaran UMKM Binaan Baru'), html);
  };

  // --- MODUL 4: MODAL LAMAR KERJA & TAMBAH LOKER ---
  window.openApplyLokerModal = function (loker) {
    var html =
      '<div style="background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:8px;padding:12px 14px;margin-bottom:16px;">' +
        '<div class="mono" style="font-size:11px;color:var(--accent);">' + loker.kode_loker + ' • KEC. ' + loker.kecamatan.toUpperCase() + '</div>' +
        '<div style="font-size:16px;font-weight:700;color:var(--text-heading);">' + loker.posisi + '</div>' +
        '<div style="font-size:13px;color:var(--text-muted);">' + loker.perusahaan + ' • Gaji: <strong>' + loker.gaji + '</strong></div>' +
      '</div>' +
      '<form method="POST" action="sdgs-demo.php#mod-loker" enctype="multipart/form-data">' +
        '<input type="hidden" name="sdgs_action" value="apply_loker">' +
        '<input type="hidden" name="loker_id" value="' + loker.id + '">' +
        '<input type="hidden" name="posisi_dilamar" value="' + loker.posisi + '">' +
        '<input type="hidden" name="perusahaan" value="' + loker.perusahaan + '">' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>NIK Pelamar (16 Digit) *</label><input type="text" name="nik_pelamar" class="form-input-sdgs mono" maxlength="16" pattern="\\d{16}" placeholder="3603..." required></div>' +
          '<div class="form-group-sdgs"><label>Nama Lengkap Pelamar *</label><input type="text" name="nama_pelamar" class="form-input-sdgs" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Kecamatan Domisili</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions(loker.kecamatan) + '</select></div>' +
          '<div class="form-group-sdgs"><label>Nomor WhatsApp / HP Aktif *</label><input type="text" name="no_hp" class="form-input-sdgs" placeholder="0813..." required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Pendidikan Terakhir</label><input type="text" name="pendidikan" class="form-input-sdgs" value="' + loker.pendidikan_min + '" required></div>' +
          '<div class="form-group-sdgs"><label>Unggah Berkas CV / Resume (PDF/DOC)</label><input type="file" name="file_cv" class="form-input-sdgs" accept=".pdf,.doc,.docx"></div>' +
        '</div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-paper-plane"></i> Kirim Lamaran & CV</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-briefcase" style="color:var(--emerald)"></i> Formulir Lamaran Kerja & Upload CV', html);
  };

  window.openAddLokerModal = function () {
    var html =
      '<form method="POST" action="sdgs-demo.php#mod-loker">' +
        '<input type="hidden" name="sdgs_action" value="save_loker">' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Posisi Pekerjaan *</label><input type="text" name="posisi" class="form-input-sdgs" required></div>' +
          '<div class="form-group-sdgs"><label>Nama Perusahaan Mitra *</label><input type="text" name="perusahaan" class="form-input-sdgs" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Lokasi Kecamatan</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions('Cikupa') + '</select></div>' +
          '<div class="form-group-sdgs"><label>Kategori Industri</label><input type="text" name="kategori" class="form-input-sdgs" value="Manufaktur & Pabrik" required></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Estimasi Gaji / Bulan</label><input type="text" name="gaji" class="form-input-sdgs" value="Rp 4.850.000" required></div>' +
          '<div class="form-group-sdgs"><label>Kuota Penerimaan (Orang)</label><input type="number" name="kuota" class="form-input-sdgs" value="15" min="1" required></div>' +
        '</div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-plus"></i> Publikasikan Lowongan</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-building" style="color:var(--accent)"></i> Tambah Lowongan Kerja Mitra Industri', html);
  };

  // --- MODUL 5: PELATIHAN, MATERI & CETAK SERTIFIKAT ---
  window.openMateriModal = function (pl) {
    var lines = String(pl.materi || '').split(/\r?\n/).filter(Boolean);
    var html =
      '<div style="margin-bottom:14px;">' +
        '<span class="pill-badge cyan">' + pl.kode_pelatihan + ' • ' + pl.durasi + '</span>' +
        '<h4 style="font-size:18px;margin:8px 0 4px;">' + pl.judul + '</h4>' +
        '<div style="font-size:13px;color:var(--text-muted);">Penyelenggara: ' + pl.penyelenggara + '</div>' +
      '</div>' +
      '<div style="background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:10px;padding:16px;margin-bottom:16px;">' +
        '<div class="mono" style="font-size:11.5px;color:var(--accent);margin-bottom:10px;">SILABUS & MODUL PEMBELAJARAN TERSTRUKTUR:</div>' +
        lines.map(function (l) {
          return '<div style="padding:8px 0;border-bottom:1px solid var(--border-subtle);display:flex;align-items:center;gap:10px;"><i class="fa-solid fa-circle-check" style="color:var(--emerald)"></i><span>' + l + '</span></div>';
        }).join('') +
      '</div>' +
      '<div style="display:flex;justify-content:space-between;align-items:center;">' +
        '<span class="pill-badge emerald"><i class="fa-solid fa-certificate"></i> ' + pl.sertifikat + '</span>' +
        '<button type="button" class="btn-sdgs btn-sdgs-primary" onclick="closeSdgsModal();openEnrollModal(' + JSON.stringify(pl).replace(/"/g, '&quot;') + ')"><i class="fa-solid fa-user-plus"></i> Daftar Pelatihan Ini</button>' +
      '</div>';
    openSdgsModal('<i class="fa-solid fa-book-open" style="color:var(--accent)"></i> Kurikulum & Materi Pembelajaran', html);
  };

  window.openEnrollModal = function (pl) {
    var html =
      '<form method="POST" action="sdgs-demo.php#mod-pelatihan">' +
        '<input type="hidden" name="sdgs_action" value="enroll_pelatihan">' +
        '<input type="hidden" name="pelatihan_id" value="' + pl.id + '">' +
        '<input type="hidden" name="judul_pelatihan" value="' + pl.judul + '">' +
        '<div class="form-group-sdgs"><label>Program Pelatihan Dipilih</label><input type="text" class="form-input-sdgs" value="' + pl.judul + '" readonly></div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>NIK Peserta (16 Digit) *</label><input type="text" name="nik_peserta" class="form-input-sdgs mono" maxlength="16" pattern="\\d{16}" placeholder="3603..." required></div>' +
          '<div class="form-group-sdgs"><label>Nama Lengkap Peserta *</label><input type="text" name="nama_peserta" class="form-input-sdgs" required></div>' +
        '</div>' +
        '<div class="form-group-sdgs"><label>Kecamatan Domisili</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions('Pakuhaji') + '</select></div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-graduation-cap"></i> Daftarkan & Terbitkan Sertifikat</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-user-graduate" style="color:var(--emerald)"></i> Pendaftaran Peserta Pelatihan Vokasi', html);
  };

  window.printSertifikatPelatihan = function (ps) {
    var area = document.getElementById('officialPrintArea');
    if (!area) return;
    area.innerHTML =
      '<div style="border:6px double #1E3A5F;padding:38px;text-align:center;">' +
        '<div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;">PEMERINTAH KABUPATEN TANGERANG • PROGRAM PEMBERDAYAAN SDGs GOAL 1</div>' +
        '<h1 style="font-size:28px;margin:12px 0 4px;color:#000;">SERTIFIKAT KOMPETENSI PELATIHAN</h1>' +
        '<div style="font-family:monospace;font-size:12px;margin-bottom:22px;">Nomor Registrasi: <strong>' + ps.no_sertifikat + '</strong></div>' +
        '<div>Diberikan dengan bangga kepada:</div>' +
        '<div style="font-size:24px;font-weight:800;margin:10px auto 6px;border-bottom:2px solid #000;display:inline-block;padding:0 28px 4px;">' + ps.nama_peserta + '</div>' +
        '<div style="font-size:12px;margin-bottom:18px;">NIK: ' + ps.nik_peserta + ' • Kecamatan ' + ps.kecamatan + ', Kabupaten Tangerang</div>' +
        '<div style="max-width:560px;margin:0 auto 24px;font-size:13px;line-height:1.6;">Telah menyelesaikan dan dinyatakan <strong>' + ps.status_peserta.toUpperCase() + '</strong> pada program:<br><strong style="font-size:15px;">' + ps.judul_pelatihan + '</strong><br>dalam rangka peningkatan kapasitas SDM dan pengentasan kemiskinan daerah (SDGs Goal 1).</div>' +
        '<div style="margin-top:34px;display:flex;justify-content:space-around;font-size:11.5px;">' +
          '<div>Kabupaten Tangerang, ' + new Date().toLocaleDateString('id-ID') + '<br>Koordinator Program Vokasi SDGs 1<br><br><br><br><strong>( Ibnu Andriano )</strong></div>' +
          '<div>Mengetahui,<br>Kepala UPTD Pelatihan & Pemberdayaan<br><br><br><br><strong>( NIP. 19840312 201001 1 008 )</strong></div>' +
        '</div>' +
      '</div>';
    window.print();
  };

  // --- MODUL 6: PAYMENT GATEWAY DONASI (QRIS / VA / E-WALLET SEPERTI CAK JOYO) ---
  window.openDonasiGatewayModal = function (km) {
    var html =
      '<div style="background:var(--bg-secondary);border:1px solid var(--border-sdgs);border-radius:10px;padding:14px;margin-bottom:16px;">' +
        '<div class="mono" style="font-size:11px;color:#FB7185;">' + km.kode_kampanye + ' • KEC. ' + km.kecamatan.toUpperCase() + '</div>' +
        '<div style="font-size:15.5px;font-weight:700;color:var(--text-heading);margin:3px 0;">' + km.judul + '</div>' +
        '<div style="font-size:12.5px;color:var(--text-muted);">Penerima Manfaat: <strong>' + km.penerima_manfaat + '</strong></div>' +
      '</div>' +
      '<form method="POST" action="sdgs-demo.php#mod-donasi">' +
        '<input type="hidden" name="sdgs_action" value="submit_donasi">' +
        '<input type="hidden" name="kampanye_id" value="' + km.id + '">' +
        '<input type="hidden" name="judul_kampanye" value="' + km.judul + '">' +
        '<div class="form-group-sdgs">' +
          '<label>Pilih Nominal Cepat atau Masukkan Nominal Donasi (Rp) *</label>' +
          '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">' +
            '<button type="button" class="btn-sdgs btn-sdgs-sm" onclick="document.getElementById(\'inpNominalDonasi\').value=50000">Rp 50.000</button>' +
            '<button type="button" class="btn-sdgs btn-sdgs-sm" onclick="document.getElementById(\'inpNominalDonasi\').value=100000">Rp 100.000</button>' +
            '<button type="button" class="btn-sdgs btn-sdgs-sm" onclick="document.getElementById(\'inpNominalDonasi\').value=250000">Rp 250.000</button>' +
            '<button type="button" class="btn-sdgs btn-sdgs-sm" onclick="document.getElementById(\'inpNominalDonasi\').value=500000">Rp 500.000</button>' +
            '<button type="button" class="btn-sdgs btn-sdgs-sm" onclick="document.getElementById(\'inpNominalDonasi\').value=1000000">Rp 1.000.000</button>' +
          '</div>' +
          '<input type="number" id="inpNominalDonasi" name="nominal" class="form-input-sdgs mono" value="100000" min="10000" step="10000" required>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Nama Donatur (Kosongkan untuk Hamba Allah)</label><input type="text" name="nama_donatur" class="form-input-sdgs" placeholder="Contoh: Ibnu Andriano"></div>' +
          '<div class="form-group-sdgs"><label>Kanal Payment Gateway</label><select name="metode_pembayaran" class="form-input-sdgs">' +
            '<option value="QRIS Dinamis">QRIS Dinamis (Semua Bank & E-Wallet)</option>' +
            '<option value="BCA Virtual Account">BCA Virtual Account (8801-081367219097)</option>' +
            '<option value="Mandiri Virtual Account">Mandiri Virtual Account (8902-081367219097)</option>' +
            '<option value="BRI Virtual Account (BRIVA)">BRI Virtual Account / BRIVA</option>' +
            '<option value="GoPay / DANA / OVO">E-Wallet GoPay / DANA / OVO (085129763119)</option>' +
          '</select></div>' +
        '</div>' +
        '<div class="form-group-sdgs"><label>Pesan / Doa Dukungan</label><input type="text" name="pesan" class="form-input-sdgs" placeholder="Semoga bermanfaat dan membawa keberkahan..."></div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-shield-heart"></i> Bayar & Konfirmasi Donasi</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-qrcode" style="color:var(--emerald)"></i> Payment Gateway Donasi Sosial SDGs 1', html);
  };

  window.openAddKampanyeModal = function () {
    var html =
      '<form method="POST" action="sdgs-demo.php#mod-donasi">' +
        '<input type="hidden" name="sdgs_action" value="save_kampanye">' +
        '<div class="form-group-sdgs"><label>Judul Kampanye Bantuan / Crowdfunding *</label><input type="text" name="judul" class="form-input-sdgs" placeholder="Contoh: Bedah Rumah Lansia Desil 1..." required></div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Kategori Program</label><select name="kategori" class="form-input-sdgs"><option value="Bedah Rumah & Sanitasi">Bedah Rumah & Sanitasi</option><option value="Pendidikan Anak Desil 1">Pendidikan Anak Desil 1</option><option value="Pemberdayaan Ekonomi">Pemberdayaan Ekonomi</option><option value="Pangan & Kesehatan Darurat">Pangan & Kesehatan Darurat</option></select></div>' +
          '<div class="form-group-sdgs"><label>Lokasi Kecamatan</label><select name="kecamatan" class="form-input-sdgs">' + getKecamatanOptions('Pakuhaji') + '</select></div>' +
        '</div>' +
        '<div class="form-row-2">' +
          '<div class="form-group-sdgs"><label>Penerima Manfaat *</label><input type="text" name="penerima_manfaat" class="form-input-sdgs" required></div>' +
          '<div class="form-group-sdgs"><label>Target Dana (Rp) *</label><input type="number" name="target_dana" class="form-input-sdgs" value="20000000" min="1000000" step="500000" required></div>' +
        '</div>' +
        '<div class="form-group-sdgs"><label>Rencana Penggunaan Dana Transparan</label><textarea name="laporan_penggunaan" class="form-input-sdgs" rows="3">1. Pengadaan material utama bantuan: 70%\n2. Penyaluran langsung dan pendampingan lapangan: 30%</textarea></div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-plus"></i> Terbitkan Kampanye</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-hand-holding-dollar" style="color:var(--accent)"></i> Buat Pengajuan Bantuan Crowdfunding Baru', html);
  };

  // --- MODUL 8: TINDAK LANJUT PENGADUAN MASYARAKAT ---
  window.openTindakLanjutModal = function (ad) {
    var html =
      '<div style="background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:8px;padding:12px;margin-bottom:14px;font-size:13px;">' +
        '<div class="mono" style="color:var(--accent);">TIKET: ' + ad.kode_tiket + ' • KEC. ' + ad.kecamatan + '</div>' +
        '<div style="font-weight:700;margin:4px 0;">' + ad.kategori_aduan + ' — ' + ad.lokasi_desa + '</div>' +
        '<div style="color:var(--text-muted);">"' + ad.isi_laporan + '"</div>' +
      '</div>' +
      '<form method="POST" action="sdgs-demo.php#mod-pengaduan">' +
        '<input type="hidden" name="sdgs_action" value="update_pengaduan">' +
        '<input type="hidden" name="id" value="' + ad.id + '">' +
        '<div class="form-group-sdgs"><label>Tahap Status Penanganan Pengaduan</label><select name="status_aduan" class="form-input-sdgs">' +
          '<option value="Laporan Diterima"' + (ad.status_aduan === 'Laporan Diterima' ? ' selected' : '') + '>1. Laporan Diterima</option>' +
          '<option value="Verifikasi Lapangan"' + (ad.status_aduan === 'Verifikasi Lapangan' ? ' selected' : '') + '>2. Verifikasi Lapangan (Ground-Check TKSK)</option>' +
          '<option value="Tindak Lanjut Dinsos"' + (ad.status_aduan === 'Tindak Lanjut Dinsos' ? ' selected' : '') + '>3. Tindak Lanjut Dinas Sosial</option>' +
          '<option value="Selesai Ditangani"' + (ad.status_aduan === 'Selesai Ditangani' ? ' selected' : '') + '>4. Selesai Ditangani</option>' +
        '</select></div>' +
        '<div class="form-group-sdgs"><label>Catatan Resmi Tindak Lanjut Petugas</label><textarea name="tindak_lanjut" class="form-input-sdgs" rows="3" required>' + (ad.tindak_lanjut || '') + '</textarea></div>' +
        '<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">' +
          '<button type="button" class="btn-sdgs" onclick="closeSdgsModal()">Batal</button>' +
          '<button type="submit" class="btn-sdgs btn-sdgs-primary"><i class="fa-solid fa-check-double"></i> Simpan Tindak Lanjut</button>' +
        '</div>' +
      '</form>';
    openSdgsModal('<i class="fa-solid fa-clipboard-check" style="color:var(--amber)"></i> Update Status & Tindak Lanjut Pengaduan', html);
  };

  // --- MODUL 10: GENERATOR CETAK LAPORAN EKSEKUTIF PDF (A4 RESMI) ---
  window.printOfficialSdgsReport = function (reportType) {
    var area = document.getElementById('officialPrintArea');
    if (!area || !DATA.kecamatan) return;

    var rowsHtml = DATA.kecamatan.map(function (k, idx) {
      return '<tr>' +
        '<td>' + (idx + 1) + '</td>' +
        '<td>' + k.kode + '</td>' +
        '<td><strong>' + k.nama + '</strong></td>' +
        '<td>Zona ' + k.zona + '</td>' +
        '<td style="text-align:right">' + k.persen + '%</td>' +
        '<td style="text-align:right">' + k.miskin_ribu + ' rb</td>' +
        '<td style="text-align:right">' + k.desil1_kk + ' KK</td>' +
        '<td style="text-align:right">' + k.bansos_kk + ' KK</td>' +
        '<td>' + k.fokus + '</td>' +
      '</tr>';
    }).join('');

    area.innerHTML =
      '<div>' +
        '<div class="print-kop">' +
          '<div>' +
            '<h2>SISTEM INFORMASI PENANGGULANGAN KEMISKINAN TERPADU (SIPANDU SDGs GOAL 1)</h2>' +
            '<div>Kabupaten Tangerang, Provinsi Banten — Laporan Eksekutif Data Resmi BPS 2026 & Monitoring 10 Modul</div>' +
          '</div>' +
          '<div style="text-align:right;font-size:10.5px;">' +
            '<strong>Dokumen: ' + (reportType || 'LAP-SDGS1-TNG-2026') + '</strong><br>' +
            'Tanggal Cetak: ' + new Date().toLocaleDateString('id-ID') +
          '</div>' +
        '</div>' +
        '<div style="margin-bottom:12px;font-size:10.5px;line-height:1.5;">' +
          '<strong>Ringkasan Eksekutif BPS Kabupaten Tangerang 2026:</strong> Berdasarkan publikasi <em>Statistik Daerah Kabupaten Tangerang 2026</em> (BPS, rilis 25 September 2026) dan <em>Kabupaten Tangerang Dalam Angka 2026</em> (BPS, rilis 27 Februari 2026), jumlah penduduk miskin tahun 2025 di Kabupaten Tangerang tercatat sebesar <strong>265,90 ribu jiwa (6,42% dari total penduduk)</strong>, menurun dibandingkan tahun 2024 (266,43 ribu jiwa / 6,55%). Garis Kemiskinan daerah tercatat Rp 684.500/kapita/bulan dengan IPM 75,04.' +
        '</div>' +
        '<table class="print-table">' +
          '<thead><tr><th>No</th><th>Kode BPS</th><th>Kecamatan</th><th>Zona</th><th>% Miskin</th><th>Jml Miskin</th><th>Desil 1 DTSEN</th><th>Bansos</th><th>Fokus Intervensi Utama</th></tr></thead>' +
          '<tbody>' + rowsHtml + '</tbody>' +
        '</table>' +
        '<div style="margin-top:14px;font-size:9.5px;">' +
          '<strong>Referensi Resmi:</strong> (1) BPS Kab. Tangerang — Statistik Daerah Kab. Tangerang 2026 (25 Sep 2026); (2) BPS Kab. Tangerang — Kab. Tangerang Dalam Angka 2026 (27 Feb 2026); (3) Portal Open Data Kab. Tangerang (opendata.tangerangkab.go.id); (4) Dashboard DTSEN 2026 Kemenko PM.' +
        '</div>' +
        '<div style="margin-top:24px;display:flex;justify-content:space-between;text-align:center;font-size:10.5px;">' +
          '<div>Disusun oleh,<br>Lead System Analyst & Developer<br><br><br><br><strong>( Ibnu Andriano — NIM 23110001 )</strong><br>S1 Sistem Informasi — Universitas Bina Bangsa</div>' +
          '<div>Tigaraksa, ' + new Date().toLocaleDateString('id-ID') + '<br>Mengetahui, Koordinator Evaluasi SDGs Daerah<br><br><br><br><strong>( Bappeda & Dinas Sosial Kab. Tangerang )</strong></div>' +
        '</div>' +
      '</div>';
    window.print();
  };

  // =========================================================================
  // 9. INITIALIZE ALL COMPONENTS ON DOM READY
  // =========================================================================
  document.addEventListener('DOMContentLoaded', function () {
    initTheme();
    initTabs();
    initCharts();
    initGlobalFilters();
    initTableFilters();
    if (DATA.kecamatan && DATA.kecamatan.length > 0) {
      selectKecamatanDetail('Pakuhaji');
    }
    var ov = document.getElementById('sdgsModalOverlay');
    if (ov) {
      ov.addEventListener('click', function (e) {
        if (e.target === ov) closeSdgsModal();
      });
    }
  });
})();
