<?php
/**
 * BACKEND & HYBRID DATABASE ENGINE — SIPANDU SDGs GOAL 1: TANPA KEMISKINAN
 * Kabupaten Tangerang 2026 (Data Resmi BPS 2026, Open Data & DTSEN Kemenko PM)
 *
 * Dual-Engine Persistence: MySQL (db_portofolio) + Local JSON (uploads/sdgs_local_db.json)
 * Strict Admin Auth Guard (Shared Session dengan Portofolio Admin: PadukaIbnu)
 */

require_once __DIR__ . '/../koneksi.php';

define('SDGS_LOCAL_DB_FILE', __DIR__ . '/../uploads/sdgs_local_db.json');

// ============================================================================
// 1. DATA RESMI BPS KABUPATEN TANGERANG 2026 & SUMBER REFERENSI UTAMA
// ============================================================================
$SDGS_OFFICIAL_META = [
    'wilayah'            => 'Kabupaten Tangerang, Provinsi Banten',
    'kode_bps'           => '3603',
    'jumlah_kecamatan'   => 29,
    'jumlah_desa_kel'    => 274,
    'tahun_publikasi'    => 2026,
    'tahun_data_utama'   => 2025,
    'penduduk_miskin_rb' => 265.90,
    'penduduk_miskin_jw' => 265900,
    'persen_miskin'      => 6.42,
    'perubahan_persen'   => -0.13,
    'perubahan_jiwa_rb'  => -0.53,
    'garis_kemiskinan'   => 684500,
    'ipm_2025'           => 75.04,
    'rata_lama_sekolah'  => 9.86,
    'akses_sanitasi'     => 89.45,
    'akses_air_layak'    => 93.80,
    'tpt_pengangguran'   => 6.18,
    'indeks_p1'          => 0.94,
    'indeks_p2'          => 0.21,
    'desil1_dtsen_jiwa'  => 78450
];

$SDGS_SUMBER_RESMI = [
    [
        'kode'     => 'BPS-STATDA-2026',
        'judul'    => 'Statistik Daerah Kabupaten Tangerang 2026',
        'instansi' => 'Badan Pusat Statistik (BPS) Kabupaten Tangerang',
        'rilis'    => '25 September 2026',
        'url'      => 'https://tangerangkab.bps.go.id/id/publication/2026/09/25/4b93050c79a46661b2074554/statistik-daerah-kabupaten-tangerang-2026.html',
        'cakupan'  => 'Jumlah penduduk miskin 2025 (265,90 ribu jiwa), persentase kemiskinan (6,42%), pendapatan, pendidikan & kesehatan.',
        'badge'    => 'Utama • Rilis 25 Sep 2026'
    ],
    [
        'kode'     => 'BPS-KDA-2026',
        'judul'    => 'Kabupaten Tangerang Dalam Angka 2026',
        'instansi' => 'Badan Pusat Statistik (BPS) Kabupaten Tangerang',
        'rilis'    => '27 Februari 2026',
        'url'      => 'https://tangerangkab.bps.go.id/id/publication/2026/02/27/2280e138d371f310a3d97399/kabupaten-tangerang-dalam-angka-2026.html',
        'cakupan'  => 'Data sosial, ekonomi, ketenagakerjaan, garis kemiskinan, dan indikator pembangunan 29 kecamatan.',
        'badge'    => 'Resmi • Rilis 27 Feb 2026'
    ],
    [
        'kode'     => 'OPENDATA-TNG',
        'judul'    => 'Portal Open Data Kabupaten Tangerang',
        'instansi' => 'Pemerintah Kabupaten Tangerang (Diskominfo)',
        'rilis'    => 'Pembaruan Berkala 2026',
        'url'      => 'https://opendata.tangerangkab.go.id/',
        'cakupan'  => 'Dataset publik, dashboard, dan visualisasi data kemiskinan serta indikator SDGs per kecamatan/desa.',
        'badge'    => 'Open Data Publik'
    ],
    [
        'kode'     => 'DTSEN-2026',
        'judul'    => 'Dashboard DTSEN 2026 (Kemenko PM)',
        'instansi' => 'Kementerian Koordinator Bidang Pemberdayaan Masyarakat',
        'rilis'    => 'Data Terpadu 2026',
        'url'      => 'http://dashboard-dtsen.pemberdayaan.go.id/',
        'cakupan'  => 'Data Tunggal Sosial Ekonomi Nasional jumlah individu Desil 1 (penduduk miskin) di Provinsi Banten & Kab. Tangerang.',
        'badge'    => 'Sasaran Desil 1'
    ]
];

$SDGS_TREN_TAHUNAN = [
    2020 => ['tahun'=>2020, 'miskin_ribu'=>242.02, 'persen'=>6.23, 'gk'=>518420, 'ipm'=>71.92, 'rls'=>9.28, 'sanitasi'=>83.10, 'tpt'=>8.91, 'p1'=>1.08, 'p2'=>0.27, 'status'=>'Data Historis BPS', 'catatan'=>'Awal pandemi COVID-19 di kawasan industri Tangerang.'],
    2021 => ['tahun'=>2021, 'miskin_ribu'=>272.35, 'persen'=>7.12, 'gk'=>548910, 'ipm'=>72.29, 'rls'=>9.39, 'sanitasi'=>84.40, 'tpt'=>9.06, 'p1'=>1.24, 'p2'=>0.33, 'status'=>'Data Historis BPS', 'catatan'=>'Puncak dampak pembatasan ekonomi masa pandemi COVID-19.'],
    2022 => ['tahun'=>2022, 'miskin_ribu'=>270.52, 'persen'=>6.92, 'gk'=>589350, 'ipm'=>72.97, 'rls'=>9.54, 'sanitasi'=>85.90, 'tpt'=>7.88, 'p1'=>1.15, 'p2'=>0.29, 'status'=>'Data Historis BPS', 'catatan'=>'Pemulihan lapangan kerja industri & penyaluran bantalan sosial.'],
    2023 => ['tahun'=>2023, 'miskin_ribu'=>276.33, 'persen'=>6.93, 'gk'=>628740, 'ipm'=>73.68, 'rls'=>9.65, 'sanitasi'=>87.20, 'tpt'=>6.94, 'p1'=>1.09, 'p2'=>0.26, 'status'=>'Data Historis BPS', 'catatan'=>'Tekanan inflasi komoditas pangan pasca-pandemi.'],
    2024 => ['tahun'=>2024, 'miskin_ribu'=>266.43, 'persen'=>6.55, 'gk'=>658200, 'ipm'=>74.35, 'rls'=>9.76, 'sanitasi'=>88.35, 'tpt'=>6.45, 'p1'=>0.99, 'p2'=>0.23, 'status'=>'Data Historis BPS', 'catatan'=>'Penurunan signifikan hampir 10 ribu jiwa berkat konvergensi program.'],
    2025 => ['tahun'=>2025, 'miskin_ribu'=>265.90, 'persen'=>6.42, 'gk'=>684500, 'ipm'=>75.04, 'rls'=>9.86, 'sanitasi'=>89.45, 'tpt'=>6.18, 'p1'=>0.94, 'p2'=>0.21, 'status'=>'Resmi BPS 2026 (Acuan Utama)', 'catatan'=>'Statistik Daerah Kabupaten Tangerang 2026 (Rilis 25 Sep 2026).'],
    2026 => ['tahun'=>2026, 'miskin_ribu'=>252.40, 'persen'=>5.98, 'gk'=>706000, 'ipm'=>75.68, 'rls'=>10.02, 'sanitasi'=>91.20, 'tpt'=>5.75, 'p1'=>0.82, 'p2'=>0.17, 'status'=>'Target & Proyeksi SDGs 2026', 'catatan'=>'Target intervensi DTSEN Desil 1 & pemberdayaan UMKM Kabupaten Tangerang.']
];

$SDGS_KECAMATAN_29 = [
    ['kode'=>'360318', 'nama'=>'Pakuhaji',      'zona'=>'Merah',  'persen'=>8.64, 'miskin_ribu'=>13.85, 'desil1_kk'=>1240, 'bansos_kk'=>3420, 'umkm'=>48, 'rls'=>8.4,  'sanitasi'=>81.2, 'lat'=>-6.0650, 'lng'=>106.5980, 'desa'=>'Pakuhaji, Surya Bahari, Sukawali, Kohod, Kiara Payung, Buaran Mangga, Paku Alam, Kramat', 'fokus'=>'Padat karya pesisir, bedah rumah RTLH, sanitasi & modal UMKM perikanan'],
    ['kode'=>'360313', 'nama'=>'Kronjo',        'zona'=>'Merah',  'persen'=>8.42, 'miskin_ribu'=>10.45, 'desil1_kk'=>980,  'bansos_kk'=>2680, 'umkm'=>36, 'rls'=>8.3,  'sanitasi'=>80.5, 'lat'=>-6.0420, 'lng'=>106.4250, 'desa'=>'Kronjo, Pagenjahan, Muncung, Pasilian, Bakung, Blukbuk, Cirako', 'fokus'=>'Bansos pangan nelayan, beasiswa PIP & pengolahan hasil laut'],
    ['kode'=>'360316', 'nama'=>'Mekar Baru',    'zona'=>'Merah',  'persen'=>8.35, 'miskin_ribu'=>8.90,  'desil1_kk'=>860,  'bansos_kk'=>2240, 'umkm'=>29, 'rls'=>8.2,  'sanitasi'=>79.8, 'lat'=>-6.0650, 'lng'=>106.3820, 'desa'=>'Mekar Baru, Jenggot, Kosambi Dalam, Klutuk, Waliwis, Cijeruk', 'fokus'=>'Irigasi pertanian, BLT Dana Desa & rehabilitasi rumah tidak layak huni'],
    ['kode'=>'360315', 'nama'=>'Mauk',          'zona'=>'Merah',  'persen'=>8.10, 'miskin_ribu'=>11.95, 'desil1_kk'=>1050, 'bansos_kk'=>2950, 'umkm'=>44, 'rls'=>8.6,  'sanitasi'=>82.4, 'lat'=>-6.0600, 'lng'=>106.5080, 'desa'=>'Mauk Timur, Mauk Barat, Tanjung Anom, Ketapang, Margamulya, Tegal Kunir', 'fokus'=>'Pemberdayaan kampung nelayan, PKH & pelatihan pengolahan boga bahari'],
    ['kode'=>'360306', 'nama'=>'Gunung Kaler',  'zona'=>'Merah',  'persen'=>7.95, 'miskin_ribu'=>9.15,  'desil1_kk'=>830,  'bansos_kk'=>2310, 'umkm'=>31, 'rls'=>8.4,  'sanitasi'=>81.0, 'lat'=>-6.0860, 'lng'=>106.4100, 'desa'=>'Gunung Kaler, Kedung, Onyam, Sidoko, Rancagede, Cibetok', 'fokus'=>'Ketahanan pangan, akses air bersih & pelatihan vokasi pemuda'],
    ['kode'=>'360310', 'nama'=>'Kemiri',        'zona'=>'Merah',  'persen'=>7.82, 'miskin_ribu'=>8.70,  'desil1_kk'=>790,  'bansos_kk'=>2190, 'umkm'=>28, 'rls'=>8.5,  'sanitasi'=>82.1, 'lat'=>-6.0520, 'lng'=>106.4680, 'desa'=>'Kemiri, Lontar, Patramanggala, Karang Anyar, Ranca Labuh, Klebet', 'fokus'=>'Bantuan sarana tani/tambak, PBI Kesehatan & UMKM agribisnis'],
    ['kode'=>'360328', 'nama'=>'Teluknaga',     'zona'=>'Merah',  'persen'=>7.65, 'miskin_ribu'=>14.60, 'desil1_kk'=>1290, 'bansos_kk'=>3650, 'umkm'=>54, 'rls'=>8.9,  'sanitasi'=>84.0, 'lat'=>-6.0620, 'lng'=>106.6420, 'desa'=>'Teluknaga, Tanjung Pasir, Kampung Melayu Timur, Lemo, Muara, Babakan Asem', 'fokus'=>'Penyerapan tenaga kerja logistik bandara, PKH & inkubasi UMKM kuliner'],
    ['kode'=>'360312', 'nama'=>'Kresek',        'zona'=>'Merah',  'persen'=>7.48, 'miskin_ribu'=>9.40,  'desil1_kk'=>840,  'bansos_kk'=>2390, 'umkm'=>35, 'rls'=>8.7,  'sanitasi'=>83.6, 'lat'=>-6.1120, 'lng'=>106.3900, 'desa'=>'Kresek, Renged, Pasir Ampo, Talok, Patrasana, Jengkol', 'fokus'=>'Sentra kerajinan & konveksi desa, BPNT Sembako & pelatihan menjahit'],
    ['kode'=>'360326', 'nama'=>'Sukadiri',      'zona'=>'Merah',  'persen'=>7.34, 'miskin_ribu'=>8.55,  'desil1_kk'=>760,  'bansos_kk'=>2140, 'umkm'=>33, 'rls'=>8.8,  'sanitasi'=>84.2, 'lat'=>-6.0820, 'lng'=>106.5550, 'desa'=>'Sukadiri, Karang Serang, Mekar Kondang, Pekayon, Buaran Jati, Rawa Kidang', 'fokus'=>'Pemberdayaan ekonomi pesisir, koperasi mikro & sanitasi sehat'],
    ['kode'=>'360321', 'nama'=>'Rajeg',         'zona'=>'Merah',  'persen'=>7.20, 'miskin_ribu'=>13.70, 'desil1_kk'=>1180, 'bansos_kk'=>3380, 'umkm'=>58, 'rls'=>9.3,  'sanitasi'=>87.5, 'lat'=>-6.1220, 'lng'=>106.5280, 'desa'=>'Rajeg, Rajeg Mulya, Sukamanah, Mekarsari, Tanjakan, Lembangsari', 'fokus'=>'Pelatihan kerja industri manufaktur, UMKM rumahan & beasiswa vokasi'],
    ['kode'=>'360304', 'nama'=>'Cisoka',        'zona'=>'Kuning', 'persen'=>6.88, 'miskin_ribu'=>9.85,  'desil1_kk'=>820,  'bansos_kk'=>2460, 'umkm'=>41, 'rls'=>9.1,  'sanitasi'=>86.4, 'lat'=>-6.2680, 'lng'=>106.4240, 'desa'=>'Cisoka, Caringin, Selapajang, Sukatani, Bojong Loa, Jeungjing', 'fokus'=>'Penguatan UMKM pangan olahan, bursa kerja pabrik & PKH pendidikan'],
    ['kode'=>'360325', 'nama'=>'Solear',        'zona'=>'Kuning', 'persen'=>6.75, 'miskin_ribu'=>9.50,  'desil1_kk'=>790,  'bansos_kk'=>2370, 'umkm'=>39, 'rls'=>9.2,  'sanitasi'=>86.8, 'lat'=>-6.3020, 'lng'=>106.4350, 'desa'=>'Solear, Cikasungka, Pasanggrahan, Cikuya, Munjul, Cireundeu', 'fokus'=>'Pelatihan digital marketing, akses KUR mikro & bantuan sembako'],
    ['kode'=>'360307', 'nama'=>'Jambe',         'zona'=>'Kuning', 'persen'=>6.68, 'miskin_ribu'=>7.20,  'desil1_kk'=>610,  'bansos_kk'=>1820, 'umkm'=>27, 'rls'=>9.0,  'sanitasi'=>85.9, 'lat'=>-6.3200, 'lng'=>106.4680, 'desa'=>'Jambe, Pasir Barat, Taban, Daru, Kutruk, Mekarsari', 'fokus'=>'Sentra kerajinan bambu, budidaya agro & pendampingan koperasi'],
    ['kode'=>'360308', 'nama'=>'Jayanti',       'zona'=>'Kuning', 'persen'=>6.54, 'miskin_ribu'=>7.85,  'desil1_kk'=>660,  'bansos_kk'=>1950, 'umkm'=>34, 'rls'=>9.2,  'sanitasi'=>87.0, 'lat'=>-6.1800, 'lng'=>106.4020, 'desa'=>'Jayanti, Pabuaran, Cikande, Sumur Bandung, Pasir Muncang, Dangdeur', 'fokus'=>'Kemitraan industri sekitar Cikande–Jayanti & sertifikasi operator produksi'],
    ['kode'=>'360327', 'nama'=>'Sukamulya',     'zona'=>'Kuning', 'persen'=>6.45, 'miskin_ribu'=>7.40,  'desil1_kk'=>620,  'bansos_kk'=>1860, 'umkm'=>32, 'rls'=>9.1,  'sanitasi'=>86.7, 'lat'=>-6.1600, 'lng'=>106.4220, 'desa'=>'Sukamulya, Kaliasin, Bunar, Benda, Kubang, Merak, Parahu', 'fokus'=>'Inkubasi usaha mikro pedesaan, BLT-DD & pelatihan keterampilan las/teknik'],
    ['kode'=>'360322', 'nama'=>'Sepatan',       'zona'=>'Kuning', 'persen'=>6.38, 'miskin_ribu'=>10.10, 'desil1_kk'=>840,  'bansos_kk'=>2510, 'umkm'=>49, 'rls'=>9.5,  'sanitasi'=>88.4, 'lat'=>-6.1150, 'lng'=>106.5850, 'desa'=>'Sepatan, Pisangan Jaya, Karet, Kayu Bongkok, Pondok Jaya, Mekar Jaya', 'fokus'=>'Digitalisasi warung & UMKM kuliner, penempatan kerja & PKH'],
    ['kode'=>'360323', 'nama'=>'Sepatan Timur', 'zona'=>'Kuning', 'persen'=>6.30, 'miskin_ribu'=>8.45,  'desil1_kk'=>700,  'bansos_kk'=>2120, 'umkm'=>38, 'rls'=>9.4,  'sanitasi'=>88.0, 'lat'=>-6.1100, 'lng'=>106.6200, 'desa'=>'Lebak Wangi, Kedaung Barat, Gempol Sari, Jati Mulya, Kampung Kelor', 'fokus'=>'Pertanian perkotaan, pemasaran e-commerce UMKM & jaminan kesehatan'],
    ['kode'=>'360324', 'nama'=>'Sindang Jaya',  'zona'=>'Kuning', 'persen'=>6.12, 'miskin_ribu'=>8.20,  'desil1_kk'=>670,  'bansos_kk'=>2050, 'umkm'=>37, 'rls'=>9.6,  'sanitasi'=>89.1, 'lat'=>-6.1750, 'lng'=>106.5600, 'desa'=>'Sindang Jaya, Sindang Asih, Wanakerta, Sukaharja, Sindang Panon', 'fokus'=>'Pelatihan kewirausahaan muda, bursa kerja & bantuan pendidikan'],
    ['kode'=>'360301', 'nama'=>'Balaraja',      'zona'=>'Kuning', 'persen'=>5.85, 'miskin_ribu'=>9.60,  'desil1_kk'=>750,  'bansos_kk'=>2380, 'umkm'=>56, 'rls'=>10.1, 'sanitasi'=>90.8, 'lat'=>-6.1970, 'lng'=>106.4520, 'desa'=>'Balaraja, Saga, Talagasari, Sentul, Tobat, Cangkudu, Gembong', 'fokus'=>'Link & match bursa kerja industri Balaraja & pemberdayaan katering/kos UMKM'],
    ['kode'=>'360329', 'nama'=>'Tigaraksa',     'zona'=>'Kuning', 'persen'=>5.62, 'miskin_ribu'=>10.25, 'desil1_kk'=>780,  'bansos_kk'=>2540, 'umkm'=>62, 'rls'=>10.4, 'sanitasi'=>91.6, 'lat'=>-6.2620, 'lng'=>106.4740, 'desa'=>'Tigaraksa, Pasir Bolang, Kadu Agung, Cisereh, Pete, Tegalsari, Sodong', 'fokus'=>'Pusat layanan terpadu pemerintahan, inkubator bisnis & vokasi digital'],
    ['kode'=>'360320', 'nama'=>'Pasar Kemis',   'zona'=>'Hijau',  'persen'=>5.34, 'miskin_ribu'=>12.40, 'desil1_kk'=>890,  'bansos_kk'=>3010, 'umkm'=>74, 'rls'=>10.5, 'sanitasi'=>92.5, 'lat'=>-6.1700, 'lng'=>106.5300, 'desa'=>'Pasar Kemis, Kuta Jaya, Kutabumi, Sukaasih, Sindang Sari, Gelam Jaya', 'fokus'=>'Serapan tenaga kerja pabrik, kemandirian UMKM & perlindungan pekerja rentan'],
    ['kode'=>'360302', 'nama'=>'Cikupa',        'zona'=>'Hijau',  'persen'=>5.18, 'miskin_ribu'=>11.80, 'desil1_kk'=>830,  'bansos_kk'=>2890, 'umkm'=>78, 'rls'=>10.6, 'sanitasi'=>93.0, 'lat'=>-6.2280, 'lng'=>106.5100, 'desa'=>'Cikupa, Bitung Jaya, Talaga, Pasir Jaya, Sukadamai, Bunder, Dukuh', 'fokus'=>'Kemitraan CSR kawasan industri Cikupa Mas & sertifikasi kompetensi'],
    ['kode'=>'360319', 'nama'=>'Panongan',      'zona'=>'Hijau',  'persen'=>5.05, 'miskin_ribu'=>7.35,  'desil1_kk'=>510,  'bansos_kk'=>1810, 'umkm'=>46, 'rls'=>10.4, 'sanitasi'=>92.4, 'lat'=>-6.2900, 'lng'=>106.5150, 'desa'=>'Panongan, Mekar Bakti, Ciakar, Peusar, Ranca Iyuh, Serdang Kulon', 'fokus'=>'Pengembangan UMKM kreatif, pelatihan ekonomi digital & PBI-JK'],
    ['kode'=>'360311', 'nama'=>'Kosambi',       'zona'=>'Hijau',  'persen'=>4.95, 'miskin_ribu'=>7.80,  'desil1_kk'=>540,  'bansos_kk'=>1920, 'umkm'=>52, 'rls'=>10.3, 'sanitasi'=>91.8, 'lat'=>-6.0750, 'lng'=>106.7000, 'desa'=>'Kosambi Barat, Kosambi Timur, Dadap, Salembaran Jaya, Cengklong', 'fokus'=>'Penyerapan kerja pergudangan/bandara & penataan permukiman pesisir'],
    ['kode'=>'360314', 'nama'=>'Legok',         'zona'=>'Hijau',  'persen'=>4.88, 'miskin_ribu'=>6.95,  'desil1_kk'=>480,  'bansos_kk'=>1710, 'umkm'=>43, 'rls'=>10.3, 'sanitasi'=>92.1, 'lat'=>-6.2900, 'lng'=>106.5900, 'desa'=>'Legok, Babat, Caringin, Serdang Wetan, Cirarab, Kemuning, Palasari', 'fokus'=>'Bursa kerja logistik/manufaktur & penguatan koperasi UMKM'],
    ['kode'=>'360305', 'nama'=>'Curug',         'zona'=>'Hijau',  'persen'=>4.72, 'miskin_ribu'=>8.35,  'desil1_kk'=>560,  'bansos_kk'=>2040, 'umkm'=>61, 'rls'=>10.8, 'sanitasi'=>93.7, 'lat'=>-6.2500, 'lng'=>106.5650, 'desa'=>'Curug Kulon, Curug Wetan, Binong, Sukabakti, Kadu, Cukanggalih', 'fokus'=>'Upskilling teknologi informasi, kemitraan ritel modern & UMKM kuliner'],
    ['kode'=>'360303', 'nama'=>'Cisauk',        'zona'=>'Hijau',  'persen'=>4.45, 'miskin_ribu'=>4.85,  'desil1_kk'=>320,  'bansos_kk'=>1190, 'umkm'=>42, 'rls'=>11.0, 'sanitasi'=>94.5, 'lat'=>-6.3330, 'lng'=>106.6400, 'desa'=>'Cisauk, Sampora, Suradita, Cibogo, Dangdang, Mekar Wangi', 'fokus'=>'Integrasi ekonomi kawasan BSD, inkubasi startup/UMKM digital'],
    ['kode'=>'360317', 'nama'=>'Pagedangan',    'zona'=>'Hijau',  'persen'=>4.28, 'miskin_ribu'=>4.60,  'desil1_kk'=>300,  'bansos_kk'=>1120, 'umkm'=>45, 'rls'=>11.1, 'sanitasi'=>95.1, 'lat'=>-6.3000, 'lng'=>106.6300, 'desa'=>'Pagedangan, Medang, Cicalengka, Lengkong Kulon, Cijantra, Situ Gadung', 'fokus'=>'Pemberdayaan jasa kreatif, kuliner & kemitraan korporasi komersial'],
    ['kode'=>'360309', 'nama'=>'Kelapa Dua',    'zona'=>'Hijau',  'persen'=>3.82, 'miskin_ribu'=>4.15,  'desil1_kk'=>260,  'bansos_kk'=>990,  'umkm'=>64, 'rls'=>11.6, 'sanitasi'=>96.8, 'lat'=>-6.2350, 'lng'=>106.6100, 'desa'=>'Kelapa Dua, Bencongan, Bojong Nangka, Pakulonan Barat, Curug Sangereng', 'fokus'=>'Kemandirian ekonomi digital, sertifikasi profesional & penjagaan kerentanan']
];

// ============================================================================
// 2. HYBRID PERSISTENT LOCAL DATABASE FOR SDGs (uploads/sdgs_local_db.json)
// ============================================================================
function sdgs_default_seed_data() {
    return [
        'settings' => [
            'mask_nik_public'   => 1,
            'allow_donasi'      => 1,
            'allow_pengaduan'   => 1,
            'allow_loker_apply' => 1,
            'show_mod_monitoring'  => 1,
            'show_mod_penduduk'    => 1,
            'show_mod_bansos'      => 1,
            'show_mod_umkm'        => 1,
            'show_mod_loker'       => 1,
            'show_mod_pelatihan'   => 1,
            'show_mod_donasi'      => 1,
            'show_mod_pengaduan'   => 1,
            'show_mod_peta'        => 1,
            'garis_kemiskinan'     => 684500,
            'nama_instansi'        => 'SIPANDU SDGs Goal 1 — Kabupaten Tangerang',
            'kontak_darurat'       => '081367219097'
        ],
        'sdgs_penduduk' => [
            ['id'=>1, 'nik'=>'3603180901820002', 'nama'=>'Sulaeman', 'jk'=>'L', 'usia'=>44, 'alamat_desa'=>'Ds. Buaran Mangga RT 02/04', 'kecamatan'=>'Pakuhaji', 'pekerjaan'=>'Buruh Harian Lepas', 'penghasilan'=>950000, 'tanggungan'=>4, 'kondisi_rumah'=>'Bilik Bambu / Lantai Tanah', 'pendidikan'=>'SD / Sederajat', 'status_ekonomi'=>'Desil 1 (Kemiskinan Ekstrem)'],
            ['id'=>2, 'nik'=>'3603184504790004', 'nama'=>'Karsinah', 'jk'=>'P', 'usia'=>47, 'alamat_desa'=>'Ds. Surya Bahari RT 01/03', 'kecamatan'=>'Pakuhaji', 'pekerjaan'=>'Pengolah Ikan Asin', 'penghasilan'=>1150000, 'tanggungan'=>3, 'kondisi_rumah'=>'Semi Permanen', 'pendidikan'=>'SD / Sederajat', 'status_ekonomi'=>'Desil 1 (Kemiskinan Ekstrem)'],
            ['id'=>3, 'nik'=>'3603131208850001', 'nama'=>'Jumadi', 'jk'=>'L', 'usia'=>41, 'alamat_desa'=>'Ds. Pagenjahan RT 04/02', 'kecamatan'=>'Kronjo', 'pekerjaan'=>'Nelayan Tradisional', 'penghasilan'=>1050000, 'tanggungan'=>5, 'kondisi_rumah'=>'Atap Rumbia / Dinding Kayu', 'pendidikan'=>'SMP / Sederajat', 'status_ekonomi'=>'Desil 1 (Kemiskinan Ekstrem)'],
            ['id'=>4, 'nik'=>'3603165803880003', 'nama'=>'Munawaroh', 'jk'=>'P', 'usia'=>38, 'alamat_desa'=>'Ds. Jenggot RT 03/01', 'kecamatan'=>'Mekar Baru', 'pekerjaan'=>'Buruh Tani Harian', 'penghasilan'=>880000, 'tanggungan'=>4, 'kondisi_rumah'=>'Semi Permanen', 'pendidikan'=>'SD / Sederajat', 'status_ekonomi'=>'Desil 1 (Kemiskinan Ekstrem)'],
            ['id'=>5, 'nik'=>'3603152106800005', 'nama'=>'Hermanudin', 'jk'=>'L', 'usia'=>46, 'alamat_desa'=>'Ds. Tanjung Anom RT 02/05', 'kecamatan'=>'Mauk', 'pekerjaan'=>'Nelayan Kecil', 'penghasilan'=>1350000, 'tanggungan'=>4, 'kondisi_rumah'=>'Semi Permanen', 'pendidikan'=>'SMP / Sederajat', 'status_ekonomi'=>'Desil 2 (Miskin)'],
            ['id'=>6, 'nik'=>'3603281411860002', 'nama'=>'Rohmatulloh', 'jk'=>'L', 'usia'=>40, 'alamat_desa'=>'Ds. Tanjung Pasir RT 05/02', 'kecamatan'=>'Teluknaga', 'pekerjaan'=>'Pedagang Keliling', 'penghasilan'=>1500000, 'tanggungan'=>3, 'kondisi_rumah'=>'Permanen Sederhana', 'pendidikan'=>'SMA / Sederajat', 'status_ekonomi'=>'Desil 2 (Miskin)'],
            ['id'=>7, 'nik'=>'3603125107830001', 'nama'=>'Siti Aminah', 'jk'=>'P', 'usia'=>43, 'alamat_desa'=>'Ds. Renged RT 01/02', 'kecamatan'=>'Kresek', 'pekerjaan'=>'Penjahit Rumahan', 'penghasilan'=>1420000, 'tanggungan'=>3, 'kondisi_rumah'=>'Semi Permanen', 'pendidikan'=>'SMP / Sederajat', 'status_ekonomi'=>'Desil 2 (Miskin)'],
            ['id'=>8, 'nik'=>'3603211902910004', 'nama'=>'Dedi Kurniawan', 'jk'=>'L', 'usia'=>35, 'alamat_desa'=>'Ds. Sukamanah RT 03/06', 'kecamatan'=>'Rajeg', 'pekerjaan'=>'Pengemudi Ojek / Serabutan', 'penghasilan'=>1680000, 'tanggungan'=>3, 'kondisi_rumah'=>'Kontrakan Petak', 'pendidikan'=>'SMA / Sederajat', 'status_ekonomi'=>'Desil 2 (Miskin)'],
            ['id'=>9, 'nik'=>'3603011705840003', 'nama'=>'Tatang Sutisna', 'jk'=>'L', 'usia'=>42, 'alamat_desa'=>'Ds. Talagasari RT 02/01', 'kecamatan'=>'Balaraja', 'pekerjaan'=>'Buruh Gudang Harian', 'penghasilan'=>1950000, 'tanggungan'=>4, 'kondisi_rumah'=>'Kontrakan Sederhana', 'pendidikan'=>'SMA / Sederajat', 'status_ekonomi'=>'Desil 3 (Rentan Miskin)'],
            ['id'=>10, 'nik'=>'3603294809890002', 'nama'=>'Nurmala Sari', 'jk'=>'P', 'usia'=>37, 'alamat_desa'=>'Kel. Kadu Agung RT 04/03', 'kecamatan'=>'Tigaraksa', 'pekerjaan'=>'Pedagang Warung Kecil', 'penghasilan'=>1850000, 'tanggungan'=>3, 'kondisi_rumah'=>'Permanen Sederhana', 'pendidikan'=>'SMA / Sederajat', 'status_ekonomi'=>'Desil 3 (Rentan Miskin)']
        ],
        'sdgs_bansos' => [
            ['id'=>1, 'kode_bansos'=>'BNS-2026-001', 'nik_penerima'=>'3603180901820002', 'nama_penerima'=>'Sulaeman', 'kecamatan'=>'Pakuhaji', 'jenis_bantuan'=>'Program Keluarga Harapan (PKH)', 'nominal_paket'=>'Rp 750.000 / Tahap', 'jadwal_penyaluran'=>'2026-10-15', 'tahap'=>'Tahap IV - 2026', 'status_verifikasi'=>'Disalurkan'],
            ['id'=>2, 'kode_bansos'=>'BNS-2026-002', 'nik_penerima'=>'3603184504790004', 'nama_penerima'=>'Karsinah', 'kecamatan'=>'Pakuhaji', 'jenis_bantuan'=>'BPNT / Program Sembako Pangan', 'nominal_paket'=>'Rp 400.000 + Beras 20 Kg', 'jadwal_penyaluran'=>'2026-10-20', 'tahap'=>'Tahap IV - 2026', 'status_verifikasi'=>'Disalurkan'],
            ['id'=>3, 'kode_bansos'=>'BNS-2026-003', 'nik_penerima'=>'3603131208850001', 'nama_penerima'=>'Jumadi', 'kecamatan'=>'Kronjo', 'jenis_bantuan'=>'BLT Dana Desa Kemiskinan Ekstrem', 'nominal_paket'=>'Rp 900.000 (3 Bulan)', 'jadwal_penyaluran'=>'2026-11-05', 'tahap'=>'Tahap IV - 2026', 'status_verifikasi'=>'Terverifikasi'],
            ['id'=>4, 'kode_bansos'=>'BNS-2026-004', 'nik_penerima'=>'3603165803880003', 'nama_penerima'=>'Munawaroh', 'kecamatan'=>'Mekar Baru', 'jenis_bantuan'=>'Program Keluarga Harapan (PKH)', 'nominal_paket'=>'Rp 750.000 / Tahap', 'jadwal_penyaluran'=>'2026-11-12', 'tahap'=>'Tahap IV - 2026', 'status_verifikasi'=>'Terverifikasi'],
            ['id'=>5, 'kode_bansos'=>'BNS-2026-005', 'nik_penerima'=>'3603152106800005', 'nama_penerima'=>'Hermanudin', 'kecamatan'=>'Mauk', 'jenis_bantuan'=>'PBI Jaminan Kesehatan & BPNT', 'nominal_paket'=>'Kartu KIS Aktif + Rp 400.000', 'jadwal_penyaluran'=>'2026-11-18', 'tahap'=>'Tahap IV - 2026', 'status_verifikasi'=>'Disalurkan'],
            ['id'=>6, 'kode_bansos'=>'BNS-2026-006', 'nik_penerima'=>'3603281411860002', 'nama_penerima'=>'Rohmatulloh', 'kecamatan'=>'Teluknaga', 'jenis_bantuan'=>'Program Indonesia Pintar (PIP)', 'nominal_paket'=>'Rp 1.000.000 / Tahun', 'jadwal_penyaluran'=>'2026-11-22', 'tahap'=>'Tahap IV - 2026', 'status_verifikasi'=>'Menunggu Verifikasi']
        ],
        'sdgs_umkm' => [
            ['id'=>1, 'kode_umkm'=>'UMKM-TNG-01', 'nama_usaha'=>'Olahan Ikan Asin & Kerupuk Bahari Surya', 'pemilik'=>'Ibu Karsinah', 'kecamatan'=>'Pakuhaji', 'kategori_usaha'=>'Kuliner & Olahan Hasil Laut', 'omzet_bulanan'=>4200000, 'pelatihan_diikuti'=>'Pelatihan Kemasan Kedap Udara & Sertifikasi Halal', 'status_pendampingan'=>'Aktif Didampingi'],
            ['id'=>2, 'kode_umkm'=>'UMKM-TNG-02', 'nama_usaha'=>'Konveksi Seragam & Busana Muslim Renged', 'pemilik'=>'Ibu Siti Aminah', 'kecamatan'=>'Kresek', 'kategori_usaha'=>'Fesyen & Konveksi', 'omzet_bulanan'=>5800000, 'pelatihan_diikuti'=>'Bantuan Mesin Jahit High-Speed & Pemasaran Marketplace', 'status_pendampingan'=>'Mandiri Berkembang'],
            ['id'=>3, 'kode_umkm'=>'UMKM-TNG-03', 'nama_usaha'=>'Kerajinan Anyaman Bambu & Topi Tangerang', 'pemilik'=>'Kelompok Usaha Jambe Mandiri', 'kecamatan'=>'Jambe', 'kategori_usaha'=>'Kerajinan Bambu', 'omzet_bulanan'=>4650000, 'pelatihan_diikuti'=>'Pendampingan Desain Produk Ekspor & Katalog Digital', 'status_pendampingan'=>'Aktif Didampingi'],
            ['id'=>4, 'kode_umkm'=>'UMKM-TNG-04', 'nama_usaha'=>'Bengkel Servis Motor & Las Listrik Berkah', 'pemilik'=>'Bpk. Rohim & Pemuda Binaan', 'kecamatan'=>'Teluknaga', 'kategori_usaha'=>'Jasa & Bengkel Otomotif', 'omzet_bulanan'=>6100000, 'pelatihan_diikuti'=>'Hibah Tool Kit Mekanik Injeksi & Manajemen Keuangan', 'status_pendampingan'=>'Mandiri Berkembang'],
            ['id'=>5, 'kode_umkm'=>'UMKM-TNG-05', 'nama_usaha'=>'Warung Aneka Camilan & Katering Harian', 'pemilik'=>'Ibu Nurmala Sari', 'kecamatan'=>'Tigaraksa', 'kategori_usaha'=>'Kuliner & Katering', 'omzet_bulanan'=>4900000, 'pelatihan_diikuti'=>'Pelatihan QRIS Digital Payment & Pembukuan UMKM', 'status_pendampingan'=>'Aktif Didampingi']
        ],
        'sdgs_loker' => [
            ['id'=>1, 'kode_loker'=>'LKR-2026-01', 'posisi'=>'Operator Produksi & Packaging Manufaktur', 'perusahaan'=>'PT Kawasan Industri Cikupa Mas', 'kecamatan'=>'Cikupa', 'kategori'=>'Manufaktur & Pabrik', 'gaji'=>'Rp 4.950.000 (UMK)', 'kuota'=>25, 'pendidikan_min'=>'SMA/SMK Sederajat', 'status_loker'=>'Terbuka'],
            ['id'=>2, 'kode_loker'=>'LKR-2026-02', 'posisi'=>'Staff Gudang & Sortir Logistik E-Commerce', 'perusahaan'=>'PT Logistik Bandara Kosambi Jaya', 'kecamatan'=>'Kosambi', 'kategori'=>'Logistik & Pergudangan', 'gaji'=>'Rp 4.800.000', 'kuota'=>18, 'pendidikan_min'=>'SMA/SMK / Paket C', 'status_loker'=>'Terbuka'],
            ['id'=>3, 'kode_loker'=>'LKR-2026-03', 'posisi'=>'Operator Mesin Jahit Garmen Ekspor', 'perusahaan'=>'PT Garmen Nusantara Balaraja', 'kecamatan'=>'Balaraja', 'kategori'=>'Tekstil & Garmen', 'gaji'=>'Rp 4.750.000 + Insentif', 'kuota'=>30, 'pendidikan_min'=>'SMP/SMA + Keterampilan Jahit', 'status_loker'=>'Terbuka'],
            ['id'=>4, 'kode_loker'=>'LKR-2026-04', 'posisi'=>'Teknisi Las & Konstruksi Bengkel', 'perusahaan'=>'CV Karya Baja Pasar Kemis', 'kecamatan'=>'Pasar Kemis', 'kategori'=>'Teknik & Konstruksi', 'gaji'=>'Rp 4.600.000', 'kuota'=>10, 'pendidikan_min'=>'SMK / Sertifikat BLK', 'status_loker'=>'Terbuka'],
            ['id'=>5, 'kode_loker'=>'LKR-2026-05', 'posisi'=>'Admin Gudang & Pengiriman UMKM Sentra', 'perusahaan'=>'Koperasi Sentra UMKM Tigaraksa', 'kecamatan'=>'Tigaraksa', 'kategori'=>'Administrasi & UMKM', 'gaji'=>'Rp 3.800.000', 'kuota'=>8, 'pendidikan_min'=>'SMA/SMK / D3', 'status_loker'=>'Terbuka']
        ],
        'sdgs_lamaran' => [
            ['id'=>1, 'kode_lamaran'=>'LAM-2026-001', 'loker_id'=>1, 'posisi_dilamar'=>'Operator Produksi & Packaging Manufaktur', 'perusahaan'=>'PT Kawasan Industri Cikupa Mas', 'nik_pelamar'=>'3603211902910004', 'nama_pelamar'=>'Dedi Kurniawan', 'kecamatan'=>'Rajeg', 'no_hp'=>'081388219011', 'pendidikan'=>'SMK Teknik Mesin', 'file_cv'=>'CV_Dedi_Kurniawan_2026.pdf', 'status_lamaran'=>'Wawancara'],
            ['id'=>2, 'kode_lamaran'=>'LAM-2026-002', 'loker_id'=>2, 'posisi_dilamar'=>'Staff Gudang & Sortir Logistik E-Commerce', 'perusahaan'=>'PT Logistik Bandara Kosambi Jaya', 'nik_pelamar'=>'3603281411860002', 'nama_pelamar'=>'Rohmatulloh', 'kecamatan'=>'Teluknaga', 'no_hp'=>'085219483321', 'pendidikan'=>'SMA IPS', 'file_cv'=>'CV_Rohmatulloh_Teluknaga.pdf', 'status_lamaran'=>'Diterima Bekerja'],
            ['id'=>3, 'kode_lamaran'=>'LAM-2026-003', 'loker_id'=>3, 'posisi_dilamar'=>'Operator Mesin Jahit Garmen Ekspor', 'perusahaan'=>'PT Garmen Nusantara Balaraja', 'nik_pelamar'=>'3603125107830001', 'nama_pelamar'=>'Siti Aminah', 'kecamatan'=>'Kresek', 'no_hp'=>'081294827100', 'pendidikan'=>'SMP + Sertifikat Menjahit', 'file_cv'=>'CV_Siti_Aminah_Kresek.pdf', 'status_lamaran'=>'Seleksi Berkas']
        ],
        'sdgs_pelatihan' => [
            ['id'=>1, 'kode_pelatihan'=>'PLT-2026-01', 'judul'=>'Pelatihan Digital Marketing, E-Commerce & Pembukuan QRIS UMKM', 'kategori'=>'Digital & Kewirausahaan', 'penyelenggara'=>'Dinas Koperasi & UMKM Kab. Tangerang', 'durasi'=>'4 Minggu (32 JP)', 'kuota'=>40, 'materi'=>"Modul 1: Riset Pasar & Branding Produk Lokal\nModul 2: Fotografi Produk Menggunakan Smartphone\nModul 3: Optimasi Toko Online, WhatsApp Business & Live Selling\nModul 4: Pencatatan Keuangan Digital & Integrasi Pembayaran QRIS", 'sertifikat'=>'Sertifikat Resmi Dinas Koperasi & UMKM'],
            ['id'=>2, 'kode_pelatihan'=>'PLT-2026-02', 'judul'=>'Pelatihan Vokasi Teknik Las Listrik & Fabrikasi Logam (BLK)', 'kategori'=>'Vokasi Teknik & Industri', 'penyelenggara'=>'UPTD BLK Kabupaten Tangerang (Jayanti)', 'durasi'=>'6 Minggu (120 JP)', 'kuota'=>25, 'materi'=>"Modul 1: Keselamatan dan Kesehatan Kerja (K3) Bengkel\nModul 2: Membaca Gambar Teknik & Persiapan Material\nModul 3: Praktik Pengelasan SMAW Posisi 1G - 3G\nModul 4: Uji Kompetensi & Penyaluran Magang Industri", 'sertifikat'=>'Sertifikat Kompetensi BNSP'],
            ['id'=>3, 'kode_pelatihan'=>'PLT-2026-03', 'judul'=>'Pelatihan Pengolahan Hasil Perikanan Pesisir & Kemasan Higienis', 'kategori'=>'Agribisnis & Perikanan', 'penyelenggara'=>'Dinas Perikanan Kab. Tangerang (Pakuhaji & Kronjo)', 'durasi'=>'3 Minggu (24 JP)', 'kuota'=>35, 'materi'=>"Modul 1: Standar Sanitasi & Higienitas Pangan Olahan Laut\nModul 2: Diversifikasi Produk (Bakso Ikan, Abon, Kerupuk Kemasan)\nModul 3: Teknologi Vacuum Packaging & Pengurusan PIRT/Halal\nModul 4: Distribusi Ritel & Koperasi Pesisir", 'sertifikat'=>'Sertifikat Kelulusan & PIRT Pendampingan'],
            ['id'=>4, 'kode_pelatihan'=>'PLT-2026-04', 'judul'=>'Bootcamp Administrasi Perkantoran, Excel & Dasar Pemrograman Web', 'kategori'=>'Teknologi Informasi', 'penyelenggara'=>'Komunitas IT & Mahasiswa Sistem Informasi', 'durasi'=>'4 Minggu (40 JP)', 'kuota'=>30, 'materi'=>"Modul 1: Pengolahan Data Administrasi & Rumus Microsoft Excel\nModul 2: Pengenalan Basis Data & Sistem Informasi\nModul 3: Dasar Pembuatan Website HTML, CSS & PHP Native\nModul 4: Penyusunan Portofolio Digital & Persiapan Kerja", 'sertifikat'=>'Sertifikat Kompetensi Digital']
        ],
        'sdgs_peserta_pelatihan' => [
            ['id'=>1, 'no_sertifikat'=>'SERT-SDGS-2026-001', 'pelatihan_id'=>1, 'judul_pelatihan'=>'Pelatihan Digital Marketing, E-Commerce & Pembukuan QRIS UMKM', 'nik_peserta'=>'3603294809890002', 'nama_peserta'=>'Nurmala Sari', 'kecamatan'=>'Tigaraksa', 'status_peserta'=>'Lulus Bersertifikat'],
            ['id'=>2, 'no_sertifikat'=>'SERT-SDGS-2026-002', 'pelatihan_id'=>3, 'judul_pelatihan'=>'Pelatihan Pengolahan Hasil Perikanan Pesisir & Kemasan Higienis', 'nik_peserta'=>'3603184504790004', 'nama_peserta'=>'Karsinah', 'kecamatan'=>'Pakuhaji', 'status_peserta'=>'Lulus Bersertifikat'],
            ['id'=>3, 'no_sertifikat'=>'SERT-SDGS-2026-003', 'pelatihan_id'=>2, 'judul_pelatihan'=>'Pelatihan Vokasi Teknik Las Listrik & Fabrikasi Logam (BLK)', 'nik_peserta'=>'3603211902910004', 'nama_peserta'=>'Dedi Kurniawan', 'kecamatan'=>'Rajeg', 'status_peserta'=>'Lulus Bersertifikat']
        ],
        'sdgs_donasi_kampanye' => [
            ['id'=>1, 'kode_kampanye'=>'KMP-2026-01', 'judul'=>'Bedah Rumah Tidak Layak Huni (RTLH) Keluarga Bpk. Sulaeman — Pakuhaji', 'kategori'=>'Bedah Rumah & Sanitasi', 'kecamatan'=>'Pakuhaji', 'penerima_manfaat'=>'Keluarga Bpk. Sulaeman (Desil 1 - Ds. Buaran Mangga)', 'target_dana'=>25000000, 'dana_terkumpul'=>21500000, 'dana_tersalurkan'=>18000000, 'laporan_penggunaan'=>"1. Pembelian material semen, pasir, bata ringan & besi beton: Rp 11.200.000\n2. Rangka atap baja ringan, genteng metal & plafon sehat: Rp 4.800.000\n3. Pembuatan MCK, septic tank komunal & instalasi air bersih: Rp 2.000.000", 'status_kampanye'=>'Aktif Menggalang'],
            ['id'=>2, 'kode_kampanye'=>'KMP-2026-02', 'judul'=>'Beasiswa Pendidikan & Perlengkapan Sekolah 50 Anak Nelayan Desil 1 Kronjo & Mauk', 'kategori'=>'Pendidikan Anak Desil 1', 'kecamatan'=>'Kronjo', 'penerima_manfaat'=>'50 Siswa SD/SMP Keluarga Nelayan Pra-Sejahtera', 'target_dana'=>30000000, 'dana_terkumpul'=>26400000, 'dana_tersalurkan'=>22500000, 'laporan_penggunaan'=>"1. Paket seragam sekolah, sepatu, tas & buku tulis 50 siswa: Rp 12.500.000\n2. Bantuan biaya transportasi & gizi anak sekolah 1 semester: Rp 10.000.000", 'status_kampanye'=>'Aktif Menggalang'],
            ['id'=>3, 'kode_kampanye'=>'KMP-2026-03', 'judul'=>'Wakaf Alat Produksi & Modal Usaha Perempuan Kepala Keluarga Pesisir Utara', 'kategori'=>'Pemberdayaan Ekonomi', 'kecamatan'=>'Mekar Baru', 'penerima_manfaat'=>'20 Ibu Kepala Keluarga Desil 1-2 Kec. Mekar Baru & Gunung Kaler', 'target_dana'=>20000000, 'dana_terkumpul'=>20000000, 'dana_tersalurkan'=>19500000, 'laporan_penggunaan'=>"1. Pengadaan 10 unit alat pengering & sealer kemasan produk: Rp 11.500.000\n2. Modal bahan baku awal untuk 20 kelompok usaha ibu rumah tangga: Rp 8.000.000", 'status_kampanye'=>'Target Tercapai']
        ],
        'sdgs_donasi_transaksi' => [
            ['id'=>1, 'kode_donasi'=>'DNS-2026-101', 'kampanye_id'=>1, 'judul_kampanye'=>'Bedah Rumah Tidak Layak Huni (RTLH) Keluarga Bpk. Sulaeman — Pakuhaji', 'nama_donatur'=>'Ibnu Andriano', 'metode_pembayaran'=>'QRIS Dinamis', 'nominal'=>500000, 'pesan'=>'Semoga rumah Bpk. Sulaeman lekas selesai dan nyaman ditempati keluarga.', 'status_transaksi'=>'Terverifikasi Lunas'],
            ['id'=>2, 'kode_donasi'=>'DNS-2026-102', 'kampanye_id'=>1, 'judul_kampanye'=>'Bedah Rumah Tidak Layak Huni (RTLH) Keluarga Bpk. Sulaeman — Pakuhaji', 'nama_donatur'=>'CSR Mitra Industri Cikupa', 'metode_pembayaran'=>'BCA Virtual Account', 'nominal'=>10000000, 'pesan'=>'Dukungan pengentasan kemiskinan ekstrem SDGs Goal 1 Kab. Tangerang.', 'status_transaksi'=>'Terverifikasi Lunas'],
            ['id'=>3, 'kode_donasi'=>'DNS-2026-103', 'kampanye_id'=>2, 'judul_kampanye'=>'Beasiswa Pendidikan & Perlengkapan Sekolah 50 Anak Nelayan Desil 1 Kronjo & Mauk', 'nama_donatur'=>'Hamba Allah (Tigaraksa)', 'metode_pembayaran'=>'Mandiri Virtual Account', 'nominal'=>1500000, 'pesan'=>'Untuk masa depan anak-anak pesisir Tangerang.', 'status_transaksi'=>'Terverifikasi Lunas'],
            ['id'=>4, 'kode_donasi'=>'DNS-2026-104', 'kampanye_id'=>3, 'judul_kampanye'=>'Wakaf Alat Produksi & Modal Usaha Perempuan Kepala Keluarga Pesisir Utara', 'nama_donatur'=>'Komunitas Rider & Developer Tangerang', 'metode_pembayaran'=>'GoPay / DANA / OVO', 'nominal'=>1250000, 'pesan'=>'Semangat berdaya untuk UMKM ibu-ibu pesisir.', 'status_transaksi'=>'Terverifikasi Lunas']
        ],
        'sdgs_pengaduan' => [
            ['id'=>1, 'kode_tiket'=>'ADU-2026-001', 'nama_pelapor'=>'Warga RT 03 (Anonim)', 'nik_terkait'=>'3603180000000012', 'kecamatan'=>'Pakuhaji', 'lokasi_desa'=>'Ds. Kiara Payung RT 03/02', 'kategori_aduan'=>'Bantuan Tidak Tepat Sasaran', 'isi_laporan'=>'Terdapat warga yang sudah memiliki usaha toko besar dan kendaraan roda empat namun masih tercatat sebagai penerima bansos sembako, sedangkan lansia janda di sebelahnya belum terdata.', 'status_aduan'=>'Tindak Lanjut Dinsos', 'tindak_lanjut'=>'Tim TKSK Kecamatan Pakuhaji telah melakukan musyawarah desa & ground-check pada 12 Nov 2026. Data penerima telah diusulkan graduasi dan dialihkan kepada lansia Desil 1 terkait.'],
            ['id'=>2, 'kode_tiket'=>'ADU-2026-002', 'nama_pelapor'=>'Ahmad Fauzi', 'nik_terkait'=>'3603131904760003', 'kecamatan'=>'Kronjo', 'lokasi_desa'=>'Ds. Muncung RT 01/04', 'kategori_aduan'=>'Warga Miskin Belum Terdata (Exclusion Error)', 'isi_laporan'=>'Keluarga nelayan buruh harian dengan 4 tanggungan anak sekolah dan kondisi atap rumah bocor belum masuk ke dalam daftar penerima PKH maupun BPNT tahun 2026.', 'status_aduan'=>'Verifikasi Lapangan', 'tindak_lanjut'=>'Petugas pendamping sosial sedang memverifikasi NIK dan kondisi rumah tangga untuk penginputan usulan DTSEN Desil 1.'],
            ['id'=>3, 'kode_tiket'=>'ADU-2026-003', 'nama_pelapor'=>'Siti Rohmah', 'nik_terkait'=>'3603125107830001', 'kecamatan'=>'Kresek', 'lokasi_desa'=>'Ds. Renged RT 02/01', 'kategori_aduan'=>'Sinkronisasi Data Kependudukan / NIK', 'isi_laporan'=>'Kartu KIS PBI Kesehatan anggota keluarga atas nama anak kedua non-aktif karena perbedaan penulisan ejaan nama di KK baru.', 'status_aduan'=>'Selesai Ditangani', 'tindak_lanjut'=>'Telah disinkronkan bersama operator SIKS-NG Desa Renged dan Disdukcapil Kab. Tangerang. Kartu KIS sudah aktif kembali.']
        ]
    ];
}

function sdgs_load_db($force_reset = false) {
    $dir = dirname(SDGS_LOCAL_DB_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $defaults = sdgs_default_seed_data();
    if ($force_reset || !file_exists(SDGS_LOCAL_DB_FILE)) {
        @file_put_contents(SDGS_LOCAL_DB_FILE, json_encode($defaults, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        return $defaults;
    }
    $raw = @file_get_contents(SDGS_LOCAL_DB_FILE);
    $data = @json_decode($raw, true);
    if (!is_array($data)) {
        @file_put_contents(SDGS_LOCAL_DB_FILE, json_encode($defaults, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        return $defaults;
    }
    foreach ($defaults as $k => $v) {
        if (!isset($data[$k]) || !is_array($data[$k])) {
            $data[$k] = $v;
        }
    }
    foreach ($defaults['settings'] as $sk => $sv) {
        if (!array_key_exists($sk, $data['settings'])) {
            $data['settings'][$sk] = $sv;
        }
    }
    return $data;
}

function sdgs_save_db($data) {
    $dir = dirname(SDGS_LOCAL_DB_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return @file_put_contents(SDGS_LOCAL_DB_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
}

function sdgs_insert_row(&$db, $table, $row) {
    $max = 0;
    foreach ($db[$table] as $r) {
        if ((int)($r['id'] ?? 0) > $max) $max = (int)$r['id'];
    }
    $row = array_merge(['id' => $max + 1], $row);
    array_unshift($db[$table], $row);
    return $row['id'];
}

function sdgs_update_row(&$db, $table, $id, $fields) {
    $id = (int)$id;
    foreach ($db[$table] as $idx => $r) {
        if ((int)($r['id'] ?? 0) === $id) {
            foreach ($fields as $k => $v) {
                $db[$table][$idx][$k] = $v;
            }
            return true;
        }
    }
    return false;
}

function sdgs_delete_row(&$db, $table, $id) {
    $id = (int)$id;
    $db[$table] = array_values(array_filter($db[$table], function ($r) use ($id) {
        return (int)($r['id'] ?? 0) !== $id;
    }));
    return true;
}

/**
 * Helper Privasi NIK: Disamarkan untuk pengunjung publik, tampil penuh khusus Admin
 */
function sdgs_display_nik($nik, $is_admin, $mask_enabled = true) {
    $nik = (string)$nik;
    if ($is_admin || !$mask_enabled || strlen($nik) < 10) {
        return $nik;
    }
    return substr($nik, 0, 6) . '******' . substr($nik, -4);
}

$sdgs_db = sdgs_load_db(false);
$sdgs_is_admin = (isset($_SESSION['sdgs_admin_logged_in']) && $_SESSION['sdgs_admin_logged_in'] === true);

// ============================================================================
// 3. HANDLER LOGIN / LOGOUT ADMIN SDGs + AKSI CRUD DENGAN PROTEKSI ADMIN
// ============================================================================
$sdgs_flash = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && !empty($_POST['sdgs_action'])) {
    $act = $_POST['sdgs_action'];
    $ok = false;
    $msg = 'Permintaan tidak dapat diproses.';

    // --- AUTH LOGIN ADMIN SDGs (Username: admin | Password: Ibnu@2026!) ---
    if ($act === 'sdgs_admin_login') {
        $u = trim($_POST['username'] ?? '');
        $p = trim($_POST['password'] ?? '');
        $sdgs_pw_hash = '$2y$10$PY8WEiOZ9Gzmj.2B2d0BGOyqC499SKeMHVcmQ77BeKpdlHbHvfJ1C';
        if ($u === 'admin' && (password_verify($p, $sdgs_pw_hash) || $p === 'Ibnu@2026!')) {
            $_SESSION['sdgs_admin_logged_in'] = true;
            $_SESSION['sdgs_admin_username']  = 'admin';
            $_SESSION['sdgs_admin_name']      = 'Admin SDGs (Ibnu Andriano)';
            $sdgs_is_admin = true;
            $ok = true;
            $msg = 'Login Admin SDGs berhasil! Seluruh fitur kontrol penuh, NIK utuh, dan pengaturan visibilitas modul kini aktif.';
        } else {
            $msg = 'Username atau password Admin salah! Silakan periksa kembali kredensial Anda.';
        }
    }
    elseif ($act === 'sdgs_admin_logout') {
        unset($_SESSION['sdgs_admin_logged_in'], $_SESSION['sdgs_admin_username'], $_SESSION['sdgs_admin_name']);
        $sdgs_is_admin = false;
        $ok = true;
        $msg = 'Anda telah keluar dari Mode Admin SDGs. Tampilan kini kembali ke Mode Publik (NIK tersensor).';
    }
    else {
        // Daftar aksi yang HANYA BOLEH dilakukan oleh ADMIN yang sudah login
        $admin_only_actions = [
            'save_penduduk', 'delete_penduduk',
            'save_bansos', 'update_bansos_status', 'delete_bansos',
            'save_umkm', 'delete_umkm',
            'save_loker', 'delete_loker', 'update_lamaran_status',
            'save_kampanye', 'update_pengaduan', 'delete_pengaduan',
            'save_sdgs_settings', 'reset_demo_data'
        ];

        if (in_array($act, $admin_only_actions, true) && !$sdgs_is_admin) {
            $msg = 'Akses ditolak! Fitur ini hanya dapat dikontrol oleh Admin yang sudah login.';
        } else {
            // --- ADMIN: PENGATURAN & VISIBILITAS MODUL SDGs ---
            if ($act === 'save_sdgs_settings') {
                $keys = [
                    'mask_nik_public', 'allow_donasi', 'allow_pengaduan', 'allow_loker_apply',
                    'show_mod_monitoring', 'show_mod_penduduk', 'show_mod_bansos', 'show_mod_umkm',
                    'show_mod_loker', 'show_mod_pelatihan', 'show_mod_donasi', 'show_mod_pengaduan', 'show_mod_peta'
                ];
                foreach ($keys as $k) {
                    $sdgs_db['settings'][$k] = isset($_POST[$k]) ? 1 : 0;
                }
                if (!empty($_POST['garis_kemiskinan'])) {
                    $sdgs_db['settings']['garis_kemiskinan'] = max(100000, (int)$_POST['garis_kemiskinan']);
                }
                if (!empty($_POST['nama_instansi'])) {
                    $sdgs_db['settings']['nama_instansi'] = trim($_POST['nama_instansi']);
                }
                $ok = sdgs_save_db($sdgs_db);
                $msg = 'Pengaturan visibilitas modul & kontrol keamanan SDGs berhasil disimpan!';
            }
            // --- MODUL 1: PENDUDUK MISKIN (ADMIN ONLY) ---
            elseif ($act === 'save_penduduk') {
                $id = (int)($_POST['id'] ?? 0);
                $nik = preg_replace('/[^0-9]/', '', $_POST['nik'] ?? '');
                $nama = trim($_POST['nama'] ?? '');
                $alamat_desa = trim($_POST['alamat_desa'] ?? '');
                if (strlen($nik) !== 16) {
                    $msg = 'Validasi gagal: NIK wajib 16 digit angka (Format Kab. Tangerang: 3603...).';
                } elseif (empty($nama) || empty($alamat_desa)) {
                    $msg = 'Nama Lengkap dan Alamat Desa/Kelurahan wajib diisi.';
                } else {
                    $payload = [
                        'nik'            => $nik,
                        'nama'           => $nama,
                        'jk'             => ($_POST['jk'] ?? 'L') === 'P' ? 'P' : 'L',
                        'usia'           => max(1, min(120, (int)($_POST['usia'] ?? 38))),
                        'alamat_desa'    => $alamat_desa,
                        'kecamatan'      => trim($_POST['kecamatan'] ?? 'Pakuhaji'),
                        'pekerjaan'      => trim($_POST['pekerjaan'] ?? 'Buruh Harian Lepas'),
                        'penghasilan'    => max(0, (int)($_POST['penghasilan'] ?? 950000)),
                        'tanggungan'     => max(1, (int)($_POST['tanggungan'] ?? 3)),
                        'kondisi_rumah'  => trim($_POST['kondisi_rumah'] ?? 'Semi Permanen'),
                        'pendidikan'     => trim($_POST['pendidikan'] ?? 'SD / Sederajat'),
                        'status_ekonomi' => trim($_POST['status_ekonomi'] ?? 'Desil 1 (Kemiskinan Ekstrem)')
                    ];
                    if ($id > 0) {
                        sdgs_update_row($sdgs_db, 'sdgs_penduduk', $id, $payload);
                        $msg = "Data penduduk a.n $nama berhasil diperbarui!";
                    } else {
                        sdgs_insert_row($sdgs_db, 'sdgs_penduduk', $payload);
                        $msg = "Data penduduk baru a.n $nama berhasil disimpan!";
                    }
                    $ok = sdgs_save_db($sdgs_db);
                }
            }
            elseif ($act === 'delete_penduduk') {
                sdgs_delete_row($sdgs_db, 'sdgs_penduduk', (int)($_POST['id'] ?? 0));
                $ok = sdgs_save_db($sdgs_db);
                $msg = 'Data penduduk berhasil dihapus.';
            }
            // --- MODUL 2: BANSOS (ADMIN ONLY) ---
            elseif ($act === 'save_bansos') {
                $id = (int)($_POST['id'] ?? 0);
                $kode = trim($_POST['kode_bansos'] ?? '') ?: ('BNS-2026-' . rand(100, 999));
                $nik = preg_replace('/[^0-9]/', '', $_POST['nik_penerima'] ?? '');
                $nama = trim($_POST['nama_penerima'] ?? '');
                if (empty($nama) || empty($nik)) {
                    $msg = 'Nama dan NIK penerima bantuan wajib diisi.';
                } else {
                    $payload = [
                        'kode_bansos'       => $kode,
                        'nik_penerima'      => $nik,
                        'nama_penerima'     => $nama,
                        'kecamatan'         => trim($_POST['kecamatan'] ?? 'Pakuhaji'),
                        'jenis_bantuan'     => trim($_POST['jenis_bantuan'] ?? 'Program Keluarga Harapan (PKH)'),
                        'nominal_paket'     => trim($_POST['nominal_paket'] ?? 'Rp 750.000 / Tahap'),
                        'jadwal_penyaluran' => trim($_POST['jadwal_penyaluran'] ?? date('Y-m-d')),
                        'tahap'             => trim($_POST['tahap'] ?? 'Tahap IV - 2026'),
                        'status_verifikasi' => trim($_POST['status_verifikasi'] ?? 'Terverifikasi')
                    ];
                    if ($id > 0) {
                        sdgs_update_row($sdgs_db, 'sdgs_bansos', $id, $payload);
                        $msg = "Penyaluran bansos $kode a.n $nama berhasil diperbarui!";
                    } else {
                        sdgs_insert_row($sdgs_db, 'sdgs_bansos', $payload);
                        $msg = "Jadwal penyaluran bansos baru ($kode) berhasil disimpan!";
                    }
                    $ok = sdgs_save_db($sdgs_db);
                }
            }
            elseif ($act === 'update_bansos_status') {
                $st = trim($_POST['status_verifikasi'] ?? 'Disalurkan');
                sdgs_update_row($sdgs_db, 'sdgs_bansos', (int)($_POST['id'] ?? 0), ['status_verifikasi' => $st]);
                $ok = sdgs_save_db($sdgs_db);
                $msg = "Status penyaluran bansos berhasil diperbarui menjadi: $st.";
            }
            elseif ($act === 'delete_bansos') {
                sdgs_delete_row($sdgs_db, 'sdgs_bansos', (int)($_POST['id'] ?? 0));
                $ok = sdgs_save_db($sdgs_db);
                $msg = 'Data bansos berhasil dihapus.';
            }
            // --- MODUL 3: UMKM BINAAN (ADMIN ONLY) ---
            elseif ($act === 'save_umkm') {
                $id = (int)($_POST['id'] ?? 0);
                $kode = trim($_POST['kode_umkm'] ?? '') ?: ('UMKM-TNG-' . rand(10, 99));
                $usaha = trim($_POST['nama_usaha'] ?? '');
                $pemilik = trim($_POST['pemilik'] ?? '');
                if (!empty($usaha) && !empty($pemilik)) {
                    $payload = [
                        'kode_umkm'           => $kode,
                        'nama_usaha'          => $usaha,
                        'pemilik'             => $pemilik,
                        'kecamatan'           => trim($_POST['kecamatan'] ?? 'Pakuhaji'),
                        'kategori_usaha'      => trim($_POST['kategori_usaha'] ?? 'Kuliner'),
                        'omzet_bulanan'       => max(0, (int)($_POST['omzet_bulanan'] ?? 3500000)),
                        'pelatihan_diikuti'   => trim($_POST['pelatihan_diikuti'] ?? 'Pelatihan Kemasan & QRIS'),
                        'status_pendampingan' => trim($_POST['status_pendampingan'] ?? 'Aktif Didampingi')
                    ];
                    if ($id > 0) {
                        sdgs_update_row($sdgs_db, 'sdgs_umkm', $id, $payload);
                        $msg = "Data UMKM $usaha berhasil diperbarui!";
                    } else {
                        sdgs_insert_row($sdgs_db, 'sdgs_umkm', $payload);
                        $msg = "UMKM Binaan baru ($usaha) berhasil didaftarkan!";
                    }
                    $ok = sdgs_save_db($sdgs_db);
                }
            }
            elseif ($act === 'delete_umkm') {
                sdgs_delete_row($sdgs_db, 'sdgs_umkm', (int)($_POST['id'] ?? 0));
                $ok = sdgs_save_db($sdgs_db);
                $msg = 'Data UMKM binaan berhasil dihapus.';
            }
            // --- MODUL 4: LOKER (ADMIN TAMBAH, PUBLIK LAMAR) ---
            elseif ($act === 'save_loker') {
                $posisi = trim($_POST['posisi'] ?? '');
                $perusahaan = trim($_POST['perusahaan'] ?? '');
                if (!empty($posisi) && !empty($perusahaan)) {
                    sdgs_insert_row($sdgs_db, 'sdgs_loker', [
                        'kode_loker'     => 'LKR-2026-' . rand(10, 99),
                        'posisi'         => $posisi,
                        'perusahaan'     => $perusahaan,
                        'kecamatan'      => trim($_POST['kecamatan'] ?? 'Cikupa'),
                        'kategori'       => trim($_POST['kategori'] ?? 'Manufaktur & Pabrik'),
                        'gaji'           => trim($_POST['gaji'] ?? 'Rp 4.850.000'),
                        'kuota'          => max(1, (int)($_POST['kuota'] ?? 10)),
                        'pendidikan_min' => trim($_POST['pendidikan_min'] ?? 'SMA/SMK'),
                        'status_loker'   => 'Terbuka'
                    ]);
                    $ok = sdgs_save_db($sdgs_db);
                    $msg = "Lowongan kerja $posisi di $perusahaan berhasil dipublikasikan!";
                }
            }
            elseif ($act === 'apply_loker') {
                $nik = preg_replace('/[^0-9]/', '', $_POST['nik_pelamar'] ?? '');
                $nama = trim($_POST['nama_pelamar'] ?? '');
                if (empty($nama) || strlen($nik) !== 16) {
                    $msg = 'Mohon lengkapi Nama Pelamar dan NIK 16 digit yang valid.';
                } else {
                    $kode = 'LAM-2026-' . rand(100, 999);
                    $cv_name = !empty($_FILES['file_cv']['name']) ? basename($_FILES['file_cv']['name']) : ('CV_' . preg_replace('/[^a-zA-Z0-9]/', '_', $nama) . '_2026.pdf');
                    sdgs_insert_row($sdgs_db, 'sdgs_lamaran', [
                        'kode_lamaran'   => $kode,
                        'loker_id'       => (int)($_POST['loker_id'] ?? 1),
                        'posisi_dilamar' => trim($_POST['posisi_dilamar'] ?? 'Operator Produksi'),
                        'perusahaan'     => trim($_POST['perusahaan'] ?? 'Mitra Industri'),
                        'nik_pelamar'    => $nik,
                        'nama_pelamar'   => $nama,
                        'kecamatan'      => trim($_POST['kecamatan'] ?? 'Pakuhaji'),
                        'no_hp'          => trim($_POST['no_hp'] ?? ''),
                        'pendidikan'     => trim($_POST['pendidikan'] ?? 'SMA/SMK'),
                        'file_cv'        => $cv_name,
                        'status_lamaran' => 'Seleksi Berkas'
                    ]);
                    $ok = sdgs_save_db($sdgs_db);
                    $msg = "Lamaran kerja $kode a.n $nama ($cv_name) berhasil dikirim!";
                }
            }
            elseif ($act === 'update_lamaran_status') {
                $st = trim($_POST['status_lamaran'] ?? 'Wawancara');
                sdgs_update_row($sdgs_db, 'sdgs_lamaran', (int)($_POST['id'] ?? 0), ['status_lamaran' => $st]);
                $ok = sdgs_save_db($sdgs_db);
                $msg = "Status pelamar kerja diperbarui menjadi: $st.";
            }
            // --- MODUL 5: PELATIHAN (PUBLIK DAFTAR) ---
            elseif ($act === 'enroll_pelatihan') {
                $nik = preg_replace('/[^0-9]/', '', $_POST['nik_peserta'] ?? '');
                $nama = trim($_POST['nama_peserta'] ?? '');
                if (empty($nama) || strlen($nik) !== 16) {
                    $msg = 'Mohon isi Nama Peserta dan NIK 16 digit yang valid.';
                } else {
                    $no_sert = 'SERT-SDGS-2026-' . rand(100, 999);
                    sdgs_insert_row($sdgs_db, 'sdgs_peserta_pelatihan', [
                        'no_sertifikat'   => $no_sert,
                        'pelatihan_id'    => (int)($_POST['pelatihan_id'] ?? 1),
                        'judul_pelatihan' => trim($_POST['judul_pelatihan'] ?? 'Pelatihan Digital UMKM'),
                        'nik_peserta'     => $nik,
                        'nama_peserta'    => $nama,
                        'kecamatan'       => trim($_POST['kecamatan'] ?? 'Pakuhaji'),
                        'status_peserta'  => 'Lulus Bersertifikat'
                    ]);
                    $ok = sdgs_save_db($sdgs_db);
                    $msg = "Peserta $nama berhasil terdaftar dengan Nomor Sertifikat: $no_sert!";
                }
            }
            // --- MODUL 6: DONASI & CROWDFUNDING ---
            elseif ($act === 'submit_donasi') {
                $kid = (int)($_POST['kampanye_id'] ?? 1);
                $donatur = trim($_POST['nama_donatur'] ?? '') ?: 'Hamba Allah (Anonim)';
                $metode = trim($_POST['metode_pembayaran'] ?? 'QRIS Dinamis');
                $nominal = max(10000, (int)($_POST['nominal'] ?? 100000));
                $kode = 'DNS-2026-' . rand(200, 999);
                sdgs_insert_row($sdgs_db, 'sdgs_donasi_transaksi', [
                    'kode_donasi'       => $kode,
                    'kampanye_id'       => $kid,
                    'judul_kampanye'    => trim($_POST['judul_kampanye'] ?? 'Program SDGs 1'),
                    'nama_donatur'      => $donatur,
                    'metode_pembayaran' => $metode,
                    'nominal'           => $nominal,
                    'pesan'             => trim($_POST['pesan'] ?? 'Semoga bermanfaat bagi warga Kab. Tangerang.'),
                    'status_transaksi'  => 'Terverifikasi Lunas'
                ]);
                foreach ($sdgs_db['sdgs_donasi_kampanye'] as $idx => $km) {
                    if ((int)$km['id'] === $kid) {
                        $sdgs_db['sdgs_donasi_kampanye'][$idx]['dana_terkumpul'] = (int)$km['dana_terkumpul'] + $nominal;
                        break;
                    }
                }
                $ok = sdgs_save_db($sdgs_db);
                $msg = "Terima kasih $donatur! Donasi Rp " . number_format($nominal, 0, ',', '.') . " via $metode ($kode) berhasil diverifikasi!";
            }
            elseif ($act === 'save_kampanye') {
                $judul = trim($_POST['judul'] ?? '');
                $penerima = trim($_POST['penerima_manfaat'] ?? '');
                if (!empty($judul) && !empty($penerima)) {
                    $kode = 'KMP-2026-' . rand(10, 99);
                    sdgs_insert_row($sdgs_db, 'sdgs_donasi_kampanye', [
                        'kode_kampanye'      => $kode,
                        'judul'              => $judul,
                        'kategori'           => trim($_POST['kategori'] ?? 'Bedah Rumah & Sanitasi'),
                        'kecamatan'          => trim($_POST['kecamatan'] ?? 'Pakuhaji'),
                        'penerima_manfaat'   => $penerima,
                        'target_dana'        => max(1000000, (int)($_POST['target_dana'] ?? 15000000)),
                        'dana_terkumpul'     => 0,
                        'dana_tersalurkan'   => 0,
                        'laporan_penggunaan' => trim($_POST['laporan_penggunaan'] ?? 'Alokasi transparan 100% kepada penerima manfaat.'),
                        'status_kampanye'    => 'Aktif Menggalang'
                    ]);
                    $ok = sdgs_save_db($sdgs_db);
                    $msg = "Kampanye crowdfunding baru ($kode) berhasil diterbitkan!";
                }
            }
            // --- MODUL 8: PENGADUAN MASYARAKAT ---
            elseif ($act === 'submit_pengaduan') {
                $desa = trim($_POST['lokasi_desa'] ?? '');
                $isi = trim($_POST['isi_laporan'] ?? '');
                if (empty($desa) || empty($isi)) {
                    $msg = 'Lokasi Desa/RT/RW dan Uraian Pengaduan wajib diisi.';
                } else {
                    $kode = 'ADU-2026-' . str_pad((string)rand(10, 999), 3, '0', STR_PAD_LEFT);
                    $kec = trim($_POST['kecamatan'] ?? 'Pakuhaji');
                    sdgs_insert_row($sdgs_db, 'sdgs_pengaduan', [
                        'kode_tiket'     => $kode,
                        'nama_pelapor'   => trim($_POST['nama_pelapor'] ?? '') ?: 'Warga Pelapor (Anonim)',
                        'nik_terkait'    => preg_replace('/[^0-9]/', '', $_POST['nik_terkait'] ?? '') ?: '-',
                        'kecamatan'      => $kec,
                        'lokasi_desa'    => $desa,
                        'kategori_aduan' => trim($_POST['kategori_aduan'] ?? 'Bantuan Tidak Tepat Sasaran'),
                        'isi_laporan'    => $isi,
                        'status_aduan'   => 'Laporan Diterima',
                        'tindak_lanjut'  => 'Laporan telah masuk ke Command Center SIPANDU SDGs 1 dan diteruskan ke TKSK Kec. ' . $kec . '.'
                    ]);
                    $ok = sdgs_save_db($sdgs_db);
                    $msg = "Pengaduan berhasil dikirim! Nomor Tiket Resmi Anda: $kode (simpan untuk melacak status).";
                }
            }
            elseif ($act === 'update_pengaduan') {
                $st = trim($_POST['status_aduan'] ?? 'Verifikasi Lapangan');
                sdgs_update_row($sdgs_db, 'sdgs_pengaduan', (int)($_POST['id'] ?? 0), [
                    'status_aduan'  => $st,
                    'tindak_lanjut' => trim($_POST['tindak_lanjut'] ?? '')
                ]);
                $ok = sdgs_save_db($sdgs_db);
                $msg = "Status tiket pengaduan berhasil diperbarui menjadi: $st.";
            }
            elseif ($act === 'delete_pengaduan') {
                sdgs_delete_row($sdgs_db, 'sdgs_pengaduan', (int)($_POST['id'] ?? 0));
                $ok = sdgs_save_db($sdgs_db);
                $msg = 'Tiket pengaduan berhasil dihapus.';
            }
            // --- MODUL 10: RESET DATA DEMO (ADMIN ONLY) ---
            elseif ($act === 'reset_demo_data') {
                $sdgs_db = sdgs_load_db(true);
                $ok = true;
                $msg = 'Seluruh data simulasi 10 modul berhasil direset ke kondisi awal!';
            }
        }
    }

    $sdgs_flash = ($ok ? 'success:' : 'error:') . $msg;
}

// ============================================================================
// 4. EXPORT CSV HANDLER (HANYA ADMIN UNTUK DATA SENSITIF, BPS PUBLIK BOLEH)
// ============================================================================
if (isset($_GET['export_csv'])) {
    $type = $_GET['export_csv'];
    if ($type !== 'bps_kecamatan' && !$sdgs_is_admin) {
        header('Location: sdgs-demo.php#mod-monitoring');
        exit;
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="SDGs1_KabTangerang2026_' . preg_replace('/[^a-z0-9_]/i', '', $type) . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));

    if ($type === 'bps_kecamatan') {
        fputcsv($out, ['Kode BPS', 'Kecamatan', 'Zona Prioritas', 'Persentase Kemiskinan (%)', 'Penduduk Miskin (Ribu Jiwa)', 'Keluarga Desil 1 DTSEN (KK)', 'Penerima Bansos (KK)', 'UMKM Binaan (Unit)', 'Rata Lama Sekolah (Thn)', 'Akses Sanitasi Layak (%)', 'Fokus Intervensi'], ';');
        foreach ($SDGS_KECAMATAN_29 as $k) {
            fputcsv($out, [$k['kode'], $k['nama'], $k['zona'], $k['persen'], $k['miskin_ribu'], $k['desil1_kk'], $k['bansos_kk'], $k['umkm'], $k['rls'], $k['sanitasi'], $k['fokus']], ';');
        }
    } elseif ($type === 'penduduk') {
        fputcsv($out, ['NIK', 'Nama Lengkap', 'JK', 'Usia', 'Alamat Desa', 'Kecamatan', 'Pekerjaan', 'Penghasilan/Bln (Rp)', 'Tanggungan', 'Kondisi Rumah', 'Pendidikan', 'Klasifikasi Desil'], ';');
        foreach ($sdgs_db['sdgs_penduduk'] as $r) {
            fputcsv($out, ["'" . $r['nik'], $r['nama'], $r['jk'], $r['usia'], $r['alamat_desa'], $r['kecamatan'], $r['pekerjaan'], $r['penghasilan'], $r['tanggungan'], $r['kondisi_rumah'], $r['pendidikan'], $r['status_ekonomi']], ';');
        }
    } elseif ($type === 'bansos') {
        fputcsv($out, ['Kode Bansos', 'NIK Penerima', 'Nama Penerima', 'Kecamatan', 'Jenis Bantuan', 'Nominal / Paket', 'Jadwal Penyaluran', 'Tahap', 'Status Verifikasi'], ';');
        foreach ($sdgs_db['sdgs_bansos'] as $r) {
            fputcsv($out, [$r['kode_bansos'], "'" . $r['nik_penerima'], $r['nama_penerima'], $r['kecamatan'], $r['jenis_bantuan'], $r['nominal_paket'], $r['jadwal_penyaluran'], $r['tahap'], $r['status_verifikasi']], ';');
        }
    } elseif ($type === 'umkm') {
        fputcsv($out, ['Kode UMKM', 'Nama Usaha', 'Pemilik', 'Kecamatan', 'Kategori', 'Omzet/Bulan (Rp)', 'Pelatihan & Bantuan', 'Status Pendampingan'], ';');
        foreach ($sdgs_db['sdgs_umkm'] as $r) {
            fputcsv($out, [$r['kode_umkm'], $r['nama_usaha'], $r['pemilik'], $r['kecamatan'], $r['kategori_usaha'], $r['omzet_bulanan'], $r['pelatihan_diikuti'], $r['status_pendampingan']], ';');
        }
    }
    fclose($out);
    exit;
}

// ============================================================================
// 5. VARIABEL DATA SIAP PAKAI UNTUK TAMPILAN PUBLIK & ADMIN
// ============================================================================
$sdgs_cfg        = $sdgs_db['settings'];
$list_penduduk   = $sdgs_db['sdgs_penduduk'];
$list_bansos     = $sdgs_db['sdgs_bansos'];
$list_umkm       = $sdgs_db['sdgs_umkm'];
$list_loker      = $sdgs_db['sdgs_loker'];
$list_lamaran    = $sdgs_db['sdgs_lamaran'];
$list_pelatihan  = $sdgs_db['sdgs_pelatihan'];
$list_peserta    = $sdgs_db['sdgs_peserta_pelatihan'];
$list_kampanye   = $sdgs_db['sdgs_donasi_kampanye'];
$list_donasi     = $sdgs_db['sdgs_donasi_transaksi'];
$list_pengaduan  = $sdgs_db['sdgs_pengaduan'];

$total_donasi_terkumpul = 0;
$total_donasi_tersalurkan = 0;
foreach ($list_kampanye as $km) {
    $total_donasi_terkumpul += (int)$km['dana_terkumpul'];
    $total_donasi_tersalurkan += (int)$km['dana_tersalurkan'];
}
$total_omzet_umkm = 0;
foreach ($list_umkm as $um) {
    $total_omzet_umkm += (int)$um['omzet_bulanan'];
}
$bansos_verified_count = 0;
foreach ($list_bansos as $bn) {
    if ($bn['status_verifikasi'] === 'Disalurkan' || $bn['status_verifikasi'] === 'Terverifikasi') {
        $bansos_verified_count++;
    }
}
$rasio_bansos_valid = count($list_bansos) > 0 ? round(($bansos_verified_count / count($list_bansos)) * 100, 1) : 100;
