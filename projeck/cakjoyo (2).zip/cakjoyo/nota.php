<?php
require_once __DIR__ . '/includes/header.php';

$kode = clean($koneksi, $_GET['kode'] ?? $_SESSION['last_order_code'] ?? '');

if (empty($kode)) {
    echo "<div class='container py-5 text-center'><h4>Kode pesanan tidak valid.</h4><a href='index.php' class='btn btn-warning mt-3'>Kembali ke Beranda</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Ambil data pesanan
$queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE kode_pesanan = '$kode' LIMIT 1");
$pesanan = mysqli_fetch_assoc($queryPesanan);

if (!$pesanan) {
    echo "<div class='container py-5 text-center'><h4>Pesanan dengan kode <strong>" . htmlspecialchars($kode) . "</strong> tidak ditemukan.</h4><a href='index.php' class='btn btn-warning mt-3'>Kembali ke Beranda</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$pesanan_id   = (int)$pesanan['id'];
$total_harga  = (int)$pesanan['total_harga'];
$status_bayar = $pesanan['status_pembayaran'] ?: 'Menunggu Pembayaran';

$queryDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $pesanan_id");
$items = [];
while ($d = mysqli_fetch_assoc($queryDetail)) {
    $items[] = $d;
}

// Format Pesan WhatsApp
$waText = "Halo Cak Joyo! Berikut rincian pesanan saya:\n\n"
        . "*Kode Pesanan:* " . $pesanan['kode_pesanan'] . "\n"
        . "*Nama:* " . $pesanan['nama_pelanggan'] . "\n"
        . "*Layanan:* " . ucfirst($pesanan['tipe_pesanan']) . ($pesanan['nomor_meja'] ? " (" . $pesanan['nomor_meja'] . ")" : "") . "\n"
        . "*Total Tagihan:* " . format_rupiah($total_harga) . "\n"
        . "*Status Pembayaran:* " . $status_bayar . "\n\n"
        . "Matur suwun Cak!";
$waUrl = whatsapp_link($resto['no_wa'], $waText);
?>

<style id="notaPagePrintStyle">
    @page {
        size: auto;
        margin: 5mm;
    }
    @media print {
        html, body {
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            height: auto !important;
        }
        header, nav, .navbar, footer, .footer-cakjoyo, .no-print, #cartOffcanvas {
            display: none !important;
        }
        .container, .row, .col-lg-8 {
            width: 100% !important;
            max-width: 100% !important;
            padding: 0 !important;
            margin: 0 !important;
        }
        #printableReceipt {
            border: 1px solid #000 !important;
            box-shadow: none !important;
            margin: 0 auto !important;
            padding: 10px 12px !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            page-break-after: avoid !important;
            font-size: 11px !important;
            line-height: 1.25 !important;
        }
        #printableReceipt.print-58mm {
            width: 56mm !important;
            max-width: 56mm !important;
            border: none !important;
            padding: 2px !important;
            font-family: 'Courier New', Courier, monospace !important;
            font-size: 10px !important;
        }
        #printableReceipt.print-80mm {
            width: 76mm !important;
            max-width: 76mm !important;
            border: none !important;
            padding: 4px !important;
            font-family: 'Courier New', Courier, monospace !important;
            font-size: 11px !important;
        }
        #printableReceipt.print-a4 {
            width: 100% !important;
            max-width: 650px !important;
            padding: 12px 16px !important;
            font-size: 12px !important;
        }
        #printableReceipt hr {
            margin: 5px 0 !important;
        }
        #printableReceipt .mb-4, #printableReceipt .mb-3, #printableReceipt .mt-4 {
            margin-top: 4px !important;
            margin-bottom: 4px !important;
        }
    }
</style>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- BANNER STATUS PAYMENT GATEWAY REAL-TIME -->
            <?php if ($status_bayar === 'Lunas'): ?>
                <div class="alert alert-success d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3 no-print shadow-sm rounded-4 p-3 border-start border-5 border-success" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-patch-check-fill fs-1 me-3 text-success"></i>
                        <div>
                            <span class="badge bg-success mb-1">STATUS PEMBAYARAN: LUNAS</span>
                            <h5 class="alert-heading fw-bold mb-1">Pembayaran Telah Dikonfirmasi Lunas!</h5>
                            <p class="mb-0 small">Pesanan <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong> telah lunas dan sedang diproses dapur.</p>
                        </div>
                    </div>
                </div>
            <?php elseif ($status_bayar === 'Menunggu Konfirmasi'): ?>
                <div class="alert alert-info d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3 no-print shadow-sm rounded-4 p-3 border-start border-5 border-info" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-shield-exclamation fs-1 me-3 text-dark"></i>
                        <div>
                            <span class="badge bg-info text-dark mb-1">STATUS: MENUNGGU KONFIRMASI ADMIN</span>
                            <h5 class="alert-heading fw-bold text-dark mb-1">Menunggu Verifikasi Pembayaran oleh Admin</h5>
                            <p class="mb-0 small text-dark">
                                Pembayaran penuh Anda sebesar <strong><?= format_rupiah($total_harga); ?></strong> sedang diperiksa oleh Admin. Status akan otomatis berubah menjadi <strong>LUNAS</strong> setelah dikonfirmasi!
                            </p>
                        </div>
                    </div>
                    <a href="bayar_gateway.php?kode=<?= urlencode($pesanan['kode_pesanan']); ?>" class="btn btn-dark btn-sm rounded-pill px-3 fw-bold text-info">
                        <i class="bi bi-shield-check me-1"></i> Cek Payment Gateway
                    </a>
                </div>
            <?php else: ?>
                <div class="alert alert-warning d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3 no-print shadow-sm rounded-4 p-3 border-start border-5 border-warning" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-hourglass-split fs-1 me-3 text-dark"></i>
                        <div>
                            <span class="badge bg-warning text-dark mb-1">STATUS: <?= htmlspecialchars(strtoupper($status_bayar)); ?></span>
                            <h5 class="alert-heading fw-bold text-dark mb-1">Tagihan Penuh Sebesar <?= format_rupiah($total_harga); ?></h5>
                            <p class="mb-0 small text-dark">
                                Silakan selesaikan pembayaran penuh (tidak dicicil) melalui QRIS, E-Wallet (081367219097), atau Bank.
                            </p>
                        </div>
                    </div>
                    <a href="bayar_gateway.php?kode=<?= urlencode($pesanan['kode_pesanan']); ?>" class="btn btn-dark btn-sm rounded-pill px-4 py-2 fw-bold text-warning shadow-sm">
                        <i class="bi bi-lightning-charge-fill me-1"></i> Bayar via Payment Gateway
                    </a>
                </div>
            <?php endif; ?>

            <!-- Stepper Progres Pesanan -->
            <div class="card border-0 shadow-sm p-3 rounded-4 mb-3 no-print">
                <h6 class="fw-bold text-center text-dark mb-2">Status Pengerjaan Dapur</h6>
                <div class="order-stepper">
                    <?php
                    $status = $pesanan['status'];
                    $steps = [
                        'Baru' => ['title' => 'Diterima', 'icon' => 'bi-receipt'],
                        'Diproses' => ['title' => 'Dimasak', 'icon' => 'bi-fire'],
                        'Siap' => ['title' => 'Siap', 'icon' => 'bi-bell'],
                        'Selesai' => ['title' => 'Selesai', 'icon' => 'bi-check2-circle']
                    ];
                    $statusKeys = ['Baru', 'Diproses', 'Siap', 'Selesai'];
                    $currentIndex = array_search($status, $statusKeys);
                    if ($currentIndex === false && $status === 'Dibatalkan') {
                        $currentIndex = -1;
                    }

                    $idx = 0;
                    foreach ($steps as $stName => $stData):
                        $isCompleted = ($currentIndex !== false && $idx < $currentIndex);
                        $isActive = ($currentIndex !== false && $idx === $currentIndex);
                        $class = $isCompleted ? 'completed' : ($isActive ? 'active' : '');
                        $idx++;
                    ?>
                        <div class="step-item <?= $class; ?>">
                            <div class="step-circle">
                                <i class="bi <?= $stData['icon']; ?>"></i>
                            </div>
                            <div class="step-title"><?= $stData['title']; ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="text-center mt-2">
                    <span class="text-muted small">Status Dapur:</span> <?= status_badge($pesanan['status']); ?>
                </div>
            </div>

            <!-- Pilihan Mode Mesin Printer (Bluetooth Mini 58mm / 80mm / Printer Besar A4) -->
            <div class="card border-0 shadow-sm p-3 rounded-4 mb-3 no-print bg-light">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                    <span class="small fw-bold text-dark"><i class="bi bi-printer-fill text-warning me-1"></i> Ukuran Cetak Struk (1 Halaman):</span>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" id="btnPrintMode58" class="btn btn-outline-dark" onclick="ubahUkuranStruk('58mm')">📱 Bluetooth Mini 58mm</button>
                        <button type="button" id="btnPrintMode80" class="btn btn-outline-dark" onclick="ubahUkuranStruk('80mm')">🧾 Thermal 80mm</button>
                        <button type="button" id="btnPrintModeA4" class="btn btn-dark active" onclick="ubahUkuranStruk('a4')">🖨️ Printer Besar / Standar</button>
                    </div>
                </div>
            </div>

            <!-- NOTA / STRUK PEMBELIAN (1 HALAMAN RINGKAS & RAPIH) -->
            <div id="printableReceipt" class="receipt-box print-a4">
                <div class="text-center mb-2">
                    <h5 class="fw-bold text-dark mb-0 text-uppercase"><?= htmlspecialchars($resto['nama_resto']); ?></h5>
                    <div class="small text-muted"><?= htmlspecialchars($resto['alamat']); ?></div>
                    <div class="small text-muted">Telp/WA: <?= htmlspecialchars($resto['no_wa']); ?></div>
                </div>

                <hr style="border-top: 1px dashed #64748b; margin: 8px 0;">

                <div class="row g-1 small mb-2">
                    <div class="col-6">
                        <span class="text-muted">Kode Pesanan:</span><br>
                        <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Waktu:</span><br>
                        <strong><?= date('d/m/Y H:i', strtotime($pesanan['created_at'])); ?> WIB</strong>
                    </div>
                    <div class="col-6">
                        <span class="text-muted">Pelanggan:</span><br>
                        <strong><?= htmlspecialchars($pesanan['nama_pelanggan']); ?> (<?= htmlspecialchars($pesanan['no_hp']); ?>)</strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Layanan & Meja:</span><br>
                        <strong><?= tipe_pesanan_label($pesanan['tipe_pesanan'], $pesanan['nomor_meja'], $pesanan['jumlah_orang'] ?? null); ?></strong>
                    </div>
                    <?php if ($pesanan['alamat_pengiriman']): ?>
                        <div class="col-12">
                            <span class="text-muted">Alamat Antar:</span>
                            <strong><?= htmlspecialchars($pesanan['alamat_pengiriman']); ?></strong>
                        </div>
                    <?php endif; ?>
                    <div class="col-6">
                        <span class="text-muted">Metode Bayar:</span><br>
                        <strong><?= metode_bayar_label($pesanan['metode_pembayaran'], $pesanan['kanal_gateway'] ?? null); ?></strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Kode Bayar Gateway:</span><br>
                        <strong class="font-monospace"><?= htmlspecialchars($pesanan['kode_bayar_gateway'] ?: '-'); ?></strong>
                    </div>
                    <div class="col-6">
                        <span class="text-muted">Status Pembayaran:</span><br>
                        <strong><?= htmlspecialchars(strtoupper($status_bayar)); ?></strong>
                    </div>
                    <div class="col-6 text-end">
                        <span class="text-muted">Status Pesanan:</span><br>
                        <strong><?= htmlspecialchars($pesanan['status']); ?></strong>
                    </div>
                </div>

                <hr style="border-top: 1px dashed #64748b; margin: 8px 0;">

                <!-- Tabel Menu -->
                <table class="table table-sm table-borderless small mb-2">
                    <thead>
                        <tr class="border-bottom text-muted">
                            <th class="ps-0 py-1">Menu</th>
                            <th class="text-center py-1">Qty</th>
                            <th class="text-end pe-0 py-1">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $d): ?>
                            <tr>
                                <td class="ps-0 py-1">
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($d['nama_menu']); ?></div>
                                    <span class="text-muted" style="font-size: 0.78rem;"><?= format_rupiah($d['harga']); ?></span>
                                    <?php if (!empty($d['catatan_item'])): ?>
                                        <span class="text-warning fst-italic" style="font-size: 0.75rem;">("<?= htmlspecialchars($d['catatan_item']); ?>")</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center align-middle py-1"><?= $d['jumlah']; ?></td>
                                <td class="text-end align-middle pe-0 py-1 fw-bold"><?= format_rupiah($d['subtotal']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <hr style="border-top: 1px dashed #64748b; margin: 8px 0;">

                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="fw-bold text-dark">TOTAL BAYAR PENUH:</span>
                    <span class="fs-5 fw-bold text-dark"><?= format_rupiah($total_harga); ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center small">
                    <span class="text-muted">STATUS PEMBAYARAN:</span>
                    <span class="fw-bold <?= $status_bayar === 'Lunas' ? 'text-success' : 'text-danger'; ?>">
                        <?= $status_bayar === 'Lunas' ? 'LUNAS (100%)' : strtoupper($status_bayar); ?>
                    </span>
                </div>

                <?php if (!empty($pesanan['catatan'])): ?>
                    <div class="p-2 bg-light rounded small mt-2">
                        <strong>Catatan:</strong> <?= htmlspecialchars($pesanan['catatan']); ?>
                    </div>
                <?php endif; ?>

                <div class="text-center small text-muted mt-3">
                    <div>Terima kasih atas pesanan Anda di Soto Lamongan Cak Joyo!</div>
                </div>
            </div>

            <!-- Tombol Aksi di Bawah Nota -->
            <div class="d-flex flex-wrap gap-2 justify-content-center mt-3 no-print">
                <?php if ($status_bayar !== 'Lunas'): ?>
                    <a href="bayar_gateway.php?kode=<?= urlencode($pesanan['kode_pesanan']); ?>" class="btn btn-danger px-3 py-2 fw-bold">
                        <i class="bi bi-credit-card me-1"></i> Buka Halaman Pembayaran
                    </a>
                <?php endif; ?>
                <button onclick="window.print()" class="btn btn-dark px-3 py-2 fw-bold">
                    <i class="bi bi-printer me-1"></i> Cetak Struk (1 Halaman)
                </button>
                <button onclick="cetakBluetoothPelanggan()" class="btn btn-primary px-3 py-2 fw-bold">
                    <i class="bi bi-bluetooth me-1"></i> Print Bluetooth Mini
                </button>
                <a href="<?= $waUrl; ?>" target="_blank" class="btn btn-success px-3 py-2">
                    <i class="bi bi-whatsapp me-1"></i> WhatsApp (081367219097)
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function ubahUkuranStruk(mode) {
    const receipt = document.getElementById('printableReceipt');
    const styleEl = document.getElementById('notaPagePrintStyle');
    receipt.className = 'receipt-box print-' + mode;

    document.getElementById('btnPrintMode58').classList.toggle('active', mode === '58mm');
    document.getElementById('btnPrintMode58').classList.toggle('btn-dark', mode === '58mm');
    document.getElementById('btnPrintMode58').classList.toggle('btn-outline-dark', mode !== '58mm');

    document.getElementById('btnPrintMode80').classList.toggle('active', mode === '80mm');
    document.getElementById('btnPrintMode80').classList.toggle('btn-dark', mode === '80mm');
    document.getElementById('btnPrintMode80').classList.toggle('btn-outline-dark', mode !== '80mm');

    document.getElementById('btnPrintModeA4').classList.toggle('active', mode === 'a4');
    document.getElementById('btnPrintModeA4').classList.toggle('btn-dark', mode === 'a4');
    document.getElementById('btnPrintModeA4').classList.toggle('btn-outline-dark', mode !== 'a4');

    if (mode === '58mm') {
        receipt.style.maxWidth = '260px';
        receipt.style.margin = '0 auto';
    } else if (mode === '80mm') {
        receipt.style.maxWidth = '340px';
        receipt.style.margin = '0 auto';
    } else {
        receipt.style.maxWidth = '100%';
    }
}

async function cetakBluetoothPelanggan() {
    ubahUkuranStruk('58mm');
    if (!navigator.bluetooth) {
        window.print();
        return;
    }
    try {
        const device = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: [
                '000018f0-0000-1000-8000-00805f9b34fb',
                'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
                '49535343-fe7d-4ae5-8fa9-9fafd205e455'
            ]
        });
        const server = await device.gatt.connect();
        const services = await server.getPrimaryServices();
        let printChar = null;
        for (const s of services) {
            const chars = await s.getCharacteristics();
            for (const c of chars) {
                if (c.properties.write || c.properties.writeWithoutResponse) {
                    printChar = c;
                    break;
                }
            }
            if (printChar) break;
        }
        if (!printChar) {
            window.print();
            return;
        }

        const escInit = '\x1B\x40';
        const alignCenter = '\x1B\x61\x01';
        const alignLeft = '\x1B\x61\x00';
        const boldOn = '\x1B\x45\x01';
        const boldOff = '\x1B\x45\x00';
        const line = '--------------------------------\n';

        let text = escInit + alignCenter + boldOn + <?= json_encode(strtoupper($resto['nama_resto']) . "\n"); ?> + boldOff;
        text += 'WA: ' + <?= json_encode($resto['no_wa'] . "\n"); ?>;
        text += alignLeft + line;
        text += 'No   : ' + <?= json_encode($pesanan['kode_pesanan'] . "\n"); ?>;
        text += 'Plg  : ' + <?= json_encode($pesanan['nama_pelanggan'] . "\n"); ?>;
        text += 'Meja : ' + <?= json_encode(($pesanan['nomor_meja'] ?: ucfirst($pesanan['tipe_pesanan'])) . "\n"); ?>;
        text += 'Bayar: ' + <?= json_encode(strtoupper($pesanan['metode_pembayaran']) . "\n"); ?>;
        text += 'Kode : ' + <?= json_encode(($pesanan['kode_bayar_gateway'] ?: '-') . "\n"); ?>;
        text += line;
        <?php foreach ($items as $d): ?>
        text += <?= json_encode($d['nama_menu'] . "\n"); ?>;
        text += <?= json_encode(' ' . $d['jumlah'] . ' x ' . number_format((int)$d['harga'], 0, ',', '.') . ' = ' . number_format((int)$d['subtotal'], 0, ',', '.') . "\n"); ?>;
        <?php endforeach; ?>
        text += line;
        text += boldOn + 'TOTAL : Rp ' + <?= json_encode(number_format($total_harga, 0, ',', '.') . "\n"); ?> + boldOff;
        text += 'STATUS: ' + <?= json_encode(strtoupper($status_bayar) . "\n"); ?>;
        text += line + alignCenter + 'Matur Suwun!\n\n\n';

        const bytes = new TextEncoder().encode(text);
        for (let i = 0; i < bytes.length; i += 100) {
            await printChar.writeValue(bytes.slice(i, i + 100));
        }
        alert('Struk berhasil dicetak ke Printer Bluetooth!');
    } catch (e) {
        window.print();
    }
}

// Auto-polling real-time setiap 3 detik agar begitu Admin mengonfirmasi pembayaran, halaman nota langsung berubah menjadi LUNAS
const notaKode = <?= json_encode($pesanan['kode_pesanan']); ?>;
let currentStatusBayar = <?= json_encode($status_bayar); ?>;
let currentStatusDapur = <?= json_encode($pesanan['status']); ?>;

setInterval(() => {
    fetch('api_payment_gateway.php?action=check_status&kode=' + encodeURIComponent(notaKode))
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.status_pembayaran !== currentStatusBayar || data.status_pesanan !== currentStatusDapur) {
                window.location.reload();
            }
        }
    })
    .catch(() => {});
}, 3000);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
