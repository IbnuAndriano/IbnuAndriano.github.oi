<?php
require_once __DIR__ . '/includes/header.php';

$cart = $_SESSION['cart'] ?? [];
$total_harga = 0;
foreach ($cart as $item) {
    $total_harga += ($item['harga'] * $item['jumlah']);
}

// Ambil daftar meja (otomatis sinkron 1 jam setelah status 'Siap')
$daftarMeja = get_daftar_meja($koneksi);
$mejaKosongCount = 0;
$firstMejaKosong = '';
foreach ($daftarMeja as $mj) {
    if ($mj['status_meja'] === 'kosong') {
        $mejaKosongCount++;
        if ($firstMejaKosong === '') {
            $firstMejaKosong = $mj['nomor_meja'];
        }
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Header Navigasi Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-muted">Beranda</a></li>
                    <li class="breadcrumb-item active text-dark fw-bold" aria-current="page">Checkout Pesanan</li>
                </ol>
            </nav>

            <?php if (isset($_GET['err']) && $_GET['err'] === 'meja_terisi'): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4 shadow-sm mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <strong>Maaf, Meja tersebut baru saja dipesan oleh pelanggan lain!</strong> Silakan pilih nomor meja lain yang berstatus <strong>Kosong</strong>.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h2 class="fw-bold text-dark mb-1"><i class="bi bi-bag-check-fill text-warning me-2"></i> Konfirmasi & Pembayaran</h2>
                    <p class="text-muted mb-0">Lengkapi data pemesan, pilih meja yang kosong, dan pilih metode pembayaran penuh.</p>
                </div>
                <a href="index.php#menu-section" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-arrow-left me-1"></i> Tambah Menu Lain
                </a>
            </div>

            <?php if (empty($cart)): ?>
                <div class="card border-0 shadow-sm p-5 text-center rounded-4">
                    <span class="fs-1 d-block mb-3">🍲</span>
                    <h4 class="fw-bold text-dark">Keranjang Belanja Anda Kosong</h4>
                    <p class="text-muted mb-4">Anda belum memilih menu Soto Lamongan atau hidangan lainnya.</p>
                    <div>
                        <a href="index.php#menu-section" class="btn btn-primary-cakjoyo px-4 py-2">
                            <i class="bi bi-book me-2"></i> Buka Daftar Menu
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <form action="simpan_pesanan.php" method="POST" enctype="multipart/form-data" id="checkoutForm">
                    <div class="row g-4">
                        <!-- KOLOM KIRI: Form Data Pemesan & Pengantaran -->
                        <div class="col-lg-7">
                            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                                <h5 class="fw-bold text-dark mb-3">
                                    <i class="bi bi-person-fill text-warning me-2"></i> 1. Informasi Pemesan & Pilih Meja
                                </h5>

                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nama Lengkap <span class="text-danger">*</span></label>
                                    <input type="text" name="nama" class="form-control" placeholder="Contoh: Budi Santoso" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nomor WhatsApp / HP <span class="text-danger">*</span></label>
                                    <input type="tel" name="hp" class="form-control" placeholder="Contoh: 081367219097" required>
                                    <div class="form-text text-muted">Untuk informasi status pesanan dan verifikasi pembayaran.</div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Tipe Pesanan <span class="text-danger">*</span></label>
                                    <div class="row g-2">
                                        <div class="col-4">
                                            <input type="radio" class="btn-check" name="tipe_pesanan" id="tipe_dine_in" value="dine_in" checked>
                                            <label class="btn btn-outline-warning w-100 text-dark fw-bold py-2" for="tipe_dine_in">
                                                🍽️ Makan Sini
                                            </label>
                                        </div>
                                        <div class="col-4">
                                            <input type="radio" class="btn-check" name="tipe_pesanan" id="tipe_take_away" value="take_away">
                                            <label class="btn btn-outline-warning w-100 text-dark fw-bold py-2" for="tipe_take_away">
                                                🥡 Bungkus
                                            </label>
                                        </div>
                                        <div class="col-4">
                                            <input type="radio" class="btn-check" name="tipe_pesanan" id="tipe_delivery" value="delivery">
                                            <label class="btn btn-outline-warning w-100 text-dark fw-bold py-2" for="tipe_delivery">
                                                🛵 Antar
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pilihan Meja Interaktif Otomatis (Khusus Dine-In) -->
                                <div class="mb-3" id="wrapNomorMeja">
                                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
                                        <label class="form-label fw-semibold mb-0">Pilih Nomor Meja <span class="text-danger">*</span></label>
                                        <div class="d-flex gap-2 small">
                                            <span class="badge bg-success-subtle text-success border border-success">🟢 Kosong (Bisa Dipesan)</span>
                                            <span class="badge bg-danger-subtle text-danger border border-danger">🔴 Terisi (Tidak Bisa Diisi)</span>
                                        </div>
                                    </div>

                                    <input type="hidden" name="nomor_meja" id="inputMeja" value="<?= htmlspecialchars($firstMejaKosong); ?>" required>

                                    <div class="row g-2 mb-2">
                                        <?php foreach ($daftarMeja as $mj): 
                                            $isKosong = ($mj['status_meja'] === 'kosong');
                                            $isSelected = ($isKosong && $mj['nomor_meja'] === $firstMejaKosong);
                                            $sisaMenit = ($mj['sisa_detik_siap'] !== null) ? ceil(((int)$mj['sisa_detik_siap']) / 60) : null;
                                        ?>
                                            <div class="col-4 col-sm-3">
                                                <button type="button"
                                                        class="btn w-100 p-2 rounded-3 text-center meja-card-btn <?= !$isKosong ? 'btn-danger bg-danger bg-opacity-10 text-danger border-danger opacity-75' : ($isSelected ? 'btn-success text-white fw-bold shadow-sm' : 'btn-outline-success'); ?>"
                                                        data-meja="<?= htmlspecialchars($mj['nomor_meja']); ?>"
                                                        onclick="pilihMeja('<?= htmlspecialchars($mj['nomor_meja']); ?>', this)"
                                                        <?= !$isKosong ? 'disabled title="Meja sedang terisi dan tidak bisa dipilih"' : ''; ?>>
                                                    <div class="fw-bold" style="font-size: 0.9rem;">
                                                        <i class="bi <?= $isKosong ? 'bi-check-circle' : 'bi-lock-fill'; ?> me-1"></i><?= htmlspecialchars($mj['nomor_meja']); ?>
                                                    </div>
                                                    <small class="d-block" style="font-size: 0.7rem;">
                                                        <?php if ($isKosong): ?>
                                                            Kosong (<?= (int)$mj['kapasitas']; ?> Org)
                                                        <?php else: ?>
                                                            Terisi <?= $sisaMenit !== null ? '(' . $sisaMenit . ' mnt)' : ''; ?>
                                                        <?php endif; ?>
                                                    </small>
                                                </button>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="form-text text-muted small mb-3">
                                        <i class="bi bi-info-circle me-1"></i> Meja yang sudah dipesan otomatis terkunci dan tidak dapat diisi. Meja akan otomatis kosong kembali paling lambat <strong>1 jam setelah pesanan berstatus Siap</strong> (atau saat dikosongkan oleh Admin).
                                    </div>

                                    <!-- Input Untuk Berapa Orang -->
                                    <div class="p-3 bg-light rounded-3 border">
                                        <label class="form-label fw-bold text-dark mb-2">
                                            <i class="bi bi-people-fill text-warning me-1"></i> Pesan Meja Untuk Berapa Orang? <span class="text-danger">*</span>
                                        </label>
                                        <div class="row g-2 align-items-center">
                                            <div class="col-sm-8">
                                                <div class="d-flex flex-wrap gap-1">
                                                    <?php for ($org = 1; $org <= 6; $org++): ?>
                                                        <button type="button"
                                                                class="btn btn-sm <?= $org === 2 ? 'btn-warning text-dark fw-bold' : 'btn-outline-secondary'; ?> btn-jml-orang px-3"
                                                                onclick="pilihJumlahOrang(<?= $org; ?>, this)">
                                                            <?= $org; ?> Org
                                                        </button>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-4">
                                                <div class="input-group input-group-sm">
                                                    <input type="number" name="jumlah_orang" id="inputJumlahOrang" class="form-control fw-bold text-center" value="2" min="1" max="30" required>
                                                    <span class="input-group-text">Orang</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Input Alamat (Khusus Delivery) -->
                                <div class="mb-3 d-none" id="wrapAlamat">
                                    <label class="form-label fw-semibold">Alamat Lengkap Pengantaran <span class="text-danger">*</span></label>
                                    <textarea name="alamat_pengiriman" id="inputAlamat" class="form-control" rows="3" placeholder="Masukkan alamat lengkap, patokan, nomor rumah/kantor..."></textarea>
                                </div>

                                <div class="mb-2">
                                    <label class="form-label fw-semibold">Catatan Khusus (Opsional)</label>
                                    <textarea name="catatan" class="form-control" rows="2" placeholder="Contoh: Koyanya banyakin ya cak, kuah tanpa seledri..."></textarea>
                                </div>
                            </div>

                            <!-- Form Metode Pembayaran (Hanya QRIS, E-Wallet, dan Bank — Langsung Lunas Tidak Dicicil) -->
                            <div class="card border-0 shadow-sm p-4 rounded-4">
                                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
                                    <h5 class="fw-bold text-dark mb-0">
                                        <i class="bi bi-wallet2 text-warning me-2"></i> 2. Metode Pembayaran (QRIS, E-Wallet, & Bank)
                                    </h5>
                                    <span class="badge bg-warning text-dark px-3 py-1 rounded-pill fw-bold">
                                        <i class="bi bi-check-all me-1"></i> Bayar Penuh (Tidak Dicicil)
                                    </span>
                                </div>
                                <p class="text-muted small mb-3">
                                    Pilih salah satu metode pembayaran di bawah ini (<strong>QRIS</strong>, <strong>E-Wallet 085129763119 a.n Ibnu Andriano</strong>, atau <strong>VA / Bank</strong>). Pembayaran dilakukan langsung penuh sesuai total tagihan.
                                </p>

                                <input type="hidden" name="kanal_gateway" id="inputKanalGateway" value="qris_gateway">

                                <div class="list-group mb-3">
                                    <!-- Opsi 1: QRIS -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer border-warning bg-warning bg-opacity-10" id="lblMetode_qris">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="qris" checked onchange="togglePaymentInfo('qris')">
                                        <div class="w-100">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h6 class="mb-0 fw-bold"><i class="bi bi-qr-code-scan text-danger me-2"></i> QRIS Payment Gateway</h6>
                                                <span class="badge bg-danger">Semua Bank & E-Wallet</span>
                                            </div>
                                            <small class="text-muted">Scan barcode QRIS Cak Joyo (BCA, Mandiri, BRI, BNI, GoPay, OVO, DANA, ShopeePay, LinkAja).</small>
                                        </div>
                                    </label>

                                    <!-- Opsi 2: E-Wallet (085129763119 a.n Ibnu Andriano) -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer" id="lblMetode_ewallet">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="ewallet" onchange="togglePaymentInfo('ewallet')">
                                        <div class="w-100">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h6 class="mb-0 fw-bold"><i class="bi bi-phone text-info me-2"></i> E-Wallet (GoPay, OVO, DANA, ShopeePay, LinkAja)</h6>
                                                <span class="badge bg-info text-dark">085129763119</span>
                                            </div>
                                            <small class="text-muted">Pembayaran penuh melalui E-Wallet ke <strong>085129763119 a.n Ibnu Andriano</strong>.</small>
                                        </div>
                                    </label>

                                    <!-- Opsi 3: Transfer / Virtual Account Bank -->
                                    <label class="list-group-item d-flex gap-3 p-3 cursor-pointer" id="lblMetode_transfer">
                                        <input class="form-check-input flex-shrink-0" type="radio" name="metode" value="transfer" onchange="togglePaymentInfo('transfer')">
                                        <div class="w-100">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h6 class="mb-0 fw-bold"><i class="bi bi-bank text-primary me-2"></i> Virtual Account (VA) & Rekening Bank</h6>
                                                <span class="badge bg-primary">BCA / Mandiri / BRI / BNI</span>
                                            </div>
                                            <small class="text-muted">Pembayaran penuh melalui Virtual Account atau Rekening Bank resmi warung.</small>
                                        </div>
                                    </label>
                                </div>

                                <!-- Box Detail QRIS -->
                                <div id="boxQRIS" class="p-3 bg-light rounded-3 border mb-3">
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="uploads/qris/<?= htmlspecialchars($resto['qris_image']); ?>" alt="QRIS" class="rounded border bg-white p-1" style="width: 72px; height: 72px; object-fit: contain;" onerror="this.src='uploads/qris/qris_sample.png'">
                                        <div>
                                            <h6 class="fw-bold text-dark mb-1">QRIS Resmi Cak Joyo (NMID: <?= htmlspecialchars($resto['qris_nmid']); ?>)</h6>
                                            <p class="small text-muted mb-0">
                                                Barcode QRIS beserta Kode Bayar Gateway super pendek (4 karakter) akan tampil di halaman berikutnya.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Box Pilihan E-Wallet -->
                                <div id="boxEwallet" class="p-3 bg-light rounded-3 border mb-3 d-none">
                                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-phone text-info me-1"></i> Pilih Aplikasi E-Wallet (Tujuan: <strong>085129763119 a.n Ibnu Andriano</strong>):</h6>
                                    <div class="row g-2 mb-2">
                                        <div class="col-6 col-md-4">
                                            <input type="radio" class="btn-check" name="pilihan_ew" id="ew_gopay" value="ewallet_gopay" checked onchange="setSubKanal('ewallet_gopay')">
                                            <label class="btn btn-outline-success w-100 fw-bold btn-sm py-2" for="ew_gopay">💚 GoPay</label>
                                        </div>
                                        <div class="col-6 col-md-4">
                                            <input type="radio" class="btn-check" name="pilihan_ew" id="ew_dana" value="ewallet_dana" onchange="setSubKanal('ewallet_dana')">
                                            <label class="btn btn-outline-info text-dark w-100 fw-bold btn-sm py-2" for="ew_dana">💙 DANA</label>
                                        </div>
                                        <div class="col-6 col-md-4">
                                            <input type="radio" class="btn-check" name="pilihan_ew" id="ew_ovo" value="ewallet_ovo" onchange="setSubKanal('ewallet_ovo')">
                                            <label class="btn btn-outline-primary w-100 fw-bold btn-sm py-2" for="ew_ovo">💜 OVO</label>
                                        </div>
                                        <div class="col-6 col-md-6">
                                            <input type="radio" class="btn-check" name="pilihan_ew" id="ew_shopeepay" value="ewallet_shopeepay" onchange="setSubKanal('ewallet_shopeepay')">
                                            <label class="btn btn-outline-danger w-100 fw-bold btn-sm py-2" for="ew_shopeepay">🧡 ShopeePay</label>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <input type="radio" class="btn-check" name="pilihan_ew" id="ew_linkaja" value="ewallet_linkaja" onchange="setSubKanal('ewallet_linkaja')">
                                            <label class="btn btn-outline-danger w-100 fw-bold btn-sm py-2" for="ew_linkaja">❤️ LinkAja</label>
                                        </div>
                                    </div>
                                    <div class="p-2 bg-white rounded border small">
                                        <?= nl2br(htmlspecialchars($resto['ewallet_info'] ?? "GoPay / OVO / DANA / ShopeePay / LinkAja: 085129763119 a.n Ibnu Andriano")); ?>
                                    </div>
                                </div>

                                <!-- Box Pilihan Bank & VA -->
                                <div id="boxTransfer" class="p-3 bg-light rounded-3 border mb-3 d-none">
                                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-bank me-1 text-primary"></i> Pilih Bank / Virtual Account Tujuan:</h6>
                                    <div class="row g-2 mb-2">
                                        <div class="col-6">
                                            <input type="radio" class="btn-check" name="pilihan_va" id="va_bca" value="va_bca" checked onchange="setSubKanal('va_bca')">
                                            <label class="btn btn-outline-primary w-100 fw-bold btn-sm py-2" for="va_bca">🏦 Bank BCA</label>
                                        </div>
                                        <div class="col-6">
                                            <input type="radio" class="btn-check" name="pilihan_va" id="va_mandiri" value="va_mandiri" onchange="setSubKanal('va_mandiri')">
                                            <label class="btn btn-outline-primary w-100 fw-bold btn-sm py-2" for="va_mandiri">🏦 Bank Mandiri</label>
                                        </div>
                                        <div class="col-6">
                                            <input type="radio" class="btn-check" name="pilihan_va" id="va_bri" value="va_bri" onchange="setSubKanal('va_bri')">
                                            <label class="btn btn-outline-primary w-100 fw-bold btn-sm py-2" for="va_bri">🏦 Bank BRI</label>
                                        </div>
                                        <div class="col-6">
                                            <input type="radio" class="btn-check" name="pilihan_va" id="va_bni" value="va_bni" onchange="setSubKanal('va_bni')">
                                            <label class="btn btn-outline-primary w-100 fw-bold btn-sm py-2" for="va_bni">🏦 Bank BNI</label>
                                        </div>
                                    </div>
                                    <div class="p-2 bg-white rounded border small">
                                        <strong>Virtual Account (VA):</strong><br>
                                        <?= nl2br(htmlspecialchars($resto['va_bank_info'] ?? '')); ?>
                                        <hr class="my-1">
                                        <strong>Rekening Bank:</strong><br>
                                        <?= nl2br(htmlspecialchars($resto['rekening_bank'] ?? '')); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- KOLOM KANAN: Ringkasan Pesanan & Tombol Kirim -->
                        <div class="col-lg-5">
                            <div class="card border-0 shadow-sm p-4 rounded-4 sticky-top" style="top: 90px;">
                                <h5 class="fw-bold text-dark mb-3">
                                    <i class="bi bi-receipt text-warning me-2"></i> Ringkasan Pesanan
                                </h5>

                                <div class="table-responsive mb-3">
                                    <table class="table table-borderless align-middle mb-0">
                                        <tbody class="border-top">
                                            <?php foreach ($cart as $key => $item): 
                                                $subtotal = $item['harga'] * $item['jumlah'];
                                            ?>
                                                <tr class="border-bottom">
                                                    <td class="ps-0">
                                                        <div class="fw-bold text-dark"><?= htmlspecialchars($item['nama']); ?></div>
                                                        <div class="small text-muted"><?= $item['jumlah']; ?> x <?= format_rupiah($item['harga']); ?></div>
                                                        <?php if (!empty($item['catatan'])): ?>
                                                            <small class="text-warning fst-italic">"<?= htmlspecialchars($item['catatan']); ?>"</small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-end fw-bold pe-0">
                                                        <?= format_rupiah($subtotal); ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="d-flex justify-content-between mb-1">
                                    <span class="text-muted small">Skema Pembayaran:</span>
                                    <span class="small fw-bold text-dark">Langsung Lunas (100%)</span>
                                </div>

                                <div class="d-flex justify-content-between mb-2 pt-2 border-top">
                                    <span class="text-muted fw-semibold">Total Tagihan:</span>
                                    <span class="fs-4 fw-bold text-warning"><?= format_rupiah($total_harga); ?></span>
                                </div>

                                <hr class="my-3">

                                <button type="submit" class="btn btn-primary-cakjoyo w-100 py-3 fw-bold fs-6 rounded-3 shadow">
                                    <i class="bi bi-shield-check me-2"></i> Lanjut ke Pembayaran Gateway
                                </button>

                                <div class="text-center mt-3">
                                    <small class="text-muted d-block">
                                        <i class="bi bi-lock-fill text-success"></i> Pembayaran Penuh via QRIS, E-Wallet, atau Bank
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function pilihMeja(nomorMeja, btnEl) {
    document.getElementById('inputMeja').value = nomorMeja;
    document.querySelectorAll('.meja-card-btn').forEach(btn => {
        if (!btn.disabled) {
            btn.classList.remove('btn-success', 'text-white', 'fw-bold', 'shadow-sm');
            btn.classList.add('btn-outline-success');
        }
    });
    btnEl.classList.remove('btn-outline-success');
    btnEl.classList.add('btn-success', 'text-white', 'fw-bold', 'shadow-sm');
}

function pilihJumlahOrang(jml, btnEl) {
    document.getElementById('inputJumlahOrang').value = jml;
    document.querySelectorAll('.btn-jml-orang').forEach(btn => {
        btn.classList.remove('btn-warning', 'text-dark', 'fw-bold');
        btn.classList.add('btn-outline-secondary');
    });
    btnEl.classList.remove('btn-outline-secondary');
    btnEl.classList.add('btn-warning', 'text-dark', 'fw-bold');
}

// Handle perubahan tipe pesanan (Dine-in vs Delivery vs Takeaway)
document.querySelectorAll('input[name="tipe_pesanan"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const val = this.value;
        const wrapMeja = document.getElementById('wrapNomorMeja');
        const inputMeja = document.getElementById('inputMeja');
        const wrapAlamat = document.getElementById('wrapAlamat');
        const inputAlamat = document.getElementById('inputAlamat');

        if (val === 'dine_in') {
            wrapMeja.classList.remove('d-none');
            inputMeja.required = true;
            wrapAlamat.classList.add('d-none');
            inputAlamat.required = false;
        } else if (val === 'delivery') {
            wrapMeja.classList.add('d-none');
            inputMeja.required = false;
            wrapAlamat.classList.remove('d-none');
            inputAlamat.required = true;
        } else {
            // Take Away
            wrapMeja.classList.add('d-none');
            inputMeja.required = false;
            wrapAlamat.classList.add('d-none');
            inputAlamat.required = false;
        }
    });
});

function setSubKanal(kanal) {
    document.getElementById('inputKanalGateway').value = kanal;
}

// Handle perubahan metode pembayaran (Hanya QRIS, E-Wallet, dan Bank)
function togglePaymentInfo(metode) {
    const boxQRIS = document.getElementById('boxQRIS');
    const boxTransfer = document.getElementById('boxTransfer');
    const boxEwallet = document.getElementById('boxEwallet');
    const inputKanal = document.getElementById('inputKanalGateway');

    boxQRIS.classList.add('d-none');
    boxTransfer.classList.add('d-none');
    boxEwallet.classList.add('d-none');

    ['qris', 'transfer', 'ewallet'].forEach(m => {
        const lbl = document.getElementById('lblMetode_' + m);
        if (lbl) lbl.classList.remove('border-warning', 'bg-warning', 'bg-opacity-10');
    });
    const activeLbl = document.getElementById('lblMetode_' + metode);
    if (activeLbl) activeLbl.classList.add('border-warning', 'bg-warning', 'bg-opacity-10');

    if (metode === 'qris') {
        boxQRIS.classList.remove('d-none');
        inputKanal.value = 'qris_gateway';
    } else if (metode === 'transfer') {
        boxTransfer.classList.remove('d-none');
        const checkedVa = document.querySelector('input[name="pilihan_va"]:checked');
        inputKanal.value = checkedVa ? checkedVa.value : 'va_bca';
    } else if (metode === 'ewallet') {
        boxEwallet.classList.remove('d-none');
        const checkedEw = document.querySelector('input[name="pilihan_ew"]:checked');
        inputKanal.value = checkedEw ? checkedEw.value : 'ewallet_gopay';
    }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
