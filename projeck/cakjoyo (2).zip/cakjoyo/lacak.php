<?php
require_once __DIR__ . '/includes/header.php';

$search = clean($koneksi, $_GET['search'] ?? $_SESSION['last_order_code'] ?? '');
$orders = [];

if (!empty($search)) {
    $sql = "SELECT * FROM pesanan 
            WHERE kode_pesanan = '$search' 
               OR no_hp LIKE '%$search%' 
            ORDER BY id DESC LIMIT 5";
    $res = mysqli_query($koneksi, $sql);
    while ($row = mysqli_fetch_assoc($res)) {
        $orders[] = $row;
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-4">
                <span class="fs-1 text-warning"><i class="bi bi-search-heart"></i></span>
                <h2 class="fw-bold text-dark mt-2">Lacak Status Pesanan</h2>
                <p class="text-muted">Pantau status pengerjaan pesanan Soto Lamongan Anda secara real-time.</p>
            </div>

            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <form method="GET" action="lacak.php">
                    <label class="form-label fw-bold text-dark">Masukkan Kode Pesanan atau Nomor WhatsApp:</label>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-light border-end-0"><i class="bi bi-receipt"></i></span>
                        <input type="text" name="search" class="form-control border-start-0" placeholder="Contoh: CJ-261116-XXXX atau 081367219097" value="<?= htmlspecialchars($search); ?>" required>
                        <button class="btn btn-primary-cakjoyo px-4 fw-bold" type="submit">
                            <i class="bi bi-search me-1"></i> Cari
                        </button>
                    </div>
                    <div class="form-text text-muted mt-2">Kode pesanan didapatkan setelah Anda menyelesaikan checkout.</div>
                </form>
            </div>

            <?php if (!empty($search)): ?>
                <?php if (count($orders) > 0): ?>
                    <h5 class="fw-bold text-dark mb-3">Hasil Pencarian Pesanan (<?= count($orders); ?> ditemukan):</h5>
                    <?php foreach ($orders as $ord): 
                        $totOrd  = (int)$ord['total_harga'];
                        $dibOrd  = (int)($ord['jumlah_dibayar'] ?? 0);
                        $sisaOrd = max(0, $totOrd - $dibOrd);
                        $stBayar = $ord['status_pembayaran'] ?: 'Menunggu Pembayaran';
                    ?>
                        <div class="card border-0 shadow-sm p-4 rounded-4 mb-3">
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3 pb-3 border-bottom">
                                <div>
                                    <span class="badge bg-light text-dark border px-3 py-2 fs-6 fw-bold">
                                        <?= htmlspecialchars($ord['kode_pesanan']); ?>
                                    </span>
                                    <div class="small text-muted mt-1">
                                        <i class="bi bi-clock me-1"></i> <?= format_tanggal($ord['created_at']); ?>
                                    </div>
                                </div>
                                <div class="d-flex flex-wrap gap-2 align-items-center">
                                    <?= status_bayar_badge($stBayar, $sisaOrd); ?>
                                    <?= status_badge($ord['status']); ?>
                                </div>
                            </div>

                            <div class="row g-3 mb-3 small">
                                <div class="col-sm-6">
                                    <span class="text-muted">Nama Pemesan:</span>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($ord['nama_pelanggan']); ?></div>
                                </div>
                                <div class="col-sm-6">
                                    <span class="text-muted">Layanan & Meja:</span>
                                    <div class="fw-bold text-dark"><?= tipe_pesanan_label($ord['tipe_pesanan'], $ord['nomor_meja'], $ord['jumlah_orang'] ?? null); ?></div>
                                </div>
                                <div class="col-sm-6">
                                    <span class="text-muted">Kanal Payment Gateway:</span>
                                    <div class="fw-bold text-dark"><?= metode_bayar_label($ord['metode_pembayaran'], $ord['kanal_gateway'] ?? null); ?></div>
                                    <?php if (!empty($ord['kode_bayar_gateway'])): ?>
                                        <small class="text-primary font-monospace fw-bold">Kode: <?= htmlspecialchars($ord['kode_bayar_gateway']); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-6">
                                    <span class="text-muted">Tagihan Penuh (Tidak Dicicil):</span>
                                    <div class="fs-6 fw-bold text-warning"><?= format_rupiah($totOrd); ?></div>
                                    <?php if ($stBayar === 'Lunas'): ?>
                                        <div class="fw-bold text-success"><i class="bi bi-check-circle-fill me-1"></i>Sudah Lunas (Terkonfirmasi Admin)</div>
                                    <?php elseif ($stBayar === 'Menunggu Konfirmasi'): ?>
                                        <div class="fw-bold text-info"><i class="bi bi-hourglass-split me-1"></i>Menunggu Konfirmasi Admin</div>
                                    <?php else: ?>
                                        <div class="fw-bold text-danger"><i class="bi bi-exclamation-circle me-1"></i>Belum Lunas (<?= htmlspecialchars($stBayar); ?>)</div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="d-flex flex-wrap justify-content-end gap-2 pt-2 border-top">
                                <?php if ($stBayar !== 'Lunas'): ?>
                                    <a href="bayar_gateway.php?kode=<?= urlencode($ord['kode_pesanan']); ?>" class="btn btn-danger btn-sm rounded-pill px-3 fw-bold">
                                        <i class="bi bi-lightning-charge-fill me-1"></i>
                                        <?= $stBayar === 'Menunggu Konfirmasi' ? 'Cek Status Verifikasi' : 'Bayar Penuh via Gateway'; ?>
                                    </a>
                                <?php else: ?>
                                    <a href="bayar_gateway.php?kode=<?= urlencode($ord['kode_pesanan']); ?>" class="btn btn-outline-success btn-sm rounded-pill px-3 fw-bold">
                                        <i class="bi bi-shield-check me-1"></i> Detail Payment Gateway
                                    </a>
                                <?php endif; ?>
                                <a href="nota.php?kode=<?= urlencode($ord['kode_pesanan']); ?>" class="btn btn-outline-dark btn-sm rounded-pill px-3">
                                    <i class="bi bi-printer me-1"></i> Cetak Struk (1 Halaman)
                                </a>
                                <a href="<?= whatsapp_link($resto['no_wa'], 'Halo Cak Joyo, saya mau tanya status pesanan kode: ' . $ord['kode_pesanan']); ?>" target="_blank" class="btn btn-success btn-sm rounded-pill px-3">
                                    <i class="bi bi-whatsapp me-1"></i> Hubungi WA (081367219097)
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="card border-0 shadow-sm p-5 text-center rounded-4">
                        <span class="fs-1 text-danger d-block mb-3"><i class="bi bi-emoji-frown"></i></span>
                        <h5 class="fw-bold text-dark">Pesanan Tidak Ditemukan</h5>
                        <p class="text-muted small">Tidak ada pesanan dengan kode atau nomor HP <strong>"<?= htmlspecialchars($search); ?>"</strong>. Pastikan Anda memasukkan kode yang benar.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
