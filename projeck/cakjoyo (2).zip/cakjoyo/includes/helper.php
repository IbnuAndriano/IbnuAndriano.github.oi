<?php
/**
 * Helper Functions - Soto Lamongan Cak Joyo
 */

if (!function_exists('format_rupiah')) {
    function format_rupiah($angka) {
        return "Rp " . number_format((float)$angka, 0, ',', '.');
    }
}

if (!function_exists('format_tanggal')) {
    function format_tanggal($datetime) {
        if (!$datetime) return "-";
        $timestamp = strtotime($datetime);
        $bulanIndo = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        $tgl = date('d', $timestamp);
        $bln = (int)date('m', $timestamp);
        $thn = date('Y', $timestamp);
        $jam = date('H:i', $timestamp);
        return "$tgl {$bulanIndo[$bln]} $thn, $jam WIB";
    }
}

if (!function_exists('status_badge')) {
    function status_badge($status) {
        switch ($status) {
            case 'Baru':
                return '<span class="badge bg-primary text-white"><i class="bi bi-clock-history me-1"></i>Pesanan Baru</span>';
            case 'Diproses':
                return '<span class="badge bg-warning text-dark"><i class="bi bi-fire me-1"></i>Sedang Dimasak</span>';
            case 'Siap':
                return '<span class="badge bg-info text-dark"><i class="bi bi-bell me-1"></i>Siap Disajikan</span>';
            case 'Selesai':
                return '<span class="badge bg-success text-white"><i class="bi bi-check-circle me-1"></i>Selesai</span>';
            case 'Dibatalkan':
                return '<span class="badge bg-danger text-white"><i class="bi bi-x-circle me-1"></i>Dibatalkan</span>';
            default:
                return '<span class="badge bg-secondary">' . htmlspecialchars($status) . '</span>';
        }
    }
}

if (!function_exists('tipe_pesanan_label')) {
    function tipe_pesanan_label($tipe, $meja = null, $jumlah_orang = null) {
        switch ($tipe) {
            case 'dine_in':
                $infoMeja = '';
                if (!empty($meja)) {
                    $labelMeja = (stripos($meja, 'meja') !== false) ? $meja : 'Meja ' . $meja;
                    $orgStr = (!empty($jumlah_orang) && (int)$jumlah_orang > 0) ? ' • ' . (int)$jumlah_orang . ' Orang' : '';
                    $infoMeja = ' (' . htmlspecialchars($labelMeja) . $orgStr . ')';
                }
                return '🍽️ Makan di Tempat' . $infoMeja;
            case 'take_away':
                return '🥡 Bawa Pulang (Take Away)';
            case 'delivery':
                return '🛵 Pengantaran (Delivery)';
            default:
                return htmlspecialchars($tipe);
        }
    }
}

if (!function_exists('metode_bayar_label')) {
    function metode_bayar_label($metode, $kanal_gateway = null) {
        if (!empty($kanal_gateway)) {
            return kanal_gateway_label($kanal_gateway);
        }
        switch (strtolower($metode)) {
            case 'qris':
                return '📱 QRIS (Semua E-Wallet & Bank)';
            case 'transfer':
            case 'bank':
                return '🏦 Transfer / Virtual Account Bank';
            case 'ewallet':
                return '📱 E-Wallet (085129763119 a.n Ibnu Andriano)';
            default:
                return '📱 ' . htmlspecialchars(ucfirst($metode));
        }
    }
}

if (!function_exists('status_bayar_badge')) {
    function status_bayar_badge($status_bayar, $sisa_tagihan = 0) {
        $status_bayar = $status_bayar ?: 'Menunggu Pembayaran';
        switch ($status_bayar) {
            case 'Lunas':
                return '<span class="badge bg-success text-white px-2 py-1"><i class="bi bi-patch-check-fill me-1"></i>Lunas</span>';
            case 'Menunggu Konfirmasi':
                return '<span class="badge bg-info text-dark px-2 py-1"><i class="bi bi-shield-exclamation me-1"></i>Menunggu Konfirmasi Admin</span>';
            case 'Menunggu Pembayaran':
                return '<span class="badge bg-warning text-dark px-2 py-1"><i class="bi bi-hourglass-split me-1"></i>Menunggu Pembayaran</span>';
            case 'Belum Masuk':
            case 'Gagal':
                return '<span class="badge bg-danger text-white px-2 py-1"><i class="bi bi-x-octagon-fill me-1"></i>Belum Masuk / Perlu Konfirmasi Ulang</span>';
            default:
                return '<span class="badge bg-secondary px-2 py-1">' . htmlspecialchars($status_bayar) . '</span>';
        }
    }
}

if (!function_exists('daftar_kanal_gateway')) {
    function daftar_kanal_gateway() {
        return [
            'qris_gateway' => [
                'grup' => 'QRIS Payment Gateway',
                'nama' => 'QRIS (Semua Bank & E-Wallet)',
                'singkat' => 'QRIS',
                'metode' => 'qris',
                'ikon' => 'bi-qr-code-scan',
                'warna' => 'danger',
                'instruksi' => 'Scan barcode QRIS Cak Joyo sesuai nominal penuh tagihan (tidak dicicil), lalu klik tombol Konfirmasi Pembayaran di bawah.'
            ],
            'ewallet_gopay' => [
                'grup' => 'E-Wallet (085129763119 a.n Ibnu Andriano)',
                'nama' => 'GoPay (085129763119 a.n Ibnu Andriano)',
                'singkat' => 'GoPay',
                'metode' => 'ewallet',
                'ikon' => 'bi-wallet2',
                'warna' => 'success',
                'instruksi' => 'Transfer penuh ke nomor GoPay: 085129763119 (a.n Ibnu Andriano), lalu klik Konfirmasi Pembayaran.'
            ],
            'ewallet_dana' => [
                'grup' => 'E-Wallet (085129763119 a.n Ibnu Andriano)',
                'nama' => 'DANA (085129763119 a.n Ibnu Andriano)',
                'singkat' => 'DANA',
                'metode' => 'ewallet',
                'ikon' => 'bi-wallet2',
                'warna' => 'info',
                'instruksi' => 'Transfer penuh ke nomor DANA: 085129763119 (a.n Ibnu Andriano), lalu klik Konfirmasi Pembayaran.'
            ],
            'ewallet_ovo' => [
                'grup' => 'E-Wallet (085129763119 a.n Ibnu Andriano)',
                'nama' => 'OVO (085129763119 a.n Ibnu Andriano)',
                'singkat' => 'OVO',
                'metode' => 'ewallet',
                'ikon' => 'bi-phone-vibrate',
                'warna' => 'primary',
                'instruksi' => 'Transfer penuh ke nomor OVO: 085129763119 (a.n Ibnu Andriano), lalu klik Konfirmasi Pembayaran.'
            ],
            'ewallet_shopeepay' => [
                'grup' => 'E-Wallet (085129763119 a.n Ibnu Andriano)',
                'nama' => 'ShopeePay (085129763119 a.n Ibnu Andriano)',
                'singkat' => 'ShopeePay',
                'metode' => 'ewallet',
                'ikon' => 'bi-bag-heart-fill',
                'warna' => 'danger',
                'instruksi' => 'Transfer penuh ke nomor ShopeePay: 085129763119 (a.n Ibnu Andriano), lalu klik Konfirmasi Pembayaran.'
            ],
            'ewallet_linkaja' => [
                'grup' => 'E-Wallet (085129763119 a.n Ibnu Andriano)',
                'nama' => 'LinkAja (085129763119 a.n Ibnu Andriano)',
                'singkat' => 'LinkAja',
                'metode' => 'ewallet',
                'ikon' => 'bi-phone-fill',
                'warna' => 'danger',
                'instruksi' => 'Transfer penuh ke nomor LinkAja: 085129763119 (a.n Ibnu Andriano), lalu klik Konfirmasi Pembayaran.'
            ],
            'va_bca' => [
                'grup' => 'Transfer / Virtual Account Bank',
                'nama' => 'Bank BCA (VA / Transfer)',
                'singkat' => 'Bank BCA',
                'metode' => 'transfer',
                'ikon' => 'bi-bank',
                'warna' => 'primary',
                'instruksi' => 'Gunakan kode Virtual Account BCA pendek di atas (atau rekening BCA toko) dengan nominal penuh tanpa dicicil.'
            ],
            'va_mandiri' => [
                'grup' => 'Transfer / Virtual Account Bank',
                'nama' => 'Bank Mandiri (VA / Transfer)',
                'singkat' => 'Bank Mandiri',
                'metode' => 'transfer',
                'ikon' => 'bi-bank',
                'warna' => 'warning',
                'instruksi' => 'Gunakan kode Virtual Account Mandiri pendek di atas (atau rekening Mandiri toko) dengan nominal penuh.'
            ],
            'va_bri' => [
                'grup' => 'Transfer / Virtual Account Bank',
                'nama' => 'Bank BRI (BRIVA / Transfer)',
                'singkat' => 'Bank BRI',
                'metode' => 'transfer',
                'ikon' => 'bi-bank',
                'warna' => 'info',
                'instruksi' => 'Gunakan kode BRIVA pendek di atas (atau rekening BRI toko) dengan nominal penuh.'
            ],
            'va_bni' => [
                'grup' => 'Transfer / Virtual Account Bank',
                'nama' => 'Bank BNI (VA / Transfer)',
                'singkat' => 'Bank BNI',
                'metode' => 'transfer',
                'ikon' => 'bi-bank',
                'warna' => 'success',
                'instruksi' => 'Gunakan kode Virtual Account BNI pendek di atas dengan nominal penuh sesuai total tagihan.'
            ]
        ];
    }
}

if (!function_exists('kanal_gateway_label')) {
    function kanal_gateway_label($kanal) {
        $daftar = daftar_kanal_gateway();
        if (isset($daftar[$kanal])) {
            return '⚡ ' . $daftar[$kanal]['nama'];
        }
        return htmlspecialchars(ucfirst(str_replace('_', ' ', (string)$kanal)));
    }
}

if (!function_exists('generate_kode_bayar_gateway')) {
    function generate_kode_bayar_gateway($kanal, $no_hp = '', $kode_pesanan = '') {
        // Dibuat SANGAT PENDEK (4 karakter saja) dan rapih sesuai permintaan user
        $last2 = strtoupper(substr(preg_replace('/[^A-Z0-9]/', '', (string)$kode_pesanan), -2));
        if (strlen($last2) < 2) {
            $last2 = '97';
        }
        switch ($kanal) {
            case 'va_bca':
                return 'BC' . $last2;
            case 'va_mandiri':
                return 'MD' . $last2;
            case 'va_bri':
                return 'BR' . $last2;
            case 'va_bni':
                return 'BN' . $last2;
            case 'qris_gateway':
                return 'QR' . $last2;
            default:
                return 'EW' . $last2;
        }
    }
}

if (!function_exists('generate_referensi_gateway')) {
    function generate_referensi_gateway() {
        return "PG" . rand(10, 99);
    }
}

if (!function_exists('generate_kode_pesanan')) {
    function generate_kode_pesanan() {
        return "CJ-" . strtoupper(substr(uniqid(), -4));
    }
}

if (!function_exists('sync_status_meja')) {
    function sync_status_meja($koneksi) {
        // 1. Jika ada pesanan di meja yang sudah berstatus 'Siap', pastikan waktu_siap tercatat
        @mysqli_query($koneksi, "UPDATE meja m 
            JOIN pesanan p ON m.pesanan_id_aktif = p.id 
            SET m.waktu_siap = COALESCE(m.waktu_siap, p.waktu_siap, NOW()),
                p.waktu_siap = COALESCE(p.waktu_siap, m.waktu_siap, NOW())
            WHERE m.status_meja = 'terisi' AND p.status = 'Siap' AND m.waktu_siap IS NULL");

        // 2. Kosongkan meja secara otomatis jika:
        //    a) Status pesanan sudah 'Siap' dan sudah berjalan >= 1 jam (3600 detik), ATAU
        //    b) Status pesanan sudah 'Selesai' atau 'Dibatalkan'
        @mysqli_query($koneksi, "UPDATE meja m
            LEFT JOIN pesanan p ON m.pesanan_id_aktif = p.id
            SET m.status_meja = 'kosong',
                m.pesanan_id_aktif = NULL,
                m.jumlah_orang_aktif = NULL,
                m.waktu_mulai_terisi = NULL,
                m.waktu_siap = NULL
            WHERE m.status_meja = 'terisi'
              AND (
                  (p.status = 'Siap' AND m.waktu_siap IS NOT NULL AND TIMESTAMPDIFF(SECOND, m.waktu_siap, NOW()) >= 3600)
                  OR (p.status IN ('Selesai', 'Dibatalkan'))
                  OR (m.pesanan_id_aktif IS NOT NULL AND p.id IS NULL)
              )");
    }
}

if (!function_exists('tandai_status_pesanan_dan_meja')) {
    function tandai_status_pesanan_dan_meja($koneksi, $pesanan_id, $newStatus) {
        $pesanan_id = (int)$pesanan_id;
        $newStatus  = clean($koneksi, $newStatus);

        if ($newStatus === 'Siap') {
            mysqli_query($koneksi, "UPDATE pesanan SET status = 'Siap', waktu_siap = COALESCE(waktu_siap, NOW()) WHERE id = $pesanan_id");
            mysqli_query($koneksi, "UPDATE meja SET waktu_siap = COALESCE(waktu_siap, NOW()) WHERE pesanan_id_aktif = $pesanan_id");
        } elseif (in_array($newStatus, ['Selesai', 'Dibatalkan'])) {
            mysqli_query($koneksi, "UPDATE pesanan SET status = '$newStatus' WHERE id = $pesanan_id");
            mysqli_query($koneksi, "UPDATE meja SET status_meja = 'kosong', pesanan_id_aktif = NULL, jumlah_orang_aktif = NULL, waktu_mulai_terisi = NULL, waktu_siap = NULL WHERE pesanan_id_aktif = $pesanan_id");
        } else {
            mysqli_query($koneksi, "UPDATE pesanan SET status = '$newStatus' WHERE id = $pesanan_id");
        }
    }
}

if (!function_exists('get_daftar_meja')) {
    function get_daftar_meja($koneksi) {
        sync_status_meja($koneksi);
        $list = [];
        $q = mysqli_query($koneksi, "SELECT m.*, p.kode_pesanan, p.nama_pelanggan, p.jumlah_orang, p.status AS status_pesanan,
            CASE WHEN m.waktu_siap IS NOT NULL THEN GREATEST(0, 3600 - TIMESTAMPDIFF(SECOND, m.waktu_siap, NOW())) ELSE NULL END AS sisa_detik_siap
            FROM meja m
            LEFT JOIN pesanan p ON m.pesanan_id_aktif = p.id
            ORDER BY m.id ASC");
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $list[] = $r;
            }
        }
        return $list;
    }
}

if (!function_exists('get_pengaturan')) {
    function get_pengaturan($koneksi) {
        $query = mysqli_query($koneksi, "SELECT * FROM pengaturan WHERE id = 1 LIMIT 1");
        if ($query && mysqli_num_rows($query) > 0) {
            return mysqli_fetch_assoc($query);
        }
        // Fallback default
        return [
            'nama_resto' => 'Soto ayam lamongan cak joyo',
            'slogan' => 'Menerima pesanan - Kelezatan Asli Soto Lamongan',
            'no_wa' => '081367219097',
            'alamat' => 'Jl. Pemuda No. 45, Lamongan / Surabaya, Jawa Timur',
            'jam_buka' => 'Buka 06.00-17.00',
            'qris_image' => 'qris_sample.png',
            'qris_nmid' => 'ID1020030040050',
            'rekening_bank' => "BCA: 8735123490 a.n Pak Cak Joyo\nMandiri: 142001928374 a.n Pak Cak Joyo",
            'va_bank_info' => "BCA Virtual Account: BC801 a.n Ibnu Andriano\nMandiri Virtual Account: MD902 a.n Ibnu Andriano\nBRI Virtual Account (BRIVA): BR788 a.n Ibnu Andriano\nBNI Virtual Account: BN241 a.n Ibnu Andriano",
            'ewallet_info' => "GoPay: 085129763119 a.n Ibnu Andriano\nOVO: 085129763119 a.n Ibnu Andriano\nDANA: 085129763119 a.n Ibnu Andriano\nShopeePay: 085129763119 a.n Ibnu Andriano\nLinkAja: 085129763119 a.n Ibnu Andriano",
            'pg_auto_confirm' => 0
        ];
    }
}

if (!function_exists('clean')) {
    function clean($koneksi, $data) {
        if (is_null($data)) return '';
        return mysqli_real_escape_string($koneksi, trim($data));
    }
}

if (!function_exists('whatsapp_link')) {
    function whatsapp_link($no_wa, $pesan) {
        // Normalisasi nomor wa (hilangkan karakter selain angka)
        $no_wa = preg_replace('/[^0-9]/', '', $no_wa);
        if (substr($no_wa, 0, 1) === '0') {
            $no_wa = '62' . substr($no_wa, 1);
        }
        return "https://api.whatsapp.com/send?phone=" . urlencode($no_wa) . "&text=" . urlencode($pesan);
    }
}
?>
