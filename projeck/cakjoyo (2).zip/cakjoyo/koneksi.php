<?php
/**
 * Koneksi Database Soto Lamongan Cak Joyo
 */

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_cakjoyo";

// Matikan exception otomatis mysqli agar error ditangani secara aman
mysqli_report(MYSQLI_REPORT_OFF);

$koneksi = @mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    // Cek apakah server MySQL jalan tapi databasenya belum dibuat
    $check_server = @mysqli_connect($host, $user, $pass);
    if ($check_server) {
        // Otomatis buat database jika belum ada
        mysqli_query($check_server, "CREATE DATABASE IF NOT EXISTS `$db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $koneksi = @mysqli_connect($host, $user, $pass, $db);
        mysqli_close($check_server);
    }
    
    if (!$koneksi) {
        die("
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 25px; border: 1px solid #f5c6cb; border-radius: 8px; background: #fdf7f7;'>
                <h3 style='color: #721c24; margin-top: 0;'>❌ Gagal Terhubung ke MySQL</h3>
                <p>Tidak dapat terhubung ke server database XAMPP.</p>
                <p><strong>Langkah Mengatasi:</strong></p>
                <ol>
                    <li>Buka aplikasi <strong>XAMPP Control Panel</strong>.</li>
                    <li>Pastikan modul <strong>Apache</strong> dan <strong>MySQL</strong> dalam status <strong>Running</strong>.</li>
                    <li>Refresh kembali halaman ini.</li>
                </ol>
            </div>
        ");
    }
}

mysqli_set_charset($koneksi, "utf8mb4");

// Auto-check jika tabel-tabel utama (seperti kategori / menu) belum terbuat, buat otomatis dari database.sql
$checkTable = @mysqli_query($koneksi, "SHOW TABLES LIKE 'kategori'");
if (!$checkTable || mysqli_num_rows($checkTable) === 0) {
    $sqlFile = __DIR__ . '/database.sql';
    if (file_exists($sqlFile)) {
        $sqlContent = file_get_contents($sqlFile);
        if ($koneksi->multi_query($sqlContent)) {
            do {
                if ($res = $koneksi->store_result()) {
                    $res->free();
                }
            } while ($koneksi->more_results() && $koneksi->next_result());
        }
    }
}

// Auto-add ewallet_info column if missing (upgrade existing installs)
$checkEwallet = @mysqli_query($koneksi, "SHOW COLUMNS FROM pengaturan LIKE 'ewallet_info'");
if ($checkEwallet && mysqli_num_rows($checkEwallet) === 0) {
    @mysqli_query($koneksi, "ALTER TABLE pengaturan ADD COLUMN ewallet_info TEXT DEFAULT NULL");
}

// Auto-add Payment Gateway columns to pengaturan if missing
$pgConfigCols = [
    'pg_aktif'        => "TINYINT(1) NOT NULL DEFAULT 1",
    'pg_auto_confirm' => "TINYINT(1) NOT NULL DEFAULT 0",
    'pg_nama'         => "VARCHAR(100) DEFAULT 'CakJoyo Payment Gateway'",
    'pg_mode'         => "VARCHAR(30) DEFAULT 'sandbox'",
    'pg_merchant_id'  => "VARCHAR(100) DEFAULT 'ID-CAKJOYO-PG01'",
    'pg_client_key'   => "VARCHAR(150) DEFAULT 'SB-Mid-client-CakJoyo2026'",
    'pg_server_key'   => "VARCHAR(150) DEFAULT 'SB-Mid-server-CakJoyo2026'",
    'va_bank_info'    => "TEXT DEFAULT NULL"
];
foreach ($pgConfigCols as $colName => $colDef) {
    $chk = @mysqli_query($koneksi, "SHOW COLUMNS FROM pengaturan LIKE '$colName'");
    if ($chk && mysqli_num_rows($chk) === 0) {
        @mysqli_query($koneksi, "ALTER TABLE pengaturan ADD COLUMN $colName $colDef");
    }
}

// Update nomor WA (081367219097), E-Wallet (085129763119 a.n Ibnu Andriano), dan VA Bank default
$defaultEwalletIbnu = "GoPay: 085129763119 a.n Ibnu Andriano\nOVO: 085129763119 a.n Ibnu Andriano\nDANA: 085129763119 a.n Ibnu Andriano\nShopeePay: 085129763119 a.n Ibnu Andriano\nLinkAja: 085129763119 a.n Ibnu Andriano";
$defaultVaBankInfo  = "BCA Virtual Account: BC801 a.n Ibnu Andriano\nMandiri Virtual Account: MD902 a.n Ibnu Andriano\nBRI Virtual Account (BRIVA): BR788 a.n Ibnu Andriano\nBNI Virtual Account: BN241 a.n Ibnu Andriano";

@mysqli_query($koneksi, "UPDATE pengaturan SET no_wa = '081367219097' WHERE id = 1 AND no_wa = '081292543664'");
@mysqli_query($koneksi, "UPDATE pengaturan SET ewallet_info = '$defaultEwalletIbnu' WHERE id = 1 AND (ewallet_info IS NULL OR ewallet_info LIKE '%081292543664%' OR ewallet_info LIKE '%081367219097%')");
@mysqli_query($koneksi, "UPDATE pengaturan SET va_bank_info = '$defaultVaBankInfo' WHERE id = 1 AND (va_bank_info IS NULL OR va_bank_info = '')");

// Auto-add Payment Gateway & Table Tracking columns to pesanan if missing
$pgPesananCols = [
    'jumlah_orang'       => "INT NOT NULL DEFAULT 1",
    'status_pembayaran'  => "VARCHAR(40) NOT NULL DEFAULT 'Menunggu Pembayaran'",
    'jumlah_dibayar'     => "INT NOT NULL DEFAULT 0",
    'sisa_tagihan'       => "INT NOT NULL DEFAULT 0",
    'kanal_gateway'      => "VARCHAR(60) DEFAULT NULL",
    'kode_bayar_gateway' => "VARCHAR(100) DEFAULT NULL",
    'referensi_gateway'  => "VARCHAR(100) DEFAULT NULL",
    'waktu_bayar'        => "DATETIME DEFAULT NULL",
    'batas_waktu_bayar'  => "DATETIME DEFAULT NULL",
    'waktu_siap'         => "DATETIME DEFAULT NULL"
];
foreach ($pgPesananCols as $colName => $colDef) {
    $chk = @mysqli_query($koneksi, "SHOW COLUMNS FROM pesanan LIKE '$colName'");
    if ($chk && mysqli_num_rows($chk) === 0) {
        @mysqli_query($koneksi, "ALTER TABLE pesanan ADD COLUMN $colName $colDef");
    }
}
// Pastikan kolom status_pembayaran bertipe VARCHAR(40) agar mendukung 'Menunggu Konfirmasi'
@mysqli_query($koneksi, "ALTER TABLE pesanan MODIFY COLUMN status_pembayaran VARCHAR(40) NOT NULL DEFAULT 'Menunggu Pembayaran'");

// Auto-create pembayaran_gateway log table if missing
@mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS `pembayaran_gateway` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `pesanan_id` INT NOT NULL,
  `kode_pesanan` VARCHAR(50) NOT NULL,
  `kode_referensi` VARCHAR(80) NOT NULL,
  `kanal_pembayaran` VARCHAR(60) NOT NULL,
  `nominal_bayar` INT NOT NULL,
  `status_transaksi` VARCHAR(30) NOT NULL DEFAULT 'Menunggu Konfirmasi',
  `keterangan` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (`pesanan_id`),
  INDEX (`kode_pesanan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
@mysqli_query($koneksi, "ALTER TABLE pembayaran_gateway MODIFY COLUMN status_transaksi VARCHAR(30) NOT NULL DEFAULT 'Menunggu Konfirmasi'");

// Auto-create tabel `meja` untuk manajemen meja otomatis & manual admin
@mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS `meja` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nomor_meja` VARCHAR(25) NOT NULL UNIQUE,
  `kapasitas` INT NOT NULL DEFAULT 4,
  `status_meja` ENUM('kosong', 'terisi') NOT NULL DEFAULT 'kosong',
  `pesanan_id_aktif` INT DEFAULT NULL,
  `jumlah_orang_aktif` INT DEFAULT NULL,
  `waktu_mulai_terisi` DATETIME DEFAULT NULL,
  `waktu_siap` DATETIME DEFAULT NULL,
  INDEX (`status_meja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$chkJmlOrgMeja = @mysqli_query($koneksi, "SHOW COLUMNS FROM meja LIKE 'jumlah_orang_aktif'");
if ($chkJmlOrgMeja && mysqli_num_rows($chkJmlOrgMeja) === 0) {
    @mysqli_query($koneksi, "ALTER TABLE meja ADD COLUMN jumlah_orang_aktif INT DEFAULT NULL");
}

// Seed 12 meja default jika tabel meja masih kosong
$chkMeja = @mysqli_query($koneksi, "SELECT COUNT(*) as c FROM meja");
if ($chkMeja && (int)mysqli_fetch_assoc($chkMeja)['c'] === 0) {
    for ($m = 1; $m <= 12; $m++) {
        $noMejaStr = 'Meja ' . str_pad((string)$m, 2, '0', STR_PAD_LEFT);
        $kap = ($m <= 8) ? 4 : 6;
        @mysqli_query($koneksi, "INSERT IGNORE INTO meja (nomor_meja, kapasitas, status_meja) VALUES ('$noMejaStr', $kap, 'kosong')");
    }
}

// Sinkronisasi kredensial admin resmi (admin / Ibnu@2026!)
$newAdminHash = '$2y$10$PY8WEiOZ9Gzmj.2B2d0BGOyqC499SKeMHVcmQ77BeKpdlHbHvfJ1C';
@mysqli_query($koneksi, "UPDATE admin SET username = 'admin', password = '$newAdminHash' WHERE id = 1 OR username = 'admin'");

// Muat fungsi helper global
require_once __DIR__ . '/includes/helper.php';

// Jalankan sinkronisasi otomatis meja (kosongkan meja otomatis jika sudah lewat 1 jam sejak status pesanan 'Siap')
if (function_exists('sync_status_meja')) {
    sync_status_meja($koneksi);
}
?>
