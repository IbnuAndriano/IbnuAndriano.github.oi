<?php
require_once __DIR__ . '/includes/header.php';

// Ambil data kategori
$kategoriQuery = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY urutan ASC");
$kategoriList = [];
if ($kategoriQuery) {
    while ($kat = mysqli_fetch_assoc($kategoriQuery)) {
        $kategoriList[] = $kat;
    }
}

// Ambil seluruh menu yang aktif
$sqlMenu = "SELECT m.*, k.nama_kategori, k.slug 
            FROM menu m 
            LEFT JOIN kategori k ON m.kategori_id = k.id 
            ORDER BY m.is_favorite DESC, m.id ASC";
$menuQuery = mysqli_query($koneksi, $sqlMenu);
?>

<!-- HERO SECTION -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <div class="hero-badge">
                    <i class="bi bi-clock-history"></i> Buka 06.00-17.00 • <span class="text-white fw-bold">Menerima Pesanan</span>
                </div>
                <h1 class="hero-title">
                    Kuah Gurih Berempah, <span>Koya Udang Melimpah!</span>
                </h1>
                <p class="hero-desc">
                    Selamat datang di <strong><?= htmlspecialchars($resto['nama_resto']); ?></strong> (Owner: <strong>Pak Cak Joyo</strong>). Nikmati kelezatan soto ayam legendaris dengan suwiran ayam gurih, kaldu kuning aromatik kaya rempah, dan bubuk koya renyah yang bikin nagih.
                </p>
                <div class="d-flex flex-wrap gap-3 mb-4">
                    <a href="#menu-section" class="btn btn-primary-cakjoyo btn-lg px-4 py-3">
                        <i class="bi bi-fire me-2"></i> Pesan Menu Sekarang
                    </a>
                    <a href="<?= whatsapp_link($resto['no_wa'], 'Halo Pak Cak Joyo, saya mau pesan...'); ?>" target="_blank" class="btn btn-outline-light btn-lg px-4 py-3">
                        <i class="bi bi-whatsapp text-success me-2"></i> Hubungi WhatsApp: <?= htmlspecialchars($resto['no_wa']); ?>
                    </a>
                </div>

                <div class="d-flex flex-wrap gap-4 pt-3 border-top border-secondary">
                    <div class="hero-feature-item">
                        <div class="hero-feature-icon"><i class="bi bi-person-badge-fill"></i></div>
                        <span>Owner: <strong>Pak Cak Joyo</strong></span>
                    </div>
                    <div class="hero-feature-item">
                        <div class="hero-feature-icon"><i class="bi bi-bag-check-fill"></i></div>
                        <span>Menerima Pesanan</span>
                    </div>
                    <div class="hero-feature-item">
                        <div class="hero-feature-icon"><i class="bi bi-clock-fill"></i></div>
                        <span>Buka 06.00 - 17.00</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 text-center">
                <div class="position-relative d-inline-block">
                    <img src="uploads/menu/soto_ayam.jpg" alt="Soto Ayam Lamongan Cak Joyo" class="img-fluid rounded-4 shadow-lg border border-3 border-warning" style="max-height: 380px; width: 100%; object-fit: cover;">
                    <div class="position-absolute bottom-0 start-50 translate-middle-x mb-n3 bg-white text-dark px-4 py-2 rounded-pill shadow-lg border border-warning text-nowrap">
                        <span class="fw-bold text-danger"><i class="bi bi-award-fill"></i> Menu Terfavorit</span> • <strong>Rp 11.000</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- HIGHLIGHT FITUR / KEUNGGULAN -->
<section class="py-5 bg-white border-bottom">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-3 col-6">
                <div class="feature-highlight-card p-3">
                    <div class="feature-highlight-icon mb-3"><i class="bi bi-fire"></i></div>
                    <h6 class="fw-bold text-dark mb-1">Kaldu Berempah Asli</h6>
                    <p class="small text-secondary mb-0">Diracik dengan rempah tradisional pilihan khas Jawa Timur.</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="feature-highlight-card p-3">
                    <div class="feature-highlight-icon mb-3"><i class="bi bi-sparkles"></i></div>
                    <h6 class="fw-bold text-dark mb-1">Koya Renyah Melimpah</h6>
                    <p class="small text-secondary mb-0">Koya udang gurih renyah bikin kuah soto makin kental mantap.</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="feature-highlight-card p-3">
                    <div class="feature-highlight-icon mb-3"><i class="bi bi-truck"></i></div>
                    <h6 class="fw-bold text-dark mb-1">Dine-in & Delivery</h6>
                    <p class="small text-secondary mb-0">Bisa pesan di tempat atau diantar hangat langsung ke rumah.</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="feature-highlight-card p-3">
                    <div class="feature-highlight-icon mb-3"><i class="bi bi-shield-check"></i></div>
                    <h6 class="fw-bold text-dark mb-1">Higienis & Segar</h6>
                    <p class="small text-secondary mb-0">Bahan ayam segar berkualitas, racikan bersih, serta bumbu rempah terjamin.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- MENU SECTION -->
<section id="menu-section" class="py-5">
    <div class="container">
        <div class="section-title-wrap">
            <span class="section-tag">DAFTAR MENU KAMI</span>
            <h2 class="section-heading">Pilihan Soto & Hidangan Lezat</h2>
            <p class="section-subheading">Silakan pilih menu favorit Anda, tambahkan ke keranjang, dan pesan dengan mudah.</p>
        </div>

        <!-- Search Bar -->
        <div class="row justify-content-center mb-4">
            <div class="col-md-6">
                <div class="input-group shadow-sm rounded-pill overflow-hidden bg-white p-1 border">
                    <span class="input-group-text bg-transparent border-0 ps-3 text-muted">
                        <i class="bi bi-search"></i>
                    </span>
                    <input type="text" id="searchMenu" class="form-control border-0 shadow-none ps-2" placeholder="Cari menu soto, lauk, atau minuman...">
                </div>
            </div>
        </div>

        <!-- Filter Kategori Tabs -->
        <div class="category-tabs">
            <button class="category-pill active" data-category="all">
                <i class="bi bi-grid-fill me-1"></i> Semua Menu
            </button>
            <?php foreach($kategoriList as $kat): ?>
                <button class="category-pill" data-category="<?= htmlspecialchars($kat['slug']); ?>">
                    <?= htmlspecialchars($kat['nama_kategori']); ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Grid Menu Items -->
        <div class="row g-4" id="menuGridContainer">
            <?php if ($menuQuery && mysqli_num_rows($menuQuery) > 0): ?>
                <?php while ($m = mysqli_fetch_assoc($menuQuery)): ?>
                    <div class="col-lg-4 col-md-6 menu-col" data-category="<?= htmlspecialchars($m['slug'] ?? 'lainnya'); ?>">
                        <div class="menu-card">
                            <div class="menu-img-wrap">
                                <img src="uploads/menu/<?= htmlspecialchars($m['gambar']); ?>" alt="<?= htmlspecialchars($m['nama_menu']); ?>" class="menu-img" onerror="this.src='uploads/menu/default_soto.jpg'">
                                
                                <?php if ($m['is_favorite'] == 1): ?>
                                    <span class="badge-fav"><i class="bi bi-heart-fill"></i> Favorit</span>
                                <?php endif; ?>
                                
                                <span class="badge-category"><?= htmlspecialchars($m['nama_kategori'] ?? 'Soto'); ?></span>
                            </div>

                            <div class="menu-body">
                                <h4 class="menu-name"><?= htmlspecialchars($m['nama_menu']); ?></h4>
                                <p class="menu-desc"><?= htmlspecialchars($m['deskripsi'] ?? 'Cita rasa khas Soto Lamongan Cak Joyo.'); ?></p>
                                
                                <div class="menu-footer">
                                    <div class="menu-price"><?= format_rupiah($m['harga']); ?></div>
                                    
                                    <?php if ($m['status'] === 'habis'): ?>
                                        <span class="badge bg-secondary py-2 px-3"><i class="bi bi-x-circle me-1"></i> Habis</span>
                                    <?php else: ?>
                                        <button class="btn-add-cart" 
                                                data-id="<?= $m['id']; ?>" 
                                                data-name="<?= htmlspecialchars($m['nama_menu']); ?>"
                                                data-price="<?= $m['harga']; ?>"
                                                title="Tambah ke Keranjang">
                                            <i class="bi bi-plus-lg"></i>
                                            <span>Pesan</span>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <p class="text-muted">Belum ada menu yang terdaftar. Buka panel admin untuk menambahkan menu.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- TESTIMONIAL / TENTANG SECTION -->
<section id="tentang-section" class="py-5 bg-white border-top">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="section-tag">CERITA WARUNG</span>
                <h2 class="fw-bold text-dark mb-3">Kenapa Memilih Soto Lamongan Cak Joyo?</h2>
                <p class="text-secondary leading-relaxed mb-4">
                    Bermula dari kecintaan pada warisan kuliner khas Lamongan Jawa Timur, Cak Joyo berkomitmen menghadirkan cita rasa soto yang autentik tanpa kompromi. Kuah soto kami dimasak perlahan dari kaldu ayam kampung murni dengan paduan rempah kunyit, serai, jahe, daun jeruk, dan kemiri yang aromatik.
                </p>
                <div class="row g-3">
                    <div class="col-sm-6">
                        <div class="feature-reason-card p-3 rounded-3 border">
                            <h6 class="fw-bold text-primary-accent mb-1 d-flex align-items-center gap-2">
                                <i class="bi bi-check2-circle fs-5"></i> Koya Udang Mantap
                            </h6>
                            <p class="small text-secondary mb-0">Diracik dari kerupuk udang pilihan dan bawang putih goreng renyah.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="feature-reason-card p-3 rounded-3 border">
                            <h6 class="fw-bold text-primary-accent mb-1 d-flex align-items-center gap-2">
                                <i class="bi bi-check2-circle fs-5"></i> Porsi Pas & Puas
                            </h6>
                            <p class="small text-secondary mb-0">Suwiran ayam banyak, kuah panas segar, bikin perut kenyang dan hati senang.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="testimonial-wrapper p-4 rounded-4 border">
                    <h5 class="fw-bold text-dark mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-chat-heart-fill text-amber"></i> Kata Pelanggan Setia
                    </h5>
                    
                    <div class="testimonial-card p-3 mb-3 rounded-3 border bg-white shadow-sm">
                        <div class="d-flex align-items-center gap-1 mb-2 star-rating">
                            <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                        <p class="small text-secondary mb-2 fst-italic">"Kuahnya bener-bener berasa kaldunya, nggak encer kayak soto biasa. Apalagi bubuk koyanya melimpah banget, maknyus pol Cak Joyo!"</p>
                        <div class="small fw-bold text-dark">— Mas Dimas, Surabaya</div>
                    </div>

                    <div class="testimonial-card p-3 rounded-3 border bg-white shadow-sm">
                        <div class="d-flex align-items-center gap-1 mb-2 star-rating">
                            <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                        <p class="small text-secondary mb-2 fst-italic">"Pesan lewat website praktis banget pas makan di meja resto, tinggal klik beres. Es jeruknya juga seger banget!"</p>
                        <div class="small fw-bold text-dark">— Mbak Rina, Lamongan</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
