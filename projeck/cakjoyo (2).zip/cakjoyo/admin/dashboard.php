<?php
require_once __DIR__ . '/header.php';

// 1. Ambil Statistik
// Total Menu
$totalMenu = 0;
$qMenu = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM menu");
if ($qMenu) $totalMenu = mysqli_fetch_assoc($qMenu)['jml'];

// Total Pesanan
$totalPesanan = 0;
$qPesanan = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM pesanan");
if ($qPesanan) $totalPesanan = mysqli_fetch_assoc($qPesanan)['jml'];

// Pesanan Baru (Perlu Tindakan)
$pesananBaru = 0;
$qBaru = mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM pesanan WHERE status = 'Baru'");
if ($qBaru) $pesananBaru = mysqli_fetch_assoc($qBaru)['jml'];

// Total Pendapatan (Hanya pesanan yang statusnya 'Selesai' atau 'Diproses' / 'Siap' atau semua pesanan non-batal)
$pendapatanTotal = 0;
$qPendapatan = mysqli_query($koneksi, "SELECT SUM(total_harga) as total FROM pesanan WHERE status != 'Dibatalkan'");
if ($qPendapatan) {
    $rowPendapatan = mysqli_fetch_assoc($qPendapatan);
    $pendapatanTotal = $rowPendapatan['total'] ?? 0;
}

// 2. Ambil 8 Pesanan Terkini
$sqlRecent = "SELECT * FROM pesanan ORDER BY id DESC LIMIT 8";
$recentOrders = mysqli_query($koneksi, $sqlRecent);
?>

<!-- KARTU STATISTIK -->
<div class="row g-4 mb-4">
    <!-- Stat 1: Total Pendapatan -->
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card">
            <div>
                <div class="stat-label">Total Omzet Penjualan</div>
                <div class="stat-value text-success"><?= format_rupiah($pendapatanTotal); ?></div>
                <small class="text-muted" style="font-size: 0.78rem;">Pesanan Berhasil & Aktif</small>
            </div>
            <div class="stat-icon bg-success-subtle text-success">
                <i class="bi bi-cash-coin"></i>
            </div>
        </div>
    </div>

    <!-- Stat 2: Pesanan Baru -->
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card">
            <div>
                <div class="stat-label">Pesanan Baru Masuk</div>
                <div class="stat-value text-danger"><?= $pesananBaru; ?></div>
                <small class="text-muted" style="font-size: 0.78rem;">Perlu Diproses Dapur</small>
            </div>
            <div class="stat-icon bg-danger-subtle text-danger">
                <i class="bi bi-bell-fill"></i>
            </div>
        </div>
    </div>

    <!-- Stat 3: Total Transaksi -->
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card">
            <div>
                <div class="stat-label">Total Semua Pesanan</div>
                <div class="stat-value text-primary"><?= $totalPesanan; ?></div>
                <small class="text-muted" style="font-size: 0.78rem;">Sejak Awal Berdiri</small>
            </div>
            <div class="stat-icon bg-primary-subtle text-primary">
                <i class="bi bi-bag-check-fill"></i>
            </div>
        </div>
    </div>

    <!-- Stat 4: Total Menu Aktif -->
    <div class="col-xl-3 col-sm-6">
        <div class="stat-card">
            <div>
                <div class="stat-label">Menu Soto & Minuman</div>
                <div class="stat-value text-warning"><?= $totalMenu; ?></div>
                <small class="text-muted" style="font-size: 0.78rem;">Item Terdaftar di Web</small>
            </div>
            <div class="stat-icon bg-warning-subtle text-warning">
                <i class="bi bi-egg-fried"></i>
            </div>
        </div>
    </div>
</div>

<!-- ALERT JIKA ADA PESANAN BARU -->
<?php if ($pesananBaru > 0): ?>
    <div class="alert alert-warning d-flex align-items-center justify-content-between p-3 rounded-4 mb-4 shadow-sm" role="alert">
        <div class="d-flex align-items-center gap-3">
            <span class="fs-3 text-danger"><i class="bi bi-exclamation-circle-fill"></i></span>
            <div>
                <h6 class="fw-bold mb-0 text-dark">Ada <?= $pesananBaru; ?> Pesanan Baru Menunggu Diproses!</h6>
                <small class="text-muted">Segera periksa dan ubah status pesanan menjadi 'Diproses' agar pelanggan mengetahui pesanannya sedang dimasak.</small>
            </div>
        </div>
        <a href="pesanan.php?status=Baru" class="btn btn-warning btn-sm fw-bold px-3 py-2 text-dark">
            <i class="bi bi-eye-fill me-1"></i> Buka Pesanan Baru
        </a>
    </div>
<?php endif; ?>

<!-- TABEL PESANAN TERBARU -->
<div class="admin-card">
    <div class="admin-card-header">
        <div>
            <h5 class="fw-bold text-dark mb-0">Pesanan Masuk Terkini</h5>
            <small class="text-muted">Daftar transaksi pesanan terakhir dari pelanggan warung.</small>
        </div>
        <div class="d-flex gap-2">
            <a href="pesanan.php" class="btn btn-outline-dark btn-sm">
                <i class="bi bi-list-ul me-1"></i> Lihat Semua Pesanan
            </a>
            <a href="menu_tambah.php" class="btn btn-warning btn-sm fw-bold text-dark">
                <i class="bi bi-plus-circle me-1"></i> Tambah Menu Baru
            </a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-custom table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Waktu</th>
                    <th>Pelanggan</th>
                    <th>Layanan</th>
                    <th>Metode</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($recentOrders) > 0): ?>
                    <?php while ($ord = mysqli_fetch_assoc($recentOrders)): ?>
                        <tr>
                            <td>
                                <a href="pesanan_detail.php?id=<?= $ord['id']; ?>" class="fw-bold text-decoration-none text-dark">
                                    <?= htmlspecialchars($ord['kode_pesanan']); ?>
                                </a>
                            </td>
                            <td>
                                <small class="text-muted"><?= date('d/m/Y H:i', strtotime($ord['created_at'])); ?></small>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($ord['nama_pelanggan']); ?></div>
                                <small class="text-muted"><?= htmlspecialchars($ord['no_hp']); ?></small>
                            </td>
                            <td>
                                <small class="fw-semibold"><?= tipe_pesanan_label($ord['tipe_pesanan'], $ord['nomor_meja'], $ord['jumlah_orang'] ?? null); ?></small>
                            </td>
                            <td>
                                <small class="badge bg-light text-dark border"><?= metode_bayar_label($ord['metode_pembayaran'], $ord['kanal_gateway'] ?? null); ?></small>
                                <?php if (!empty($ord['kode_bayar_gateway'])): ?>
                                    <div class="small text-primary font-monospace fw-bold" style="font-size: 0.72rem;">Kode: <?= htmlspecialchars($ord['kode_bayar_gateway']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong class="text-dark d-block"><?= format_rupiah($ord['total_harga']); ?></strong>
                                <?= status_bayar_badge($ord['status_pembayaran'] ?? 'Menunggu Pembayaran'); ?>
                            </td>
                            <td>
                                <?= status_badge($ord['status']); ?>
                            </td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="pesanan_detail.php?id=<?= $ord['id']; ?>" class="btn btn-outline-secondary" title="Lihat Rincian">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="cetak_struk.php?id=<?= $ord['id']; ?>" target="_blank" class="btn btn-outline-dark" title="Cetak Struk Kasir">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <a href="<?= whatsapp_link($ord['no_hp'], 'Halo ' . $ord['nama_pelanggan'] . ', pesanan Anda di Soto Lamongan Cak Joyo (Kode: ' . $ord['kode_pesanan'] . ') saat ini berstatus: ' . $ord['status']); ?>" target="_blank" class="btn btn-outline-success" title="WhatsApp Pelanggan">
                                        <i class="bi bi-whatsapp"></i>
                                    </a>
                                    <a href="update_status.php?aksi=hapus_pesanan&id=<?= $ord['id']; ?>" class="btn btn-outline-danger" title="Hapus Data Pesanan" onclick="return confirm('Yakin ingin menghapus permanen pesanan <?= htmlspecialchars($ord['kode_pesanan']); ?>?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                            Belum ada pesanan masuk.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
