<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id   = (int)($_GET['id'] ?? 0);
$kode = clean($koneksi, $_GET['kode'] ?? '');

if ($id > 0) {
    $queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id = $id LIMIT 1");
} else {
    $queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE kode_pesanan = '$kode' LIMIT 1");
}
$pesanan = mysqli_fetch_assoc($queryPesanan);

if (!$pesanan) {
    die("Pesanan tidak ditemukan.");
}

$id = (int)$pesanan['id'];
$queryDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $id");
$items = [];
while ($d = mysqli_fetch_assoc($queryDetail)) {
    $items[] = $d;
}

$resto = get_pengaturan($koneksi);
$ukuran = $_GET['ukuran'] ?? '58mm'; // 58mm (Bluetooth Mini), 80mm (Thermal), a4 (Printer Besar)
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk #<?= htmlspecialchars($pesanan['kode_pesanan']); ?></title>
    <style id="dynamicPageStyle">
        <?php if ($ukuran === '58mm'): ?>
            @page { size: 58mm auto; margin: 1mm; }
        <?php elseif ($ukuran === '80mm'): ?>
            @page { size: 80mm auto; margin: 2mm; }
        <?php else: ?>
            @page { size: A4 portrait; margin: 8mm; }
        <?php endif; ?>
    </style>
    <style>
        * {
            box-sizing: border-box;
        }
        html, body {
            font-family: 'Courier New', Courier, monospace;
            background-color: #f1f5f9;
            margin: 0;
            padding: 12px;
            color: #000;
        }
        .no-print {
            max-width: 680px;
            margin: 0 auto 14px auto;
            background: #ffffff;
            border: 1px solid #cbd5e1;
            border-radius: 10px;
            padding: 12px 16px;
            font-family: Arial, sans-serif;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .toolbar-row {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
            justify-content: space-between;
        }
        .btn-tool {
            border: 1px solid #cbd5e1;
            background: #f8fafc;
            color: #0f172a;
            padding: 7px 12px;
            font-size: 12.5px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .btn-tool.active {
            background: #0f172a;
            color: #fbbf24;
            border-color: #0f172a;
        }
        .btn-print-main {
            background: #d97706;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 13px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }
        .btn-bt {
            background: #2563eb;
            color: #fff;
            border: none;
            padding: 8px 14px;
            font-size: 13px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        /* Container Struk (1 Halaman Utuh) */
        .struk-container {
            background: #fff;
            margin: 0 auto;
            border: 1px solid #cbd5e1;
            page-break-inside: avoid;
            break-inside: avoid;
        }
        /* Ukuran 58mm (Bluetooth Printer Mini) */
        .struk-container.mode-58mm {
            width: 56mm;
            padding: 6px 5px;
            font-size: 10.5px;
            line-height: 1.25;
        }
        /* Ukuran 80mm (Printer Kasir Medium) */
        .struk-container.mode-80mm {
            width: 76mm;
            padding: 10px 8px;
            font-size: 11.5px;
            line-height: 1.3;
        }
        /* Ukuran Printer Besar (A4 / Inkjet / Laser - 1 Halaman) */
        .struk-container.mode-a4 {
            width: 100%;
            max-width: 650px;
            padding: 20px 24px;
            font-size: 13px;
            line-height: 1.4;
        }

        .text-center { text-align: center; }
        .text-end { text-align: right; }
        .fw-bold { font-weight: bold; }
        .dashed {
            border-top: 1px dashed #000;
            margin: 6px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: inherit;
        }
        td, th {
            padding: 2px 0;
            vertical-align: top;
        }

        @media print {
            html, body {
                background: transparent !important;
                padding: 0 !important;
                margin: 0 !important;
            }
            .no-print {
                display: none !important;
            }
            .struk-container {
                border: none !important;
                box-shadow: none !important;
                margin: 0 auto !important;
                page-break-inside: avoid !important;
                break-inside: avoid !important;
                page-break-after: avoid !important;
            }
            .struk-container.mode-58mm {
                width: 100% !important;
                max-width: 56mm !important;
                padding: 0 !important;
            }
            .struk-container.mode-80mm {
                width: 100% !important;
                max-width: 76mm !important;
                padding: 0 !important;
            }
            .struk-container.mode-a4 {
                width: 100% !important;
                max-width: 100% !important;
                padding: 5mm !important;
            }
        }
    </style>
</head>
<body>

<div class="no-print">
    <div class="toolbar-row" style="margin-bottom: 10px;">
        <div>
            <strong style="font-size: 13px;">Pilih Ukuran Kertas / Mesin Printer:</strong>
        </div>
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
            <button type="button" id="btnMode58" class="btn-tool <?= $ukuran === '58mm' ? 'active' : ''; ?>" onclick="setPrinterMode('58mm')">
                📱 Bluetooth Mini (58mm)
            </button>
            <button type="button" id="btnMode80" class="btn-tool <?= $ukuran === '80mm' ? 'active' : ''; ?>" onclick="setPrinterMode('80mm')">
                🧾 Thermal Kasir (80mm)
            </button>
            <button type="button" id="btnModeA4" class="btn-tool <?= $ukuran === 'a4' ? 'active' : ''; ?>" onclick="setPrinterMode('a4')">
                🖨️ Printer Besar / A4 (1 Halaman)
            </button>
        </div>
    </div>
    <div class="toolbar-row" style="border-top: 1px solid #e2e8f0; padding-top: 10px;">
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <button class="btn-print-main" onclick="window.print()">🖨️ Cetak Struk (1 Halaman)</button>
            <button class="btn-bt" onclick="cetakBluetoothLangsung()">🔵 Print Bluetooth Langsung (ESC/POS)</button>
        </div>
        <button class="btn-tool" onclick="window.close()">✖ Tutup</button>
    </div>
    <div id="btStatusMsg" style="font-size: 11.5px; color: #2563eb; margin-top: 6px; display: none;"></div>
</div>

<div id="strukBox" class="struk-container mode-<?= htmlspecialchars($ukuran); ?>">
    <div class="text-center">
        <div class="fw-bold" style="font-size: 1.15em; text-transform: uppercase;"><?= htmlspecialchars($resto['nama_resto']); ?></div>
        <div style="font-size: 0.9em;"><?= htmlspecialchars($resto['alamat']); ?></div>
        <div style="font-size: 0.9em;">WA: <?= htmlspecialchars($resto['no_wa']); ?></div>
    </div>

    <div class="dashed"></div>

    <table>
        <tr>
            <td>No: <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong></td>
            <td class="text-end"><?= date('d/m/y H:i', strtotime($pesanan['created_at'])); ?></td>
        </tr>
        <tr>
            <td>Plg: <?= htmlspecialchars($pesanan['nama_pelanggan']); ?></td>
            <td class="text-end">
                <?= htmlspecialchars(ucfirst(str_replace('_', ' ', $pesanan['tipe_pesanan']))); ?>
                <?php if (!empty($pesanan['nomor_meja'])): ?>
                    (<?= htmlspecialchars($pesanan['nomor_meja']); ?><?= !empty($pesanan['jumlah_orang']) ? ' • ' . (int)$pesanan['jumlah_orang'] . ' Org' : ''; ?>)
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td>Bayar: <?= htmlspecialchars(strtoupper($pesanan['metode_pembayaran'])); ?></td>
            <td class="text-end">Kode: <strong><?= htmlspecialchars($pesanan['kode_bayar_gateway'] ?: '-'); ?></strong></td>
        </tr>
        <tr>
            <td>Status Bayar:</td>
            <td class="text-end fw-bold"><?= htmlspecialchars(strtoupper($pesanan['status_pembayaran'] ?: 'MENUNGGU PEMBAYARAN')); ?></td>
        </tr>
    </table>

    <div class="dashed"></div>

    <table>
        <?php foreach ($items as $d): ?>
            <tr>
                <td colspan="2">
                    <strong><?= htmlspecialchars($d['nama_menu']); ?></strong>
                    <?php if (!empty($d['catatan_item'])): ?>
                        <span style="font-size: 0.85em; font-style: italic;">(<?= htmlspecialchars($d['catatan_item']); ?>)</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td style="padding-left: 6px;">
                    <?= (int)$d['jumlah']; ?> x <?= number_format((int)$d['harga'], 0, ',', '.'); ?>
                </td>
                <td class="text-end fw-bold">
                    <?= number_format((int)$d['subtotal'], 0, ',', '.'); ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="dashed"></div>

    <table>
        <tr>
            <td class="fw-bold" style="font-size: 1.1em;">TOTAL BAYAR:</td>
            <td class="text-end fw-bold" style="font-size: 1.15em;">
                Rp <?= number_format((int)$pesanan['total_harga'], 0, ',', '.'); ?>
            </td>
        </tr>
        <tr>
            <td>STATUS:</td>
            <td class="text-end fw-bold">
                <?= ($pesanan['status_pembayaran'] === 'Lunas') ? 'LUNAS (100%)' : strtoupper($pesanan['status_pembayaran'] ?: 'MENUNGGU PEMBAYARAN'); ?>
            </td>
        </tr>
    </table>

    <?php if (!empty($pesanan['catatan'])): ?>
        <div class="dashed"></div>
        <div style="font-size: 0.9em;">
            <strong>Catatan:</strong> <?= htmlspecialchars($pesanan['catatan']); ?>
        </div>
    <?php endif; ?>

    <div class="dashed"></div>

    <div class="text-center" style="font-size: 0.9em; margin-top: 4px;">
        Matur Suwun atas Pesanan Anda!<br>
        Soto Ayam Lamongan Cak Joyo
    </div>
</div>

<script>
function setPrinterMode(mode) {
    const box = document.getElementById('strukBox');
    const styleEl = document.getElementById('dynamicPageStyle');
    box.className = 'struk-container mode-' + mode;

    document.getElementById('btnMode58').classList.toggle('active', mode === '58mm');
    document.getElementById('btnMode80').classList.toggle('active', mode === '80mm');
    document.getElementById('btnModeA4').classList.toggle('active', mode === 'a4');

    if (mode === '58mm') {
        styleEl.innerHTML = '@page { size: 58mm auto; margin: 1mm; }';
    } else if (mode === '80mm') {
        styleEl.innerHTML = '@page { size: 80mm auto; margin: 2mm; }';
    } else {
        styleEl.innerHTML = '@page { size: A4 portrait; margin: 8mm; }';
    }
}

// Fitur Cetak Langsung ke Mesin Bluetooth Printer Mini via Web Bluetooth API (ESC/POS)
async function cetakBluetoothLangsung() {
    const statusEl = document.getElementById('btStatusMsg');
    statusEl.style.display = 'block';

    if (!navigator.bluetooth) {
        statusEl.innerText = 'Membuka dialog cetak Bluetooth / Sistem... Pilih printer Bluetooth Anda.';
        window.print();
        return;
    }

    try {
        statusEl.innerText = 'Mencari perangkat Bluetooth Printer...';
        const device = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: [
                '000018f0-0000-1000-8000-00805f9b34fb',
                'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
                '49535343-fe7d-4ae5-8fa9-9fafd205e455'
            ]
        });

        statusEl.innerText = 'Menghubungkan ke ' + (device.name || 'Printer Bluetooth') + '...';
        const server = await device.gatt.connect();
        const services = await server.getPrimaryServices();
        let printChar = null;

        for (const service of services) {
            const chars = await service.getCharacteristics();
            for (const c of chars) {
                if (c.properties.write || c.properties.writeWithoutResponse) {
                    printChar = c;
                    break;
                }
            }
            if (printChar) break;
        }

        if (!printChar) {
            window.print();
            return;
        }

        // Susun teks ESC/POS 32 kolom (58mm)
        const escInit = '\x1B\x40';
        const alignCenter = '\x1B\x61\x01';
        const alignLeft = '\x1B\x61\x00';
        const boldOn = '\x1B\x45\x01';
        const boldOff = '\x1B\x45\x00';
        const line = '--------------------------------\n';

        let text = escInit + alignCenter + boldOn + <?= json_encode(strtoupper($resto['nama_resto']) . "\n"); ?> + boldOff;
        text += <?= json_encode($resto['alamat'] . "\n"); ?>;
        text += 'WA: ' + <?= json_encode($resto['no_wa'] . "\n"); ?>;
        text += alignLeft + line;
        text += 'No   : ' + <?= json_encode($pesanan['kode_pesanan'] . "\n"); ?>;
        text += 'Waktu: ' + <?= json_encode(date('d/m/y H:i', strtotime($pesanan['created_at'])) . "\n"); ?>;
        text += 'Plg  : ' + <?= json_encode($pesanan['nama_pelanggan'] . "\n"); ?>;
        text += 'Tipe : ' + <?= json_encode(ucfirst(str_replace('_', ' ', $pesanan['tipe_pesanan'])) . ($pesanan['nomor_meja'] ? ' (' . $pesanan['nomor_meja'] . ')' : '') . "\n"); ?>;
        text += 'Bayar: ' + <?= json_encode(strtoupper($pesanan['metode_pembayaran']) . ' (' . ($pesanan['status_pembayaran'] ?: 'Menunggu') . ")\n"); ?>;
        text += line;
        <?php foreach ($items as $d): ?>
        text += <?= json_encode($d['nama_menu'] . "\n"); ?>;
        text += <?= json_encode(' ' . $d['jumlah'] . ' x ' . number_format((int)$d['harga'], 0, ',', '.') . ' = ' . number_format((int)$d['subtotal'], 0, ',', '.') . "\n"); ?>;
        <?php endforeach; ?>
        text += line;
        text += boldOn + 'TOTAL: Rp ' + <?= json_encode(number_format((int)$pesanan['total_harga'], 0, ',', '.') . "\n"); ?> + boldOff;
        text += 'STATUS: ' + <?= json_encode(strtoupper($pesanan['status_pembayaran'] ?: 'MENUNGGU PEMBAYARAN') . "\n"); ?>;
        text += line;
        text += alignCenter + 'Matur Suwun!\nSoto Lamongan Cak Joyo\n\n\n';

        const encoder = new TextEncoder();
        const bytes = encoder.encode(text);
        const chunkSize = 100;
        for (let i = 0; i < bytes.length; i += chunkSize) {
            const chunk = bytes.slice(i, i + chunkSize);
            await printChar.writeValue(chunk);
        }
        statusEl.innerText = '✅ Struk berhasil dicetak ke Printer Bluetooth!';
    } catch (err) {
        statusEl.innerText = 'Membuka dialog cetak standar...';
        window.print();
    }
}
</script>
</body>
</html>
