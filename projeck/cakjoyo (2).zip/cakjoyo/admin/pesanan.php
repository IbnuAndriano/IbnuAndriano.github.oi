<?php
require_once __DIR__ . '/header.php';

$statusFilter = clean($koneksi, $_GET['status'] ?? '');
$search       = clean($koneksi, $_GET['search'] ?? '');
$tanggal      = clean($koneksi, $_GET['tanggal'] ?? '');

$where = [];
if (!empty($statusFilter)) {
    $where[] = "status = '$statusFilter'";
}
if (!empty($search)) {
    $where[] = "(kode_pesanan LIKE '%$search%' OR nama_pelanggan LIKE '%$search%' OR no_hp LIKE '%$search%')";
}
if (!empty($tanggal)) {
    $where[] = "DATE(created_at) = '$tanggal'";
}

$whereSql = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT * FROM pesanan $whereSql ORDER BY id DESC";
$result = mysqli_query($koneksi, $sql);

// Hitung jumlah tiap status untuk badge tab
$countAll = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM pesanan"))['c'];
$countBaru = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM pesanan WHERE status = 'Baru'"))['c'];
$countDiproses = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM pesanan WHERE status = 'Diproses'"))['c'];
$countSiap = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM pesanan WHERE status = 'Siap'"))['c'];
$countSelesai = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM pesanan WHERE status = 'Selesai'"))['c'];
$autoConfirmAktif = (int)($resto['pg_auto_confirm'] ?? 0) === 1;
?>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
        <h4 class="fw-bold text-dark mb-1">Daftar Pesanan & Konfirmasi Pembayaran</h4>
        <p class="text-muted small mb-0">Konfirmasi apakah pembayaran pelanggan sudah benar masuk atau belum, serta kelola status dapur & meja.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($autoConfirmAktif): ?>
            <a href="update_status.php?toggle_auto_confirm=0" class="btn btn-success btn-sm fw-bold" title="Klik untuk beralih ke mode konfirmasi manual Admin">
                <i class="bi bi-lightning-charge-fill me-1"></i> Mode Bayar: Otomatis Lunas (Aktif)
            </a>
        <?php else: ?>
            <a href="update_status.php?toggle_auto_confirm=1" class="btn btn-warning btn-sm fw-bold text-dark" title="Klik jika ingin mengaktifkan verifikasi otomatis">
                <i class="bi bi-shield-lock-fill me-1"></i> Mode Bayar: Wajib Konfirmasi Admin Dulu (Aktif)
            </a>
        <?php endif; ?>
        <a href="meja.php" class="btn btn-outline-primary btn-sm fw-bold">
            <i class="bi bi-grid-3x3-gap me-1"></i> Kelola Meja
        </a>
        <a href="laporan.php" class="btn btn-outline-dark btn-sm">
            <i class="bi bi-file-earmark-excel me-1"></i> Rekap Laporan
        </a>
    </div>
</div>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3 py-2 mb-4" role="alert">
        <i class="bi bi-trash-fill me-1"></i> Data pesanan berhasil dihapus dan meja terkait telah dikosongkan!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- STATUS TABS -->
<div class="d-flex flex-wrap gap-2 mb-4">
    <a href="pesanan.php" class="btn btn-sm <?= empty($statusFilter) ? 'btn-dark' : 'btn-outline-secondary'; ?> rounded-pill px-3">
        Semua (<?= $countAll; ?>)
    </a>
    <a href="pesanan.php?status=Baru" class="btn btn-sm <?= $statusFilter === 'Baru' ? 'btn-primary' : 'btn-outline-primary'; ?> rounded-pill px-3">
        Baru (<?= $countBaru; ?>)
    </a>
    <a href="pesanan.php?status=Diproses" class="btn btn-sm <?= $statusFilter === 'Diproses' ? 'btn-warning text-dark' : 'btn-outline-warning text-dark'; ?> rounded-pill px-3">
        Dimasak (<?= $countDiproses; ?>)
    </a>
    <a href="pesanan.php?status=Siap" class="btn btn-sm <?= $statusFilter === 'Siap' ? 'btn-info text-dark' : 'btn-outline-info text-dark'; ?> rounded-pill px-3">
        Siap Saji (<?= $countSiap; ?>)
    </a>
    <a href="pesanan.php?status=Selesai" class="btn btn-sm <?= $statusFilter === 'Selesai' ? 'btn-success' : 'btn-outline-success'; ?> rounded-pill px-3">
        Selesai (<?= $countSelesai; ?>)
    </a>
</div>

<!-- FILTER & SEARCH -->
<div class="card border-0 shadow-sm p-3 rounded-4 mb-4">
    <form method="GET" action="pesanan.php" class="row g-2 align-items-center">
        <?php if (!empty($statusFilter)): ?>
            <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter); ?>">
        <?php endif; ?>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                <input type="text" name="search" class="form-control" placeholder="Cari kode pesanan, nama, no HP..." value="<?= htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-md-4">
            <input type="date" name="tanggal" class="form-control" value="<?= htmlspecialchars($tanggal); ?>" title="Filter Tanggal">
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-dark w-100">
                <i class="bi bi-filter me-1"></i> Filter
            </button>
            <?php if (!empty($search) || !empty($tanggal)): ?>
                <a href="pesanan.php<?= !empty($statusFilter) ? '?status=' . $statusFilter : ''; ?>" class="btn btn-outline-secondary">Reset</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- TABEL PESANAN -->
<div class="admin-card">
    <div class="table-responsive">
        <table class="table table-custom table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Waktu</th>
                    <th>Pelanggan</th>
                    <th>Layanan</th>
                    <th>Kanal Bayar</th>
                    <th>Tagihan & Status Bayar</th>
                    <th>Status Dapur</th>
                    <th>Ubah Cepat</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($ord = mysqli_fetch_assoc($result)): 
                        $totO  = (int)$ord['total_harga'];
                        $dibO  = (int)($ord['jumlah_dibayar'] ?? 0);
                        $sisaO = max(0, $totO - $dibO);
                        $stByr = $ord['status_pembayaran'] ?: 'Menunggu Pembayaran';
                    ?>
                        <tr>
                            <td>
                                <a href="pesanan_detail.php?id=<?= $ord['id']; ?>" class="fw-bold text-decoration-none text-dark">
                                    <?= htmlspecialchars($ord['kode_pesanan']); ?>
                                </a>
                                <?php if (!empty($ord['bukti_bayar'])): ?>
                                    <span class="badge bg-info-subtle text-info border small ms-1" title="Ada Bukti Bayar"><i class="bi bi-receipt"></i> Bukti</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small class="text-muted"><?= date('d/m/Y H:i', strtotime($ord['created_at'])); ?></small>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($ord['nama_pelanggan']); ?></div>
                                <small class="text-muted"><?= htmlspecialchars($ord['no_hp']); ?></small>
                            </td>
                            <td>
                                <small class="fw-semibold"><?= tipe_pesanan_label($ord['tipe_pesanan'], $ord['nomor_meja'], $ord['jumlah_orang'] ?? null); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border"><?= metode_bayar_label($ord['metode_pembayaran'], $ord['kanal_gateway'] ?? null); ?></span>
                                <?php if (!empty($ord['kode_bayar_gateway'])): ?>
                                    <div class="small text-primary fw-bold font-monospace mt-1" style="font-size: 0.78rem;">Kode: <?= htmlspecialchars($ord['kode_bayar_gateway']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= format_rupiah($totO); ?></div>
                                <div class="mt-1"><?= status_bayar_badge($stByr, $sisaO); ?></div>
                                <?php if ($stByr !== 'Lunas' && $ord['status'] !== 'Dibatalkan'): ?>
                                    <div class="d-flex gap-1 mt-2">
                                        <a href="update_status.php?id=<?= $ord['id']; ?>&aksi_bayar=lunas"
                                           class="btn btn-success btn-sm py-0 px-2 fw-bold"
                                           style="font-size: 0.72rem;"
                                           title="Konfirmasi bahwa dana pembayaran sudah benar masuk">
                                            ✅ Konfirmasi Lunas
                                        </a>
                                        <?php if ($stByr === 'Menunggu Konfirmasi'): ?>
                                            <a href="update_status.php?id=<?= $ord['id']; ?>&aksi_bayar=belum_bayar"
                                               class="btn btn-outline-danger btn-sm py-0 px-2"
                                               style="font-size: 0.72rem;"
                                               title="Dana belum masuk, kembalikan status">
                                                ❌ Belum Masuk
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= status_badge($ord['status']); ?>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Update
                                    </button>
                                    <ul class="dropdown-menu shadow border-0">
                                        <li><a class="dropdown-item" href="update_status.php?id=<?= $ord['id']; ?>&status=Baru">🔵 Pesanan Baru</a></li>
                                        <li><a class="dropdown-item" href="update_status.php?id=<?= $ord['id']; ?>&status=Diproses">🟠 Sedang Dimasak</a></li>
                                        <li><a class="dropdown-item" href="update_status.php?id=<?= $ord['id']; ?>&status=Siap">🟣 Siap Saji</a></li>
                                        <li><a class="dropdown-item" href="update_status.php?id=<?= $ord['id']; ?>&status=Selesai">🟢 Selesai</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="update_status.php?id=<?= $ord['id']; ?>&status=Dibatalkan" onclick="return confirm('Yakin ingin membatalkan pesanan ini?')">🔴 Batalkan Pesanan</a></li>
                                        <li><a class="dropdown-item text-danger fw-bold" href="update_status.php?aksi=hapus_pesanan&id=<?= $ord['id']; ?>" onclick="return confirm('Yakin ingin MENGHAPUS permanen data pesanan <?= htmlspecialchars($ord['kode_pesanan']); ?>?')">🗑️ Hapus Pesanan</a></li>
                                    </ul>
                                </div>
                            </td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="pesanan_detail.php?id=<?= $ord['id']; ?>" class="btn btn-outline-primary" title="Lihat Detail">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="cetak_struk.php?id=<?= $ord['id']; ?>" target="_blank" class="btn btn-outline-dark" title="Cetak Struk">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <a href="<?= whatsapp_link($ord['no_hp'], 'Halo ' . $ord['nama_pelanggan'] . ', status pesanan Anda di Soto Lamongan Cak Joyo (' . $ord['kode_pesanan'] . ') sekarang adalah: ' . $ord['status']); ?>" target="_blank" class="btn btn-outline-success" title="Hubungi Pelanggan">
                                        <i class="bi bi-whatsapp"></i>
                                    </a>
                                    <a href="update_status.php?aksi=hapus_pesanan&id=<?= $ord['id']; ?>" class="btn btn-outline-danger" title="Hapus Data Pesanan" onclick="return confirm('Yakin ingin menghapus permanen pesanan <?= htmlspecialchars($ord['kode_pesanan']); ?>?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center py-5 text-muted">
                            <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                            Tidak ada pesanan yang sesuai filter.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
