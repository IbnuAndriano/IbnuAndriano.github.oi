<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id = (int)($_GET['id'] ?? 0);
$queryPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id = $id LIMIT 1");
$pesanan = mysqli_fetch_assoc($queryPesanan);

if (!$pesanan) {
    header("Location: pesanan.php");
    exit;
}

// Handle update status dari form detail jika dikirim (SEBELUM output HTML header.php!)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['update_status'])) {
    $newStatus = clean($koneksi, $_POST['status']);
    tandai_status_pesanan_dan_meja($koneksi, $id, $newStatus);
    header("Location: pesanan_detail.php?id=$id&updated=1");
    exit;
}

// Handle Konfirmasi Pembayaran oleh Admin (Sudah Benar Bayar vs Belum Masuk)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['aksi_konfirmasi_bayar'])) {
    $aksiBayar  = $_POST['aksi_konfirmasi_bayar'];
    $totHarga   = (int)$pesanan['total_harga'];
    $kanalAdmin = clean($koneksi, $pesanan['kanal_gateway'] ?: 'qris_gateway');
    $refKode    = $pesanan['referensi_gateway'] ?: generate_referensi_gateway();

    if ($aksiBayar === 'lunas') {
        $stDapur = ($pesanan['status'] === 'Baru') ? 'Diproses' : $pesanan['status'];
        mysqli_query($koneksi, "UPDATE pesanan SET 
            status_pembayaran = 'Lunas',
            jumlah_dibayar = $totHarga,
            sisa_tagihan = 0,
            status = '$stDapur',
            waktu_bayar = COALESCE(waktu_bayar, NOW())
            WHERE id = $id");

        mysqli_query($koneksi, "UPDATE pembayaran_gateway SET status_transaksi = 'Lunas (Dikonfirmasi Admin)' WHERE pesanan_id = $id");
        mysqli_query($koneksi, "INSERT INTO pembayaran_gateway (
            pesanan_id, kode_pesanan, kode_referensi, kanal_pembayaran, nominal_bayar, status_transaksi, keterangan, created_at
        ) VALUES (
            $id, '{$pesanan['kode_pesanan']}', '$refKode', '$kanalAdmin', $totHarga, 'Lunas (Dikonfirmasi Admin)', 'Admin mengonfirmasi pembayaran penuh sudah benar masuk', NOW()
        )");
    } elseif ($aksiBayar === 'belum_masuk') {
        mysqli_query($koneksi, "UPDATE pesanan SET 
            status_pembayaran = 'Belum Masuk',
            jumlah_dibayar = 0,
            sisa_tagihan = $totHarga
            WHERE id = $id");

        mysqli_query($koneksi, "INSERT INTO pembayaran_gateway (
            pesanan_id, kode_pesanan, kode_referensi, kanal_pembayaran, nominal_bayar, status_transaksi, keterangan, created_at
        ) VALUES (
            $id, '{$pesanan['kode_pesanan']}', '$refKode', '$kanalAdmin', 0, 'Belum Masuk', 'Admin mengecek dana belum masuk, status dikembalikan', NOW()
        )");
    }
    header("Location: pesanan_detail.php?id=$id&updated=1");
    exit;
}

require_once __DIR__ . '/header.php';

// Ambil item menu yang dipesan
$queryDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $id");

$total_harga    = (int)$pesanan['total_harga'];
$jumlah_dibayar = (int)($pesanan['jumlah_dibayar'] ?? 0);
$sisa_tagihan   = max(0, $total_harga - $jumlah_dibayar);
$status_bayar   = $pesanan['status_pembayaran'] ?: 'Menunggu Pembayaran';

$qRiwayat = mysqli_query($koneksi, "SELECT * FROM pembayaran_gateway WHERE pesanan_id = $id ORDER BY id ASC");
?>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1">
                <li class="breadcrumb-item"><a href="pesanan.php" class="text-decoration-none">Pesanan</a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($pesanan['kode_pesanan']); ?></li>
            </ol>
        </nav>
        <h4 class="fw-bold text-dark mb-0">Rincian Pesanan: <?= htmlspecialchars($pesanan['kode_pesanan']); ?></h4>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a href="cetak_struk.php?id=<?= $pesanan['id']; ?>" target="_blank" class="btn btn-outline-dark btn-sm">
            <i class="bi bi-printer me-1"></i> Cetak Struk Kasir
        </a>
        <a href="<?= whatsapp_link($pesanan['no_hp'], 'Halo ' . $pesanan['nama_pelanggan'] . ', perihal pesanan Anda di Soto Lamongan Cak Joyo (' . $pesanan['kode_pesanan'] . ')...'); ?>" target="_blank" class="btn btn-success btn-sm">
            <i class="bi bi-whatsapp me-1"></i> Hubungi Pemesan
        </a>
        <a href="update_status.php?aksi=hapus_pesanan&id=<?= $pesanan['id']; ?>" class="btn btn-danger btn-sm fw-bold" onclick="return confirm('Yakin ingin menghapus permanen pesanan <?= htmlspecialchars($pesanan['kode_pesanan']); ?>?')">
            <i class="bi bi-trash me-1"></i> Hapus Pesanan
        </a>
    </div>
</div>

<?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> Status pesanan berhasil diperbarui!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- KOLOM KIRI: Tabel Rincian Menu -->
    <div class="col-lg-8">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <h6 class="fw-bold text-dark mb-0"><i class="bi bi-basket-fill text-warning me-2"></i> Item yang Dipesan</h6>
            </div>
            <div class="table-responsive">
                <table class="table table-custom align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Menu</th>
                            <th class="text-end">Harga</th>
                            <th class="text-center">Jumlah</th>
                            <th class="text-end">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($d = mysqli_fetch_assoc($queryDetail)): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($d['nama_menu']); ?></div>
                                    <?php if (!empty($d['catatan_item'])): ?>
                                        <small class="text-warning fst-italic">Catatan: "<?= htmlspecialchars($d['catatan_item']); ?>"</small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end"><?= format_rupiah($d['harga']); ?></td>
                                <td class="text-center fw-bold"><?= $d['jumlah']; ?></td>
                                <td class="text-end fw-bold text-dark"><?= format_rupiah($d['subtotal']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                    <tfoot class="border-top">
                        <tr>
                            <th colspan="3" class="text-end fs-6">TOTAL TAGIHAN:</th>
                            <th class="text-end fs-5 text-dark"><?= format_rupiah($total_harga); ?></th>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end small text-muted">SUDAH DIBAYAR (GATEWAY):</th>
                            <th class="text-end text-success"><?= format_rupiah($jumlah_dibayar); ?></th>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end small text-muted"><?= $sisa_tagihan > 0 ? 'SISA KEKURANGAN BAYAR:' : 'STATUS LUNAS:'; ?></th>
                            <th class="text-end <?= $sisa_tagihan > 0 ? 'text-danger' : 'text-success'; ?>">
                                <?= $sisa_tagihan > 0 ? format_rupiah($sisa_tagihan) : 'Rp 0 (LUNAS)'; ?>
                            </th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Riwayat Transaksi Payment Gateway -->
        <div class="admin-card mb-4">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h6 class="fw-bold text-dark mb-0"><i class="bi bi-shield-check text-success me-2"></i> Riwayat Transaksi Payment Gateway</h6>
                <div><?= status_bayar_badge($status_bayar, $sisa_tagihan); ?></div>
            </div>
            <div class="table-responsive">
                <table class="table table-custom align-middle mb-0 small">
                    <thead>
                        <tr>
                            <th>Waktu</th>
                            <th>Ref Gateway</th>
                            <th>Kanal</th>
                            <th>Keterangan</th>
                            <th class="text-end">Nominal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($qRiwayat && mysqli_num_rows($qRiwayat) > 0): ?>
                            <?php while ($rw = mysqli_fetch_assoc($qRiwayat)): ?>
                                <tr>
                                    <td><?= format_tanggal($rw['created_at']); ?></td>
                                    <td class="font-monospace fw-bold"><?= htmlspecialchars($rw['kode_referensi']); ?></td>
                                    <td><?= kanal_gateway_label($rw['kanal_pembayaran']); ?></td>
                                    <td><?= htmlspecialchars($rw['keterangan'] ?? '-'); ?></td>
                                    <td class="text-end fw-bold text-success">+ <?= format_rupiah($rw['nominal_bayar']); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-3 text-muted">Belum ada catatan pembayaran masuk dari Payment Gateway.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if (!empty($pesanan['catatan'])): ?>
            <div class="card border-0 shadow-sm p-3 rounded-4 mb-4 bg-light">
                <h6 class="fw-bold text-dark mb-1"><i class="bi bi-chat-left-dots text-warning me-2"></i> Catatan Khusus dari Pelanggan:</h6>
                <p class="mb-0 text-muted fst-italic">"<?= nl2br(htmlspecialchars($pesanan['catatan'])); ?>"</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- KOLOM KANAN: Informasi Pemesan, Payment Gateway & Ubah Status -->
    <div class="col-lg-4">
        <!-- Card Konfirmasi Pembayaran oleh Admin -->
        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4 border-top border-4 <?= $status_bayar === 'Lunas' ? 'border-success' : ($status_bayar === 'Menunggu Konfirmasi' ? 'border-info' : 'border-warning'); ?>">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-credit-card-2-front text-warning me-2"></i> Konfirmasi Pembayaran Gateway</h6>
            <div class="mb-2">
                <span class="small text-muted d-block mb-1">Status Pembayaran:</span>
                <div><?= status_bayar_badge($status_bayar); ?></div>
            </div>
            <div class="small mb-3">
                <div class="d-flex justify-content-between py-1 border-bottom">
                    <span class="text-muted">Tagihan Penuh (100%):</span>
                    <strong><?= format_rupiah($total_harga); ?></strong>
                </div>
                <div class="d-flex justify-content-between py-1">
                    <span class="text-muted">Kode Bayar Gateway:</span>
                    <strong class="font-monospace text-primary"><?= htmlspecialchars($pesanan['kode_bayar_gateway'] ?: '-'); ?></strong>
                </div>
            </div>

            <?php if ($status_bayar !== 'Lunas'): ?>
                <form method="POST" action="pesanan_detail.php?id=<?= $pesanan['id']; ?>" class="p-3 bg-light rounded-3 border">
                    <label class="form-label small fw-bold text-dark mb-2">
                        Apakah pembayaran penuh <strong><?= format_rupiah($total_harga); ?></strong> sudah benar masuk?
                    </label>
                    <div class="d-grid gap-2">
                        <button type="submit" name="aksi_konfirmasi_bayar" value="lunas" class="btn btn-success btn-sm fw-bold py-2">
                            <i class="bi bi-patch-check-fill me-1"></i> ✅ Sudah Benar Bayar (Set LUNAS)
                        </button>
                        <button type="submit" name="aksi_konfirmasi_bayar" value="belum_masuk" class="btn btn-outline-danger btn-sm fw-bold">
                            <i class="bi bi-x-circle me-1"></i> ❌ Belum Masuk / Belum Bayar
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="alert alert-success small py-2 px-3 mb-0">
                    <i class="bi bi-check-circle-fill me-1"></i> Pembayaran pesanan ini telah dikonfirmasi <strong>LUNAS</strong>.
                </div>
            <?php endif; ?>
            <div class="mt-2 text-center">
                <a href="../bayar_gateway.php?kode=<?= urlencode($pesanan['kode_pesanan']); ?>" target="_blank" class="btn btn-link btn-sm text-decoration-none">
                    <i class="bi bi-box-arrow-up-right me-1"></i> Buka Halaman Payment Gateway Pelanggan
                </a>
            </div>
        </div>

        <!-- Card Update Status -->
        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-sliders text-warning me-2"></i> Kelola Status Pesanan</h6>
            <div class="mb-3">
                <span class="small text-muted d-block mb-1">Status Saat Ini:</span>
                <div><?= status_badge($pesanan['status']); ?></div>
            </div>

            <form method="POST" action="pesanan_detail.php?id=<?= $pesanan['id']; ?>">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Ubah Status Menjadi:</label>
                    <select name="status" class="form-select">
                        <option value="Baru" <?= $pesanan['status'] === 'Baru' ? 'selected' : ''; ?>>🔵 Baru (Menunggu)</option>
                        <option value="Diproses" <?= $pesanan['status'] === 'Diproses' ? 'selected' : ''; ?>>🟠 Diproses (Dimasak di Dapur)</option>
                        <option value="Siap" <?= $pesanan['status'] === 'Siap' ? 'selected' : ''; ?>>🟣 Siap (Disajikan / Diantar)</option>
                        <option value="Selesai" <?= $pesanan['status'] === 'Selesai' ? 'selected' : ''; ?>>🟢 Selesai (Lunas & Diterima)</option>
                        <option value="Dibatalkan" <?= $pesanan['status'] === 'Dibatalkan' ? 'selected' : ''; ?>>🔴 Dibatalkan</option>
                    </select>
                </div>
                <button type="submit" name="update_status" class="btn btn-warning w-100 fw-bold text-dark">
                    <i class="bi bi-check-lg me-1"></i> Simpan Status Baru
                </button>
            </form>
        </div>

        <!-- Card Data Pemesan -->
        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-person-lines-fill text-warning me-2"></i> Data Pelanggan</h6>
            <div class="mb-2">
                <small class="text-muted d-block">Nama Lengkap:</small>
                <strong><?= htmlspecialchars($pesanan['nama_pelanggan']); ?></strong>
            </div>
            <div class="mb-2">
                <small class="text-muted d-block">Nomor Telepon / WA:</small>
                <strong><?= htmlspecialchars($pesanan['no_hp']); ?></strong>
            </div>
            <div class="mb-2">
                <small class="text-muted d-block">Tipe Layanan & Meja:</small>
                <strong><?= tipe_pesanan_label($pesanan['tipe_pesanan'], $pesanan['nomor_meja'], $pesanan['jumlah_orang'] ?? null); ?></strong>
            </div>
            <?php if (!empty($pesanan['alamat_pengiriman'])): ?>
                <div class="mb-2">
                    <small class="text-muted d-block">Alamat Pengiriman:</small>
                    <p class="small text-dark mb-0"><?= nl2br(htmlspecialchars($pesanan['alamat_pengiriman'])); ?></p>
                </div>
            <?php endif; ?>
            <div class="mb-2">
                <small class="text-muted d-block">Kanal Payment Gateway:</small>
                <strong><?= metode_bayar_label($pesanan['metode_pembayaran'], $pesanan['kanal_gateway'] ?? null); ?></strong>
            </div>
            <div>
                <small class="text-muted d-block">Waktu Pesan:</small>
                <small class="text-dark"><?= format_tanggal($pesanan['created_at']); ?></small>
            </div>
        </div>

        <!-- Card Bukti Pembayaran -->
        <?php if (!empty($pesanan['bukti_bayar'])): ?>
            <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-image text-warning me-2"></i> Bukti Pembayaran</h6>
                <a href="../uploads/bukti/<?= htmlspecialchars($pesanan['bukti_bayar']); ?>" target="_blank">
                    <img src="../uploads/bukti/<?= htmlspecialchars($pesanan['bukti_bayar']); ?>" alt="Bukti Transfer" class="img-fluid rounded border shadow-sm">
                </a>
                <small class="text-muted d-block text-center mt-2">Klik gambar untuk memperbesar</small>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
