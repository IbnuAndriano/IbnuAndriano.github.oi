<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

// Handle aksi manual ubah status meja oleh Admin SEBELUM output HTML header.php!
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' || isset($_GET['aksi'])) {
    $aksi   = $_REQUEST['aksi'] ?? '';
    $mejaId = (int)($_REQUEST['id'] ?? 0);

    if ($aksi === 'set_kosong' && $mejaId > 0) {
        mysqli_query($koneksi, "UPDATE meja SET status_meja = 'kosong', pesanan_id_aktif = NULL, jumlah_orang_aktif = NULL, waktu_mulai_terisi = NULL, waktu_siap = NULL WHERE id = $mejaId");
        header("Location: meja.php?msg=updated");
        exit;
    } elseif ($aksi === 'set_terisi' && $mejaId > 0) {
        $jmlOrg = max(1, (int)($_REQUEST['orang'] ?? 2));
        mysqli_query($koneksi, "UPDATE meja SET status_meja = 'terisi', jumlah_orang_aktif = $jmlOrg, waktu_mulai_terisi = NOW(), waktu_siap = NULL WHERE id = $mejaId");
        header("Location: meja.php?msg=updated");
        exit;
    } elseif ($aksi === 'kosongkan_semua') {
        mysqli_query($koneksi, "UPDATE meja SET status_meja = 'kosong', pesanan_id_aktif = NULL, jumlah_orang_aktif = NULL, waktu_mulai_terisi = NULL, waktu_siap = NULL");
        header("Location: meja.php?msg=all_cleared");
        exit;
    } elseif ($aksi === 'tambah_meja' && !empty($_POST['nomor_meja'])) {
        $noBaru  = clean($koneksi, $_POST['nomor_meja']);
        $kapBaru = max(1, (int)($_POST['kapasitas'] ?? 4));
        mysqli_query($koneksi, "INSERT IGNORE INTO meja (nomor_meja, kapasitas, status_meja) VALUES ('$noBaru', $kapBaru, 'kosong')");
        header("Location: meja.php?msg=added");
        exit;
    } elseif ($aksi === 'hapus_meja' && $mejaId > 0) {
        mysqli_query($koneksi, "DELETE FROM meja WHERE id = $mejaId");
        header("Location: meja.php?msg=deleted");
        exit;
    }
}

require_once __DIR__ . '/header.php';

$daftarMeja = get_daftar_meja($koneksi);
$jmlKosong = 0;
$jmlTerisi = 0;
foreach ($daftarMeja as $mj) {
    if ($mj['status_meja'] === 'kosong') $jmlKosong++;
    else $jmlTerisi++;
}
?>

<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <div>
        <h4 class="fw-bold text-dark mb-1">Manajemen Status Meja Pelanggan</h4>
        <p class="text-muted small mb-0">
            Kelola meja kosong/terisi secara manual maupun otomatis (otomatis kosong kembali paling lambat <strong>1 jam setelah pesanan berstatus Siap</strong>).
        </p>
    </div>
    <div class="d-flex gap-2">
        <a href="meja.php?aksi=kosongkan_semua" class="btn btn-outline-success btn-sm fw-bold" onclick="return confirm('Kosongkan semua meja sekarang?')">
            <i class="bi bi-check2-all me-1"></i> Kosongkan Semua Meja
        </a>
    </div>
</div>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-3 py-2 mb-4" role="alert">
        <i class="bi bi-check-circle-fill me-1"></i> Status meja berhasil diperbarui!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<!-- RINGKASAN MEJA & TAMBAH MEJA -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3 rounded-4 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted fw-semibold">Meja Kosong (Bisa Dipesan)</small>
                    <h3 class="fw-bold text-success mb-0"><?= $jmlKosong; ?> Meja</h3>
                </div>
                <span class="fs-2 text-success"><i class="bi bi-check-circle-fill"></i></span>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3 rounded-4 border-start border-4 border-danger">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <small class="text-muted fw-semibold">Meja Terisi (Terkunci Otomatis)</small>
                    <h3 class="fw-bold text-danger mb-0"><?= $jmlTerisi; ?> Meja</h3>
                </div>
                <span class="fs-2 text-danger"><i class="bi bi-lock-fill"></i></span>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3 rounded-4">
            <form method="POST" action="meja.php" class="row g-2 align-items-end">
                <input type="hidden" name="aksi" value="tambah_meja">
                <div class="col-5">
                    <label class="form-label small fw-bold mb-1">Nama Meja</label>
                    <input type="text" name="nomor_meja" class="form-control form-control-sm" placeholder="Meja 13" required>
                </div>
                <div class="col-3">
                    <label class="form-label small fw-bold mb-1">Kursi</label>
                    <input type="number" name="kapasitas" class="form-control form-control-sm" value="4" min="1">
                </div>
                <div class="col-4">
                    <button type="submit" class="btn btn-warning btn-sm w-100 fw-bold text-dark">
                        <i class="bi bi-plus-lg"></i> Tambah
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- GRID DAFTAR MEJA -->
<div class="row g-3">
    <?php foreach ($daftarMeja as $mj): 
        $isKosong = ($mj['status_meja'] === 'kosong');
        $sisaDetik = $mj['sisa_detik_siap'] !== null ? (int)$mj['sisa_detik_siap'] : null;
        $sisaMenit = $sisaDetik !== null ? ceil($sisaDetik / 60) : null;
        $jmlOrgMeja = !empty($mj['jumlah_orang']) ? (int)$mj['jumlah_orang'] : (!empty($mj['jumlah_orang_aktif']) ? (int)$mj['jumlah_orang_aktif'] : null);
    ?>
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="card border-2 shadow-sm rounded-4 h-100 <?= $isKosong ? 'border-success' : 'border-danger bg-danger bg-opacity-10'; ?>">
                <div class="card-body p-3 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="fw-bold text-dark mb-0"><?= htmlspecialchars($mj['nomor_meja']); ?></h5>
                            <?php if ($isKosong): ?>
                                <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>KOSONG</span>
                            <?php else: ?>
                                <span class="badge bg-danger"><i class="bi bi-lock-fill me-1"></i>TERISI</span>
                            <?php endif; ?>
                        </div>
                        <small class="text-muted d-block mb-2"><i class="bi bi-people me-1"></i>Kapasitas Maks: <?= (int)$mj['kapasitas']; ?> Orang</small>

                        <?php if (!$isKosong): ?>
                            <div class="p-2 bg-white rounded-3 border small mb-2">
                                <?php if (!empty($mj['kode_pesanan'])): ?>
                                    <div class="fw-bold text-dark">Pesanan: <a href="pesanan_detail.php?id=<?= (int)$mj['pesanan_id_aktif']; ?>"><?= htmlspecialchars($mj['kode_pesanan']); ?></a></div>
                                    <div>Pelanggan: <strong><?= htmlspecialchars($mj['nama_pelanggan']); ?></strong></div>
                                    <?php if ($jmlOrgMeja): ?>
                                        <div>Jumlah Tamu: <strong class="text-primary"><?= $jmlOrgMeja; ?> Orang</strong></div>
                                    <?php endif; ?>
                                    <div class="mt-1">Status Dapur: <?= status_badge($mj['status_pesanan']); ?></div>
                                    <?php if ($sisaMenit !== null): ?>
                                        <div class="mt-1 text-danger fw-bold" style="font-size: 0.76rem;">
                                            <i class="bi bi-stopwatch me-1"></i>Otomatis Kosong dlm: <?= $sisaMenit; ?> menit
                                        </div>
                                    <?php else: ?>
                                        <div class="mt-1 text-muted" style="font-size: 0.75rem;">
                                            Timer 1 jam aktif saat status 'Siap'
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="text-dark fw-semibold">Diisi Manual oleh Admin</div>
                                    <?php if ($jmlOrgMeja): ?>
                                        <div>Jumlah Tamu: <strong><?= $jmlOrgMeja; ?> Orang</strong></div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="p-2 bg-light rounded-3 border small text-muted mb-2">
                                Meja siap dipesan oleh pelanggan baru di halaman Checkout.
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex gap-2 mt-2 pt-2 border-top">
                        <?php if ($isKosong): ?>
                            <a href="meja.php?aksi=set_terisi&id=<?= $mj['id']; ?>&orang=<?= (int)$mj['kapasitas']; ?>" class="btn btn-outline-danger btn-sm w-100 fw-bold">
                                <i class="bi bi-lock-fill me-1"></i> Set Terisi
                            </a>
                        <?php else: ?>
                            <a href="meja.php?aksi=set_kosong&id=<?= $mj['id']; ?>" class="btn btn-success btn-sm w-100 fw-bold">
                                <i class="bi bi-unlock-fill me-1"></i> Set Kosong Sekarang
                            </a>
                        <?php endif; ?>
                        <a href="meja.php?aksi=hapus_meja&id=<?= $mj['id']; ?>" class="btn btn-outline-secondary btn-sm" title="Hapus Meja" onclick="return confirm('Hapus <?= htmlspecialchars($mj['nomor_meja']); ?>?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
