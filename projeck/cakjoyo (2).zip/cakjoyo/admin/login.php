<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

// Jika sudah login, langsung alihkan ke dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $username = clean($koneksi, $_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Silakan isi username dan password.';
    } else {
        $sql = "SELECT * FROM admin WHERE username = '$username' LIMIT 1";
        $result = mysqli_query($koneksi, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            $admin = mysqli_fetch_assoc($result);
            $hash = $admin['password'];

            $is_valid = false;
            // 1. Verifikasi dengan password_verify (Bcrypt)
            if (password_verify($password, $hash)) {
                $is_valid = true;
            }
            // 2. Auto-sync kredensial resmi admin (admin / Ibnu@2026!)
            elseif ($username === 'admin' && $password === 'Ibnu@2026!') {
                $is_valid = true;
                $newHash = password_hash('Ibnu@2026!', PASSWORD_BCRYPT);
                $stmt = mysqli_prepare($koneksi, "UPDATE admin SET password = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, "si", $newHash, $admin['id']);
                mysqli_stmt_execute($stmt);
            }

            if ($is_valid) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id']        = $admin['id'];
                $_SESSION['admin_username']  = $admin['username'];
                $_SESSION['admin_nama']      = $admin['nama_lengkap'];
                
                header("Location: dashboard.php");
                exit;
            } else {
                $error = 'Password yang Anda masukkan salah.';
            }
        } else {
            $error = 'Username tidak terdaftar.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Soto Lamongan Cak Joyo</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    
    <style>
        :root {
            --primary: #d97706;
            --primary-hover: #b45309;
            --slate-900: #0f172a;
            --slate-800: #1e293b;
            --slate-700: #334155;
            --slate-600: #475569;
            --slate-200: #e2e8f0;
            --slate-100: #f1f5f9;
        }

        body {
            background: linear-gradient(145deg, #0b1329 0%, #0f172a 50%, #1e293b 100%);
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            color: #0f172a;
        }

        .login-card {
            background: #ffffff;
            border-radius: 18px;
            box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.1);
            max-width: 420px;
            width: 100%;
            overflow: hidden;
            border: 1px solid var(--slate-200);
        }

        .login-header-section {
            padding: 36px 32px 24px;
            text-align: center;
            background: #ffffff;
            border-bottom: 1px solid var(--slate-100);
        }

        .brand-icon-wrap {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: #ffffff;
            border-radius: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            margin-bottom: 14px;
            box-shadow: 0 8px 16px -4px rgba(217, 119, 6, 0.35);
        }

        .login-title {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--slate-900);
            margin-bottom: 4px;
            letter-spacing: -0.3px;
        }

        .login-subtitle {
            font-size: 0.85rem;
            color: var(--slate-600);
            font-weight: 500;
        }

        .login-body {
            padding: 28px 32px 36px;
        }

        .form-label {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--slate-700);
            margin-bottom: 6px;
        }

        .input-group-custom {
            border: 1px solid var(--slate-200);
            border-radius: 10px;
            overflow: hidden;
            transition: all 0.2s ease;
            background: #ffffff;
        }

        .input-group-custom:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
        }

        .input-group-custom .input-group-text {
            background: transparent;
            border: none;
            color: var(--slate-600);
            padding-left: 14px;
        }

        .input-group-custom .form-control {
            border: none;
            padding: 11px 14px;
            font-size: 0.92rem;
            color: var(--slate-900);
        }

        .input-group-custom .form-control:focus {
            box-shadow: none;
        }

        .btn-toggle-password {
            background: transparent;
            border: none;
            color: var(--slate-600);
            padding-right: 14px;
            cursor: pointer;
        }

        .btn-toggle-password:hover {
            color: var(--slate-900);
        }

        .btn-login-submit {
            background: var(--primary);
            color: #ffffff;
            font-weight: 700;
            font-size: 0.95rem;
            border: none;
            padding: 12px;
            border-radius: 10px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(217, 119, 6, 0.3);
        }

        .btn-login-submit:hover {
            background: var(--primary-hover);
            color: #ffffff;
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(217, 119, 6, 0.4);
        }

        .btn-back-link {
            color: var(--slate-600);
            font-size: 0.86rem;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.15s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-back-link:hover {
            color: var(--primary);
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header-section">
        <div class="brand-icon-wrap">
            <i class="bi bi-egg-fried"></i>
        </div>
        <h4 class="login-title">Panel Admin Cak Joyo</h4>
        <div class="login-subtitle">Sistem Manajemen Warung Soto Lamongan</div>
    </div>

    <div class="login-body">
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger d-flex align-items-center small py-2 px-3 rounded-3 mb-4" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                <div><?= htmlspecialchars($error); ?></div>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <div class="input-group input-group-custom">
                    <span class="input-group-text"><i class="bi bi-person"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label">Password</label>
                <div class="input-group input-group-custom">
                    <span class="input-group-text"><i class="bi bi-key"></i></span>
                    <input type="password" name="password" id="passwordInput" class="form-control" placeholder="Masukkan password" required>
                    <button type="button" class="btn-toggle-password" id="togglePasswordBtn" title="Lihat password">
                        <i class="bi bi-eye" id="toggleIcon"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-login-submit w-100 mb-3">
                <i class="bi bi-box-arrow-in-right me-2"></i> Masuk Sekarang
            </button>

            <div class="text-center mt-4">
                <a href="../index.php" class="btn-back-link">
                    <i class="bi bi-arrow-left"></i> Kembali ke Website Pembeli
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    const toggleBtn = document.getElementById('togglePasswordBtn');
    const passwordInput = document.getElementById('passwordInput');
    const toggleIcon = document.getElementById('toggleIcon');

    if (toggleBtn && passwordInput && toggleIcon) {
        toggleBtn.addEventListener('click', function () {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            toggleIcon.className = isPassword ? 'bi bi-eye-slash' : 'bi bi-eye';
        });
    }
</script>

</body>
</html>