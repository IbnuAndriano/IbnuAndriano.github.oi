<?php
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/../koneksi.php';

$id         = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$status     = clean($koneksi, $_GET['status'] ?? $_POST['status'] ?? '');
$aksi_bayar = clean($koneksi, $_GET['aksi_bayar'] ?? $_POST['aksi_bayar'] ?? '');
$aksi       = clean($koneksi, $_GET['aksi'] ?? $_POST['aksi'] ?? '');

// 0. Hapus Data Pesanan oleh Admin
if ($aksi === 'hapus_pesanan' && $id > 0) {
    // Kosongkan meja jika pesanan ini sedang menempati meja
    mysqli_query($koneksi, "UPDATE meja SET status_meja = 'kosong', pesanan_id_aktif = NULL, jumlah_orang_aktif = NULL, waktu_mulai_terisi = NULL, waktu_siap = NULL WHERE pesanan_id_aktif = $id");
    // Hapus detail pesanan & riwayat gateway
    mysqli_query($koneksi, "DELETE FROM detail_pesanan WHERE pesanan_id = $id");
    mysqli_query($koneksi, "DELETE FROM pembayaran_gateway WHERE pesanan_id = $id");
    // Hapus pesanan utama
    mysqli_query($koneksi, "DELETE FROM pesanan WHERE id = $id");

    header("Location: pesanan.php?deleted=1");
    exit;
}

// 1. Toggle Mode Auto-Confirm Payment Gateway
if (isset($_GET['toggle_auto_confirm'])) {
    $val = (int)$_GET['toggle_auto_confirm'] === 1 ? 1 : 0;
    mysqli_query($koneksi, "UPDATE pengaturan SET pg_auto_confirm = $val WHERE id = 1");
    $ref = $_SERVER['HTTP_REFERER'] ?? 'pesanan.php';
    header("Location: $ref");
    exit;
}

// 2. Konfirmasi Pembayaran oleh Admin (Sudah Benar Bayar vs Belum Bayar)
if ($id > 0 && !empty($aksi_bayar)) {
    $qP = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id = $id LIMIT 1");
    $pesanan = mysqli_fetch_assoc($qP);
    if ($pesanan) {
        $total_harga = (int)$pesanan['total_harga'];
        $kanal       = $pesanan['kanal_gateway'] ?: 'qris_gateway';
        $refKode     = $pesanan['referensi_gateway'] ?: generate_referensi_gateway();

        if ($aksi_bayar === 'lunas') {
            $statusDapur = ($pesanan['status'] === 'Baru') ? 'Diproses' : $pesanan['status'];
            mysqli_query($koneksi, "UPDATE pesanan SET 
                status_pembayaran = 'Lunas',
                jumlah_dibayar = $total_harga,
                sisa_tagihan = 0,
                status = '$statusDapur',
                waktu_bayar = COALESCE(waktu_bayar, NOW())
                WHERE id = $id");

            mysqli_query($koneksi, "UPDATE pembayaran_gateway SET status_transaksi = 'Lunas (Dikonfirmasi Admin)' WHERE pesanan_id = $id");
            mysqli_query($koneksi, "INSERT INTO pembayaran_gateway (
                pesanan_id, kode_pesanan, kode_referensi, kanal_pembayaran, nominal_bayar, status_transaksi, keterangan, created_at
            ) VALUES (
                $id, '{$pesanan['kode_pesanan']}', '$refKode', '$kanal', $total_harga, 'Lunas (Dikonfirmasi Admin)', 'Admin mengonfirmasi pembayaran sudah benar masuk (Lunas 100%)', NOW()
            )");
        } elseif ($aksi_bayar === 'belum_bayar') {
            mysqli_query($koneksi, "UPDATE pesanan SET 
                status_pembayaran = 'Belum Masuk',
                jumlah_dibayar = 0,
                sisa_tagihan = $total_harga
                WHERE id = $id");

            mysqli_query($koneksi, "INSERT INTO pembayaran_gateway (
                pesanan_id, kode_pesanan, kode_referensi, kanal_pembayaran, nominal_bayar, status_transaksi, keterangan, created_at
            ) VALUES (
                $id, '{$pesanan['kode_pesanan']}', '$refKode', '$kanal', 0, 'Belum Masuk', 'Admin mengecek dana belum masuk, status dikembalikan ke Belum Masuk', NOW()
            )");
        }
    }
    $ref = $_SERVER['HTTP_REFERER'] ?? 'pesanan.php';
    header("Location: $ref");
    exit;
}

// 3. Update Status Pengerjaan Dapur & Sinkronisasi Otomatis Meja (1 Jam setelah status 'Siap')
$allowed = ['Baru', 'Diproses', 'Siap', 'Selesai', 'Dibatalkan'];
if ($id > 0 && in_array($status, $allowed)) {
    tandai_status_pesanan_dan_meja($koneksi, $id, $status);
}

$ref = $_SERVER['HTTP_REFERER'] ?? 'pesanan.php';
header("Location: $ref");
exit;
