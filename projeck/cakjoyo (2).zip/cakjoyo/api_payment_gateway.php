<?php
/**
 * API & Webhook Handler Payment Gateway - Soto Ayam Lamongan Cak Joyo
 *
 * Aturan:
 * - Pembayaran hanya menggunakan QRIS, E-Wallet (081367219097), dan Bank (BCA, Mandiri, BRI, BNI)
 * - Pembayaran harus langsung penuh / 100% (tidak dicicil)
 * - Ketika pelanggan membayar, status menjadi 'Menunggu Konfirmasi' agar Admin mengonfirmasi terlebih dahulu sudah benar bayar/belum (kecuali jika Mode Auto-Confirm diaktifkan oleh Admin)
 */
session_start();
require_once __DIR__ . '/koneksi.php';

header('Content-Type: application/json; charset=utf-8');

$action = $_REQUEST['action'] ?? 'check_status';
$kode   = clean($koneksi, $_REQUEST['kode'] ?? '');

if (empty($kode)) {
    echo json_encode(['success' => false, 'message' => 'Kode pesanan tidak ditemukan.']);
    exit;
}

$qPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE kode_pesanan = '$kode' LIMIT 1");
$pesanan  = mysqli_fetch_assoc($qPesanan);

if (!$pesanan) {
    echo json_encode(['success' => false, 'message' => 'Data pesanan tidak ditemukan.']);
    exit;
}

$pesanan_id  = (int)$pesanan['id'];
$daftarKanal = daftar_kanal_gateway();
$resto       = get_pengaturan($koneksi);
$autoConfirm = (int)($resto['pg_auto_confirm'] ?? 0);

function get_riwayat_gateway($koneksi, $pesanan_id) {
    $rows = [];
    $q = mysqli_query($koneksi, "SELECT * FROM pembayaran_gateway WHERE pesanan_id = $pesanan_id ORDER BY id DESC");
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['nominal_formatted'] = format_rupiah($r['nominal_bayar']);
            $r['waktu_formatted']   = format_tanggal($r['created_at']);
            $r['kanal_label']       = kanal_gateway_label($r['kanal_pembayaran']);
            $rows[] = $r;
        }
    }
    return $rows;
}

$total_harga    = (int)$pesanan['total_harga'];
$jumlah_dibayar = (int)$pesanan['jumlah_dibayar'];
$sisa_tagihan   = ($pesanan['status_pembayaran'] === 'Lunas') ? 0 : $total_harga;

// 1. GANTI KANAL PEMBAYARAN GATEWAY (Hanya QRIS, E-Wallet, dan Bank)
if ($action === 'change_channel') {
    $kanalBaru = clean($koneksi, $_POST['kanal'] ?? 'qris_gateway');
    if (!isset($daftarKanal[$kanalBaru])) {
        echo json_encode(['success' => false, 'message' => 'Kanal pembayaran tidak tersedia.']);
        exit;
    }

    $metodeInduk = $daftarKanal[$kanalBaru]['metode'];
    $kodeBayar   = generate_kode_bayar_gateway($kanalBaru, $pesanan['no_hp'], $pesanan['kode_pesanan']);
    $refBaru     = $pesanan['referensi_gateway'] ?: generate_referensi_gateway();

    mysqli_query($koneksi, "UPDATE pesanan SET 
                metode_pembayaran = '$metodeInduk',
                kanal_gateway = '$kanalBaru',
                kode_bayar_gateway = '$kodeBayar',
                referensi_gateway = '$refBaru'
               WHERE id = $pesanan_id");

    echo json_encode([
        'success'            => true,
        'kanal_gateway'      => $kanalBaru,
        'kanal_nama'         => $daftarKanal[$kanalBaru]['nama'],
        'kanal_grup'         => $daftarKanal[$kanalBaru]['grup'],
        'kanal_instruksi'    => $daftarKanal[$kanalBaru]['instruksi'],
        'kode_bayar_gateway' => $kodeBayar,
        'referensi_gateway'  => $refBaru
    ]);
    exit;
}

// 2. PROSES KIRIM PEMBAYARAN PENUH OLEH PELANGGAN (TIDAK DICICIL)
if ($action === 'process_payment') {
    $kanalBayar = clean($koneksi, $_POST['kanal'] ?? ($pesanan['kanal_gateway'] ?: 'qris_gateway'));
    if (!isset($daftarKanal[$kanalBayar])) {
        $kanalBayar = 'qris_gateway';
    }

    if ($pesanan['status_pembayaran'] === 'Lunas') {
        echo json_encode([
            'success'           => true,
            'status_pembayaran' => 'Lunas',
            'message'           => 'Pesanan ini sudah LUNAS.'
        ]);
        exit;
    }

    // Proses upload bukti bayar jika pelanggan melampirkan foto/screenshot
    $bukti_nama = $pesanan['bukti_bayar'];
    if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] === UPLOAD_ERR_OK) {
        $fileTmp  = $_FILES['bukti']['tmp_name'];
        $fileName = $_FILES['bukti']['name'];
        $ext      = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed  = ['jpg', 'jpeg', 'png', 'webp'];
        if (in_array($ext, $allowed)) {
            $bukti_nama = "bukti_" . time() . "_" . rand(100, 999) . "." . $ext;
            $destDir    = __DIR__ . '/uploads/bukti';
            if (!is_dir($destDir)) {
                mkdir($destDir, 0777, true);
            }
            move_uploaded_file($fileTmp, "$destDir/$bukti_nama");
        }
    }

    $kodeRef   = generate_referensi_gateway();
    $metodeInd = $daftarKanal[$kanalBayar]['metode'];
    $kodeBayar = generate_kode_bayar_gateway($kanalBayar, $pesanan['no_hp'], $pesanan['kode_pesanan']);

    // Cek apakah mode Auto-Confirm aktif atau harus menunggu konfirmasi Admin terlebih dahulu
    if ($autoConfirm === 1) {
        $statusBayarBaru   = 'Lunas';
        $statusTransLog    = 'Lunas (Otomatis)';
        $jmlDibayarBaru    = $total_harga;
        $sisaBaru          = 0;
        $ketTransaksi      = 'Pembayaran Penuh Lunas (Verifikasi Otomatis Gateway)';
        $statusPesananBaru = ($pesanan['status'] === 'Baru') ? 'Diproses' : $pesanan['status'];
    } else {
        // Default: Admin harus konfirmasi terlebih dahulu sudah benar bayar/belum
        $statusBayarBaru   = 'Menunggu Konfirmasi';
        $statusTransLog    = 'Menunggu Konfirmasi';
        $jmlDibayarBaru    = 0;
        $sisaBaru          = $total_harga;
        $ketTransaksi      = 'Pelanggan mengirimkan pembayaran penuh ' . format_rupiah($total_harga) . ' (Menunggu Konfirmasi Admin)';
        $statusPesananBaru = $pesanan['status'];
    }

    $ketClean = clean($koneksi, $ketTransaksi);
    mysqli_query($koneksi, "INSERT INTO pembayaran_gateway (
        pesanan_id, kode_pesanan, kode_referensi, kanal_pembayaran, nominal_bayar, status_transaksi, keterangan, created_at
    ) VALUES (
        $pesanan_id, '{$pesanan['kode_pesanan']}', '$kodeRef', '$kanalBayar', $total_harga, '$statusTransLog', '$ketClean', NOW()
    )");

    $buktiSql = !empty($bukti_nama) ? "'$bukti_nama'" : "bukti_bayar";
    mysqli_query($koneksi, "UPDATE pesanan SET 
                            metode_pembayaran = '$metodeInd',
                            kanal_gateway = '$kanalBayar',
                            kode_bayar_gateway = '$kodeBayar',
                            referensi_gateway = '$kodeRef',
                            jumlah_dibayar = $jmlDibayarBaru,
                            sisa_tagihan = $sisaBaru,
                            status_pembayaran = '$statusBayarBaru',
                            status = '$statusPesananBaru',
                            bukti_bayar = $buktiSql,
                            waktu_bayar = NOW()
                         WHERE id = $pesanan_id");

    echo json_encode([
        'success'           => true,
        'kode_pesanan'      => $pesanan['kode_pesanan'],
        'kode_referensi'    => $kodeRef,
        'status_pembayaran' => $statusBayarBaru,
        'message'           => ($statusBayarBaru === 'Lunas')
            ? 'Pembayaran penuh berhasil diverifikasi otomatis! Status pesanan Anda sekarang LUNAS.'
            : 'Pembayaran telah dikirim! Menunggu Admin mengonfirmasi apakah dana sudah benar masuk. Halaman ini akan otomatis menjadi LUNAS setelah dikonfirmasi Admin.'
    ]);
    exit;
}

// 3. DEFAULT: CHECK STATUS REAL-TIME
$kanalAktif = $pesanan['kanal_gateway'] ?: 'qris_gateway';
if (!isset($daftarKanal[$kanalAktif])) {
    $kanalAktif = 'qris_gateway';
}
$infoKanal = $daftarKanal[$kanalAktif];

echo json_encode([
    'success'                   => true,
    'kode_pesanan'              => $pesanan['kode_pesanan'],
    'nama_pelanggan'            => $pesanan['nama_pelanggan'],
    'total_harga'               => $total_harga,
    'total_harga_fmt'           => format_rupiah($total_harga),
    'jumlah_dibayar'            => $jumlah_dibayar,
    'jumlah_dibayar_fmt'        => format_rupiah($jumlah_dibayar),
    'sisa_tagihan'              => $sisa_tagihan,
    'sisa_tagihan_fmt'          => format_rupiah($sisa_tagihan),
    'status_pembayaran'         => $pesanan['status_pembayaran'] ?: 'Menunggu Pembayaran',
    'status_bayar_badge_html'   => status_bayar_badge($pesanan['status_pembayaran']),
    'status_pesanan'            => $pesanan['status'],
    'status_pesanan_badge_html' => status_badge($pesanan['status']),
    'kanal_gateway'             => $kanalAktif,
    'kanal_nama'                => $infoKanal['nama'],
    'kanal_instruksi'           => $infoKanal['instruksi'],
    'kode_bayar_gateway'        => $pesanan['kode_bayar_gateway'] ?: generate_kode_bayar_gateway($kanalAktif, $pesanan['no_hp'], $pesanan['kode_pesanan']),
    'referensi_gateway'         => $pesanan['referensi_gateway'] ?: '-',
    'waktu_bayar'               => $pesanan['waktu_bayar'] ? format_tanggal($pesanan['waktu_bayar']) : '-',
    'riwayat_pembayaran'        => get_riwayat_gateway($koneksi, $pesanan_id)
]);
