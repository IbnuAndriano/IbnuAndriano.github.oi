<?php
/**
 * Portal Smart Payment Gateway - Soto Ayam Lamongan Cak Joyo
 * - Pembayaran hanya menggunakan QRIS, E-Wallet (081367219097), dan Bank (BCA, Mandiri, BRI, BNI)
 * - Pembayaran langsung lunas 100% sesuai tagihan (tidak dicicil)
 * - Kode Pembayaran / Nomor VA pendek dan rapih
 * - Menunggu konfirmasi Admin terlebih dahulu sudah benar bayar/belum (atau otomatis jika Auto-Confirm aktif)
 */
require_once __DIR__ . '/includes/header.php';

$kode = clean($koneksi, $_GET['kode'] ?? $_SESSION['last_order_code'] ?? '');
if (empty($kode)) {
    echo "<div class='container py-5 text-center'><h4>Kode pesanan tidak ditemukan.</h4><a href='index.php' class='btn btn-warning mt-3'>Kembali ke Beranda</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$qPesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE kode_pesanan = '$kode' LIMIT 1");
$pesanan  = mysqli_fetch_assoc($qPesanan);

if (!$pesanan) {
    echo "<div class='container py-5 text-center'><h4>Pesanan dengan kode <strong>" . htmlspecialchars($kode) . "</strong> tidak ditemukan.</h4><a href='index.php' class='btn btn-warning mt-3'>Kembali ke Beranda</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$pesanan_id     = (int)$pesanan['id'];
$total_harga    = (int)$pesanan['total_harga'];
$status_bayar   = $pesanan['status_pembayaran'] ?: 'Menunggu Pembayaran';
$isLunas        = ($status_bayar === 'Lunas');

$daftarKanal = daftar_kanal_gateway();
$kanalAktif  = $pesanan['kanal_gateway'] ?: 'qris_gateway';
if (!isset($daftarKanal[$kanalAktif])) {
    $kanalAktif = 'qris_gateway';
}
$infoKanal = $daftarKanal[$kanalAktif];
$kodeBayar = generate_kode_bayar_gateway($kanalAktif, $pesanan['no_hp'], $pesanan['kode_pesanan']);
if ($pesanan['kode_bayar_gateway'] !== $kodeBayar) {
    mysqli_query($koneksi, "UPDATE pesanan SET kode_bayar_gateway = '$kodeBayar' WHERE id = $pesanan_id");
}

// Ambil rincian item pesanan
$qDetail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = $pesanan_id");
$items = [];
while ($d = mysqli_fetch_assoc($qDetail)) {
    $items[] = $d;
}

// Ambil riwayat transaksi payment gateway
$qRiwayat = mysqli_query($koneksi, "SELECT * FROM pembayaran_gateway WHERE pesanan_id = $pesanan_id ORDER BY id DESC");
$riwayat = [];
if ($qRiwayat) {
    while ($r = mysqli_fetch_assoc($qRiwayat)) {
        $riwayat[] = $r;
    }
}
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Header Gateway -->
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                <div>
                    <span class="badge bg-dark text-warning px-3 py-2 rounded-pill mb-2">
                        <i class="bi bi-shield-check me-1"></i> <?= htmlspecialchars($resto['pg_nama'] ?? 'CakJoyo Payment Gateway'); ?> • Pembayaran Penuh (Tidak Dicicil)
                    </span>
                    <h3 class="fw-bold text-dark mb-0">Pembayaran Pesanan #<?= htmlspecialchars($pesanan['kode_pesanan']); ?></h3>
                </div>
                <div class="d-flex gap-2">
                    <a href="nota.php?kode=<?= urlencode($pesanan['kode_pesanan']); ?>" class="btn btn-outline-dark btn-sm rounded-pill px-3">
                        <i class="bi bi-printer me-1"></i> Lihat & Cetak Struk (1 Halaman)
                    </a>
                    <a href="lacak.php?search=<?= urlencode($pesanan['kode_pesanan']); ?>" class="btn btn-outline-secondary btn-sm rounded-pill px-3">
                        <i class="bi bi-search me-1"></i> Lacak Pesanan
                    </a>
                </div>
            </div>

            <!-- BANNER STATUS PEMBAYARAN REAL-TIME -->
            <div class="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden">
                <?php if ($status_bayar === 'Lunas'): ?>
                    <div class="p-4 bg-success text-white d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 56px; height: 56px; font-size: 1.8rem;">
                                <i class="bi bi-patch-check-fill"></i>
                            </div>
                            <div>
                                <span class="badge bg-white text-success fw-bold mb-1">STATUS: SUDAH LUNAS (TERKONFIRMASI)</span>
                                <h4 class="fw-bold mb-1">Pembayaran Anda Telah Dikonfirmasi Lunas!</h4>
                                <p class="mb-0 small opacity-90">
                                    Terima kasih! Pembayaran penuh sebesar <strong><?= format_rupiah($total_harga); ?></strong> telah terverifikasi. Pesanan Anda sedang diproses dapur.
                                </p>
                            </div>
                        </div>
                        <div class="text-md-end">
                            <div class="small opacity-75">Total Lunas:</div>
                            <div class="fs-3 fw-bold"><?= format_rupiah($total_harga); ?></div>
                            <a href="nota.php?kode=<?= urlencode($pesanan['kode_pesanan']); ?>" class="btn btn-light btn-sm fw-bold text-success mt-1 rounded-pill px-3">
                                <i class="bi bi-printer me-1"></i> Cetak Struk Lunas
                            </a>
                        </div>
                    </div>
                <?php elseif ($status_bayar === 'Menunggu Konfirmasi'): ?>
                    <div class="p-4 bg-info bg-opacity-25 border-start border-5 border-info d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-info text-dark rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 56px; height: 56px; font-size: 1.8rem;">
                                <i class="bi bi-shield-exclamation"></i>
                            </div>
                            <div>
                                <span class="badge bg-info text-dark fw-bold mb-1">STATUS: MENUNGGU KONFIRMASI ADMIN</span>
                                <h4 class="fw-bold text-dark mb-1">Pembayaran Sedang Dicek oleh Admin</h4>
                                <p class="mb-0 small text-dark">
                                    Pembayaran Anda sebesar <strong><?= format_rupiah($total_harga); ?></strong> telah dikirim ke sistem. Admin sedang memeriksa apakah pembayaran sudah benar masuk. <strong>Halaman ini akan otomatis berubah menjadi LUNAS begitu dikonfirmasi Admin!</strong>
                                </p>
                            </div>
                        </div>
                        <div class="text-md-end">
                            <div class="spinner-border text-info spinner-border-sm me-1" role="status"></div>
                            <span class="small fw-bold text-dark">Mengecek otomatis...</span>
                            <div class="mt-2">
                                <a href="<?= whatsapp_link($resto['no_wa'], 'Halo Admin Cak Joyo, saya sudah melakukan pembayaran penuh untuk Kode Pesanan: ' . $pesanan['kode_pesanan'] . ' sebesar ' . format_rupiah($total_harga) . '. Mohon dikonfirmasi ya.'); ?>" target="_blank" class="btn btn-success btn-sm rounded-pill px-3">
                                    <i class="bi bi-whatsapp me-1"></i> Chat Admin (081367219097)
                                </a>
                            </div>
                        </div>
                    </div>
                <?php elseif ($status_bayar === 'Belum Masuk'): ?>
                    <div class="p-4 bg-danger text-white d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-white text-danger rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 56px; height: 56px; font-size: 1.8rem;">
                                <i class="bi bi-x-octagon-fill"></i>
                            </div>
                            <div>
                                <span class="badge bg-warning text-dark fw-bold mb-1">STATUS: PEMBAYARAN BELUM MASUK</span>
                                <h4 class="fw-bold mb-1">Pembayaran Belum Ditemukan oleh Admin</h4>
                                <p class="mb-0 small opacity-90">
                                    Berdasarkan pengecekan Admin, dana sebesar <strong><?= format_rupiah($total_harga); ?></strong> belum masuk. Silakan selesaikan pembayaran penuh dan lampirkan bukti bayar di bawah ini.
                                </p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="p-4 bg-warning bg-opacity-25 border-start border-5 border-warning d-flex flex-wrap align-items-center justify-content-between gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 56px; height: 56px; font-size: 1.7rem;">
                                <i class="bi bi-hourglass-split"></i>
                            </div>
                            <div>
                                <span class="badge bg-warning text-dark fw-bold mb-1">STATUS: MENUNGGU PEMBAYARAN</span>
                                <h4 class="fw-bold text-dark mb-1">Total Tagihan Penuh: <span class="text-danger"><?= format_rupiah($total_harga); ?></span></h4>
                                <p class="mb-0 small text-muted">
                                    Silakan selesaikan pembayaran langsung lunas (tidak dicicil) melalui <strong>QRIS</strong>, <strong>E-Wallet (081367219097)</strong>, atau <strong>Bank</strong> di bawah ini.
                                </p>
                            </div>
                        </div>
                        <div class="text-md-end">
                            <span class="badge bg-dark text-warning px-3 py-2">Harus Bayar Penuh 100%</span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="row g-4">
                <!-- KOLOM KIRI: KANAL PEMBAYARAN GATEWAY (QRIS, E-WALLET, BANK) -->
                <div class="col-lg-7">
                    <?php if (!$isLunas): ?>
                        <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <h5 class="fw-bold text-dark mb-0">
                                    <i class="bi bi-credit-card-2-front-fill text-warning me-2"></i>
                                    1. Pilih Metode Pembayaran (QRIS, E-Wallet, atau Bank)
                                </h5>
                                <span class="badge bg-light text-dark border">Kode Pendek & Rapih</span>
                            </div>

                            <!-- Pilihan Kanal Gateway -->
                            <div class="row g-2 mb-4">
                                <?php foreach ($daftarKanal as $kodeK => $kInfo): ?>
                                    <div class="col-6 col-md-4">
                                        <button type="button"
                                                onclick="gantiKanalGateway('<?= $kodeK; ?>')"
                                                id="btnKanal_<?= $kodeK; ?>"
                                                class="btn w-100 text-start p-2 rounded-3 border position-relative kanal-btn <?= $kanalAktif === $kodeK ? 'border-warning bg-warning bg-opacity-10 fw-bold shadow-sm' : 'bg-light text-dark'; ?>"
                                                style="font-size: 0.85rem;">
                                            <div class="d-flex align-items-center gap-2">
                                                <i class="bi <?= $kInfo['ikon']; ?> text-<?= $kInfo['warna']; ?> fs-5"></i>
                                                <div class="text-truncate">
                                                    <div class="fw-bold text-dark text-truncate"><?= htmlspecialchars($kInfo['singkat']); ?></div>
                                                    <small class="text-muted d-block text-truncate" style="font-size: 0.7rem;"><?= htmlspecialchars(strtoupper($kInfo['metode'])); ?></small>
                                                </div>
                                            </div>
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Box Kode Pembayaran Pendek & Rapih -->
                            <div class="p-4 rounded-4 bg-light border border-2 mb-4">
                                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                    <span class="badge bg-dark text-white px-3 py-1" id="labelGrupKanal"><?= htmlspecialchars($infoKanal['grup']); ?></span>
                                    <span class="small text-muted">Ref: <strong class="font-monospace" id="labelRefGateway"><?= htmlspecialchars($pesanan['referensi_gateway'] ?: 'PG-' . $pesanan['id']); ?></strong></span>
                                </div>

                                <h5 class="fw-bold text-dark mb-3" id="labelNamaKanal"><?= htmlspecialchars($infoKanal['nama']); ?></h5>

                                <!-- Area Barcode QRIS -->
                                <div id="areaQrisGateway" class="text-center py-3 bg-white rounded-4 border mb-3 <?= $kanalAktif === 'qris_gateway' ? '' : 'd-none'; ?>">
                                    <div class="d-inline-block px-3 py-1 bg-danger text-white fw-bold rounded-pill small mb-2">
                                        QRIS RESMI CAK JOYO • NMID: <?= htmlspecialchars($resto['qris_nmid']); ?>
                                    </div>
                                    <div class="my-2">
                                        <img src="uploads/qris/<?= htmlspecialchars($resto['qris_image']); ?>"
                                             alt="QRIS Cak Joyo"
                                             class="img-fluid rounded border p-2 shadow-sm"
                                             style="max-width: 200px;"
                                             onerror="this.src='uploads/qris/qris_sample.png'">
                                    </div>
                                    <div class="small text-muted">Tagihan Penuh: <strong class="text-dark"><?= format_rupiah($total_harga); ?></strong></div>
                                </div>

                                <!-- Box Kode Bayar Gateway Sangat Pendek & Rapih -->
                                <div class="p-3 bg-white rounded-3 border d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                                    <div>
                                        <small class="text-muted d-block">Kode Bayar Gateway (Sangat Pendek):</small>
                                        <span class="fs-3 fw-bold text-primary font-monospace" id="kodeBayarText" style="letter-spacing: 2px;"><?= htmlspecialchars($kodeBayar); ?></span>
                                    </div>
                                    <button type="button" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold" onclick="salinKodeBayar()">
                                        <i class="bi bi-clipboard-check me-1"></i> Salin Kode
                                    </button>
                                </div>

                                <!-- Info E-Wallet (085129763119 a.n Ibnu Andriano), VA Akun Bank, & Rekening Bank -->
                                <div class="p-3 bg-white rounded-3 border small mb-3">
                                    <div class="fw-bold text-dark mb-1"><i class="bi bi-person-check-fill text-success me-1"></i> Informasi Akun Pembayaran Resmi:</div>
                                    <div class="mb-2">
                                        <strong class="text-info">📱 E-Wallet (GoPay/OVO/DANA/ShopeePay/LinkAja):</strong><br>
                                        <?= nl2br(htmlspecialchars($resto['ewallet_info'] ?? '085129763119 a.n Ibnu Andriano')); ?>
                                    </div>
                                    <?php if (!empty($resto['va_bank_info'])): ?>
                                        <div class="mb-2 pt-2 border-top">
                                            <strong class="text-primary">🏦 Virtual Account (VA) Bank:</strong><br>
                                            <?= nl2br(htmlspecialchars($resto['va_bank_info'])); ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="pt-2 border-top text-muted">
                                        <strong class="text-dark">🏦 Rekening Bank Warung:</strong><br>
                                        <?= nl2br(htmlspecialchars($resto['rekening_bank'])); ?>
                                    </div>
                                </div>

                                <div class="alert alert-secondary small mb-0 py-2 px-3">
                                    <i class="bi bi-info-circle-fill me-1"></i>
                                    <span id="labelInstruksiKanal"><?= htmlspecialchars($infoKanal['instruksi']); ?></span>
                                </div>
                            </div>

                            <!-- 2. Form Kirim Pembayaran Penuh untuk Dikonfirmasi Admin -->
                            <div class="card border-warning border-2 bg-warning bg-opacity-10 p-3 rounded-4">
                                <h6 class="fw-bold text-dark mb-2">
                                    <i class="bi bi-check2-square text-warning me-1"></i>
                                    2. Konfirmasi Pembayaran Penuh (<?= format_rupiah($total_harga); ?>)
                                </h6>
                                <p class="small text-muted mb-3">
                                    Pembayaran wajib langsung lunas <strong><?= format_rupiah($total_harga); ?></strong> (tidak dicicil). Setelah Anda klik tombol di bawah, Admin akan memverifikasi apakah pembayaran sudah benar masuk sebelum status diubah menjadi <strong>LUNAS</strong>.
                                </p>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark">Nominal Pembayaran Penuh (Terkunci 100%):</label>
                                    <input type="text" class="form-control fw-bold fs-5 text-success bg-white" value="<?= format_rupiah($total_harga); ?> (Langsung Lunas / Tidak Dicicil)" readonly>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark">Unggah Screenshot / Bukti Bayar (Opsional untuk Mempercepat Verifikasi Admin):</label>
                                    <input type="file" id="inputBuktiBayar" class="form-control form-control-sm bg-white" accept="image/*">
                                </div>

                                <button type="button" id="btnBayarSekarang" onclick="prosesBayarGateway()" class="btn btn-primary-cakjoyo w-100 py-3 fw-bold fs-6 rounded-3 shadow">
                                    <i class="bi bi-send-check-fill me-2"></i>
                                    <?= $status_bayar === 'Menunggu Konfirmasi' ? 'Kirim Ulang Konfirmasi Pembayaran (' . format_rupiah($total_harga) . ')' : 'Saya Sudah Bayar Penuh (' . format_rupiah($total_harga) . ')'; ?>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- KOLOM KANAN: RINGKASAN TAGIHAN & RIWAYAT GATEWAY -->
                <div class="col-lg-5">
                    <div class="card border-0 shadow-sm p-4 rounded-4 mb-4">
                        <h5 class="fw-bold text-dark mb-3">
                            <i class="bi bi-receipt-cutoff text-warning me-2"></i> Rincian Tagihan & Meja
                        </h5>

                        <div class="p-3 rounded-3 bg-light border mb-3">
                            <div class="d-flex justify-content-between small mb-2">
                                <span class="text-muted">Nama Pelanggan:</span>
                                <strong class="text-dark"><?= htmlspecialchars($pesanan['nama_pelanggan']); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between small mb-2">
                                <span class="text-muted">Nomor HP / WA:</span>
                                <strong class="text-dark"><?= htmlspecialchars($pesanan['no_hp']); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between small mb-2">
                                <span class="text-muted">Layanan & Meja:</span>
                                <strong class="text-dark"><?= tipe_pesanan_label($pesanan['tipe_pesanan'], $pesanan['nomor_meja'], $pesanan['jumlah_orang'] ?? null); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between small mb-2">
                                <span class="text-muted">Status Dapur:</span>
                                <span id="badgeStatusPesanan"><?= status_badge($pesanan['status']); ?></span>
                            </div>
                            <div class="d-flex justify-content-between small">
                                <span class="text-muted">Status Pembayaran:</span>
                                <span id="badgeStatusBayar"><?= status_bayar_badge($status_bayar); ?></span>
                            </div>
                        </div>

                        <!-- Daftar Item Pesanan -->
                        <h6 class="fw-bold small text-uppercase text-muted mb-2">Item yang Dipesan:</h6>
                        <div class="table-responsive mb-3">
                            <table class="table table-sm table-borderless small mb-0">
                                <tbody>
                                    <?php foreach ($items as $it): ?>
                                        <tr class="border-bottom">
                                            <td class="ps-0 py-2">
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($it['nama_menu']); ?></div>
                                                <small class="text-muted"><?= $it['jumlah']; ?> x <?= format_rupiah($it['harga']); ?></small>
                                            </td>
                                            <td class="text-end pe-0 py-2 fw-bold align-middle"><?= format_rupiah($it['subtotal']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="border-top pt-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold text-dark">TOTAL BAYAR PENUH:</span>
                                <span class="fs-4 fw-bold text-warning"><?= format_rupiah($total_harga); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- RIWAYAT PEMBAYARAN GATEWAY -->
                    <div class="card border-0 shadow-sm p-4 rounded-4">
                        <h6 class="fw-bold text-dark mb-3">
                            <i class="bi bi-clock-history text-warning me-2"></i> Log Status Payment Gateway
                        </h6>
                        <?php if (count($riwayat) > 0): ?>
                            <div class="list-group list-group-flush small">
                                <?php foreach ($riwayat as $rw): ?>
                                    <div class="list-group-item px-0 py-2">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="fw-bold text-dark"><?= format_rupiah($rw['nominal_bayar']); ?></span>
                                            <span class="badge <?= strpos($rw['status_transaksi'], 'Lunas') !== false || $rw['status_transaksi'] === 'Berhasil' ? 'bg-success' : 'bg-info text-dark'; ?>">
                                                <?= htmlspecialchars($rw['status_transaksi']); ?>
                                            </span>
                                        </div>
                                        <div class="text-dark fw-semibold mt-1"><?= kanal_gateway_label($rw['kanal_pembayaran']); ?></div>
                                        <div class="text-muted" style="font-size: 0.75rem;">
                                            Ref: <span class="font-monospace"><?= htmlspecialchars($rw['kode_referensi']); ?></span> • <?= format_tanggal($rw['created_at']); ?>
                                        </div>
                                        <?php if (!empty($rw['keterangan'])): ?>
                                            <div class="text-muted fst-italic mt-1" style="font-size: 0.75rem;"><?= htmlspecialchars($rw['keterangan']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-3 text-muted small">
                                <i class="bi bi-hourglass d-block fs-4 mb-1"></i>
                                Menunggu pengiriman pembayaran penuh dari pelanggan.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let currentKanal = <?= json_encode($kanalAktif); ?>;
const kodePesanan = <?= json_encode($pesanan['kode_pesanan']); ?>;

function salinKodeBayar() {
    const txt = document.getElementById('kodeBayarText').innerText;
    navigator.clipboard.writeText(txt).then(() => {
        alert('Kode Pembayaran / Nomor berhasil disalin: ' + txt);
    });
}

function gantiKanalGateway(kanal) {
    currentKanal = kanal;
    const formData = new FormData();
    formData.append('action', 'change_channel');
    formData.append('kode', kodePesanan);
    formData.append('kanal', kanal);

    fetch('api_payment_gateway.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.querySelectorAll('.kanal-btn').forEach(btn => {
                btn.classList.remove('border-warning', 'bg-warning', 'bg-opacity-10', 'fw-bold', 'shadow-sm');
                btn.classList.add('bg-light');
            });
            const activeBtn = document.getElementById('btnKanal_' + kanal);
            if (activeBtn) {
                activeBtn.classList.remove('bg-light');
                activeBtn.classList.add('border-warning', 'bg-warning', 'bg-opacity-10', 'fw-bold', 'shadow-sm');
            }
            document.getElementById('labelGrupKanal').innerText = data.kanal_grup;
            document.getElementById('labelNamaKanal').innerText = data.kanal_nama;
            document.getElementById('labelInstruksiKanal').innerText = data.kanal_instruksi;
            document.getElementById('kodeBayarText').innerText = data.kode_bayar_gateway;
            document.getElementById('labelRefGateway').innerText = data.referensi_gateway;

            const areaQris = document.getElementById('areaQrisGateway');
            if (kanal === 'qris_gateway') {
                areaQris.classList.remove('d-none');
            } else {
                areaQris.classList.add('d-none');
            }
        }
    });
}

function prosesBayarGateway() {
    const btn = document.getElementById('btnBayarSekarang');
    const fileInput = document.getElementById('inputBuktiBayar');

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Mengirim Pembayaran ke Sistem...';
    }

    const formData = new FormData();
    formData.append('action', 'process_payment');
    formData.append('kode', kodePesanan);
    formData.append('kanal', currentKanal);
    if (fileInput && fileInput.files.length > 0) {
        formData.append('bukti', fileInput.files[0]);
    }

    fetch('api_payment_gateway.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            window.location.reload();
        } else {
            alert(data.message || 'Gagal mengirim konfirmasi pembayaran.');
            if (btn) btn.disabled = false;
        }
    })
    .catch(() => {
        if (btn) btn.disabled = false;
    });
}

// Polling otomatis setiap 3 detik: begitu Admin klik Konfirmasi Lunas, halaman pelanggan otomatis update menjadi LUNAS!
let lastKnownStatusBayar = <?= json_encode($status_bayar); ?>;
let lastKnownStatusDapur = <?= json_encode($pesanan['status']); ?>;
setInterval(() => {
    fetch('api_payment_gateway.php?action=check_status&kode=' + encodeURIComponent(kodePesanan))
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (data.status_pembayaran !== lastKnownStatusBayar || data.status_pesanan !== lastKnownStatusDapur) {
                window.location.reload();
            }
        }
    })
    .catch(() => {});
}, 3000);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
