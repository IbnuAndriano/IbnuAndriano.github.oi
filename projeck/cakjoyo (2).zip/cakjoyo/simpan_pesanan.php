<?php
/**
 * Simpan Pesanan Pelanggan Soto Lamongan Cak Joyo
 */
session_start();
require_once __DIR__ . '/koneksi.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header("Location: index.php");
    exit;
}

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    header("Location: index.php");
    exit;
}

// Sinkronisasi meja otomatis (kosongkan meja yang sudah lewat 1 jam sejak status 'Siap')
sync_status_meja($koneksi);

// 1. Ambil data formulir
$nama            = clean($koneksi, $_POST['nama'] ?? '');
$hp              = clean($koneksi, $_POST['hp'] ?? '');
$tipe_pesanan    = clean($koneksi, $_POST['tipe_pesanan'] ?? 'dine_in');
$nomor_meja      = clean($koneksi, $_POST['nomor_meja'] ?? '');
$jumlah_orang    = max(1, (int)($_POST['jumlah_orang'] ?? 1));
$alamat          = clean($koneksi, $_POST['alamat_pengiriman'] ?? '');
$metode          = clean($koneksi, $_POST['metode'] ?? 'qris');
$kanal_gateway   = clean($koneksi, $_POST['kanal_gateway'] ?? 'qris_gateway');
$catatan         = clean($koneksi, $_POST['catatan'] ?? '');

// Pastikan metode hanya QRIS, E-Wallet, atau Bank
if (!in_array($metode, ['qris', 'ewallet', 'transfer'])) {
    $metode = 'qris';
    $kanal_gateway = 'qris_gateway';
}

// Validasi Meja untuk Makan di Tempat (Dine-In)
if ($tipe_pesanan === 'dine_in') {
    if (empty($nomor_meja)) {
        header("Location: checkout.php?err=meja_terisi");
        exit;
    }
    $qCekMeja = mysqli_query($koneksi, "SELECT * FROM meja WHERE nomor_meja = '$nomor_meja' LIMIT 1");
    if ($qCekMeja && mysqli_num_rows($qCekMeja) > 0) {
        $rowMeja = mysqli_fetch_assoc($qCekMeja);
        if ($rowMeja['status_meja'] === 'terisi') {
            header("Location: checkout.php?err=meja_terisi");
            exit;
        }
    }
} else {
    $nomor_meja = '';
}

// Hitung total harga dari session cart (Pembayaran harus penuh 100% tidak dicicil)
$total_harga = 0;
foreach ($cart as $item) {
    $total_harga += ($item['harga'] * $item['jumlah']);
}

// 2. Generate Kode Pesanan Unik & Kode Payment Gateway Pendek & Rapih
$kode_pesanan       = generate_kode_pesanan();
$kode_bayar_gateway = generate_kode_bayar_gateway($kanal_gateway, $hp, $kode_pesanan);
$referensi_gateway  = generate_referensi_gateway();

// 3. Masukkan ke tabel `pesanan`
$sqlPesanan = "INSERT INTO pesanan (
    kode_pesanan,
    nama_pelanggan,
    no_hp,
    tipe_pesanan,
    nomor_meja,
    jumlah_orang,
    alamat_pengiriman,
    metode_pembayaran,
    kanal_gateway,
    kode_bayar_gateway,
    referensi_gateway,
    total_harga,
    jumlah_dibayar,
    sisa_tagihan,
    status_pembayaran,
    batas_waktu_bayar,
    catatan,
    status,
    created_at
) VALUES (
    '$kode_pesanan',
    '$nama',
    '$hp',
    '$tipe_pesanan',
    " . (!empty($nomor_meja) ? "'$nomor_meja'" : "NULL") . ",
    $jumlah_orang,
    " . (!empty($alamat) ? "'$alamat'" : "NULL") . ",
    '$metode',
    '$kanal_gateway',
    '$kode_bayar_gateway',
    '$referensi_gateway',
    $total_harga,
    0,
    $total_harga,
    'Menunggu Pembayaran',
    DATE_ADD(NOW(), INTERVAL 24 HOUR),
    " . (!empty($catatan) ? "'$catatan'" : "NULL") . ",
    'Baru',
    NOW()
)";

if (mysqli_query($koneksi, $sqlPesanan)) {
    $pesanan_id = mysqli_insert_id($koneksi);

    // 4. Jika Dine-In, otomatis tandai meja sebagai TERISI beserta jumlah orangnya
    if ($tipe_pesanan === 'dine_in' && !empty($nomor_meja)) {
        mysqli_query($koneksi, "UPDATE meja SET 
            status_meja = 'terisi',
            pesanan_id_aktif = $pesanan_id,
            jumlah_orang_aktif = $jumlah_orang,
            waktu_mulai_terisi = NOW(),
            waktu_siap = NULL
            WHERE nomor_meja = '$nomor_meja'");
    }

    // 5. Masukkan rincian pesanan ke tabel `detail_pesanan`
    foreach ($cart as $item) {
        $menu_id   = (int)$item['menu_id'];
        $nama_menu = clean($koneksi, $item['nama']);
        $harga     = (int)$item['harga'];
        $jumlah    = (int)$item['jumlah'];
        $subtotal  = $harga * $jumlah;
        $catatan_i = clean($koneksi, $item['catatan'] ?? '');

        $sqlDetail = "INSERT INTO detail_pesanan (
            pesanan_id, menu_id, nama_menu, harga, jumlah, subtotal, catatan_item
        ) VALUES (
            $pesanan_id, $menu_id, '$nama_menu', $harga, $jumlah, $subtotal, " . (!empty($catatan_i) ? "'$catatan_i'" : "NULL") . "
        )";
        mysqli_query($koneksi, $sqlDetail);
    }

    // 6. Kosongkan keranjang belanja
    $_SESSION['cart'] = [];

    // 7. Simpan kode pesanan terakhir di session
    $_SESSION['last_order_code'] = $kode_pesanan;

    // 8. Alihkan langsung ke Portal Payment Gateway
    header("Location: bayar_gateway.php?kode=" . urlencode($kode_pesanan));
    exit;
} else {
    die("Terjadi kesalahan saat menyimpan pesanan: " . mysqli_error($koneksi));
}
